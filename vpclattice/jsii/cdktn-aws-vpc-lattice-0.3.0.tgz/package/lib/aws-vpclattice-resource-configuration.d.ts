import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsResourceConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#allow_association_to_shareable_service_network AwsResourceConfiguration#allow_association_to_shareable_service_network}
    */
    readonly allowAssociationToShareableServiceNetwork?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#custom_domain_name AwsResourceConfiguration#custom_domain_name}
    */
    readonly customDomainName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#domain_verification_id AwsResourceConfiguration#domain_verification_id}
    */
    readonly domainVerificationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#name AwsResourceConfiguration#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#port_ranges AwsResourceConfiguration#port_ranges}
    */
    readonly portRanges?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#protocol AwsResourceConfiguration#protocol}
    */
    readonly protocol?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#region AwsResourceConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#resource_configuration_group_id AwsResourceConfiguration#resource_configuration_group_id}
    */
    readonly resourceConfigurationGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#resource_gateway_identifier AwsResourceConfiguration#resource_gateway_identifier}
    */
    readonly resourceGatewayIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#tags AwsResourceConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#type AwsResourceConfiguration#type}
    */
    readonly type?: string;
    /**
    * resource_configuration_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#resource_configuration_definition AwsResourceConfiguration#resource_configuration_definition}
    */
    readonly resourceConfigurationDefinition?: AwsResourceConfiguration.ResourceConfigurationDefinitionProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#timeouts AwsResourceConfiguration#timeouts}
    */
    readonly timeouts?: AwsResourceConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration aws_vpclattice_resource_configuration}
*/
export declare class AwsResourceConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpclattice_resource_configuration";
    /**
    * Generates CDKTN code for importing a AwsResourceConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsResourceConfiguration to import
    * @param importFromId The id of the existing AwsResourceConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsResourceConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration aws_vpclattice_resource_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsResourceConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsResourceConfigurationConfig);
    private _allowAssociationToShareableServiceNetwork?;
    get allowAssociationToShareableServiceNetwork(): boolean | cdktn.IResolvable;
    set allowAssociationToShareableServiceNetwork(value: boolean | cdktn.IResolvable);
    resetAllowAssociationToShareableServiceNetwork(): void;
    get allowAssociationToShareableServiceNetworkInput(): boolean | cdktn.IResolvable | undefined;
    get arn(): string;
    private _customDomainName?;
    get customDomainName(): string;
    set customDomainName(value: string);
    resetCustomDomainName(): void;
    get customDomainNameInput(): string | undefined;
    get domainVerificationArn(): string;
    private _domainVerificationId?;
    get domainVerificationId(): string;
    set domainVerificationId(value: string);
    resetDomainVerificationId(): void;
    get domainVerificationIdInput(): string | undefined;
    get domainVerificationStatus(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _portRanges?;
    get portRanges(): string[];
    set portRanges(value: string[]);
    resetPortRanges(): void;
    get portRangesInput(): string[] | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceConfigurationGroupId?;
    get resourceConfigurationGroupId(): string;
    set resourceConfigurationGroupId(value: string);
    resetResourceConfigurationGroupId(): void;
    get resourceConfigurationGroupIdInput(): string | undefined;
    private _resourceGatewayIdentifier?;
    get resourceGatewayIdentifier(): string;
    set resourceGatewayIdentifier(value: string);
    resetResourceGatewayIdentifier(): void;
    get resourceGatewayIdentifierInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _resourceConfigurationDefinition;
    get resourceConfigurationDefinition(): AwsResourceConfiguration.ResourceConfigurationDefinitionPropertyList;
    putResourceConfigurationDefinition(value: AwsResourceConfiguration.ResourceConfigurationDefinitionProperty[] | cdktn.IResolvable): void;
    resetResourceConfigurationDefinition(): void;
    get resourceConfigurationDefinitionInput(): cdktn.IResolvable | AwsResourceConfiguration.ResourceConfigurationDefinitionProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsResourceConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsResourceConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsResourceConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsResourceConfigurationArnResourcePropertyToTerraform(struct?: AwsResourceConfiguration.ArnResourceProperty | cdktn.IResolvable): any;
export declare function awsResourceConfigurationArnResourcePropertyToHclTerraform(struct?: AwsResourceConfiguration.ArnResourceProperty | cdktn.IResolvable): any;
export declare function awsResourceConfigurationDnsResourcePropertyToTerraform(struct?: AwsResourceConfiguration.DnsResourceProperty | cdktn.IResolvable): any;
export declare function awsResourceConfigurationDnsResourcePropertyToHclTerraform(struct?: AwsResourceConfiguration.DnsResourceProperty | cdktn.IResolvable): any;
export declare function awsResourceConfigurationIpResourcePropertyToTerraform(struct?: AwsResourceConfiguration.IpResourceProperty | cdktn.IResolvable): any;
export declare function awsResourceConfigurationIpResourcePropertyToHclTerraform(struct?: AwsResourceConfiguration.IpResourceProperty | cdktn.IResolvable): any;
export declare function awsResourceConfigurationResourceConfigurationDefinitionPropertyToTerraform(struct?: AwsResourceConfiguration.ResourceConfigurationDefinitionProperty | cdktn.IResolvable): any;
export declare function awsResourceConfigurationResourceConfigurationDefinitionPropertyToHclTerraform(struct?: AwsResourceConfiguration.ResourceConfigurationDefinitionProperty | cdktn.IResolvable): any;
export declare function awsResourceConfigurationTimeoutsPropertyToTerraform(struct?: AwsResourceConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsResourceConfigurationTimeoutsPropertyToHclTerraform(struct?: AwsResourceConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsResourceConfiguration {
    interface ArnResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#arn AwsResourceConfiguration#arn}
        */
        readonly arn: string;
    }
    class ArnResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ArnResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ArnResourceProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
    }
    class ArnResourcePropertyList extends cdktn.ComplexList {
        internalValue?: ArnResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ArnResourcePropertyOutputReference;
    }
    interface DnsResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#domain_name AwsResourceConfiguration#domain_name}
        */
        readonly domainName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#ip_address_type AwsResourceConfiguration#ip_address_type}
        */
        readonly ipAddressType: string;
    }
    class DnsResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DnsResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DnsResourceProperty | cdktn.IResolvable | undefined);
        private _domainName?;
        get domainName(): string;
        set domainName(value: string);
        get domainNameInput(): string | undefined;
        private _ipAddressType?;
        get ipAddressType(): string;
        set ipAddressType(value: string);
        get ipAddressTypeInput(): string | undefined;
    }
    class DnsResourcePropertyList extends cdktn.ComplexList {
        internalValue?: DnsResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DnsResourcePropertyOutputReference;
    }
    interface IpResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#ip_address AwsResourceConfiguration#ip_address}
        */
        readonly ipAddress: string;
    }
    class IpResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IpResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IpResourceProperty | cdktn.IResolvable | undefined);
        private _ipAddress?;
        get ipAddress(): string;
        set ipAddress(value: string);
        get ipAddressInput(): string | undefined;
    }
    class IpResourcePropertyList extends cdktn.ComplexList {
        internalValue?: IpResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IpResourcePropertyOutputReference;
    }
    interface ResourceConfigurationDefinitionProperty {
        /**
        * arn_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#arn_resource AwsResourceConfiguration#arn_resource}
        */
        readonly arnResource?: ArnResourceProperty[] | cdktn.IResolvable;
        /**
        * dns_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#dns_resource AwsResourceConfiguration#dns_resource}
        */
        readonly dnsResource?: DnsResourceProperty[] | cdktn.IResolvable;
        /**
        * ip_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#ip_resource AwsResourceConfiguration#ip_resource}
        */
        readonly ipResource?: IpResourceProperty[] | cdktn.IResolvable;
    }
    class ResourceConfigurationDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceConfigurationDefinitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceConfigurationDefinitionProperty | cdktn.IResolvable | undefined);
        private _arnResource;
        get arnResource(): ArnResourcePropertyList;
        putArnResource(value: ArnResourceProperty[] | cdktn.IResolvable): void;
        resetArnResource(): void;
        get arnResourceInput(): cdktn.IResolvable | ArnResourceProperty[] | undefined;
        private _dnsResource;
        get dnsResource(): DnsResourcePropertyList;
        putDnsResource(value: DnsResourceProperty[] | cdktn.IResolvable): void;
        resetDnsResource(): void;
        get dnsResourceInput(): cdktn.IResolvable | DnsResourceProperty[] | undefined;
        private _ipResource;
        get ipResource(): IpResourcePropertyList;
        putIpResource(value: IpResourceProperty[] | cdktn.IResolvable): void;
        resetIpResource(): void;
        get ipResourceInput(): cdktn.IResolvable | IpResourceProperty[] | undefined;
    }
    class ResourceConfigurationDefinitionPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceConfigurationDefinitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceConfigurationDefinitionPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#create AwsResourceConfiguration#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#delete AwsResourceConfiguration#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpclattice_resource_configuration#update AwsResourceConfiguration#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
