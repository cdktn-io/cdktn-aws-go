import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfWebAclConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#description TfWebAcl#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#id TfWebAcl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name TfWebAcl#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name_prefix TfWebAcl#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#region TfWebAcl#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#rule_json TfWebAcl#rule_json}
    */
    readonly ruleJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#scope TfWebAcl#scope}
    */
    readonly scope: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#tags TfWebAcl#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#tags_all TfWebAcl#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#token_domains TfWebAcl#token_domains}
    */
    readonly tokenDomains?: string[];
    /**
    * association_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#association_config TfWebAcl#association_config}
    */
    readonly associationConfig?: TfWebAcl.AssociationConfigProperty;
    /**
    * captcha_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#captcha_config TfWebAcl#captcha_config}
    */
    readonly captchaConfig?: TfWebAcl.CaptchaConfigProperty;
    /**
    * challenge_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#challenge_config TfWebAcl#challenge_config}
    */
    readonly challengeConfig?: TfWebAcl.ChallengeConfigProperty;
    /**
    * custom_response_body block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_response_body TfWebAcl#custom_response_body}
    */
    readonly customResponseBody?: TfWebAcl.CustomResponseBodyProperty[] | cdktn.IResolvable;
    /**
    * data_protection_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#data_protection_config TfWebAcl#data_protection_config}
    */
    readonly dataProtectionConfig?: TfWebAcl.DataProtectionConfigProperty;
    /**
    * default_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#default_action TfWebAcl#default_action}
    */
    readonly defaultAction: TfWebAcl.DefaultActionProperty;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#rule TfWebAcl#rule}
    */
    readonly rule?: TfWebAcl.RuleProperty[] | cdktn.IResolvable;
    /**
    * visibility_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#visibility_config TfWebAcl#visibility_config}
    */
    readonly visibilityConfig: TfWebAcl.VisibilityConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl aws_wafv2_web_acl}
*/
export declare class TfWebAcl extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_wafv2_web_acl";
    /**
    * Generates CDKTN code for importing a TfWebAcl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfWebAcl to import
    * @param importFromId The id of the existing TfWebAcl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfWebAcl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl aws_wafv2_web_acl} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfWebAclConfig
    */
    constructor(scope: Construct, id: string, config: TfWebAclConfig);
    get applicationIntegrationUrl(): string;
    get arn(): string;
    get capacity(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lockToken(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _ruleJson?;
    get ruleJson(): string;
    set ruleJson(value: string);
    resetRuleJson(): void;
    get ruleJsonInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _tokenDomains?;
    get tokenDomains(): string[];
    set tokenDomains(value: string[]);
    resetTokenDomains(): void;
    get tokenDomainsInput(): string[] | undefined;
    private _associationConfig;
    get associationConfig(): TfWebAcl.AssociationConfigPropertyOutputReference;
    putAssociationConfig(value: TfWebAcl.AssociationConfigProperty): void;
    resetAssociationConfig(): void;
    get associationConfigInput(): TfWebAcl.AssociationConfigProperty | undefined;
    private _captchaConfig;
    get captchaConfig(): TfWebAcl.CaptchaConfigPropertyOutputReference;
    putCaptchaConfig(value: TfWebAcl.CaptchaConfigProperty): void;
    resetCaptchaConfig(): void;
    get captchaConfigInput(): TfWebAcl.CaptchaConfigProperty | undefined;
    private _challengeConfig;
    get challengeConfig(): TfWebAcl.ChallengeConfigPropertyOutputReference;
    putChallengeConfig(value: TfWebAcl.ChallengeConfigProperty): void;
    resetChallengeConfig(): void;
    get challengeConfigInput(): TfWebAcl.ChallengeConfigProperty | undefined;
    private _customResponseBody;
    get customResponseBody(): TfWebAcl.CustomResponseBodyPropertyList;
    putCustomResponseBody(value: TfWebAcl.CustomResponseBodyProperty[] | cdktn.IResolvable): void;
    resetCustomResponseBody(): void;
    get customResponseBodyInput(): cdktn.IResolvable | TfWebAcl.CustomResponseBodyProperty[] | undefined;
    private _dataProtectionConfig;
    get dataProtectionConfig(): TfWebAcl.DataProtectionConfigPropertyOutputReference;
    putDataProtectionConfig(value: TfWebAcl.DataProtectionConfigProperty): void;
    resetDataProtectionConfig(): void;
    get dataProtectionConfigInput(): TfWebAcl.DataProtectionConfigProperty | undefined;
    private _defaultAction;
    get defaultAction(): TfWebAcl.DefaultActionPropertyOutputReference;
    putDefaultAction(value: TfWebAcl.DefaultActionProperty): void;
    get defaultActionInput(): TfWebAcl.DefaultActionProperty | undefined;
    private _rule;
    get rule(): TfWebAcl.RulePropertyList;
    putRule(value: TfWebAcl.RuleProperty[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | TfWebAcl.RuleProperty[] | undefined;
    private _visibilityConfig;
    get visibilityConfig(): TfWebAcl.VisibilityConfigPropertyOutputReference;
    putVisibilityConfig(value: TfWebAcl.VisibilityConfigProperty): void;
    get visibilityConfigInput(): TfWebAcl.VisibilityConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfWebAclMapperApiGatewayPropertyToTerraform(struct?: TfWebAcl.ApiGatewayPropertyOutputReference | TfWebAcl.ApiGatewayProperty): any;
export declare function tfWebAclMapperApiGatewayPropertyToHclTerraform(struct?: TfWebAcl.ApiGatewayPropertyOutputReference | TfWebAcl.ApiGatewayProperty): any;
export declare function tfWebAclMapperAppRunnerServicePropertyToTerraform(struct?: TfWebAcl.AppRunnerServicePropertyOutputReference | TfWebAcl.AppRunnerServiceProperty): any;
export declare function tfWebAclMapperAppRunnerServicePropertyToHclTerraform(struct?: TfWebAcl.AppRunnerServicePropertyOutputReference | TfWebAcl.AppRunnerServiceProperty): any;
export declare function tfWebAclMapperCloudfrontPropertyToTerraform(struct?: TfWebAcl.CloudfrontPropertyOutputReference | TfWebAcl.CloudfrontProperty): any;
export declare function tfWebAclMapperCloudfrontPropertyToHclTerraform(struct?: TfWebAcl.CloudfrontPropertyOutputReference | TfWebAcl.CloudfrontProperty): any;
export declare function tfWebAclMapperCognitoUserPoolPropertyToTerraform(struct?: TfWebAcl.CognitoUserPoolPropertyOutputReference | TfWebAcl.CognitoUserPoolProperty): any;
export declare function tfWebAclMapperCognitoUserPoolPropertyToHclTerraform(struct?: TfWebAcl.CognitoUserPoolPropertyOutputReference | TfWebAcl.CognitoUserPoolProperty): any;
export declare function tfWebAclMapperVerifiedAccessInstancePropertyToTerraform(struct?: TfWebAcl.VerifiedAccessInstancePropertyOutputReference | TfWebAcl.VerifiedAccessInstanceProperty): any;
export declare function tfWebAclMapperVerifiedAccessInstancePropertyToHclTerraform(struct?: TfWebAcl.VerifiedAccessInstancePropertyOutputReference | TfWebAcl.VerifiedAccessInstanceProperty): any;
export declare function tfWebAclMapperRequestBodyPropertyToTerraform(struct?: TfWebAcl.RequestBodyProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperRequestBodyPropertyToHclTerraform(struct?: TfWebAcl.RequestBodyProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperAssociationConfigPropertyToTerraform(struct?: TfWebAcl.AssociationConfigPropertyOutputReference | TfWebAcl.AssociationConfigProperty): any;
export declare function tfWebAclMapperAssociationConfigPropertyToHclTerraform(struct?: TfWebAcl.AssociationConfigPropertyOutputReference | TfWebAcl.AssociationConfigProperty): any;
export declare function tfWebAclMapperCaptchaConfigImmunityTimePropertyPropertyToTerraform(struct?: TfWebAcl.CaptchaConfigImmunityTimePropertyPropertyOutputReference | TfWebAcl.CaptchaConfigImmunityTimePropertyProperty): any;
export declare function tfWebAclMapperCaptchaConfigImmunityTimePropertyPropertyToHclTerraform(struct?: TfWebAcl.CaptchaConfigImmunityTimePropertyPropertyOutputReference | TfWebAcl.CaptchaConfigImmunityTimePropertyProperty): any;
export declare function tfWebAclMapperCaptchaConfigPropertyToTerraform(struct?: TfWebAcl.CaptchaConfigPropertyOutputReference | TfWebAcl.CaptchaConfigProperty): any;
export declare function tfWebAclMapperCaptchaConfigPropertyToHclTerraform(struct?: TfWebAcl.CaptchaConfigPropertyOutputReference | TfWebAcl.CaptchaConfigProperty): any;
export declare function tfWebAclMapperChallengeConfigImmunityTimePropertyPropertyToTerraform(struct?: TfWebAcl.ChallengeConfigImmunityTimePropertyPropertyOutputReference | TfWebAcl.ChallengeConfigImmunityTimePropertyProperty): any;
export declare function tfWebAclMapperChallengeConfigImmunityTimePropertyPropertyToHclTerraform(struct?: TfWebAcl.ChallengeConfigImmunityTimePropertyPropertyOutputReference | TfWebAcl.ChallengeConfigImmunityTimePropertyProperty): any;
export declare function tfWebAclMapperChallengeConfigPropertyToTerraform(struct?: TfWebAcl.ChallengeConfigPropertyOutputReference | TfWebAcl.ChallengeConfigProperty): any;
export declare function tfWebAclMapperChallengeConfigPropertyToHclTerraform(struct?: TfWebAcl.ChallengeConfigPropertyOutputReference | TfWebAcl.ChallengeConfigProperty): any;
export declare function tfWebAclMapperCustomResponseBodyPropertyToTerraform(struct?: TfWebAcl.CustomResponseBodyProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperCustomResponseBodyPropertyToHclTerraform(struct?: TfWebAcl.CustomResponseBodyProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperFieldPropertyToTerraform(struct?: TfWebAcl.FieldPropertyOutputReference | TfWebAcl.FieldProperty): any;
export declare function tfWebAclMapperFieldPropertyToHclTerraform(struct?: TfWebAcl.FieldPropertyOutputReference | TfWebAcl.FieldProperty): any;
export declare function tfWebAclMapperDataProtectionPropertyToTerraform(struct?: TfWebAcl.DataProtectionProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperDataProtectionPropertyToHclTerraform(struct?: TfWebAcl.DataProtectionProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperDataProtectionConfigPropertyToTerraform(struct?: TfWebAcl.DataProtectionConfigPropertyOutputReference | TfWebAcl.DataProtectionConfigProperty): any;
export declare function tfWebAclMapperDataProtectionConfigPropertyToHclTerraform(struct?: TfWebAcl.DataProtectionConfigPropertyOutputReference | TfWebAcl.DataProtectionConfigProperty): any;
export declare function tfWebAclMapperDefaultActionAllowCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: TfWebAcl.DefaultActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperDefaultActionAllowCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: TfWebAcl.DefaultActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperDefaultActionAllowCustomRequestHandlingPropertyToTerraform(struct?: TfWebAcl.DefaultActionAllowCustomRequestHandlingPropertyOutputReference | TfWebAcl.DefaultActionAllowCustomRequestHandlingProperty): any;
export declare function tfWebAclMapperDefaultActionAllowCustomRequestHandlingPropertyToHclTerraform(struct?: TfWebAcl.DefaultActionAllowCustomRequestHandlingPropertyOutputReference | TfWebAcl.DefaultActionAllowCustomRequestHandlingProperty): any;
export declare function tfWebAclMapperDefaultActionAllowPropertyToTerraform(struct?: TfWebAcl.DefaultActionAllowPropertyOutputReference | TfWebAcl.DefaultActionAllowProperty): any;
export declare function tfWebAclMapperDefaultActionAllowPropertyToHclTerraform(struct?: TfWebAcl.DefaultActionAllowPropertyOutputReference | TfWebAcl.DefaultActionAllowProperty): any;
export declare function tfWebAclMapperDefaultActionBlockCustomResponseResponseHeaderPropertyToTerraform(struct?: TfWebAcl.DefaultActionBlockCustomResponseResponseHeaderProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperDefaultActionBlockCustomResponseResponseHeaderPropertyToHclTerraform(struct?: TfWebAcl.DefaultActionBlockCustomResponseResponseHeaderProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperDefaultActionBlockCustomResponsePropertyToTerraform(struct?: TfWebAcl.DefaultActionBlockCustomResponsePropertyOutputReference | TfWebAcl.DefaultActionBlockCustomResponseProperty): any;
export declare function tfWebAclMapperDefaultActionBlockCustomResponsePropertyToHclTerraform(struct?: TfWebAcl.DefaultActionBlockCustomResponsePropertyOutputReference | TfWebAcl.DefaultActionBlockCustomResponseProperty): any;
export declare function tfWebAclMapperDefaultActionBlockPropertyToTerraform(struct?: TfWebAcl.DefaultActionBlockPropertyOutputReference | TfWebAcl.DefaultActionBlockProperty): any;
export declare function tfWebAclMapperDefaultActionBlockPropertyToHclTerraform(struct?: TfWebAcl.DefaultActionBlockPropertyOutputReference | TfWebAcl.DefaultActionBlockProperty): any;
export declare function tfWebAclMapperDefaultActionPropertyToTerraform(struct?: TfWebAcl.DefaultActionPropertyOutputReference | TfWebAcl.DefaultActionProperty): any;
export declare function tfWebAclMapperDefaultActionPropertyToHclTerraform(struct?: TfWebAcl.DefaultActionPropertyOutputReference | TfWebAcl.DefaultActionProperty): any;
export declare function tfWebAclMapperRuleActionAllowCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: TfWebAcl.RuleActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperRuleActionAllowCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: TfWebAcl.RuleActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperRuleActionAllowCustomRequestHandlingPropertyToTerraform(struct?: TfWebAcl.RuleActionAllowCustomRequestHandlingPropertyOutputReference | TfWebAcl.RuleActionAllowCustomRequestHandlingProperty): any;
export declare function tfWebAclMapperRuleActionAllowCustomRequestHandlingPropertyToHclTerraform(struct?: TfWebAcl.RuleActionAllowCustomRequestHandlingPropertyOutputReference | TfWebAcl.RuleActionAllowCustomRequestHandlingProperty): any;
export declare function tfWebAclMapperRuleActionAllowPropertyToTerraform(struct?: TfWebAcl.RuleActionAllowPropertyOutputReference | TfWebAcl.RuleActionAllowProperty): any;
export declare function tfWebAclMapperRuleActionAllowPropertyToHclTerraform(struct?: TfWebAcl.RuleActionAllowPropertyOutputReference | TfWebAcl.RuleActionAllowProperty): any;
export declare function tfWebAclMapperRuleActionBlockCustomResponseResponseHeaderPropertyToTerraform(struct?: TfWebAcl.RuleActionBlockCustomResponseResponseHeaderProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperRuleActionBlockCustomResponseResponseHeaderPropertyToHclTerraform(struct?: TfWebAcl.RuleActionBlockCustomResponseResponseHeaderProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperRuleActionBlockCustomResponsePropertyToTerraform(struct?: TfWebAcl.RuleActionBlockCustomResponsePropertyOutputReference | TfWebAcl.RuleActionBlockCustomResponseProperty): any;
export declare function tfWebAclMapperRuleActionBlockCustomResponsePropertyToHclTerraform(struct?: TfWebAcl.RuleActionBlockCustomResponsePropertyOutputReference | TfWebAcl.RuleActionBlockCustomResponseProperty): any;
export declare function tfWebAclMapperRuleActionBlockPropertyToTerraform(struct?: TfWebAcl.RuleActionBlockPropertyOutputReference | TfWebAcl.RuleActionBlockProperty): any;
export declare function tfWebAclMapperRuleActionBlockPropertyToHclTerraform(struct?: TfWebAcl.RuleActionBlockPropertyOutputReference | TfWebAcl.RuleActionBlockProperty): any;
export declare function tfWebAclMapperRuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: TfWebAcl.RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperRuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: TfWebAcl.RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperRuleActionCaptchaCustomRequestHandlingPropertyToTerraform(struct?: TfWebAcl.RuleActionCaptchaCustomRequestHandlingPropertyOutputReference | TfWebAcl.RuleActionCaptchaCustomRequestHandlingProperty): any;
export declare function tfWebAclMapperRuleActionCaptchaCustomRequestHandlingPropertyToHclTerraform(struct?: TfWebAcl.RuleActionCaptchaCustomRequestHandlingPropertyOutputReference | TfWebAcl.RuleActionCaptchaCustomRequestHandlingProperty): any;
export declare function tfWebAclMapperCaptchaPropertyToTerraform(struct?: TfWebAcl.CaptchaPropertyOutputReference | TfWebAcl.CaptchaProperty): any;
export declare function tfWebAclMapperCaptchaPropertyToHclTerraform(struct?: TfWebAcl.CaptchaPropertyOutputReference | TfWebAcl.CaptchaProperty): any;
export declare function tfWebAclMapperRuleActionChallengeCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: TfWebAcl.RuleActionChallengeCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperRuleActionChallengeCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: TfWebAcl.RuleActionChallengeCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperRuleActionChallengeCustomRequestHandlingPropertyToTerraform(struct?: TfWebAcl.RuleActionChallengeCustomRequestHandlingPropertyOutputReference | TfWebAcl.RuleActionChallengeCustomRequestHandlingProperty): any;
export declare function tfWebAclMapperRuleActionChallengeCustomRequestHandlingPropertyToHclTerraform(struct?: TfWebAcl.RuleActionChallengeCustomRequestHandlingPropertyOutputReference | TfWebAcl.RuleActionChallengeCustomRequestHandlingProperty): any;
export declare function tfWebAclMapperChallengePropertyToTerraform(struct?: TfWebAcl.ChallengePropertyOutputReference | TfWebAcl.ChallengeProperty): any;
export declare function tfWebAclMapperChallengePropertyToHclTerraform(struct?: TfWebAcl.ChallengePropertyOutputReference | TfWebAcl.ChallengeProperty): any;
export declare function tfWebAclMapperRuleActionCountCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: TfWebAcl.RuleActionCountCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperRuleActionCountCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: TfWebAcl.RuleActionCountCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperRuleActionCountCustomRequestHandlingPropertyToTerraform(struct?: TfWebAcl.RuleActionCountCustomRequestHandlingPropertyOutputReference | TfWebAcl.RuleActionCountCustomRequestHandlingProperty): any;
export declare function tfWebAclMapperRuleActionCountCustomRequestHandlingPropertyToHclTerraform(struct?: TfWebAcl.RuleActionCountCustomRequestHandlingPropertyOutputReference | TfWebAcl.RuleActionCountCustomRequestHandlingProperty): any;
export declare function tfWebAclMapperRuleActionCountPropertyToTerraform(struct?: TfWebAcl.RuleActionCountPropertyOutputReference | TfWebAcl.RuleActionCountProperty): any;
export declare function tfWebAclMapperRuleActionCountPropertyToHclTerraform(struct?: TfWebAcl.RuleActionCountPropertyOutputReference | TfWebAcl.RuleActionCountProperty): any;
export declare function tfWebAclMapperActionPropertyToTerraform(struct?: TfWebAcl.ActionPropertyOutputReference | TfWebAcl.ActionProperty): any;
export declare function tfWebAclMapperActionPropertyToHclTerraform(struct?: TfWebAcl.ActionPropertyOutputReference | TfWebAcl.ActionProperty): any;
export declare function tfWebAclMapperRuleCaptchaConfigImmunityTimePropertyPropertyToTerraform(struct?: TfWebAcl.RuleCaptchaConfigImmunityTimePropertyPropertyOutputReference | TfWebAcl.RuleCaptchaConfigImmunityTimePropertyProperty): any;
export declare function tfWebAclMapperRuleCaptchaConfigImmunityTimePropertyPropertyToHclTerraform(struct?: TfWebAcl.RuleCaptchaConfigImmunityTimePropertyPropertyOutputReference | TfWebAcl.RuleCaptchaConfigImmunityTimePropertyProperty): any;
export declare function tfWebAclMapperRuleCaptchaConfigPropertyToTerraform(struct?: TfWebAcl.RuleCaptchaConfigPropertyOutputReference | TfWebAcl.RuleCaptchaConfigProperty): any;
export declare function tfWebAclMapperRuleCaptchaConfigPropertyToHclTerraform(struct?: TfWebAcl.RuleCaptchaConfigPropertyOutputReference | TfWebAcl.RuleCaptchaConfigProperty): any;
export declare function tfWebAclMapperRuleChallengeConfigImmunityTimePropertyPropertyToTerraform(struct?: TfWebAcl.RuleChallengeConfigImmunityTimePropertyPropertyOutputReference | TfWebAcl.RuleChallengeConfigImmunityTimePropertyProperty): any;
export declare function tfWebAclMapperRuleChallengeConfigImmunityTimePropertyPropertyToHclTerraform(struct?: TfWebAcl.RuleChallengeConfigImmunityTimePropertyPropertyOutputReference | TfWebAcl.RuleChallengeConfigImmunityTimePropertyProperty): any;
export declare function tfWebAclMapperRuleChallengeConfigPropertyToTerraform(struct?: TfWebAcl.RuleChallengeConfigPropertyOutputReference | TfWebAcl.RuleChallengeConfigProperty): any;
export declare function tfWebAclMapperRuleChallengeConfigPropertyToHclTerraform(struct?: TfWebAcl.RuleChallengeConfigPropertyOutputReference | TfWebAcl.RuleChallengeConfigProperty): any;
export declare function tfWebAclMapperRuleOverrideActionCountPropertyToTerraform(struct?: TfWebAcl.RuleOverrideActionCountPropertyOutputReference | TfWebAcl.RuleOverrideActionCountProperty): any;
export declare function tfWebAclMapperRuleOverrideActionCountPropertyToHclTerraform(struct?: TfWebAcl.RuleOverrideActionCountPropertyOutputReference | TfWebAcl.RuleOverrideActionCountProperty): any;
export declare function tfWebAclMapperNonePropertyToTerraform(struct?: TfWebAcl.NonePropertyOutputReference | TfWebAcl.NoneProperty): any;
export declare function tfWebAclMapperNonePropertyToHclTerraform(struct?: TfWebAcl.NonePropertyOutputReference | TfWebAcl.NoneProperty): any;
export declare function tfWebAclMapperOverrideActionPropertyToTerraform(struct?: TfWebAcl.OverrideActionPropertyOutputReference | TfWebAcl.OverrideActionProperty): any;
export declare function tfWebAclMapperOverrideActionPropertyToHclTerraform(struct?: TfWebAcl.OverrideActionPropertyOutputReference | TfWebAcl.OverrideActionProperty): any;
export declare function tfWebAclMapperRuleLabelPropertyToTerraform(struct?: TfWebAcl.RuleLabelProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperRuleLabelPropertyToHclTerraform(struct?: TfWebAcl.RuleLabelProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperRuleVisibilityConfigPropertyToTerraform(struct?: TfWebAcl.RuleVisibilityConfigPropertyOutputReference | TfWebAcl.RuleVisibilityConfigProperty): any;
export declare function tfWebAclMapperRuleVisibilityConfigPropertyToHclTerraform(struct?: TfWebAcl.RuleVisibilityConfigPropertyOutputReference | TfWebAcl.RuleVisibilityConfigProperty): any;
export declare function tfWebAclMapperRulePropertyToTerraform(struct?: TfWebAcl.RuleProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperRulePropertyToHclTerraform(struct?: TfWebAcl.RuleProperty | cdktn.IResolvable): any;
export declare function tfWebAclMapperVisibilityConfigPropertyToTerraform(struct?: TfWebAcl.VisibilityConfigPropertyOutputReference | TfWebAcl.VisibilityConfigProperty): any;
export declare function tfWebAclMapperVisibilityConfigPropertyToHclTerraform(struct?: TfWebAcl.VisibilityConfigPropertyOutputReference | TfWebAcl.VisibilityConfigProperty): any;
export declare namespace TfWebAcl {
    interface ApiGatewayProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#default_size_inspection_limit TfWebAcl#default_size_inspection_limit}
        */
        readonly defaultSizeInspectionLimit: string;
    }
    class ApiGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApiGatewayProperty | undefined;
        set internalValue(value: ApiGatewayProperty | undefined);
        private _defaultSizeInspectionLimit?;
        get defaultSizeInspectionLimit(): string;
        set defaultSizeInspectionLimit(value: string);
        get defaultSizeInspectionLimitInput(): string | undefined;
    }
    interface AppRunnerServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#default_size_inspection_limit TfWebAcl#default_size_inspection_limit}
        */
        readonly defaultSizeInspectionLimit: string;
    }
    class AppRunnerServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AppRunnerServiceProperty | undefined;
        set internalValue(value: AppRunnerServiceProperty | undefined);
        private _defaultSizeInspectionLimit?;
        get defaultSizeInspectionLimit(): string;
        set defaultSizeInspectionLimit(value: string);
        get defaultSizeInspectionLimitInput(): string | undefined;
    }
    interface CloudfrontProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#default_size_inspection_limit TfWebAcl#default_size_inspection_limit}
        */
        readonly defaultSizeInspectionLimit: string;
    }
    class CloudfrontPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudfrontProperty | undefined;
        set internalValue(value: CloudfrontProperty | undefined);
        private _defaultSizeInspectionLimit?;
        get defaultSizeInspectionLimit(): string;
        set defaultSizeInspectionLimit(value: string);
        get defaultSizeInspectionLimitInput(): string | undefined;
    }
    interface CognitoUserPoolProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#default_size_inspection_limit TfWebAcl#default_size_inspection_limit}
        */
        readonly defaultSizeInspectionLimit: string;
    }
    class CognitoUserPoolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CognitoUserPoolProperty | undefined;
        set internalValue(value: CognitoUserPoolProperty | undefined);
        private _defaultSizeInspectionLimit?;
        get defaultSizeInspectionLimit(): string;
        set defaultSizeInspectionLimit(value: string);
        get defaultSizeInspectionLimitInput(): string | undefined;
    }
    interface VerifiedAccessInstanceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#default_size_inspection_limit TfWebAcl#default_size_inspection_limit}
        */
        readonly defaultSizeInspectionLimit: string;
    }
    class VerifiedAccessInstancePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VerifiedAccessInstanceProperty | undefined;
        set internalValue(value: VerifiedAccessInstanceProperty | undefined);
        private _defaultSizeInspectionLimit?;
        get defaultSizeInspectionLimit(): string;
        set defaultSizeInspectionLimit(value: string);
        get defaultSizeInspectionLimitInput(): string | undefined;
    }
    interface RequestBodyProperty {
        /**
        * api_gateway block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#api_gateway TfWebAcl#api_gateway}
        */
        readonly apiGateway?: ApiGatewayProperty;
        /**
        * app_runner_service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#app_runner_service TfWebAcl#app_runner_service}
        */
        readonly appRunnerService?: AppRunnerServiceProperty;
        /**
        * cloudfront block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#cloudfront TfWebAcl#cloudfront}
        */
        readonly cloudfront?: CloudfrontProperty;
        /**
        * cognito_user_pool block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#cognito_user_pool TfWebAcl#cognito_user_pool}
        */
        readonly cognitoUserPool?: CognitoUserPoolProperty;
        /**
        * verified_access_instance block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#verified_access_instance TfWebAcl#verified_access_instance}
        */
        readonly verifiedAccessInstance?: VerifiedAccessInstanceProperty;
    }
    class RequestBodyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RequestBodyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RequestBodyProperty | cdktn.IResolvable | undefined);
        private _apiGateway;
        get apiGateway(): ApiGatewayPropertyOutputReference;
        putApiGateway(value: ApiGatewayProperty): void;
        resetApiGateway(): void;
        get apiGatewayInput(): ApiGatewayProperty | undefined;
        private _appRunnerService;
        get appRunnerService(): AppRunnerServicePropertyOutputReference;
        putAppRunnerService(value: AppRunnerServiceProperty): void;
        resetAppRunnerService(): void;
        get appRunnerServiceInput(): AppRunnerServiceProperty | undefined;
        private _cloudfront;
        get cloudfront(): CloudfrontPropertyOutputReference;
        putCloudfront(value: CloudfrontProperty): void;
        resetCloudfront(): void;
        get cloudfrontInput(): CloudfrontProperty | undefined;
        private _cognitoUserPool;
        get cognitoUserPool(): CognitoUserPoolPropertyOutputReference;
        putCognitoUserPool(value: CognitoUserPoolProperty): void;
        resetCognitoUserPool(): void;
        get cognitoUserPoolInput(): CognitoUserPoolProperty | undefined;
        private _verifiedAccessInstance;
        get verifiedAccessInstance(): VerifiedAccessInstancePropertyOutputReference;
        putVerifiedAccessInstance(value: VerifiedAccessInstanceProperty): void;
        resetVerifiedAccessInstance(): void;
        get verifiedAccessInstanceInput(): VerifiedAccessInstanceProperty | undefined;
    }
    class RequestBodyPropertyList extends cdktn.ComplexList {
        internalValue?: RequestBodyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RequestBodyPropertyOutputReference;
    }
    interface AssociationConfigProperty {
        /**
        * request_body block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#request_body TfWebAcl#request_body}
        */
        readonly requestBody?: RequestBodyProperty[] | cdktn.IResolvable;
    }
    class AssociationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AssociationConfigProperty | undefined;
        set internalValue(value: AssociationConfigProperty | undefined);
        private _requestBody;
        get requestBody(): RequestBodyPropertyList;
        putRequestBody(value: RequestBodyProperty[] | cdktn.IResolvable): void;
        resetRequestBody(): void;
        get requestBodyInput(): cdktn.IResolvable | RequestBodyProperty[] | undefined;
    }
    interface CaptchaConfigImmunityTimePropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#immunity_time TfWebAcl#immunity_time}
        */
        readonly immunityTime?: number;
    }
    class CaptchaConfigImmunityTimePropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CaptchaConfigImmunityTimePropertyProperty | undefined;
        set internalValue(value: CaptchaConfigImmunityTimePropertyProperty | undefined);
        private _immunityTime?;
        get immunityTime(): number;
        set immunityTime(value: number);
        resetImmunityTime(): void;
        get immunityTimeInput(): number | undefined;
    }
    interface CaptchaConfigProperty {
        /**
        * immunity_time_property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#immunity_time_property TfWebAcl#immunity_time_property}
        */
        readonly immunityTimeProperty?: CaptchaConfigImmunityTimePropertyProperty;
    }
    class CaptchaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CaptchaConfigProperty | undefined;
        set internalValue(value: CaptchaConfigProperty | undefined);
        private _immunityTimeProperty;
        get immunityTimeProperty(): CaptchaConfigImmunityTimePropertyPropertyOutputReference;
        putImmunityTimeProperty(value: CaptchaConfigImmunityTimePropertyProperty): void;
        resetImmunityTimeProperty(): void;
        get immunityTimePropertyInput(): CaptchaConfigImmunityTimePropertyProperty | undefined;
    }
    interface ChallengeConfigImmunityTimePropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#immunity_time TfWebAcl#immunity_time}
        */
        readonly immunityTime?: number;
    }
    class ChallengeConfigImmunityTimePropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ChallengeConfigImmunityTimePropertyProperty | undefined;
        set internalValue(value: ChallengeConfigImmunityTimePropertyProperty | undefined);
        private _immunityTime?;
        get immunityTime(): number;
        set immunityTime(value: number);
        resetImmunityTime(): void;
        get immunityTimeInput(): number | undefined;
    }
    interface ChallengeConfigProperty {
        /**
        * immunity_time_property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#immunity_time_property TfWebAcl#immunity_time_property}
        */
        readonly immunityTimeProperty?: ChallengeConfigImmunityTimePropertyProperty;
    }
    class ChallengeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ChallengeConfigProperty | undefined;
        set internalValue(value: ChallengeConfigProperty | undefined);
        private _immunityTimeProperty;
        get immunityTimeProperty(): ChallengeConfigImmunityTimePropertyPropertyOutputReference;
        putImmunityTimeProperty(value: ChallengeConfigImmunityTimePropertyProperty): void;
        resetImmunityTimeProperty(): void;
        get immunityTimePropertyInput(): ChallengeConfigImmunityTimePropertyProperty | undefined;
    }
    interface CustomResponseBodyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#content TfWebAcl#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#content_type TfWebAcl#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#key TfWebAcl#key}
        */
        readonly key: string;
    }
    class CustomResponseBodyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomResponseBodyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomResponseBodyProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
    }
    class CustomResponseBodyPropertyList extends cdktn.ComplexList {
        internalValue?: CustomResponseBodyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomResponseBodyPropertyOutputReference;
    }
    interface FieldProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#field_keys TfWebAcl#field_keys}
        */
        readonly fieldKeys?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#field_type TfWebAcl#field_type}
        */
        readonly fieldType: string;
    }
    class FieldPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FieldProperty | undefined;
        set internalValue(value: FieldProperty | undefined);
        private _fieldKeys?;
        get fieldKeys(): string[];
        set fieldKeys(value: string[]);
        resetFieldKeys(): void;
        get fieldKeysInput(): string[] | undefined;
        private _fieldType?;
        get fieldType(): string;
        set fieldType(value: string);
        get fieldTypeInput(): string | undefined;
    }
    interface DataProtectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#action TfWebAcl#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#exclude_rate_based_details TfWebAcl#exclude_rate_based_details}
        */
        readonly excludeRateBasedDetails?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#exclude_rule_match_details TfWebAcl#exclude_rule_match_details}
        */
        readonly excludeRuleMatchDetails?: boolean | cdktn.IResolvable;
        /**
        * field block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#field TfWebAcl#field}
        */
        readonly field: FieldProperty;
    }
    class DataProtectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataProtectionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataProtectionProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _excludeRateBasedDetails?;
        get excludeRateBasedDetails(): boolean | cdktn.IResolvable;
        set excludeRateBasedDetails(value: boolean | cdktn.IResolvable);
        resetExcludeRateBasedDetails(): void;
        get excludeRateBasedDetailsInput(): boolean | cdktn.IResolvable | undefined;
        private _excludeRuleMatchDetails?;
        get excludeRuleMatchDetails(): boolean | cdktn.IResolvable;
        set excludeRuleMatchDetails(value: boolean | cdktn.IResolvable);
        resetExcludeRuleMatchDetails(): void;
        get excludeRuleMatchDetailsInput(): boolean | cdktn.IResolvable | undefined;
        private _field;
        get field(): FieldPropertyOutputReference;
        putField(value: FieldProperty): void;
        get fieldInput(): FieldProperty | undefined;
    }
    class DataProtectionPropertyList extends cdktn.ComplexList {
        internalValue?: DataProtectionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataProtectionPropertyOutputReference;
    }
    interface DataProtectionConfigProperty {
        /**
        * data_protection block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#data_protection TfWebAcl#data_protection}
        */
        readonly dataProtection?: DataProtectionProperty[] | cdktn.IResolvable;
    }
    class DataProtectionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataProtectionConfigProperty | undefined;
        set internalValue(value: DataProtectionConfigProperty | undefined);
        private _dataProtection;
        get dataProtection(): DataProtectionPropertyList;
        putDataProtection(value: DataProtectionProperty[] | cdktn.IResolvable): void;
        resetDataProtection(): void;
        get dataProtectionInput(): cdktn.IResolvable | DataProtectionProperty[] | undefined;
    }
    interface DefaultActionAllowCustomRequestHandlingInsertHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name TfWebAcl#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#value TfWebAcl#value}
        */
        readonly value: string;
    }
    class DefaultActionAllowCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class DefaultActionAllowCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultActionAllowCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultActionAllowCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface DefaultActionAllowCustomRequestHandlingProperty {
        /**
        * insert_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#insert_header TfWebAcl#insert_header}
        */
        readonly insertHeader: DefaultActionAllowCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
    }
    class DefaultActionAllowCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultActionAllowCustomRequestHandlingProperty | undefined;
        set internalValue(value: DefaultActionAllowCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): DefaultActionAllowCustomRequestHandlingInsertHeaderPropertyList;
        putInsertHeader(value: DefaultActionAllowCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable): void;
        get insertHeaderInput(): cdktn.IResolvable | DefaultActionAllowCustomRequestHandlingInsertHeaderProperty[] | undefined;
    }
    interface DefaultActionAllowProperty {
        /**
        * custom_request_handling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_request_handling TfWebAcl#custom_request_handling}
        */
        readonly customRequestHandling?: DefaultActionAllowCustomRequestHandlingProperty;
    }
    class DefaultActionAllowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultActionAllowProperty | undefined;
        set internalValue(value: DefaultActionAllowProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): DefaultActionAllowCustomRequestHandlingPropertyOutputReference;
        putCustomRequestHandling(value: DefaultActionAllowCustomRequestHandlingProperty): void;
        resetCustomRequestHandling(): void;
        get customRequestHandlingInput(): DefaultActionAllowCustomRequestHandlingProperty | undefined;
    }
    interface DefaultActionBlockCustomResponseResponseHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name TfWebAcl#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#value TfWebAcl#value}
        */
        readonly value: string;
    }
    class DefaultActionBlockCustomResponseResponseHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultActionBlockCustomResponseResponseHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultActionBlockCustomResponseResponseHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class DefaultActionBlockCustomResponseResponseHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultActionBlockCustomResponseResponseHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultActionBlockCustomResponseResponseHeaderPropertyOutputReference;
    }
    interface DefaultActionBlockCustomResponseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_response_body_key TfWebAcl#custom_response_body_key}
        */
        readonly customResponseBodyKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#response_code TfWebAcl#response_code}
        */
        readonly responseCode: number;
        /**
        * response_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#response_header TfWebAcl#response_header}
        */
        readonly responseHeader?: DefaultActionBlockCustomResponseResponseHeaderProperty[] | cdktn.IResolvable;
    }
    class DefaultActionBlockCustomResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultActionBlockCustomResponseProperty | undefined;
        set internalValue(value: DefaultActionBlockCustomResponseProperty | undefined);
        private _customResponseBodyKey?;
        get customResponseBodyKey(): string;
        set customResponseBodyKey(value: string);
        resetCustomResponseBodyKey(): void;
        get customResponseBodyKeyInput(): string | undefined;
        private _responseCode?;
        get responseCode(): number;
        set responseCode(value: number);
        get responseCodeInput(): number | undefined;
        private _responseHeader;
        get responseHeader(): DefaultActionBlockCustomResponseResponseHeaderPropertyList;
        putResponseHeader(value: DefaultActionBlockCustomResponseResponseHeaderProperty[] | cdktn.IResolvable): void;
        resetResponseHeader(): void;
        get responseHeaderInput(): cdktn.IResolvable | DefaultActionBlockCustomResponseResponseHeaderProperty[] | undefined;
    }
    interface DefaultActionBlockProperty {
        /**
        * custom_response block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_response TfWebAcl#custom_response}
        */
        readonly customResponse?: DefaultActionBlockCustomResponseProperty;
    }
    class DefaultActionBlockPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultActionBlockProperty | undefined;
        set internalValue(value: DefaultActionBlockProperty | undefined);
        private _customResponse;
        get customResponse(): DefaultActionBlockCustomResponsePropertyOutputReference;
        putCustomResponse(value: DefaultActionBlockCustomResponseProperty): void;
        resetCustomResponse(): void;
        get customResponseInput(): DefaultActionBlockCustomResponseProperty | undefined;
    }
    interface DefaultActionProperty {
        /**
        * allow block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#allow TfWebAcl#allow}
        */
        readonly allow?: DefaultActionAllowProperty;
        /**
        * block block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#block TfWebAcl#block}
        */
        readonly block?: DefaultActionBlockProperty;
    }
    class DefaultActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultActionProperty | undefined;
        set internalValue(value: DefaultActionProperty | undefined);
        private _allow;
        get allow(): DefaultActionAllowPropertyOutputReference;
        putAllow(value: DefaultActionAllowProperty): void;
        resetAllow(): void;
        get allowInput(): DefaultActionAllowProperty | undefined;
        private _block;
        get block(): DefaultActionBlockPropertyOutputReference;
        putBlock(value: DefaultActionBlockProperty): void;
        resetBlock(): void;
        get blockInput(): DefaultActionBlockProperty | undefined;
    }
    interface RuleActionAllowCustomRequestHandlingInsertHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name TfWebAcl#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#value TfWebAcl#value}
        */
        readonly value: string;
    }
    class RuleActionAllowCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RuleActionAllowCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: RuleActionAllowCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleActionAllowCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RuleActionAllowCustomRequestHandlingProperty {
        /**
        * insert_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#insert_header TfWebAcl#insert_header}
        */
        readonly insertHeader: RuleActionAllowCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
    }
    class RuleActionAllowCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionAllowCustomRequestHandlingProperty | undefined;
        set internalValue(value: RuleActionAllowCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RuleActionAllowCustomRequestHandlingInsertHeaderPropertyList;
        putInsertHeader(value: RuleActionAllowCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable): void;
        get insertHeaderInput(): cdktn.IResolvable | RuleActionAllowCustomRequestHandlingInsertHeaderProperty[] | undefined;
    }
    interface RuleActionAllowProperty {
        /**
        * custom_request_handling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_request_handling TfWebAcl#custom_request_handling}
        */
        readonly customRequestHandling?: RuleActionAllowCustomRequestHandlingProperty;
    }
    class RuleActionAllowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionAllowProperty | undefined;
        set internalValue(value: RuleActionAllowProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RuleActionAllowCustomRequestHandlingPropertyOutputReference;
        putCustomRequestHandling(value: RuleActionAllowCustomRequestHandlingProperty): void;
        resetCustomRequestHandling(): void;
        get customRequestHandlingInput(): RuleActionAllowCustomRequestHandlingProperty | undefined;
    }
    interface RuleActionBlockCustomResponseResponseHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name TfWebAcl#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#value TfWebAcl#value}
        */
        readonly value: string;
    }
    class RuleActionBlockCustomResponseResponseHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleActionBlockCustomResponseResponseHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleActionBlockCustomResponseResponseHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RuleActionBlockCustomResponseResponseHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: RuleActionBlockCustomResponseResponseHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleActionBlockCustomResponseResponseHeaderPropertyOutputReference;
    }
    interface RuleActionBlockCustomResponseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_response_body_key TfWebAcl#custom_response_body_key}
        */
        readonly customResponseBodyKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#response_code TfWebAcl#response_code}
        */
        readonly responseCode: number;
        /**
        * response_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#response_header TfWebAcl#response_header}
        */
        readonly responseHeader?: RuleActionBlockCustomResponseResponseHeaderProperty[] | cdktn.IResolvable;
    }
    class RuleActionBlockCustomResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionBlockCustomResponseProperty | undefined;
        set internalValue(value: RuleActionBlockCustomResponseProperty | undefined);
        private _customResponseBodyKey?;
        get customResponseBodyKey(): string;
        set customResponseBodyKey(value: string);
        resetCustomResponseBodyKey(): void;
        get customResponseBodyKeyInput(): string | undefined;
        private _responseCode?;
        get responseCode(): number;
        set responseCode(value: number);
        get responseCodeInput(): number | undefined;
        private _responseHeader;
        get responseHeader(): RuleActionBlockCustomResponseResponseHeaderPropertyList;
        putResponseHeader(value: RuleActionBlockCustomResponseResponseHeaderProperty[] | cdktn.IResolvable): void;
        resetResponseHeader(): void;
        get responseHeaderInput(): cdktn.IResolvable | RuleActionBlockCustomResponseResponseHeaderProperty[] | undefined;
    }
    interface RuleActionBlockProperty {
        /**
        * custom_response block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_response TfWebAcl#custom_response}
        */
        readonly customResponse?: RuleActionBlockCustomResponseProperty;
    }
    class RuleActionBlockPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionBlockProperty | undefined;
        set internalValue(value: RuleActionBlockProperty | undefined);
        private _customResponse;
        get customResponse(): RuleActionBlockCustomResponsePropertyOutputReference;
        putCustomResponse(value: RuleActionBlockCustomResponseProperty): void;
        resetCustomResponse(): void;
        get customResponseInput(): RuleActionBlockCustomResponseProperty | undefined;
    }
    interface RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name TfWebAcl#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#value TfWebAcl#value}
        */
        readonly value: string;
    }
    class RuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RuleActionCaptchaCustomRequestHandlingProperty {
        /**
        * insert_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#insert_header TfWebAcl#insert_header}
        */
        readonly insertHeader: RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
    }
    class RuleActionCaptchaCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionCaptchaCustomRequestHandlingProperty | undefined;
        set internalValue(value: RuleActionCaptchaCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyList;
        putInsertHeader(value: RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable): void;
        get insertHeaderInput(): cdktn.IResolvable | RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty[] | undefined;
    }
    interface CaptchaProperty {
        /**
        * custom_request_handling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_request_handling TfWebAcl#custom_request_handling}
        */
        readonly customRequestHandling?: RuleActionCaptchaCustomRequestHandlingProperty;
    }
    class CaptchaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CaptchaProperty | undefined;
        set internalValue(value: CaptchaProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RuleActionCaptchaCustomRequestHandlingPropertyOutputReference;
        putCustomRequestHandling(value: RuleActionCaptchaCustomRequestHandlingProperty): void;
        resetCustomRequestHandling(): void;
        get customRequestHandlingInput(): RuleActionCaptchaCustomRequestHandlingProperty | undefined;
    }
    interface RuleActionChallengeCustomRequestHandlingInsertHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name TfWebAcl#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#value TfWebAcl#value}
        */
        readonly value: string;
    }
    class RuleActionChallengeCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleActionChallengeCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleActionChallengeCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RuleActionChallengeCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: RuleActionChallengeCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleActionChallengeCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RuleActionChallengeCustomRequestHandlingProperty {
        /**
        * insert_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#insert_header TfWebAcl#insert_header}
        */
        readonly insertHeader: RuleActionChallengeCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
    }
    class RuleActionChallengeCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionChallengeCustomRequestHandlingProperty | undefined;
        set internalValue(value: RuleActionChallengeCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RuleActionChallengeCustomRequestHandlingInsertHeaderPropertyList;
        putInsertHeader(value: RuleActionChallengeCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable): void;
        get insertHeaderInput(): cdktn.IResolvable | RuleActionChallengeCustomRequestHandlingInsertHeaderProperty[] | undefined;
    }
    interface ChallengeProperty {
        /**
        * custom_request_handling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_request_handling TfWebAcl#custom_request_handling}
        */
        readonly customRequestHandling?: RuleActionChallengeCustomRequestHandlingProperty;
    }
    class ChallengePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ChallengeProperty | undefined;
        set internalValue(value: ChallengeProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RuleActionChallengeCustomRequestHandlingPropertyOutputReference;
        putCustomRequestHandling(value: RuleActionChallengeCustomRequestHandlingProperty): void;
        resetCustomRequestHandling(): void;
        get customRequestHandlingInput(): RuleActionChallengeCustomRequestHandlingProperty | undefined;
    }
    interface RuleActionCountCustomRequestHandlingInsertHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name TfWebAcl#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#value TfWebAcl#value}
        */
        readonly value: string;
    }
    class RuleActionCountCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleActionCountCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleActionCountCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RuleActionCountCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: RuleActionCountCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleActionCountCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RuleActionCountCustomRequestHandlingProperty {
        /**
        * insert_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#insert_header TfWebAcl#insert_header}
        */
        readonly insertHeader: RuleActionCountCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
    }
    class RuleActionCountCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionCountCustomRequestHandlingProperty | undefined;
        set internalValue(value: RuleActionCountCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RuleActionCountCustomRequestHandlingInsertHeaderPropertyList;
        putInsertHeader(value: RuleActionCountCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable): void;
        get insertHeaderInput(): cdktn.IResolvable | RuleActionCountCustomRequestHandlingInsertHeaderProperty[] | undefined;
    }
    interface RuleActionCountProperty {
        /**
        * custom_request_handling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_request_handling TfWebAcl#custom_request_handling}
        */
        readonly customRequestHandling?: RuleActionCountCustomRequestHandlingProperty;
    }
    class RuleActionCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionCountProperty | undefined;
        set internalValue(value: RuleActionCountProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RuleActionCountCustomRequestHandlingPropertyOutputReference;
        putCustomRequestHandling(value: RuleActionCountCustomRequestHandlingProperty): void;
        resetCustomRequestHandling(): void;
        get customRequestHandlingInput(): RuleActionCountCustomRequestHandlingProperty | undefined;
    }
    interface ActionProperty {
        /**
        * allow block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#allow TfWebAcl#allow}
        */
        readonly allow?: RuleActionAllowProperty;
        /**
        * block block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#block TfWebAcl#block}
        */
        readonly block?: RuleActionBlockProperty;
        /**
        * captcha block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#captcha TfWebAcl#captcha}
        */
        readonly captcha?: CaptchaProperty;
        /**
        * challenge block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#challenge TfWebAcl#challenge}
        */
        readonly challenge?: ChallengeProperty;
        /**
        * count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#count TfWebAcl#count}
        */
        readonly count?: RuleActionCountProperty;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionProperty | undefined;
        set internalValue(value: ActionProperty | undefined);
        private _allow;
        get allow(): RuleActionAllowPropertyOutputReference;
        putAllow(value: RuleActionAllowProperty): void;
        resetAllow(): void;
        get allowInput(): RuleActionAllowProperty | undefined;
        private _block;
        get block(): RuleActionBlockPropertyOutputReference;
        putBlock(value: RuleActionBlockProperty): void;
        resetBlock(): void;
        get blockInput(): RuleActionBlockProperty | undefined;
        private _captcha;
        get captcha(): CaptchaPropertyOutputReference;
        putCaptcha(value: CaptchaProperty): void;
        resetCaptcha(): void;
        get captchaInput(): CaptchaProperty | undefined;
        private _challenge;
        get challenge(): ChallengePropertyOutputReference;
        putChallenge(value: ChallengeProperty): void;
        resetChallenge(): void;
        get challengeInput(): ChallengeProperty | undefined;
        private _count;
        get count(): RuleActionCountPropertyOutputReference;
        putCount(value: RuleActionCountProperty): void;
        resetCount(): void;
        get countInput(): RuleActionCountProperty | undefined;
    }
    interface RuleCaptchaConfigImmunityTimePropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#immunity_time TfWebAcl#immunity_time}
        */
        readonly immunityTime?: number;
    }
    class RuleCaptchaConfigImmunityTimePropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleCaptchaConfigImmunityTimePropertyProperty | undefined;
        set internalValue(value: RuleCaptchaConfigImmunityTimePropertyProperty | undefined);
        private _immunityTime?;
        get immunityTime(): number;
        set immunityTime(value: number);
        resetImmunityTime(): void;
        get immunityTimeInput(): number | undefined;
    }
    interface RuleCaptchaConfigProperty {
        /**
        * immunity_time_property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#immunity_time_property TfWebAcl#immunity_time_property}
        */
        readonly immunityTimeProperty?: RuleCaptchaConfigImmunityTimePropertyProperty;
    }
    class RuleCaptchaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleCaptchaConfigProperty | undefined;
        set internalValue(value: RuleCaptchaConfigProperty | undefined);
        private _immunityTimeProperty;
        get immunityTimeProperty(): RuleCaptchaConfigImmunityTimePropertyPropertyOutputReference;
        putImmunityTimeProperty(value: RuleCaptchaConfigImmunityTimePropertyProperty): void;
        resetImmunityTimeProperty(): void;
        get immunityTimePropertyInput(): RuleCaptchaConfigImmunityTimePropertyProperty | undefined;
    }
    interface RuleChallengeConfigImmunityTimePropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#immunity_time TfWebAcl#immunity_time}
        */
        readonly immunityTime?: number;
    }
    class RuleChallengeConfigImmunityTimePropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleChallengeConfigImmunityTimePropertyProperty | undefined;
        set internalValue(value: RuleChallengeConfigImmunityTimePropertyProperty | undefined);
        private _immunityTime?;
        get immunityTime(): number;
        set immunityTime(value: number);
        resetImmunityTime(): void;
        get immunityTimeInput(): number | undefined;
    }
    interface RuleChallengeConfigProperty {
        /**
        * immunity_time_property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#immunity_time_property TfWebAcl#immunity_time_property}
        */
        readonly immunityTimeProperty?: RuleChallengeConfigImmunityTimePropertyProperty;
    }
    class RuleChallengeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleChallengeConfigProperty | undefined;
        set internalValue(value: RuleChallengeConfigProperty | undefined);
        private _immunityTimeProperty;
        get immunityTimeProperty(): RuleChallengeConfigImmunityTimePropertyPropertyOutputReference;
        putImmunityTimeProperty(value: RuleChallengeConfigImmunityTimePropertyProperty): void;
        resetImmunityTimeProperty(): void;
        get immunityTimePropertyInput(): RuleChallengeConfigImmunityTimePropertyProperty | undefined;
    }
    interface RuleOverrideActionCountProperty {
    }
    class RuleOverrideActionCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleOverrideActionCountProperty | undefined;
        set internalValue(value: RuleOverrideActionCountProperty | undefined);
    }
    interface NoneProperty {
    }
    class NonePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NoneProperty | undefined;
        set internalValue(value: NoneProperty | undefined);
    }
    interface OverrideActionProperty {
        /**
        * count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#count TfWebAcl#count}
        */
        readonly count?: RuleOverrideActionCountProperty;
        /**
        * none block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#none TfWebAcl#none}
        */
        readonly none?: NoneProperty;
    }
    class OverrideActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OverrideActionProperty | undefined;
        set internalValue(value: OverrideActionProperty | undefined);
        private _count;
        get count(): RuleOverrideActionCountPropertyOutputReference;
        putCount(value: RuleOverrideActionCountProperty): void;
        resetCount(): void;
        get countInput(): RuleOverrideActionCountProperty | undefined;
        private _none;
        get none(): NonePropertyOutputReference;
        putNone(value: NoneProperty): void;
        resetNone(): void;
        get noneInput(): NoneProperty | undefined;
    }
    interface RuleLabelProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name TfWebAcl#name}
        */
        readonly name: string;
    }
    class RuleLabelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleLabelProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleLabelProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class RuleLabelPropertyList extends cdktn.ComplexList {
        internalValue?: RuleLabelProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleLabelPropertyOutputReference;
    }
    interface RuleVisibilityConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#cloudwatch_metrics_enabled TfWebAcl#cloudwatch_metrics_enabled}
        */
        readonly cloudwatchMetricsEnabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#metric_name TfWebAcl#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#sampled_requests_enabled TfWebAcl#sampled_requests_enabled}
        */
        readonly sampledRequestsEnabled: boolean | cdktn.IResolvable;
    }
    class RuleVisibilityConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleVisibilityConfigProperty | undefined;
        set internalValue(value: RuleVisibilityConfigProperty | undefined);
        private _cloudwatchMetricsEnabled?;
        get cloudwatchMetricsEnabled(): boolean | cdktn.IResolvable;
        set cloudwatchMetricsEnabled(value: boolean | cdktn.IResolvable);
        get cloudwatchMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _sampledRequestsEnabled?;
        get sampledRequestsEnabled(): boolean | cdktn.IResolvable;
        set sampledRequestsEnabled(value: boolean | cdktn.IResolvable);
        get sampledRequestsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name TfWebAcl#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#priority TfWebAcl#priority}
        */
        readonly priority: number;
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#action TfWebAcl#action}
        */
        readonly action?: ActionProperty;
        /**
        * captcha_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#captcha_config TfWebAcl#captcha_config}
        */
        readonly captchaConfig?: RuleCaptchaConfigProperty;
        /**
        * challenge_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#challenge_config TfWebAcl#challenge_config}
        */
        readonly challengeConfig?: RuleChallengeConfigProperty;
        /**
        * override_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#override_action TfWebAcl#override_action}
        */
        readonly overrideAction?: OverrideActionProperty;
        /**
        * rule_label block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#rule_label TfWebAcl#rule_label}
        */
        readonly ruleLabel?: RuleLabelProperty[] | cdktn.IResolvable;
        /**
        * statement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#statement TfWebAcl#statement}
        */
        readonly statement?: any;
        /**
        * visibility_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#visibility_config TfWebAcl#visibility_config}
        */
        readonly visibilityConfig: RuleVisibilityConfigProperty;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        get priorityInput(): number | undefined;
        private _action;
        get action(): ActionPropertyOutputReference;
        putAction(value: ActionProperty): void;
        resetAction(): void;
        get actionInput(): ActionProperty | undefined;
        private _captchaConfig;
        get captchaConfig(): RuleCaptchaConfigPropertyOutputReference;
        putCaptchaConfig(value: RuleCaptchaConfigProperty): void;
        resetCaptchaConfig(): void;
        get captchaConfigInput(): RuleCaptchaConfigProperty | undefined;
        private _challengeConfig;
        get challengeConfig(): RuleChallengeConfigPropertyOutputReference;
        putChallengeConfig(value: RuleChallengeConfigProperty): void;
        resetChallengeConfig(): void;
        get challengeConfigInput(): RuleChallengeConfigProperty | undefined;
        private _overrideAction;
        get overrideAction(): OverrideActionPropertyOutputReference;
        putOverrideAction(value: OverrideActionProperty): void;
        resetOverrideAction(): void;
        get overrideActionInput(): OverrideActionProperty | undefined;
        private _ruleLabel;
        get ruleLabel(): RuleLabelPropertyList;
        putRuleLabel(value: RuleLabelProperty[] | cdktn.IResolvable): void;
        resetRuleLabel(): void;
        get ruleLabelInput(): cdktn.IResolvable | RuleLabelProperty[] | undefined;
        private _statement?;
        get statement(): any;
        set statement(value: any);
        resetStatement(): void;
        get statementInput(): any;
        private _visibilityConfig;
        get visibilityConfig(): RuleVisibilityConfigPropertyOutputReference;
        putVisibilityConfig(value: RuleVisibilityConfigProperty): void;
        get visibilityConfigInput(): RuleVisibilityConfigProperty | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
    interface VisibilityConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#cloudwatch_metrics_enabled TfWebAcl#cloudwatch_metrics_enabled}
        */
        readonly cloudwatchMetricsEnabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#metric_name TfWebAcl#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#sampled_requests_enabled TfWebAcl#sampled_requests_enabled}
        */
        readonly sampledRequestsEnabled: boolean | cdktn.IResolvable;
    }
    class VisibilityConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VisibilityConfigProperty | undefined;
        set internalValue(value: VisibilityConfigProperty | undefined);
        private _cloudwatchMetricsEnabled?;
        get cloudwatchMetricsEnabled(): boolean | cdktn.IResolvable;
        set cloudwatchMetricsEnabled(value: boolean | cdktn.IResolvable);
        get cloudwatchMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _sampledRequestsEnabled?;
        get sampledRequestsEnabled(): boolean | cdktn.IResolvable;
        set sampledRequestsEnabled(value: boolean | cdktn.IResolvable);
        get sampledRequestsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
}
