import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfApiKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_api_key#region TfApiKey#region}
    */
    readonly region?: string;
    /**
    * Specifies whether this is for an AWS CloudFront distribution or for a regional application. Valid values are CLOUDFRONT or REGIONAL.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_api_key#scope TfApiKey#scope}
    */
    readonly scope: string;
    /**
    * The domains that you want to be able to use the API key with, for example example.com. Maximum of 5 domains.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_api_key#token_domains TfApiKey#token_domains}
    */
    readonly tokenDomains: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_api_key aws_wafv2_api_key}
*/
export declare class TfApiKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_wafv2_api_key";
    /**
    * Generates CDKTN code for importing a TfApiKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfApiKey to import
    * @param importFromId The id of the existing TfApiKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_api_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfApiKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_api_key aws_wafv2_api_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfApiKeyConfig
    */
    constructor(scope: Construct, id: string, config: TfApiKeyConfig);
    get apiKey(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
    private _tokenDomains?;
    get tokenDomains(): string[];
    set tokenDomains(value: string[]);
    get tokenDomainsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
