import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfWebAclLoggingConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#id TfWebAclLoggingConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * AWS Kinesis Firehose Delivery Stream ARNs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#log_destination_configs TfWebAclLoggingConfiguration#log_destination_configs}
    */
    readonly logDestinationConfigs: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#region TfWebAclLoggingConfiguration#region}
    */
    readonly region?: string;
    /**
    * AWS WebACL ARN
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#resource_arn TfWebAclLoggingConfiguration#resource_arn}
    */
    readonly resourceArn: string;
    /**
    * logging_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#logging_filter TfWebAclLoggingConfiguration#logging_filter}
    */
    readonly loggingFilter?: TfWebAclLoggingConfiguration.LoggingFilterProperty;
    /**
    * redacted_fields block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#redacted_fields TfWebAclLoggingConfiguration#redacted_fields}
    */
    readonly redactedFields?: TfWebAclLoggingConfiguration.RedactedFieldsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration aws_wafv2_web_acl_logging_configuration}
*/
export declare class TfWebAclLoggingConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_wafv2_web_acl_logging_configuration";
    /**
    * Generates CDKTN code for importing a TfWebAclLoggingConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfWebAclLoggingConfiguration to import
    * @param importFromId The id of the existing TfWebAclLoggingConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfWebAclLoggingConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration aws_wafv2_web_acl_logging_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfWebAclLoggingConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: TfWebAclLoggingConfigurationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logDestinationConfigs?;
    get logDestinationConfigs(): string[];
    set logDestinationConfigs(value: string[]);
    get logDestinationConfigsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceArn?;
    get resourceArn(): string;
    set resourceArn(value: string);
    get resourceArnInput(): string | undefined;
    private _loggingFilter;
    get loggingFilter(): TfWebAclLoggingConfiguration.LoggingFilterPropertyOutputReference;
    putLoggingFilter(value: TfWebAclLoggingConfiguration.LoggingFilterProperty): void;
    resetLoggingFilter(): void;
    get loggingFilterInput(): TfWebAclLoggingConfiguration.LoggingFilterProperty | undefined;
    private _redactedFields;
    get redactedFields(): TfWebAclLoggingConfiguration.RedactedFieldsPropertyList;
    putRedactedFields(value: TfWebAclLoggingConfiguration.RedactedFieldsProperty[] | cdktn.IResolvable): void;
    resetRedactedFields(): void;
    get redactedFieldsInput(): cdktn.IResolvable | TfWebAclLoggingConfiguration.RedactedFieldsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfWebAclLoggingConfigurationActionConditionPropertyToTerraform(struct?: TfWebAclLoggingConfiguration.ActionConditionPropertyOutputReference | TfWebAclLoggingConfiguration.ActionConditionProperty): any;
export declare function tfWebAclLoggingConfigurationActionConditionPropertyToHclTerraform(struct?: TfWebAclLoggingConfiguration.ActionConditionPropertyOutputReference | TfWebAclLoggingConfiguration.ActionConditionProperty): any;
export declare function tfWebAclLoggingConfigurationLabelNameConditionPropertyToTerraform(struct?: TfWebAclLoggingConfiguration.LabelNameConditionPropertyOutputReference | TfWebAclLoggingConfiguration.LabelNameConditionProperty): any;
export declare function tfWebAclLoggingConfigurationLabelNameConditionPropertyToHclTerraform(struct?: TfWebAclLoggingConfiguration.LabelNameConditionPropertyOutputReference | TfWebAclLoggingConfiguration.LabelNameConditionProperty): any;
export declare function tfWebAclLoggingConfigurationConditionPropertyToTerraform(struct?: TfWebAclLoggingConfiguration.ConditionProperty | cdktn.IResolvable): any;
export declare function tfWebAclLoggingConfigurationConditionPropertyToHclTerraform(struct?: TfWebAclLoggingConfiguration.ConditionProperty | cdktn.IResolvable): any;
export declare function tfWebAclLoggingConfigurationFilterPropertyToTerraform(struct?: TfWebAclLoggingConfiguration.FilterProperty | cdktn.IResolvable): any;
export declare function tfWebAclLoggingConfigurationFilterPropertyToHclTerraform(struct?: TfWebAclLoggingConfiguration.FilterProperty | cdktn.IResolvable): any;
export declare function tfWebAclLoggingConfigurationLoggingFilterPropertyToTerraform(struct?: TfWebAclLoggingConfiguration.LoggingFilterPropertyOutputReference | TfWebAclLoggingConfiguration.LoggingFilterProperty): any;
export declare function tfWebAclLoggingConfigurationLoggingFilterPropertyToHclTerraform(struct?: TfWebAclLoggingConfiguration.LoggingFilterPropertyOutputReference | TfWebAclLoggingConfiguration.LoggingFilterProperty): any;
export declare function tfWebAclLoggingConfigurationMethodPropertyToTerraform(struct?: TfWebAclLoggingConfiguration.MethodPropertyOutputReference | TfWebAclLoggingConfiguration.MethodProperty): any;
export declare function tfWebAclLoggingConfigurationMethodPropertyToHclTerraform(struct?: TfWebAclLoggingConfiguration.MethodPropertyOutputReference | TfWebAclLoggingConfiguration.MethodProperty): any;
export declare function tfWebAclLoggingConfigurationQueryStringPropertyToTerraform(struct?: TfWebAclLoggingConfiguration.QueryStringPropertyOutputReference | TfWebAclLoggingConfiguration.QueryStringProperty): any;
export declare function tfWebAclLoggingConfigurationQueryStringPropertyToHclTerraform(struct?: TfWebAclLoggingConfiguration.QueryStringPropertyOutputReference | TfWebAclLoggingConfiguration.QueryStringProperty): any;
export declare function tfWebAclLoggingConfigurationSingleHeaderPropertyToTerraform(struct?: TfWebAclLoggingConfiguration.SingleHeaderPropertyOutputReference | TfWebAclLoggingConfiguration.SingleHeaderProperty): any;
export declare function tfWebAclLoggingConfigurationSingleHeaderPropertyToHclTerraform(struct?: TfWebAclLoggingConfiguration.SingleHeaderPropertyOutputReference | TfWebAclLoggingConfiguration.SingleHeaderProperty): any;
export declare function tfWebAclLoggingConfigurationUriPathPropertyToTerraform(struct?: TfWebAclLoggingConfiguration.UriPathPropertyOutputReference | TfWebAclLoggingConfiguration.UriPathProperty): any;
export declare function tfWebAclLoggingConfigurationUriPathPropertyToHclTerraform(struct?: TfWebAclLoggingConfiguration.UriPathPropertyOutputReference | TfWebAclLoggingConfiguration.UriPathProperty): any;
export declare function tfWebAclLoggingConfigurationRedactedFieldsPropertyToTerraform(struct?: TfWebAclLoggingConfiguration.RedactedFieldsProperty | cdktn.IResolvable): any;
export declare function tfWebAclLoggingConfigurationRedactedFieldsPropertyToHclTerraform(struct?: TfWebAclLoggingConfiguration.RedactedFieldsProperty | cdktn.IResolvable): any;
export declare namespace TfWebAclLoggingConfiguration {
    interface ActionConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#action TfWebAclLoggingConfiguration#action}
        */
        readonly action: string;
    }
    class ActionConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionConditionProperty | undefined;
        set internalValue(value: ActionConditionProperty | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
    }
    interface LabelNameConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#label_name TfWebAclLoggingConfiguration#label_name}
        */
        readonly labelName: string;
    }
    class LabelNameConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LabelNameConditionProperty | undefined;
        set internalValue(value: LabelNameConditionProperty | undefined);
        private _labelName?;
        get labelName(): string;
        set labelName(value: string);
        get labelNameInput(): string | undefined;
    }
    interface ConditionProperty {
        /**
        * action_condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#action_condition TfWebAclLoggingConfiguration#action_condition}
        */
        readonly actionCondition?: ActionConditionProperty;
        /**
        * label_name_condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#label_name_condition TfWebAclLoggingConfiguration#label_name_condition}
        */
        readonly labelNameCondition?: LabelNameConditionProperty;
    }
    class ConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionProperty | cdktn.IResolvable | undefined);
        private _actionCondition;
        get actionCondition(): ActionConditionPropertyOutputReference;
        putActionCondition(value: ActionConditionProperty): void;
        resetActionCondition(): void;
        get actionConditionInput(): ActionConditionProperty | undefined;
        private _labelNameCondition;
        get labelNameCondition(): LabelNameConditionPropertyOutputReference;
        putLabelNameCondition(value: LabelNameConditionProperty): void;
        resetLabelNameCondition(): void;
        get labelNameConditionInput(): LabelNameConditionProperty | undefined;
    }
    class ConditionPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#behavior TfWebAclLoggingConfiguration#behavior}
        */
        readonly behavior: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#requirement TfWebAclLoggingConfiguration#requirement}
        */
        readonly requirement: string;
        /**
        * condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#condition TfWebAclLoggingConfiguration#condition}
        */
        readonly condition: ConditionProperty[] | cdktn.IResolvable;
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _behavior?;
        get behavior(): string;
        set behavior(value: string);
        get behaviorInput(): string | undefined;
        private _requirement?;
        get requirement(): string;
        set requirement(value: string);
        get requirementInput(): string | undefined;
        private _condition;
        get condition(): ConditionPropertyList;
        putCondition(value: ConditionProperty[] | cdktn.IResolvable): void;
        get conditionInput(): cdktn.IResolvable | ConditionProperty[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface LoggingFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#default_behavior TfWebAclLoggingConfiguration#default_behavior}
        */
        readonly defaultBehavior: string;
        /**
        * filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#filter TfWebAclLoggingConfiguration#filter}
        */
        readonly filter: FilterProperty[] | cdktn.IResolvable;
    }
    class LoggingFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingFilterProperty | undefined;
        set internalValue(value: LoggingFilterProperty | undefined);
        private _defaultBehavior?;
        get defaultBehavior(): string;
        set defaultBehavior(value: string);
        get defaultBehaviorInput(): string | undefined;
        private _filter;
        get filter(): FilterPropertyList;
        putFilter(value: FilterProperty[] | cdktn.IResolvable): void;
        get filterInput(): cdktn.IResolvable | FilterProperty[] | undefined;
    }
    interface MethodProperty {
    }
    class MethodPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MethodProperty | undefined;
        set internalValue(value: MethodProperty | undefined);
    }
    interface QueryStringProperty {
    }
    class QueryStringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QueryStringProperty | undefined;
        set internalValue(value: QueryStringProperty | undefined);
    }
    interface SingleHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#name TfWebAclLoggingConfiguration#name}
        */
        readonly name: string;
    }
    class SingleHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SingleHeaderProperty | undefined;
        set internalValue(value: SingleHeaderProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    interface UriPathProperty {
    }
    class UriPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UriPathProperty | undefined;
        set internalValue(value: UriPathProperty | undefined);
    }
    interface RedactedFieldsProperty {
        /**
        * method block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#method TfWebAclLoggingConfiguration#method}
        */
        readonly method?: MethodProperty;
        /**
        * query_string block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#query_string TfWebAclLoggingConfiguration#query_string}
        */
        readonly queryString?: QueryStringProperty;
        /**
        * single_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#single_header TfWebAclLoggingConfiguration#single_header}
        */
        readonly singleHeader?: SingleHeaderProperty;
        /**
        * uri_path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl_logging_configuration#uri_path TfWebAclLoggingConfiguration#uri_path}
        */
        readonly uriPath?: UriPathProperty;
    }
    class RedactedFieldsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RedactedFieldsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RedactedFieldsProperty | cdktn.IResolvable | undefined);
        private _method;
        get method(): MethodPropertyOutputReference;
        putMethod(value: MethodProperty): void;
        resetMethod(): void;
        get methodInput(): MethodProperty | undefined;
        private _queryString;
        get queryString(): QueryStringPropertyOutputReference;
        putQueryString(value: QueryStringProperty): void;
        resetQueryString(): void;
        get queryStringInput(): QueryStringProperty | undefined;
        private _singleHeader;
        get singleHeader(): SingleHeaderPropertyOutputReference;
        putSingleHeader(value: SingleHeaderProperty): void;
        resetSingleHeader(): void;
        get singleHeaderInput(): SingleHeaderProperty | undefined;
        private _uriPath;
        get uriPath(): UriPathPropertyOutputReference;
        putUriPath(value: UriPathProperty): void;
        resetUriPath(): void;
        get uriPathInput(): UriPathProperty | undefined;
    }
    class RedactedFieldsPropertyList extends cdktn.ComplexList {
        internalValue?: RedactedFieldsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RedactedFieldsPropertyOutputReference;
    }
}
