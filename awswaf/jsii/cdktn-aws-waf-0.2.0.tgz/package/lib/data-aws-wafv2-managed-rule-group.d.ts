import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfManagedRuleGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/wafv2_managed_rule_group#name DataTfManagedRuleGroup#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/wafv2_managed_rule_group#region DataTfManagedRuleGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/wafv2_managed_rule_group#scope DataTfManagedRuleGroup#scope}
    */
    readonly scope: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/wafv2_managed_rule_group#vendor_name DataTfManagedRuleGroup#vendor_name}
    */
    readonly vendorName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/wafv2_managed_rule_group#version_name DataTfManagedRuleGroup#version_name}
    */
    readonly versionName?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/wafv2_managed_rule_group aws_wafv2_managed_rule_group}
*/
export declare class DataTfManagedRuleGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_wafv2_managed_rule_group";
    /**
    * Generates CDKTN code for importing a DataTfManagedRuleGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfManagedRuleGroup to import
    * @param importFromId The id of the existing DataTfManagedRuleGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/wafv2_managed_rule_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfManagedRuleGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/wafv2_managed_rule_group aws_wafv2_managed_rule_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfManagedRuleGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataTfManagedRuleGroupConfig);
    private _availableLabels;
    get availableLabels(): DataTfManagedRuleGroup.AvailableLabelsPropertyList;
    get capacity(): number;
    private _consumedLabels;
    get consumedLabels(): DataTfManagedRuleGroup.ConsumedLabelsPropertyList;
    get labelNamespace(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rules;
    get rules(): DataTfManagedRuleGroup.RulesPropertyList;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
    get snsTopicArn(): string;
    private _vendorName?;
    get vendorName(): string;
    set vendorName(value: string);
    get vendorNameInput(): string | undefined;
    private _versionName?;
    get versionName(): string;
    set versionName(value: string);
    resetVersionName(): void;
    get versionNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfManagedRuleGroupAvailableLabelsPropertyToTerraform(struct?: DataTfManagedRuleGroup.AvailableLabelsProperty): any;
export declare function dataTfManagedRuleGroupAvailableLabelsPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.AvailableLabelsProperty): any;
export declare function dataTfManagedRuleGroupConsumedLabelsPropertyToTerraform(struct?: DataTfManagedRuleGroup.ConsumedLabelsProperty): any;
export declare function dataTfManagedRuleGroupConsumedLabelsPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.ConsumedLabelsProperty): any;
export declare function dataTfManagedRuleGroupRulesActionAllowCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: DataTfManagedRuleGroup.RulesActionAllowCustomRequestHandlingInsertHeaderProperty): any;
export declare function dataTfManagedRuleGroupRulesActionAllowCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.RulesActionAllowCustomRequestHandlingInsertHeaderProperty): any;
export declare function dataTfManagedRuleGroupRulesActionAllowCustomRequestHandlingPropertyToTerraform(struct?: DataTfManagedRuleGroup.RulesActionAllowCustomRequestHandlingProperty): any;
export declare function dataTfManagedRuleGroupRulesActionAllowCustomRequestHandlingPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.RulesActionAllowCustomRequestHandlingProperty): any;
export declare function dataTfManagedRuleGroupAllowPropertyToTerraform(struct?: DataTfManagedRuleGroup.AllowProperty): any;
export declare function dataTfManagedRuleGroupAllowPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.AllowProperty): any;
export declare function dataTfManagedRuleGroupResponseHeaderPropertyToTerraform(struct?: DataTfManagedRuleGroup.ResponseHeaderProperty): any;
export declare function dataTfManagedRuleGroupResponseHeaderPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.ResponseHeaderProperty): any;
export declare function dataTfManagedRuleGroupCustomResponsePropertyToTerraform(struct?: DataTfManagedRuleGroup.CustomResponseProperty): any;
export declare function dataTfManagedRuleGroupCustomResponsePropertyToHclTerraform(struct?: DataTfManagedRuleGroup.CustomResponseProperty): any;
export declare function dataTfManagedRuleGroupBlockPropertyToTerraform(struct?: DataTfManagedRuleGroup.BlockProperty): any;
export declare function dataTfManagedRuleGroupBlockPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.BlockProperty): any;
export declare function dataTfManagedRuleGroupRulesActionCaptchaCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: DataTfManagedRuleGroup.RulesActionCaptchaCustomRequestHandlingInsertHeaderProperty): any;
export declare function dataTfManagedRuleGroupRulesActionCaptchaCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.RulesActionCaptchaCustomRequestHandlingInsertHeaderProperty): any;
export declare function dataTfManagedRuleGroupRulesActionCaptchaCustomRequestHandlingPropertyToTerraform(struct?: DataTfManagedRuleGroup.RulesActionCaptchaCustomRequestHandlingProperty): any;
export declare function dataTfManagedRuleGroupRulesActionCaptchaCustomRequestHandlingPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.RulesActionCaptchaCustomRequestHandlingProperty): any;
export declare function dataTfManagedRuleGroupCaptchaPropertyToTerraform(struct?: DataTfManagedRuleGroup.CaptchaProperty): any;
export declare function dataTfManagedRuleGroupCaptchaPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.CaptchaProperty): any;
export declare function dataTfManagedRuleGroupRulesActionChallengeCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: DataTfManagedRuleGroup.RulesActionChallengeCustomRequestHandlingInsertHeaderProperty): any;
export declare function dataTfManagedRuleGroupRulesActionChallengeCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.RulesActionChallengeCustomRequestHandlingInsertHeaderProperty): any;
export declare function dataTfManagedRuleGroupRulesActionChallengeCustomRequestHandlingPropertyToTerraform(struct?: DataTfManagedRuleGroup.RulesActionChallengeCustomRequestHandlingProperty): any;
export declare function dataTfManagedRuleGroupRulesActionChallengeCustomRequestHandlingPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.RulesActionChallengeCustomRequestHandlingProperty): any;
export declare function dataTfManagedRuleGroupChallengePropertyToTerraform(struct?: DataTfManagedRuleGroup.ChallengeProperty): any;
export declare function dataTfManagedRuleGroupChallengePropertyToHclTerraform(struct?: DataTfManagedRuleGroup.ChallengeProperty): any;
export declare function dataTfManagedRuleGroupRulesActionCountCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: DataTfManagedRuleGroup.RulesActionCountCustomRequestHandlingInsertHeaderProperty): any;
export declare function dataTfManagedRuleGroupRulesActionCountCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.RulesActionCountCustomRequestHandlingInsertHeaderProperty): any;
export declare function dataTfManagedRuleGroupRulesActionCountCustomRequestHandlingPropertyToTerraform(struct?: DataTfManagedRuleGroup.RulesActionCountCustomRequestHandlingProperty): any;
export declare function dataTfManagedRuleGroupRulesActionCountCustomRequestHandlingPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.RulesActionCountCustomRequestHandlingProperty): any;
export declare function dataTfManagedRuleGroupCountPropertyToTerraform(struct?: DataTfManagedRuleGroup.CountProperty): any;
export declare function dataTfManagedRuleGroupCountPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.CountProperty): any;
export declare function dataTfManagedRuleGroupActionPropertyToTerraform(struct?: DataTfManagedRuleGroup.ActionProperty): any;
export declare function dataTfManagedRuleGroupActionPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.ActionProperty): any;
export declare function dataTfManagedRuleGroupRulesPropertyToTerraform(struct?: DataTfManagedRuleGroup.RulesProperty): any;
export declare function dataTfManagedRuleGroupRulesPropertyToHclTerraform(struct?: DataTfManagedRuleGroup.RulesProperty): any;
export declare namespace DataTfManagedRuleGroup {
    interface AvailableLabelsProperty {
    }
    class AvailableLabelsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AvailableLabelsProperty | undefined;
        set internalValue(value: AvailableLabelsProperty | undefined);
        get name(): string;
    }
    class AvailableLabelsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AvailableLabelsPropertyOutputReference;
    }
    interface ConsumedLabelsProperty {
    }
    class ConsumedLabelsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConsumedLabelsProperty | undefined;
        set internalValue(value: ConsumedLabelsProperty | undefined);
        get name(): string;
    }
    class ConsumedLabelsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConsumedLabelsPropertyOutputReference;
    }
    interface RulesActionAllowCustomRequestHandlingInsertHeaderProperty {
    }
    class RulesActionAllowCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesActionAllowCustomRequestHandlingInsertHeaderProperty | undefined;
        set internalValue(value: RulesActionAllowCustomRequestHandlingInsertHeaderProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class RulesActionAllowCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesActionAllowCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RulesActionAllowCustomRequestHandlingProperty {
    }
    class RulesActionAllowCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesActionAllowCustomRequestHandlingProperty | undefined;
        set internalValue(value: RulesActionAllowCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RulesActionAllowCustomRequestHandlingInsertHeaderPropertyList;
    }
    class RulesActionAllowCustomRequestHandlingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesActionAllowCustomRequestHandlingPropertyOutputReference;
    }
    interface AllowProperty {
    }
    class AllowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AllowProperty | undefined;
        set internalValue(value: AllowProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RulesActionAllowCustomRequestHandlingPropertyList;
    }
    class AllowPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AllowPropertyOutputReference;
    }
    interface ResponseHeaderProperty {
    }
    class ResponseHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResponseHeaderProperty | undefined;
        set internalValue(value: ResponseHeaderProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class ResponseHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResponseHeaderPropertyOutputReference;
    }
    interface CustomResponseProperty {
    }
    class CustomResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomResponseProperty | undefined;
        set internalValue(value: CustomResponseProperty | undefined);
        get customResponseBodyKey(): string;
        get responseCode(): number;
        private _responseHeader;
        get responseHeader(): ResponseHeaderPropertyList;
    }
    class CustomResponsePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomResponsePropertyOutputReference;
    }
    interface BlockProperty {
    }
    class BlockPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BlockProperty | undefined;
        set internalValue(value: BlockProperty | undefined);
        private _customResponse;
        get customResponse(): CustomResponsePropertyList;
    }
    class BlockPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BlockPropertyOutputReference;
    }
    interface RulesActionCaptchaCustomRequestHandlingInsertHeaderProperty {
    }
    class RulesActionCaptchaCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesActionCaptchaCustomRequestHandlingInsertHeaderProperty | undefined;
        set internalValue(value: RulesActionCaptchaCustomRequestHandlingInsertHeaderProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class RulesActionCaptchaCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesActionCaptchaCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RulesActionCaptchaCustomRequestHandlingProperty {
    }
    class RulesActionCaptchaCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesActionCaptchaCustomRequestHandlingProperty | undefined;
        set internalValue(value: RulesActionCaptchaCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RulesActionCaptchaCustomRequestHandlingInsertHeaderPropertyList;
    }
    class RulesActionCaptchaCustomRequestHandlingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesActionCaptchaCustomRequestHandlingPropertyOutputReference;
    }
    interface CaptchaProperty {
    }
    class CaptchaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CaptchaProperty | undefined;
        set internalValue(value: CaptchaProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RulesActionCaptchaCustomRequestHandlingPropertyList;
    }
    class CaptchaPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CaptchaPropertyOutputReference;
    }
    interface RulesActionChallengeCustomRequestHandlingInsertHeaderProperty {
    }
    class RulesActionChallengeCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesActionChallengeCustomRequestHandlingInsertHeaderProperty | undefined;
        set internalValue(value: RulesActionChallengeCustomRequestHandlingInsertHeaderProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class RulesActionChallengeCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesActionChallengeCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RulesActionChallengeCustomRequestHandlingProperty {
    }
    class RulesActionChallengeCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesActionChallengeCustomRequestHandlingProperty | undefined;
        set internalValue(value: RulesActionChallengeCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RulesActionChallengeCustomRequestHandlingInsertHeaderPropertyList;
    }
    class RulesActionChallengeCustomRequestHandlingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesActionChallengeCustomRequestHandlingPropertyOutputReference;
    }
    interface ChallengeProperty {
    }
    class ChallengePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ChallengeProperty | undefined;
        set internalValue(value: ChallengeProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RulesActionChallengeCustomRequestHandlingPropertyList;
    }
    class ChallengePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ChallengePropertyOutputReference;
    }
    interface RulesActionCountCustomRequestHandlingInsertHeaderProperty {
    }
    class RulesActionCountCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesActionCountCustomRequestHandlingInsertHeaderProperty | undefined;
        set internalValue(value: RulesActionCountCustomRequestHandlingInsertHeaderProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class RulesActionCountCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesActionCountCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RulesActionCountCustomRequestHandlingProperty {
    }
    class RulesActionCountCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesActionCountCustomRequestHandlingProperty | undefined;
        set internalValue(value: RulesActionCountCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RulesActionCountCustomRequestHandlingInsertHeaderPropertyList;
    }
    class RulesActionCountCustomRequestHandlingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesActionCountCustomRequestHandlingPropertyOutputReference;
    }
    interface CountProperty {
    }
    class CountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CountProperty | undefined;
        set internalValue(value: CountProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RulesActionCountCustomRequestHandlingPropertyList;
    }
    class CountPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CountPropertyOutputReference;
    }
    interface ActionProperty {
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | undefined;
        set internalValue(value: ActionProperty | undefined);
        private _allow;
        get allow(): AllowPropertyList;
        private _block;
        get block(): BlockPropertyList;
        private _captcha;
        get captcha(): CaptchaPropertyList;
        private _challenge;
        get challenge(): ChallengePropertyList;
        private _count;
        get count(): CountPropertyList;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface RulesProperty {
    }
    class RulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesProperty | undefined;
        set internalValue(value: RulesProperty | undefined);
        private _action;
        get action(): ActionPropertyList;
        get name(): string;
    }
    class RulesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesPropertyOutputReference;
    }
}
