import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWafv2WebAclConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#description AwsWafv2WebAcl#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#id AwsWafv2WebAcl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name AwsWafv2WebAcl#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name_prefix AwsWafv2WebAcl#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#region AwsWafv2WebAcl#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#rule_json AwsWafv2WebAcl#rule_json}
    */
    readonly ruleJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#scope AwsWafv2WebAcl#scope}
    */
    readonly scope: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#tags AwsWafv2WebAcl#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#tags_all AwsWafv2WebAcl#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#token_domains AwsWafv2WebAcl#token_domains}
    */
    readonly tokenDomains?: string[];
    /**
    * association_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#association_config AwsWafv2WebAcl#association_config}
    */
    readonly associationConfig?: AwsWafv2WebAcl.AssociationConfigProperty;
    /**
    * captcha_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#captcha_config AwsWafv2WebAcl#captcha_config}
    */
    readonly captchaConfig?: AwsWafv2WebAcl.CaptchaConfigProperty;
    /**
    * challenge_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#challenge_config AwsWafv2WebAcl#challenge_config}
    */
    readonly challengeConfig?: AwsWafv2WebAcl.ChallengeConfigProperty;
    /**
    * custom_response_body block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_response_body AwsWafv2WebAcl#custom_response_body}
    */
    readonly customResponseBody?: AwsWafv2WebAcl.CustomResponseBodyProperty[] | cdktn.IResolvable;
    /**
    * data_protection_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#data_protection_config AwsWafv2WebAcl#data_protection_config}
    */
    readonly dataProtectionConfig?: AwsWafv2WebAcl.DataProtectionConfigProperty;
    /**
    * default_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#default_action AwsWafv2WebAcl#default_action}
    */
    readonly defaultAction: AwsWafv2WebAcl.DefaultActionProperty;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#rule AwsWafv2WebAcl#rule}
    */
    readonly rule?: AwsWafv2WebAcl.RuleProperty[] | cdktn.IResolvable;
    /**
    * visibility_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#visibility_config AwsWafv2WebAcl#visibility_config}
    */
    readonly visibilityConfig: AwsWafv2WebAcl.VisibilityConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl aws_wafv2_web_acl}
*/
export declare class AwsWafv2WebAcl extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_wafv2_web_acl";
    /**
    * Generates CDKTN code for importing a AwsWafv2WebAcl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWafv2WebAcl to import
    * @param importFromId The id of the existing AwsWafv2WebAcl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWafv2WebAcl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl aws_wafv2_web_acl} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWafv2WebAclConfig
    */
    constructor(scope: Construct, id: string, config: AwsWafv2WebAclConfig);
    get applicationIntegrationUrl(): string;
    get arn(): string;
    get capacity(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lockToken(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _ruleJson?;
    get ruleJson(): string;
    set ruleJson(value: string);
    resetRuleJson(): void;
    get ruleJsonInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _tokenDomains?;
    get tokenDomains(): string[];
    set tokenDomains(value: string[]);
    resetTokenDomains(): void;
    get tokenDomainsInput(): string[] | undefined;
    private _associationConfig;
    get associationConfig(): AwsWafv2WebAcl.AssociationConfigPropertyOutputReference;
    putAssociationConfig(value: AwsWafv2WebAcl.AssociationConfigProperty): void;
    resetAssociationConfig(): void;
    get associationConfigInput(): AwsWafv2WebAcl.AssociationConfigProperty | undefined;
    private _captchaConfig;
    get captchaConfig(): AwsWafv2WebAcl.CaptchaConfigPropertyOutputReference;
    putCaptchaConfig(value: AwsWafv2WebAcl.CaptchaConfigProperty): void;
    resetCaptchaConfig(): void;
    get captchaConfigInput(): AwsWafv2WebAcl.CaptchaConfigProperty | undefined;
    private _challengeConfig;
    get challengeConfig(): AwsWafv2WebAcl.ChallengeConfigPropertyOutputReference;
    putChallengeConfig(value: AwsWafv2WebAcl.ChallengeConfigProperty): void;
    resetChallengeConfig(): void;
    get challengeConfigInput(): AwsWafv2WebAcl.ChallengeConfigProperty | undefined;
    private _customResponseBody;
    get customResponseBody(): AwsWafv2WebAcl.CustomResponseBodyPropertyList;
    putCustomResponseBody(value: AwsWafv2WebAcl.CustomResponseBodyProperty[] | cdktn.IResolvable): void;
    resetCustomResponseBody(): void;
    get customResponseBodyInput(): cdktn.IResolvable | AwsWafv2WebAcl.CustomResponseBodyProperty[] | undefined;
    private _dataProtectionConfig;
    get dataProtectionConfig(): AwsWafv2WebAcl.DataProtectionConfigPropertyOutputReference;
    putDataProtectionConfig(value: AwsWafv2WebAcl.DataProtectionConfigProperty): void;
    resetDataProtectionConfig(): void;
    get dataProtectionConfigInput(): AwsWafv2WebAcl.DataProtectionConfigProperty | undefined;
    private _defaultAction;
    get defaultAction(): AwsWafv2WebAcl.DefaultActionPropertyOutputReference;
    putDefaultAction(value: AwsWafv2WebAcl.DefaultActionProperty): void;
    get defaultActionInput(): AwsWafv2WebAcl.DefaultActionProperty | undefined;
    private _rule;
    get rule(): AwsWafv2WebAcl.RulePropertyList;
    putRule(value: AwsWafv2WebAcl.RuleProperty[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | AwsWafv2WebAcl.RuleProperty[] | undefined;
    private _visibilityConfig;
    get visibilityConfig(): AwsWafv2WebAcl.VisibilityConfigPropertyOutputReference;
    putVisibilityConfig(value: AwsWafv2WebAcl.VisibilityConfigProperty): void;
    get visibilityConfigInput(): AwsWafv2WebAcl.VisibilityConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWafv2WebAclMapperApiGatewayPropertyToTerraform(struct?: AwsWafv2WebAcl.ApiGatewayPropertyOutputReference | AwsWafv2WebAcl.ApiGatewayProperty): any;
export declare function awsWafv2WebAclMapperApiGatewayPropertyToHclTerraform(struct?: AwsWafv2WebAcl.ApiGatewayPropertyOutputReference | AwsWafv2WebAcl.ApiGatewayProperty): any;
export declare function awsWafv2WebAclMapperAppRunnerServicePropertyToTerraform(struct?: AwsWafv2WebAcl.AppRunnerServicePropertyOutputReference | AwsWafv2WebAcl.AppRunnerServiceProperty): any;
export declare function awsWafv2WebAclMapperAppRunnerServicePropertyToHclTerraform(struct?: AwsWafv2WebAcl.AppRunnerServicePropertyOutputReference | AwsWafv2WebAcl.AppRunnerServiceProperty): any;
export declare function awsWafv2WebAclMapperCloudfrontPropertyToTerraform(struct?: AwsWafv2WebAcl.CloudfrontPropertyOutputReference | AwsWafv2WebAcl.CloudfrontProperty): any;
export declare function awsWafv2WebAclMapperCloudfrontPropertyToHclTerraform(struct?: AwsWafv2WebAcl.CloudfrontPropertyOutputReference | AwsWafv2WebAcl.CloudfrontProperty): any;
export declare function awsWafv2WebAclMapperCognitoUserPoolPropertyToTerraform(struct?: AwsWafv2WebAcl.CognitoUserPoolPropertyOutputReference | AwsWafv2WebAcl.CognitoUserPoolProperty): any;
export declare function awsWafv2WebAclMapperCognitoUserPoolPropertyToHclTerraform(struct?: AwsWafv2WebAcl.CognitoUserPoolPropertyOutputReference | AwsWafv2WebAcl.CognitoUserPoolProperty): any;
export declare function awsWafv2WebAclMapperVerifiedAccessInstancePropertyToTerraform(struct?: AwsWafv2WebAcl.VerifiedAccessInstancePropertyOutputReference | AwsWafv2WebAcl.VerifiedAccessInstanceProperty): any;
export declare function awsWafv2WebAclMapperVerifiedAccessInstancePropertyToHclTerraform(struct?: AwsWafv2WebAcl.VerifiedAccessInstancePropertyOutputReference | AwsWafv2WebAcl.VerifiedAccessInstanceProperty): any;
export declare function awsWafv2WebAclMapperRequestBodyPropertyToTerraform(struct?: AwsWafv2WebAcl.RequestBodyProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperRequestBodyPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RequestBodyProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperAssociationConfigPropertyToTerraform(struct?: AwsWafv2WebAcl.AssociationConfigPropertyOutputReference | AwsWafv2WebAcl.AssociationConfigProperty): any;
export declare function awsWafv2WebAclMapperAssociationConfigPropertyToHclTerraform(struct?: AwsWafv2WebAcl.AssociationConfigPropertyOutputReference | AwsWafv2WebAcl.AssociationConfigProperty): any;
export declare function awsWafv2WebAclMapperCaptchaConfigImmunityTimePropertyPropertyToTerraform(struct?: AwsWafv2WebAcl.CaptchaConfigImmunityTimePropertyPropertyOutputReference | AwsWafv2WebAcl.CaptchaConfigImmunityTimePropertyProperty): any;
export declare function awsWafv2WebAclMapperCaptchaConfigImmunityTimePropertyPropertyToHclTerraform(struct?: AwsWafv2WebAcl.CaptchaConfigImmunityTimePropertyPropertyOutputReference | AwsWafv2WebAcl.CaptchaConfigImmunityTimePropertyProperty): any;
export declare function awsWafv2WebAclMapperCaptchaConfigPropertyToTerraform(struct?: AwsWafv2WebAcl.CaptchaConfigPropertyOutputReference | AwsWafv2WebAcl.CaptchaConfigProperty): any;
export declare function awsWafv2WebAclMapperCaptchaConfigPropertyToHclTerraform(struct?: AwsWafv2WebAcl.CaptchaConfigPropertyOutputReference | AwsWafv2WebAcl.CaptchaConfigProperty): any;
export declare function awsWafv2WebAclMapperChallengeConfigImmunityTimePropertyPropertyToTerraform(struct?: AwsWafv2WebAcl.ChallengeConfigImmunityTimePropertyPropertyOutputReference | AwsWafv2WebAcl.ChallengeConfigImmunityTimePropertyProperty): any;
export declare function awsWafv2WebAclMapperChallengeConfigImmunityTimePropertyPropertyToHclTerraform(struct?: AwsWafv2WebAcl.ChallengeConfigImmunityTimePropertyPropertyOutputReference | AwsWafv2WebAcl.ChallengeConfigImmunityTimePropertyProperty): any;
export declare function awsWafv2WebAclMapperChallengeConfigPropertyToTerraform(struct?: AwsWafv2WebAcl.ChallengeConfigPropertyOutputReference | AwsWafv2WebAcl.ChallengeConfigProperty): any;
export declare function awsWafv2WebAclMapperChallengeConfigPropertyToHclTerraform(struct?: AwsWafv2WebAcl.ChallengeConfigPropertyOutputReference | AwsWafv2WebAcl.ChallengeConfigProperty): any;
export declare function awsWafv2WebAclMapperCustomResponseBodyPropertyToTerraform(struct?: AwsWafv2WebAcl.CustomResponseBodyProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperCustomResponseBodyPropertyToHclTerraform(struct?: AwsWafv2WebAcl.CustomResponseBodyProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperFieldPropertyToTerraform(struct?: AwsWafv2WebAcl.FieldPropertyOutputReference | AwsWafv2WebAcl.FieldProperty): any;
export declare function awsWafv2WebAclMapperFieldPropertyToHclTerraform(struct?: AwsWafv2WebAcl.FieldPropertyOutputReference | AwsWafv2WebAcl.FieldProperty): any;
export declare function awsWafv2WebAclMapperDataProtectionPropertyToTerraform(struct?: AwsWafv2WebAcl.DataProtectionProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperDataProtectionPropertyToHclTerraform(struct?: AwsWafv2WebAcl.DataProtectionProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperDataProtectionConfigPropertyToTerraform(struct?: AwsWafv2WebAcl.DataProtectionConfigPropertyOutputReference | AwsWafv2WebAcl.DataProtectionConfigProperty): any;
export declare function awsWafv2WebAclMapperDataProtectionConfigPropertyToHclTerraform(struct?: AwsWafv2WebAcl.DataProtectionConfigPropertyOutputReference | AwsWafv2WebAcl.DataProtectionConfigProperty): any;
export declare function awsWafv2WebAclMapperDefaultActionAllowCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: AwsWafv2WebAcl.DefaultActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperDefaultActionAllowCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: AwsWafv2WebAcl.DefaultActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperDefaultActionAllowCustomRequestHandlingPropertyToTerraform(struct?: AwsWafv2WebAcl.DefaultActionAllowCustomRequestHandlingPropertyOutputReference | AwsWafv2WebAcl.DefaultActionAllowCustomRequestHandlingProperty): any;
export declare function awsWafv2WebAclMapperDefaultActionAllowCustomRequestHandlingPropertyToHclTerraform(struct?: AwsWafv2WebAcl.DefaultActionAllowCustomRequestHandlingPropertyOutputReference | AwsWafv2WebAcl.DefaultActionAllowCustomRequestHandlingProperty): any;
export declare function awsWafv2WebAclMapperDefaultActionAllowPropertyToTerraform(struct?: AwsWafv2WebAcl.DefaultActionAllowPropertyOutputReference | AwsWafv2WebAcl.DefaultActionAllowProperty): any;
export declare function awsWafv2WebAclMapperDefaultActionAllowPropertyToHclTerraform(struct?: AwsWafv2WebAcl.DefaultActionAllowPropertyOutputReference | AwsWafv2WebAcl.DefaultActionAllowProperty): any;
export declare function awsWafv2WebAclMapperDefaultActionBlockCustomResponseResponseHeaderPropertyToTerraform(struct?: AwsWafv2WebAcl.DefaultActionBlockCustomResponseResponseHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperDefaultActionBlockCustomResponseResponseHeaderPropertyToHclTerraform(struct?: AwsWafv2WebAcl.DefaultActionBlockCustomResponseResponseHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperDefaultActionBlockCustomResponsePropertyToTerraform(struct?: AwsWafv2WebAcl.DefaultActionBlockCustomResponsePropertyOutputReference | AwsWafv2WebAcl.DefaultActionBlockCustomResponseProperty): any;
export declare function awsWafv2WebAclMapperDefaultActionBlockCustomResponsePropertyToHclTerraform(struct?: AwsWafv2WebAcl.DefaultActionBlockCustomResponsePropertyOutputReference | AwsWafv2WebAcl.DefaultActionBlockCustomResponseProperty): any;
export declare function awsWafv2WebAclMapperDefaultActionBlockPropertyToTerraform(struct?: AwsWafv2WebAcl.DefaultActionBlockPropertyOutputReference | AwsWafv2WebAcl.DefaultActionBlockProperty): any;
export declare function awsWafv2WebAclMapperDefaultActionBlockPropertyToHclTerraform(struct?: AwsWafv2WebAcl.DefaultActionBlockPropertyOutputReference | AwsWafv2WebAcl.DefaultActionBlockProperty): any;
export declare function awsWafv2WebAclMapperDefaultActionPropertyToTerraform(struct?: AwsWafv2WebAcl.DefaultActionPropertyOutputReference | AwsWafv2WebAcl.DefaultActionProperty): any;
export declare function awsWafv2WebAclMapperDefaultActionPropertyToHclTerraform(struct?: AwsWafv2WebAcl.DefaultActionPropertyOutputReference | AwsWafv2WebAcl.DefaultActionProperty): any;
export declare function awsWafv2WebAclMapperRuleActionAllowCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperRuleActionAllowCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperRuleActionAllowCustomRequestHandlingPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleActionAllowCustomRequestHandlingPropertyOutputReference | AwsWafv2WebAcl.RuleActionAllowCustomRequestHandlingProperty): any;
export declare function awsWafv2WebAclMapperRuleActionAllowCustomRequestHandlingPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleActionAllowCustomRequestHandlingPropertyOutputReference | AwsWafv2WebAcl.RuleActionAllowCustomRequestHandlingProperty): any;
export declare function awsWafv2WebAclMapperRuleActionAllowPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleActionAllowPropertyOutputReference | AwsWafv2WebAcl.RuleActionAllowProperty): any;
export declare function awsWafv2WebAclMapperRuleActionAllowPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleActionAllowPropertyOutputReference | AwsWafv2WebAcl.RuleActionAllowProperty): any;
export declare function awsWafv2WebAclMapperRuleActionBlockCustomResponseResponseHeaderPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleActionBlockCustomResponseResponseHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperRuleActionBlockCustomResponseResponseHeaderPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleActionBlockCustomResponseResponseHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperRuleActionBlockCustomResponsePropertyToTerraform(struct?: AwsWafv2WebAcl.RuleActionBlockCustomResponsePropertyOutputReference | AwsWafv2WebAcl.RuleActionBlockCustomResponseProperty): any;
export declare function awsWafv2WebAclMapperRuleActionBlockCustomResponsePropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleActionBlockCustomResponsePropertyOutputReference | AwsWafv2WebAcl.RuleActionBlockCustomResponseProperty): any;
export declare function awsWafv2WebAclMapperRuleActionBlockPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleActionBlockPropertyOutputReference | AwsWafv2WebAcl.RuleActionBlockProperty): any;
export declare function awsWafv2WebAclMapperRuleActionBlockPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleActionBlockPropertyOutputReference | AwsWafv2WebAcl.RuleActionBlockProperty): any;
export declare function awsWafv2WebAclMapperRuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperRuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperRuleActionCaptchaCustomRequestHandlingPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleActionCaptchaCustomRequestHandlingPropertyOutputReference | AwsWafv2WebAcl.RuleActionCaptchaCustomRequestHandlingProperty): any;
export declare function awsWafv2WebAclMapperRuleActionCaptchaCustomRequestHandlingPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleActionCaptchaCustomRequestHandlingPropertyOutputReference | AwsWafv2WebAcl.RuleActionCaptchaCustomRequestHandlingProperty): any;
export declare function awsWafv2WebAclMapperCaptchaPropertyToTerraform(struct?: AwsWafv2WebAcl.CaptchaPropertyOutputReference | AwsWafv2WebAcl.CaptchaProperty): any;
export declare function awsWafv2WebAclMapperCaptchaPropertyToHclTerraform(struct?: AwsWafv2WebAcl.CaptchaPropertyOutputReference | AwsWafv2WebAcl.CaptchaProperty): any;
export declare function awsWafv2WebAclMapperRuleActionChallengeCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleActionChallengeCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperRuleActionChallengeCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleActionChallengeCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperRuleActionChallengeCustomRequestHandlingPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleActionChallengeCustomRequestHandlingPropertyOutputReference | AwsWafv2WebAcl.RuleActionChallengeCustomRequestHandlingProperty): any;
export declare function awsWafv2WebAclMapperRuleActionChallengeCustomRequestHandlingPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleActionChallengeCustomRequestHandlingPropertyOutputReference | AwsWafv2WebAcl.RuleActionChallengeCustomRequestHandlingProperty): any;
export declare function awsWafv2WebAclMapperChallengePropertyToTerraform(struct?: AwsWafv2WebAcl.ChallengePropertyOutputReference | AwsWafv2WebAcl.ChallengeProperty): any;
export declare function awsWafv2WebAclMapperChallengePropertyToHclTerraform(struct?: AwsWafv2WebAcl.ChallengePropertyOutputReference | AwsWafv2WebAcl.ChallengeProperty): any;
export declare function awsWafv2WebAclMapperRuleActionCountCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleActionCountCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperRuleActionCountCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleActionCountCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperRuleActionCountCustomRequestHandlingPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleActionCountCustomRequestHandlingPropertyOutputReference | AwsWafv2WebAcl.RuleActionCountCustomRequestHandlingProperty): any;
export declare function awsWafv2WebAclMapperRuleActionCountCustomRequestHandlingPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleActionCountCustomRequestHandlingPropertyOutputReference | AwsWafv2WebAcl.RuleActionCountCustomRequestHandlingProperty): any;
export declare function awsWafv2WebAclMapperRuleActionCountPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleActionCountPropertyOutputReference | AwsWafv2WebAcl.RuleActionCountProperty): any;
export declare function awsWafv2WebAclMapperRuleActionCountPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleActionCountPropertyOutputReference | AwsWafv2WebAcl.RuleActionCountProperty): any;
export declare function awsWafv2WebAclMapperActionPropertyToTerraform(struct?: AwsWafv2WebAcl.ActionPropertyOutputReference | AwsWafv2WebAcl.ActionProperty): any;
export declare function awsWafv2WebAclMapperActionPropertyToHclTerraform(struct?: AwsWafv2WebAcl.ActionPropertyOutputReference | AwsWafv2WebAcl.ActionProperty): any;
export declare function awsWafv2WebAclMapperRuleCaptchaConfigImmunityTimePropertyPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleCaptchaConfigImmunityTimePropertyPropertyOutputReference | AwsWafv2WebAcl.RuleCaptchaConfigImmunityTimePropertyProperty): any;
export declare function awsWafv2WebAclMapperRuleCaptchaConfigImmunityTimePropertyPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleCaptchaConfigImmunityTimePropertyPropertyOutputReference | AwsWafv2WebAcl.RuleCaptchaConfigImmunityTimePropertyProperty): any;
export declare function awsWafv2WebAclMapperRuleCaptchaConfigPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleCaptchaConfigPropertyOutputReference | AwsWafv2WebAcl.RuleCaptchaConfigProperty): any;
export declare function awsWafv2WebAclMapperRuleCaptchaConfigPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleCaptchaConfigPropertyOutputReference | AwsWafv2WebAcl.RuleCaptchaConfigProperty): any;
export declare function awsWafv2WebAclMapperRuleChallengeConfigImmunityTimePropertyPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleChallengeConfigImmunityTimePropertyPropertyOutputReference | AwsWafv2WebAcl.RuleChallengeConfigImmunityTimePropertyProperty): any;
export declare function awsWafv2WebAclMapperRuleChallengeConfigImmunityTimePropertyPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleChallengeConfigImmunityTimePropertyPropertyOutputReference | AwsWafv2WebAcl.RuleChallengeConfigImmunityTimePropertyProperty): any;
export declare function awsWafv2WebAclMapperRuleChallengeConfigPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleChallengeConfigPropertyOutputReference | AwsWafv2WebAcl.RuleChallengeConfigProperty): any;
export declare function awsWafv2WebAclMapperRuleChallengeConfigPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleChallengeConfigPropertyOutputReference | AwsWafv2WebAcl.RuleChallengeConfigProperty): any;
export declare function awsWafv2WebAclMapperRuleOverrideActionCountPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleOverrideActionCountPropertyOutputReference | AwsWafv2WebAcl.RuleOverrideActionCountProperty): any;
export declare function awsWafv2WebAclMapperRuleOverrideActionCountPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleOverrideActionCountPropertyOutputReference | AwsWafv2WebAcl.RuleOverrideActionCountProperty): any;
export declare function awsWafv2WebAclMapperNonePropertyToTerraform(struct?: AwsWafv2WebAcl.NonePropertyOutputReference | AwsWafv2WebAcl.NoneProperty): any;
export declare function awsWafv2WebAclMapperNonePropertyToHclTerraform(struct?: AwsWafv2WebAcl.NonePropertyOutputReference | AwsWafv2WebAcl.NoneProperty): any;
export declare function awsWafv2WebAclMapperOverrideActionPropertyToTerraform(struct?: AwsWafv2WebAcl.OverrideActionPropertyOutputReference | AwsWafv2WebAcl.OverrideActionProperty): any;
export declare function awsWafv2WebAclMapperOverrideActionPropertyToHclTerraform(struct?: AwsWafv2WebAcl.OverrideActionPropertyOutputReference | AwsWafv2WebAcl.OverrideActionProperty): any;
export declare function awsWafv2WebAclMapperRuleLabelPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleLabelProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperRuleLabelPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleLabelProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperRuleVisibilityConfigPropertyToTerraform(struct?: AwsWafv2WebAcl.RuleVisibilityConfigPropertyOutputReference | AwsWafv2WebAcl.RuleVisibilityConfigProperty): any;
export declare function awsWafv2WebAclMapperRuleVisibilityConfigPropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleVisibilityConfigPropertyOutputReference | AwsWafv2WebAcl.RuleVisibilityConfigProperty): any;
export declare function awsWafv2WebAclMapperRulePropertyToTerraform(struct?: AwsWafv2WebAcl.RuleProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperRulePropertyToHclTerraform(struct?: AwsWafv2WebAcl.RuleProperty | cdktn.IResolvable): any;
export declare function awsWafv2WebAclMapperVisibilityConfigPropertyToTerraform(struct?: AwsWafv2WebAcl.VisibilityConfigPropertyOutputReference | AwsWafv2WebAcl.VisibilityConfigProperty): any;
export declare function awsWafv2WebAclMapperVisibilityConfigPropertyToHclTerraform(struct?: AwsWafv2WebAcl.VisibilityConfigPropertyOutputReference | AwsWafv2WebAcl.VisibilityConfigProperty): any;
export declare namespace AwsWafv2WebAcl {
    interface ApiGatewayProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#default_size_inspection_limit AwsWafv2WebAcl#default_size_inspection_limit}
        */
        readonly defaultSizeInspectionLimit: string;
    }
    class ApiGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApiGatewayProperty | undefined;
        set internalValue(value: ApiGatewayProperty | undefined);
        private _defaultSizeInspectionLimit?;
        get defaultSizeInspectionLimit(): string;
        set defaultSizeInspectionLimit(value: string);
        get defaultSizeInspectionLimitInput(): string | undefined;
    }
    interface AppRunnerServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#default_size_inspection_limit AwsWafv2WebAcl#default_size_inspection_limit}
        */
        readonly defaultSizeInspectionLimit: string;
    }
    class AppRunnerServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AppRunnerServiceProperty | undefined;
        set internalValue(value: AppRunnerServiceProperty | undefined);
        private _defaultSizeInspectionLimit?;
        get defaultSizeInspectionLimit(): string;
        set defaultSizeInspectionLimit(value: string);
        get defaultSizeInspectionLimitInput(): string | undefined;
    }
    interface CloudfrontProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#default_size_inspection_limit AwsWafv2WebAcl#default_size_inspection_limit}
        */
        readonly defaultSizeInspectionLimit: string;
    }
    class CloudfrontPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudfrontProperty | undefined;
        set internalValue(value: CloudfrontProperty | undefined);
        private _defaultSizeInspectionLimit?;
        get defaultSizeInspectionLimit(): string;
        set defaultSizeInspectionLimit(value: string);
        get defaultSizeInspectionLimitInput(): string | undefined;
    }
    interface CognitoUserPoolProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#default_size_inspection_limit AwsWafv2WebAcl#default_size_inspection_limit}
        */
        readonly defaultSizeInspectionLimit: string;
    }
    class CognitoUserPoolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CognitoUserPoolProperty | undefined;
        set internalValue(value: CognitoUserPoolProperty | undefined);
        private _defaultSizeInspectionLimit?;
        get defaultSizeInspectionLimit(): string;
        set defaultSizeInspectionLimit(value: string);
        get defaultSizeInspectionLimitInput(): string | undefined;
    }
    interface VerifiedAccessInstanceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#default_size_inspection_limit AwsWafv2WebAcl#default_size_inspection_limit}
        */
        readonly defaultSizeInspectionLimit: string;
    }
    class VerifiedAccessInstancePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VerifiedAccessInstanceProperty | undefined;
        set internalValue(value: VerifiedAccessInstanceProperty | undefined);
        private _defaultSizeInspectionLimit?;
        get defaultSizeInspectionLimit(): string;
        set defaultSizeInspectionLimit(value: string);
        get defaultSizeInspectionLimitInput(): string | undefined;
    }
    interface RequestBodyProperty {
        /**
        * api_gateway block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#api_gateway AwsWafv2WebAcl#api_gateway}
        */
        readonly apiGateway?: ApiGatewayProperty;
        /**
        * app_runner_service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#app_runner_service AwsWafv2WebAcl#app_runner_service}
        */
        readonly appRunnerService?: AppRunnerServiceProperty;
        /**
        * cloudfront block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#cloudfront AwsWafv2WebAcl#cloudfront}
        */
        readonly cloudfront?: CloudfrontProperty;
        /**
        * cognito_user_pool block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#cognito_user_pool AwsWafv2WebAcl#cognito_user_pool}
        */
        readonly cognitoUserPool?: CognitoUserPoolProperty;
        /**
        * verified_access_instance block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#verified_access_instance AwsWafv2WebAcl#verified_access_instance}
        */
        readonly verifiedAccessInstance?: VerifiedAccessInstanceProperty;
    }
    class RequestBodyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RequestBodyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RequestBodyProperty | cdktn.IResolvable | undefined);
        private _apiGateway;
        get apiGateway(): ApiGatewayPropertyOutputReference;
        putApiGateway(value: ApiGatewayProperty): void;
        resetApiGateway(): void;
        get apiGatewayInput(): ApiGatewayProperty | undefined;
        private _appRunnerService;
        get appRunnerService(): AppRunnerServicePropertyOutputReference;
        putAppRunnerService(value: AppRunnerServiceProperty): void;
        resetAppRunnerService(): void;
        get appRunnerServiceInput(): AppRunnerServiceProperty | undefined;
        private _cloudfront;
        get cloudfront(): CloudfrontPropertyOutputReference;
        putCloudfront(value: CloudfrontProperty): void;
        resetCloudfront(): void;
        get cloudfrontInput(): CloudfrontProperty | undefined;
        private _cognitoUserPool;
        get cognitoUserPool(): CognitoUserPoolPropertyOutputReference;
        putCognitoUserPool(value: CognitoUserPoolProperty): void;
        resetCognitoUserPool(): void;
        get cognitoUserPoolInput(): CognitoUserPoolProperty | undefined;
        private _verifiedAccessInstance;
        get verifiedAccessInstance(): VerifiedAccessInstancePropertyOutputReference;
        putVerifiedAccessInstance(value: VerifiedAccessInstanceProperty): void;
        resetVerifiedAccessInstance(): void;
        get verifiedAccessInstanceInput(): VerifiedAccessInstanceProperty | undefined;
    }
    class RequestBodyPropertyList extends cdktn.ComplexList {
        internalValue?: RequestBodyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RequestBodyPropertyOutputReference;
    }
    interface AssociationConfigProperty {
        /**
        * request_body block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#request_body AwsWafv2WebAcl#request_body}
        */
        readonly requestBody?: RequestBodyProperty[] | cdktn.IResolvable;
    }
    class AssociationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AssociationConfigProperty | undefined;
        set internalValue(value: AssociationConfigProperty | undefined);
        private _requestBody;
        get requestBody(): RequestBodyPropertyList;
        putRequestBody(value: RequestBodyProperty[] | cdktn.IResolvable): void;
        resetRequestBody(): void;
        get requestBodyInput(): cdktn.IResolvable | RequestBodyProperty[] | undefined;
    }
    interface CaptchaConfigImmunityTimePropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#immunity_time AwsWafv2WebAcl#immunity_time}
        */
        readonly immunityTime?: number;
    }
    class CaptchaConfigImmunityTimePropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CaptchaConfigImmunityTimePropertyProperty | undefined;
        set internalValue(value: CaptchaConfigImmunityTimePropertyProperty | undefined);
        private _immunityTime?;
        get immunityTime(): number;
        set immunityTime(value: number);
        resetImmunityTime(): void;
        get immunityTimeInput(): number | undefined;
    }
    interface CaptchaConfigProperty {
        /**
        * immunity_time_property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#immunity_time_property AwsWafv2WebAcl#immunity_time_property}
        */
        readonly immunityTimeProperty?: CaptchaConfigImmunityTimePropertyProperty;
    }
    class CaptchaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CaptchaConfigProperty | undefined;
        set internalValue(value: CaptchaConfigProperty | undefined);
        private _immunityTimeProperty;
        get immunityTimeProperty(): CaptchaConfigImmunityTimePropertyPropertyOutputReference;
        putImmunityTimeProperty(value: CaptchaConfigImmunityTimePropertyProperty): void;
        resetImmunityTimeProperty(): void;
        get immunityTimePropertyInput(): CaptchaConfigImmunityTimePropertyProperty | undefined;
    }
    interface ChallengeConfigImmunityTimePropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#immunity_time AwsWafv2WebAcl#immunity_time}
        */
        readonly immunityTime?: number;
    }
    class ChallengeConfigImmunityTimePropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ChallengeConfigImmunityTimePropertyProperty | undefined;
        set internalValue(value: ChallengeConfigImmunityTimePropertyProperty | undefined);
        private _immunityTime?;
        get immunityTime(): number;
        set immunityTime(value: number);
        resetImmunityTime(): void;
        get immunityTimeInput(): number | undefined;
    }
    interface ChallengeConfigProperty {
        /**
        * immunity_time_property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#immunity_time_property AwsWafv2WebAcl#immunity_time_property}
        */
        readonly immunityTimeProperty?: ChallengeConfigImmunityTimePropertyProperty;
    }
    class ChallengeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ChallengeConfigProperty | undefined;
        set internalValue(value: ChallengeConfigProperty | undefined);
        private _immunityTimeProperty;
        get immunityTimeProperty(): ChallengeConfigImmunityTimePropertyPropertyOutputReference;
        putImmunityTimeProperty(value: ChallengeConfigImmunityTimePropertyProperty): void;
        resetImmunityTimeProperty(): void;
        get immunityTimePropertyInput(): ChallengeConfigImmunityTimePropertyProperty | undefined;
    }
    interface CustomResponseBodyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#content AwsWafv2WebAcl#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#content_type AwsWafv2WebAcl#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#key AwsWafv2WebAcl#key}
        */
        readonly key: string;
    }
    class CustomResponseBodyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomResponseBodyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomResponseBodyProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
    }
    class CustomResponseBodyPropertyList extends cdktn.ComplexList {
        internalValue?: CustomResponseBodyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomResponseBodyPropertyOutputReference;
    }
    interface FieldProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#field_keys AwsWafv2WebAcl#field_keys}
        */
        readonly fieldKeys?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#field_type AwsWafv2WebAcl#field_type}
        */
        readonly fieldType: string;
    }
    class FieldPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FieldProperty | undefined;
        set internalValue(value: FieldProperty | undefined);
        private _fieldKeys?;
        get fieldKeys(): string[];
        set fieldKeys(value: string[]);
        resetFieldKeys(): void;
        get fieldKeysInput(): string[] | undefined;
        private _fieldType?;
        get fieldType(): string;
        set fieldType(value: string);
        get fieldTypeInput(): string | undefined;
    }
    interface DataProtectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#action AwsWafv2WebAcl#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#exclude_rate_based_details AwsWafv2WebAcl#exclude_rate_based_details}
        */
        readonly excludeRateBasedDetails?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#exclude_rule_match_details AwsWafv2WebAcl#exclude_rule_match_details}
        */
        readonly excludeRuleMatchDetails?: boolean | cdktn.IResolvable;
        /**
        * field block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#field AwsWafv2WebAcl#field}
        */
        readonly field: FieldProperty;
    }
    class DataProtectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataProtectionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataProtectionProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _excludeRateBasedDetails?;
        get excludeRateBasedDetails(): boolean | cdktn.IResolvable;
        set excludeRateBasedDetails(value: boolean | cdktn.IResolvable);
        resetExcludeRateBasedDetails(): void;
        get excludeRateBasedDetailsInput(): boolean | cdktn.IResolvable | undefined;
        private _excludeRuleMatchDetails?;
        get excludeRuleMatchDetails(): boolean | cdktn.IResolvable;
        set excludeRuleMatchDetails(value: boolean | cdktn.IResolvable);
        resetExcludeRuleMatchDetails(): void;
        get excludeRuleMatchDetailsInput(): boolean | cdktn.IResolvable | undefined;
        private _field;
        get field(): FieldPropertyOutputReference;
        putField(value: FieldProperty): void;
        get fieldInput(): FieldProperty | undefined;
    }
    class DataProtectionPropertyList extends cdktn.ComplexList {
        internalValue?: DataProtectionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataProtectionPropertyOutputReference;
    }
    interface DataProtectionConfigProperty {
        /**
        * data_protection block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#data_protection AwsWafv2WebAcl#data_protection}
        */
        readonly dataProtection?: DataProtectionProperty[] | cdktn.IResolvable;
    }
    class DataProtectionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataProtectionConfigProperty | undefined;
        set internalValue(value: DataProtectionConfigProperty | undefined);
        private _dataProtection;
        get dataProtection(): DataProtectionPropertyList;
        putDataProtection(value: DataProtectionProperty[] | cdktn.IResolvable): void;
        resetDataProtection(): void;
        get dataProtectionInput(): cdktn.IResolvable | DataProtectionProperty[] | undefined;
    }
    interface DefaultActionAllowCustomRequestHandlingInsertHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name AwsWafv2WebAcl#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#value AwsWafv2WebAcl#value}
        */
        readonly value: string;
    }
    class DefaultActionAllowCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class DefaultActionAllowCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultActionAllowCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultActionAllowCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface DefaultActionAllowCustomRequestHandlingProperty {
        /**
        * insert_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#insert_header AwsWafv2WebAcl#insert_header}
        */
        readonly insertHeader: DefaultActionAllowCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
    }
    class DefaultActionAllowCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultActionAllowCustomRequestHandlingProperty | undefined;
        set internalValue(value: DefaultActionAllowCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): DefaultActionAllowCustomRequestHandlingInsertHeaderPropertyList;
        putInsertHeader(value: DefaultActionAllowCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable): void;
        get insertHeaderInput(): cdktn.IResolvable | DefaultActionAllowCustomRequestHandlingInsertHeaderProperty[] | undefined;
    }
    interface DefaultActionAllowProperty {
        /**
        * custom_request_handling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_request_handling AwsWafv2WebAcl#custom_request_handling}
        */
        readonly customRequestHandling?: DefaultActionAllowCustomRequestHandlingProperty;
    }
    class DefaultActionAllowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultActionAllowProperty | undefined;
        set internalValue(value: DefaultActionAllowProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): DefaultActionAllowCustomRequestHandlingPropertyOutputReference;
        putCustomRequestHandling(value: DefaultActionAllowCustomRequestHandlingProperty): void;
        resetCustomRequestHandling(): void;
        get customRequestHandlingInput(): DefaultActionAllowCustomRequestHandlingProperty | undefined;
    }
    interface DefaultActionBlockCustomResponseResponseHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name AwsWafv2WebAcl#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#value AwsWafv2WebAcl#value}
        */
        readonly value: string;
    }
    class DefaultActionBlockCustomResponseResponseHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultActionBlockCustomResponseResponseHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultActionBlockCustomResponseResponseHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class DefaultActionBlockCustomResponseResponseHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultActionBlockCustomResponseResponseHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultActionBlockCustomResponseResponseHeaderPropertyOutputReference;
    }
    interface DefaultActionBlockCustomResponseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_response_body_key AwsWafv2WebAcl#custom_response_body_key}
        */
        readonly customResponseBodyKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#response_code AwsWafv2WebAcl#response_code}
        */
        readonly responseCode: number;
        /**
        * response_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#response_header AwsWafv2WebAcl#response_header}
        */
        readonly responseHeader?: DefaultActionBlockCustomResponseResponseHeaderProperty[] | cdktn.IResolvable;
    }
    class DefaultActionBlockCustomResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultActionBlockCustomResponseProperty | undefined;
        set internalValue(value: DefaultActionBlockCustomResponseProperty | undefined);
        private _customResponseBodyKey?;
        get customResponseBodyKey(): string;
        set customResponseBodyKey(value: string);
        resetCustomResponseBodyKey(): void;
        get customResponseBodyKeyInput(): string | undefined;
        private _responseCode?;
        get responseCode(): number;
        set responseCode(value: number);
        get responseCodeInput(): number | undefined;
        private _responseHeader;
        get responseHeader(): DefaultActionBlockCustomResponseResponseHeaderPropertyList;
        putResponseHeader(value: DefaultActionBlockCustomResponseResponseHeaderProperty[] | cdktn.IResolvable): void;
        resetResponseHeader(): void;
        get responseHeaderInput(): cdktn.IResolvable | DefaultActionBlockCustomResponseResponseHeaderProperty[] | undefined;
    }
    interface DefaultActionBlockProperty {
        /**
        * custom_response block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_response AwsWafv2WebAcl#custom_response}
        */
        readonly customResponse?: DefaultActionBlockCustomResponseProperty;
    }
    class DefaultActionBlockPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultActionBlockProperty | undefined;
        set internalValue(value: DefaultActionBlockProperty | undefined);
        private _customResponse;
        get customResponse(): DefaultActionBlockCustomResponsePropertyOutputReference;
        putCustomResponse(value: DefaultActionBlockCustomResponseProperty): void;
        resetCustomResponse(): void;
        get customResponseInput(): DefaultActionBlockCustomResponseProperty | undefined;
    }
    interface DefaultActionProperty {
        /**
        * allow block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#allow AwsWafv2WebAcl#allow}
        */
        readonly allow?: DefaultActionAllowProperty;
        /**
        * block block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#block AwsWafv2WebAcl#block}
        */
        readonly block?: DefaultActionBlockProperty;
    }
    class DefaultActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultActionProperty | undefined;
        set internalValue(value: DefaultActionProperty | undefined);
        private _allow;
        get allow(): DefaultActionAllowPropertyOutputReference;
        putAllow(value: DefaultActionAllowProperty): void;
        resetAllow(): void;
        get allowInput(): DefaultActionAllowProperty | undefined;
        private _block;
        get block(): DefaultActionBlockPropertyOutputReference;
        putBlock(value: DefaultActionBlockProperty): void;
        resetBlock(): void;
        get blockInput(): DefaultActionBlockProperty | undefined;
    }
    interface RuleActionAllowCustomRequestHandlingInsertHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name AwsWafv2WebAcl#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#value AwsWafv2WebAcl#value}
        */
        readonly value: string;
    }
    class RuleActionAllowCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RuleActionAllowCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: RuleActionAllowCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleActionAllowCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RuleActionAllowCustomRequestHandlingProperty {
        /**
        * insert_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#insert_header AwsWafv2WebAcl#insert_header}
        */
        readonly insertHeader: RuleActionAllowCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
    }
    class RuleActionAllowCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionAllowCustomRequestHandlingProperty | undefined;
        set internalValue(value: RuleActionAllowCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RuleActionAllowCustomRequestHandlingInsertHeaderPropertyList;
        putInsertHeader(value: RuleActionAllowCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable): void;
        get insertHeaderInput(): cdktn.IResolvable | RuleActionAllowCustomRequestHandlingInsertHeaderProperty[] | undefined;
    }
    interface RuleActionAllowProperty {
        /**
        * custom_request_handling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_request_handling AwsWafv2WebAcl#custom_request_handling}
        */
        readonly customRequestHandling?: RuleActionAllowCustomRequestHandlingProperty;
    }
    class RuleActionAllowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionAllowProperty | undefined;
        set internalValue(value: RuleActionAllowProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RuleActionAllowCustomRequestHandlingPropertyOutputReference;
        putCustomRequestHandling(value: RuleActionAllowCustomRequestHandlingProperty): void;
        resetCustomRequestHandling(): void;
        get customRequestHandlingInput(): RuleActionAllowCustomRequestHandlingProperty | undefined;
    }
    interface RuleActionBlockCustomResponseResponseHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name AwsWafv2WebAcl#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#value AwsWafv2WebAcl#value}
        */
        readonly value: string;
    }
    class RuleActionBlockCustomResponseResponseHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleActionBlockCustomResponseResponseHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleActionBlockCustomResponseResponseHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RuleActionBlockCustomResponseResponseHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: RuleActionBlockCustomResponseResponseHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleActionBlockCustomResponseResponseHeaderPropertyOutputReference;
    }
    interface RuleActionBlockCustomResponseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_response_body_key AwsWafv2WebAcl#custom_response_body_key}
        */
        readonly customResponseBodyKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#response_code AwsWafv2WebAcl#response_code}
        */
        readonly responseCode: number;
        /**
        * response_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#response_header AwsWafv2WebAcl#response_header}
        */
        readonly responseHeader?: RuleActionBlockCustomResponseResponseHeaderProperty[] | cdktn.IResolvable;
    }
    class RuleActionBlockCustomResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionBlockCustomResponseProperty | undefined;
        set internalValue(value: RuleActionBlockCustomResponseProperty | undefined);
        private _customResponseBodyKey?;
        get customResponseBodyKey(): string;
        set customResponseBodyKey(value: string);
        resetCustomResponseBodyKey(): void;
        get customResponseBodyKeyInput(): string | undefined;
        private _responseCode?;
        get responseCode(): number;
        set responseCode(value: number);
        get responseCodeInput(): number | undefined;
        private _responseHeader;
        get responseHeader(): RuleActionBlockCustomResponseResponseHeaderPropertyList;
        putResponseHeader(value: RuleActionBlockCustomResponseResponseHeaderProperty[] | cdktn.IResolvable): void;
        resetResponseHeader(): void;
        get responseHeaderInput(): cdktn.IResolvable | RuleActionBlockCustomResponseResponseHeaderProperty[] | undefined;
    }
    interface RuleActionBlockProperty {
        /**
        * custom_response block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_response AwsWafv2WebAcl#custom_response}
        */
        readonly customResponse?: RuleActionBlockCustomResponseProperty;
    }
    class RuleActionBlockPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionBlockProperty | undefined;
        set internalValue(value: RuleActionBlockProperty | undefined);
        private _customResponse;
        get customResponse(): RuleActionBlockCustomResponsePropertyOutputReference;
        putCustomResponse(value: RuleActionBlockCustomResponseProperty): void;
        resetCustomResponse(): void;
        get customResponseInput(): RuleActionBlockCustomResponseProperty | undefined;
    }
    interface RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name AwsWafv2WebAcl#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#value AwsWafv2WebAcl#value}
        */
        readonly value: string;
    }
    class RuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RuleActionCaptchaCustomRequestHandlingProperty {
        /**
        * insert_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#insert_header AwsWafv2WebAcl#insert_header}
        */
        readonly insertHeader: RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
    }
    class RuleActionCaptchaCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionCaptchaCustomRequestHandlingProperty | undefined;
        set internalValue(value: RuleActionCaptchaCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyList;
        putInsertHeader(value: RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable): void;
        get insertHeaderInput(): cdktn.IResolvable | RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty[] | undefined;
    }
    interface CaptchaProperty {
        /**
        * custom_request_handling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_request_handling AwsWafv2WebAcl#custom_request_handling}
        */
        readonly customRequestHandling?: RuleActionCaptchaCustomRequestHandlingProperty;
    }
    class CaptchaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CaptchaProperty | undefined;
        set internalValue(value: CaptchaProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RuleActionCaptchaCustomRequestHandlingPropertyOutputReference;
        putCustomRequestHandling(value: RuleActionCaptchaCustomRequestHandlingProperty): void;
        resetCustomRequestHandling(): void;
        get customRequestHandlingInput(): RuleActionCaptchaCustomRequestHandlingProperty | undefined;
    }
    interface RuleActionChallengeCustomRequestHandlingInsertHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name AwsWafv2WebAcl#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#value AwsWafv2WebAcl#value}
        */
        readonly value: string;
    }
    class RuleActionChallengeCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleActionChallengeCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleActionChallengeCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RuleActionChallengeCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: RuleActionChallengeCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleActionChallengeCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RuleActionChallengeCustomRequestHandlingProperty {
        /**
        * insert_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#insert_header AwsWafv2WebAcl#insert_header}
        */
        readonly insertHeader: RuleActionChallengeCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
    }
    class RuleActionChallengeCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionChallengeCustomRequestHandlingProperty | undefined;
        set internalValue(value: RuleActionChallengeCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RuleActionChallengeCustomRequestHandlingInsertHeaderPropertyList;
        putInsertHeader(value: RuleActionChallengeCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable): void;
        get insertHeaderInput(): cdktn.IResolvable | RuleActionChallengeCustomRequestHandlingInsertHeaderProperty[] | undefined;
    }
    interface ChallengeProperty {
        /**
        * custom_request_handling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_request_handling AwsWafv2WebAcl#custom_request_handling}
        */
        readonly customRequestHandling?: RuleActionChallengeCustomRequestHandlingProperty;
    }
    class ChallengePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ChallengeProperty | undefined;
        set internalValue(value: ChallengeProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RuleActionChallengeCustomRequestHandlingPropertyOutputReference;
        putCustomRequestHandling(value: RuleActionChallengeCustomRequestHandlingProperty): void;
        resetCustomRequestHandling(): void;
        get customRequestHandlingInput(): RuleActionChallengeCustomRequestHandlingProperty | undefined;
    }
    interface RuleActionCountCustomRequestHandlingInsertHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name AwsWafv2WebAcl#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#value AwsWafv2WebAcl#value}
        */
        readonly value: string;
    }
    class RuleActionCountCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleActionCountCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleActionCountCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RuleActionCountCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: RuleActionCountCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleActionCountCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RuleActionCountCustomRequestHandlingProperty {
        /**
        * insert_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#insert_header AwsWafv2WebAcl#insert_header}
        */
        readonly insertHeader: RuleActionCountCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
    }
    class RuleActionCountCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionCountCustomRequestHandlingProperty | undefined;
        set internalValue(value: RuleActionCountCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RuleActionCountCustomRequestHandlingInsertHeaderPropertyList;
        putInsertHeader(value: RuleActionCountCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable): void;
        get insertHeaderInput(): cdktn.IResolvable | RuleActionCountCustomRequestHandlingInsertHeaderProperty[] | undefined;
    }
    interface RuleActionCountProperty {
        /**
        * custom_request_handling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#custom_request_handling AwsWafv2WebAcl#custom_request_handling}
        */
        readonly customRequestHandling?: RuleActionCountCustomRequestHandlingProperty;
    }
    class RuleActionCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionCountProperty | undefined;
        set internalValue(value: RuleActionCountProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RuleActionCountCustomRequestHandlingPropertyOutputReference;
        putCustomRequestHandling(value: RuleActionCountCustomRequestHandlingProperty): void;
        resetCustomRequestHandling(): void;
        get customRequestHandlingInput(): RuleActionCountCustomRequestHandlingProperty | undefined;
    }
    interface ActionProperty {
        /**
        * allow block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#allow AwsWafv2WebAcl#allow}
        */
        readonly allow?: RuleActionAllowProperty;
        /**
        * block block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#block AwsWafv2WebAcl#block}
        */
        readonly block?: RuleActionBlockProperty;
        /**
        * captcha block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#captcha AwsWafv2WebAcl#captcha}
        */
        readonly captcha?: CaptchaProperty;
        /**
        * challenge block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#challenge AwsWafv2WebAcl#challenge}
        */
        readonly challenge?: ChallengeProperty;
        /**
        * count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#count AwsWafv2WebAcl#count}
        */
        readonly count?: RuleActionCountProperty;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionProperty | undefined;
        set internalValue(value: ActionProperty | undefined);
        private _allow;
        get allow(): RuleActionAllowPropertyOutputReference;
        putAllow(value: RuleActionAllowProperty): void;
        resetAllow(): void;
        get allowInput(): RuleActionAllowProperty | undefined;
        private _block;
        get block(): RuleActionBlockPropertyOutputReference;
        putBlock(value: RuleActionBlockProperty): void;
        resetBlock(): void;
        get blockInput(): RuleActionBlockProperty | undefined;
        private _captcha;
        get captcha(): CaptchaPropertyOutputReference;
        putCaptcha(value: CaptchaProperty): void;
        resetCaptcha(): void;
        get captchaInput(): CaptchaProperty | undefined;
        private _challenge;
        get challenge(): ChallengePropertyOutputReference;
        putChallenge(value: ChallengeProperty): void;
        resetChallenge(): void;
        get challengeInput(): ChallengeProperty | undefined;
        private _count;
        get count(): RuleActionCountPropertyOutputReference;
        putCount(value: RuleActionCountProperty): void;
        resetCount(): void;
        get countInput(): RuleActionCountProperty | undefined;
    }
    interface RuleCaptchaConfigImmunityTimePropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#immunity_time AwsWafv2WebAcl#immunity_time}
        */
        readonly immunityTime?: number;
    }
    class RuleCaptchaConfigImmunityTimePropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleCaptchaConfigImmunityTimePropertyProperty | undefined;
        set internalValue(value: RuleCaptchaConfigImmunityTimePropertyProperty | undefined);
        private _immunityTime?;
        get immunityTime(): number;
        set immunityTime(value: number);
        resetImmunityTime(): void;
        get immunityTimeInput(): number | undefined;
    }
    interface RuleCaptchaConfigProperty {
        /**
        * immunity_time_property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#immunity_time_property AwsWafv2WebAcl#immunity_time_property}
        */
        readonly immunityTimeProperty?: RuleCaptchaConfigImmunityTimePropertyProperty;
    }
    class RuleCaptchaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleCaptchaConfigProperty | undefined;
        set internalValue(value: RuleCaptchaConfigProperty | undefined);
        private _immunityTimeProperty;
        get immunityTimeProperty(): RuleCaptchaConfigImmunityTimePropertyPropertyOutputReference;
        putImmunityTimeProperty(value: RuleCaptchaConfigImmunityTimePropertyProperty): void;
        resetImmunityTimeProperty(): void;
        get immunityTimePropertyInput(): RuleCaptchaConfigImmunityTimePropertyProperty | undefined;
    }
    interface RuleChallengeConfigImmunityTimePropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#immunity_time AwsWafv2WebAcl#immunity_time}
        */
        readonly immunityTime?: number;
    }
    class RuleChallengeConfigImmunityTimePropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleChallengeConfigImmunityTimePropertyProperty | undefined;
        set internalValue(value: RuleChallengeConfigImmunityTimePropertyProperty | undefined);
        private _immunityTime?;
        get immunityTime(): number;
        set immunityTime(value: number);
        resetImmunityTime(): void;
        get immunityTimeInput(): number | undefined;
    }
    interface RuleChallengeConfigProperty {
        /**
        * immunity_time_property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#immunity_time_property AwsWafv2WebAcl#immunity_time_property}
        */
        readonly immunityTimeProperty?: RuleChallengeConfigImmunityTimePropertyProperty;
    }
    class RuleChallengeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleChallengeConfigProperty | undefined;
        set internalValue(value: RuleChallengeConfigProperty | undefined);
        private _immunityTimeProperty;
        get immunityTimeProperty(): RuleChallengeConfigImmunityTimePropertyPropertyOutputReference;
        putImmunityTimeProperty(value: RuleChallengeConfigImmunityTimePropertyProperty): void;
        resetImmunityTimeProperty(): void;
        get immunityTimePropertyInput(): RuleChallengeConfigImmunityTimePropertyProperty | undefined;
    }
    interface RuleOverrideActionCountProperty {
    }
    class RuleOverrideActionCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleOverrideActionCountProperty | undefined;
        set internalValue(value: RuleOverrideActionCountProperty | undefined);
    }
    interface NoneProperty {
    }
    class NonePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NoneProperty | undefined;
        set internalValue(value: NoneProperty | undefined);
    }
    interface OverrideActionProperty {
        /**
        * count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#count AwsWafv2WebAcl#count}
        */
        readonly count?: RuleOverrideActionCountProperty;
        /**
        * none block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#none AwsWafv2WebAcl#none}
        */
        readonly none?: NoneProperty;
    }
    class OverrideActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OverrideActionProperty | undefined;
        set internalValue(value: OverrideActionProperty | undefined);
        private _count;
        get count(): RuleOverrideActionCountPropertyOutputReference;
        putCount(value: RuleOverrideActionCountProperty): void;
        resetCount(): void;
        get countInput(): RuleOverrideActionCountProperty | undefined;
        private _none;
        get none(): NonePropertyOutputReference;
        putNone(value: NoneProperty): void;
        resetNone(): void;
        get noneInput(): NoneProperty | undefined;
    }
    interface RuleLabelProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name AwsWafv2WebAcl#name}
        */
        readonly name: string;
    }
    class RuleLabelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleLabelProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleLabelProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class RuleLabelPropertyList extends cdktn.ComplexList {
        internalValue?: RuleLabelProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleLabelPropertyOutputReference;
    }
    interface RuleVisibilityConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#cloudwatch_metrics_enabled AwsWafv2WebAcl#cloudwatch_metrics_enabled}
        */
        readonly cloudwatchMetricsEnabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#metric_name AwsWafv2WebAcl#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#sampled_requests_enabled AwsWafv2WebAcl#sampled_requests_enabled}
        */
        readonly sampledRequestsEnabled: boolean | cdktn.IResolvable;
    }
    class RuleVisibilityConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleVisibilityConfigProperty | undefined;
        set internalValue(value: RuleVisibilityConfigProperty | undefined);
        private _cloudwatchMetricsEnabled?;
        get cloudwatchMetricsEnabled(): boolean | cdktn.IResolvable;
        set cloudwatchMetricsEnabled(value: boolean | cdktn.IResolvable);
        get cloudwatchMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _sampledRequestsEnabled?;
        get sampledRequestsEnabled(): boolean | cdktn.IResolvable;
        set sampledRequestsEnabled(value: boolean | cdktn.IResolvable);
        get sampledRequestsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#name AwsWafv2WebAcl#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#priority AwsWafv2WebAcl#priority}
        */
        readonly priority: number;
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#action AwsWafv2WebAcl#action}
        */
        readonly action?: ActionProperty;
        /**
        * captcha_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#captcha_config AwsWafv2WebAcl#captcha_config}
        */
        readonly captchaConfig?: RuleCaptchaConfigProperty;
        /**
        * challenge_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#challenge_config AwsWafv2WebAcl#challenge_config}
        */
        readonly challengeConfig?: RuleChallengeConfigProperty;
        /**
        * override_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#override_action AwsWafv2WebAcl#override_action}
        */
        readonly overrideAction?: OverrideActionProperty;
        /**
        * rule_label block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#rule_label AwsWafv2WebAcl#rule_label}
        */
        readonly ruleLabel?: RuleLabelProperty[] | cdktn.IResolvable;
        /**
        * statement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#statement AwsWafv2WebAcl#statement}
        */
        readonly statement?: any;
        /**
        * visibility_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#visibility_config AwsWafv2WebAcl#visibility_config}
        */
        readonly visibilityConfig: RuleVisibilityConfigProperty;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        get priorityInput(): number | undefined;
        private _action;
        get action(): ActionPropertyOutputReference;
        putAction(value: ActionProperty): void;
        resetAction(): void;
        get actionInput(): ActionProperty | undefined;
        private _captchaConfig;
        get captchaConfig(): RuleCaptchaConfigPropertyOutputReference;
        putCaptchaConfig(value: RuleCaptchaConfigProperty): void;
        resetCaptchaConfig(): void;
        get captchaConfigInput(): RuleCaptchaConfigProperty | undefined;
        private _challengeConfig;
        get challengeConfig(): RuleChallengeConfigPropertyOutputReference;
        putChallengeConfig(value: RuleChallengeConfigProperty): void;
        resetChallengeConfig(): void;
        get challengeConfigInput(): RuleChallengeConfigProperty | undefined;
        private _overrideAction;
        get overrideAction(): OverrideActionPropertyOutputReference;
        putOverrideAction(value: OverrideActionProperty): void;
        resetOverrideAction(): void;
        get overrideActionInput(): OverrideActionProperty | undefined;
        private _ruleLabel;
        get ruleLabel(): RuleLabelPropertyList;
        putRuleLabel(value: RuleLabelProperty[] | cdktn.IResolvable): void;
        resetRuleLabel(): void;
        get ruleLabelInput(): cdktn.IResolvable | RuleLabelProperty[] | undefined;
        private _statement?;
        get statement(): any;
        set statement(value: any);
        resetStatement(): void;
        get statementInput(): any;
        private _visibilityConfig;
        get visibilityConfig(): RuleVisibilityConfigPropertyOutputReference;
        putVisibilityConfig(value: RuleVisibilityConfigProperty): void;
        get visibilityConfigInput(): RuleVisibilityConfigProperty | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
    interface VisibilityConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#cloudwatch_metrics_enabled AwsWafv2WebAcl#cloudwatch_metrics_enabled}
        */
        readonly cloudwatchMetricsEnabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#metric_name AwsWafv2WebAcl#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_web_acl#sampled_requests_enabled AwsWafv2WebAcl#sampled_requests_enabled}
        */
        readonly sampledRequestsEnabled: boolean | cdktn.IResolvable;
    }
    class VisibilityConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VisibilityConfigProperty | undefined;
        set internalValue(value: VisibilityConfigProperty | undefined);
        private _cloudwatchMetricsEnabled?;
        get cloudwatchMetricsEnabled(): boolean | cdktn.IResolvable;
        set cloudwatchMetricsEnabled(value: boolean | cdktn.IResolvable);
        get cloudwatchMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _sampledRequestsEnabled?;
        get sampledRequestsEnabled(): boolean | cdktn.IResolvable;
        set sampledRequestsEnabled(value: boolean | cdktn.IResolvable);
        get sampledRequestsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
}
