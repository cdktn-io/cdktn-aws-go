import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWafv2RuleGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#capacity AwsWafv2RuleGroup#capacity}
    */
    readonly capacity: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#description AwsWafv2RuleGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#id AwsWafv2RuleGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#name AwsWafv2RuleGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#name_prefix AwsWafv2RuleGroup#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#region AwsWafv2RuleGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#rules_json AwsWafv2RuleGroup#rules_json}
    */
    readonly rulesJson?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#scope AwsWafv2RuleGroup#scope}
    */
    readonly scope: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#tags AwsWafv2RuleGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#tags_all AwsWafv2RuleGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * custom_response_body block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#custom_response_body AwsWafv2RuleGroup#custom_response_body}
    */
    readonly customResponseBody?: AwsWafv2RuleGroup.CustomResponseBodyProperty[] | cdktn.IResolvable;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#rule AwsWafv2RuleGroup#rule}
    */
    readonly rule?: AwsWafv2RuleGroup.RuleProperty[] | cdktn.IResolvable;
    /**
    * visibility_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#visibility_config AwsWafv2RuleGroup#visibility_config}
    */
    readonly visibilityConfig: AwsWafv2RuleGroup.VisibilityConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group aws_wafv2_rule_group}
*/
export declare class AwsWafv2RuleGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_wafv2_rule_group";
    /**
    * Generates CDKTN code for importing a AwsWafv2RuleGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWafv2RuleGroup to import
    * @param importFromId The id of the existing AwsWafv2RuleGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWafv2RuleGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group aws_wafv2_rule_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWafv2RuleGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsWafv2RuleGroupConfig);
    get arn(): string;
    private _capacity?;
    get capacity(): number;
    set capacity(value: number);
    get capacityInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lockToken(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rulesJson?;
    get rulesJson(): string;
    set rulesJson(value: string);
    resetRulesJson(): void;
    get rulesJsonInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _customResponseBody;
    get customResponseBody(): AwsWafv2RuleGroup.CustomResponseBodyPropertyList;
    putCustomResponseBody(value: AwsWafv2RuleGroup.CustomResponseBodyProperty[] | cdktn.IResolvable): void;
    resetCustomResponseBody(): void;
    get customResponseBodyInput(): cdktn.IResolvable | AwsWafv2RuleGroup.CustomResponseBodyProperty[] | undefined;
    private _rule;
    get rule(): AwsWafv2RuleGroup.RulePropertyList;
    putRule(value: AwsWafv2RuleGroup.RuleProperty[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | AwsWafv2RuleGroup.RuleProperty[] | undefined;
    private _visibilityConfig;
    get visibilityConfig(): AwsWafv2RuleGroup.VisibilityConfigPropertyOutputReference;
    putVisibilityConfig(value: AwsWafv2RuleGroup.VisibilityConfigProperty): void;
    get visibilityConfigInput(): AwsWafv2RuleGroup.VisibilityConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWafv2RuleGroupCustomResponseBodyPropertyToTerraform(struct?: AwsWafv2RuleGroup.CustomResponseBodyProperty | cdktn.IResolvable): any;
export declare function awsWafv2RuleGroupCustomResponseBodyPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.CustomResponseBodyProperty | cdktn.IResolvable): any;
export declare function awsWafv2RuleGroupRuleActionAllowCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: AwsWafv2RuleGroup.RuleActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2RuleGroupRuleActionAllowCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.RuleActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2RuleGroupRuleActionAllowCustomRequestHandlingPropertyToTerraform(struct?: AwsWafv2RuleGroup.RuleActionAllowCustomRequestHandlingPropertyOutputReference | AwsWafv2RuleGroup.RuleActionAllowCustomRequestHandlingProperty): any;
export declare function awsWafv2RuleGroupRuleActionAllowCustomRequestHandlingPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.RuleActionAllowCustomRequestHandlingPropertyOutputReference | AwsWafv2RuleGroup.RuleActionAllowCustomRequestHandlingProperty): any;
export declare function awsWafv2RuleGroupAllowPropertyToTerraform(struct?: AwsWafv2RuleGroup.AllowPropertyOutputReference | AwsWafv2RuleGroup.AllowProperty): any;
export declare function awsWafv2RuleGroupAllowPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.AllowPropertyOutputReference | AwsWafv2RuleGroup.AllowProperty): any;
export declare function awsWafv2RuleGroupResponseHeaderPropertyToTerraform(struct?: AwsWafv2RuleGroup.ResponseHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2RuleGroupResponseHeaderPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.ResponseHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2RuleGroupCustomResponsePropertyToTerraform(struct?: AwsWafv2RuleGroup.CustomResponsePropertyOutputReference | AwsWafv2RuleGroup.CustomResponseProperty): any;
export declare function awsWafv2RuleGroupCustomResponsePropertyToHclTerraform(struct?: AwsWafv2RuleGroup.CustomResponsePropertyOutputReference | AwsWafv2RuleGroup.CustomResponseProperty): any;
export declare function awsWafv2RuleGroupBlockPropertyToTerraform(struct?: AwsWafv2RuleGroup.BlockPropertyOutputReference | AwsWafv2RuleGroup.BlockProperty): any;
export declare function awsWafv2RuleGroupBlockPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.BlockPropertyOutputReference | AwsWafv2RuleGroup.BlockProperty): any;
export declare function awsWafv2RuleGroupRuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: AwsWafv2RuleGroup.RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2RuleGroupRuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2RuleGroupRuleActionCaptchaCustomRequestHandlingPropertyToTerraform(struct?: AwsWafv2RuleGroup.RuleActionCaptchaCustomRequestHandlingPropertyOutputReference | AwsWafv2RuleGroup.RuleActionCaptchaCustomRequestHandlingProperty): any;
export declare function awsWafv2RuleGroupRuleActionCaptchaCustomRequestHandlingPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.RuleActionCaptchaCustomRequestHandlingPropertyOutputReference | AwsWafv2RuleGroup.RuleActionCaptchaCustomRequestHandlingProperty): any;
export declare function awsWafv2RuleGroupCaptchaPropertyToTerraform(struct?: AwsWafv2RuleGroup.CaptchaPropertyOutputReference | AwsWafv2RuleGroup.CaptchaProperty): any;
export declare function awsWafv2RuleGroupCaptchaPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.CaptchaPropertyOutputReference | AwsWafv2RuleGroup.CaptchaProperty): any;
export declare function awsWafv2RuleGroupRuleActionChallengeCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: AwsWafv2RuleGroup.RuleActionChallengeCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2RuleGroupRuleActionChallengeCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.RuleActionChallengeCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2RuleGroupRuleActionChallengeCustomRequestHandlingPropertyToTerraform(struct?: AwsWafv2RuleGroup.RuleActionChallengeCustomRequestHandlingPropertyOutputReference | AwsWafv2RuleGroup.RuleActionChallengeCustomRequestHandlingProperty): any;
export declare function awsWafv2RuleGroupRuleActionChallengeCustomRequestHandlingPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.RuleActionChallengeCustomRequestHandlingPropertyOutputReference | AwsWafv2RuleGroup.RuleActionChallengeCustomRequestHandlingProperty): any;
export declare function awsWafv2RuleGroupChallengePropertyToTerraform(struct?: AwsWafv2RuleGroup.ChallengePropertyOutputReference | AwsWafv2RuleGroup.ChallengeProperty): any;
export declare function awsWafv2RuleGroupChallengePropertyToHclTerraform(struct?: AwsWafv2RuleGroup.ChallengePropertyOutputReference | AwsWafv2RuleGroup.ChallengeProperty): any;
export declare function awsWafv2RuleGroupRuleActionCountCustomRequestHandlingInsertHeaderPropertyToTerraform(struct?: AwsWafv2RuleGroup.RuleActionCountCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2RuleGroupRuleActionCountCustomRequestHandlingInsertHeaderPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.RuleActionCountCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable): any;
export declare function awsWafv2RuleGroupRuleActionCountCustomRequestHandlingPropertyToTerraform(struct?: AwsWafv2RuleGroup.RuleActionCountCustomRequestHandlingPropertyOutputReference | AwsWafv2RuleGroup.RuleActionCountCustomRequestHandlingProperty): any;
export declare function awsWafv2RuleGroupRuleActionCountCustomRequestHandlingPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.RuleActionCountCustomRequestHandlingPropertyOutputReference | AwsWafv2RuleGroup.RuleActionCountCustomRequestHandlingProperty): any;
export declare function awsWafv2RuleGroupCountPropertyToTerraform(struct?: AwsWafv2RuleGroup.CountPropertyOutputReference | AwsWafv2RuleGroup.CountProperty): any;
export declare function awsWafv2RuleGroupCountPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.CountPropertyOutputReference | AwsWafv2RuleGroup.CountProperty): any;
export declare function awsWafv2RuleGroupActionPropertyToTerraform(struct?: AwsWafv2RuleGroup.ActionPropertyOutputReference | AwsWafv2RuleGroup.ActionProperty): any;
export declare function awsWafv2RuleGroupActionPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.ActionPropertyOutputReference | AwsWafv2RuleGroup.ActionProperty): any;
export declare function awsWafv2RuleGroupImmunityTimePropertyPropertyToTerraform(struct?: AwsWafv2RuleGroup.ImmunityTimePropertyPropertyOutputReference | AwsWafv2RuleGroup.ImmunityTimePropertyProperty): any;
export declare function awsWafv2RuleGroupImmunityTimePropertyPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.ImmunityTimePropertyPropertyOutputReference | AwsWafv2RuleGroup.ImmunityTimePropertyProperty): any;
export declare function awsWafv2RuleGroupCaptchaConfigPropertyToTerraform(struct?: AwsWafv2RuleGroup.CaptchaConfigPropertyOutputReference | AwsWafv2RuleGroup.CaptchaConfigProperty): any;
export declare function awsWafv2RuleGroupCaptchaConfigPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.CaptchaConfigPropertyOutputReference | AwsWafv2RuleGroup.CaptchaConfigProperty): any;
export declare function awsWafv2RuleGroupRuleLabelPropertyToTerraform(struct?: AwsWafv2RuleGroup.RuleLabelProperty | cdktn.IResolvable): any;
export declare function awsWafv2RuleGroupRuleLabelPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.RuleLabelProperty | cdktn.IResolvable): any;
export declare function awsWafv2RuleGroupRuleVisibilityConfigPropertyToTerraform(struct?: AwsWafv2RuleGroup.RuleVisibilityConfigPropertyOutputReference | AwsWafv2RuleGroup.RuleVisibilityConfigProperty): any;
export declare function awsWafv2RuleGroupRuleVisibilityConfigPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.RuleVisibilityConfigPropertyOutputReference | AwsWafv2RuleGroup.RuleVisibilityConfigProperty): any;
export declare function awsWafv2RuleGroupRulePropertyToTerraform(struct?: AwsWafv2RuleGroup.RuleProperty | cdktn.IResolvable): any;
export declare function awsWafv2RuleGroupRulePropertyToHclTerraform(struct?: AwsWafv2RuleGroup.RuleProperty | cdktn.IResolvable): any;
export declare function awsWafv2RuleGroupVisibilityConfigPropertyToTerraform(struct?: AwsWafv2RuleGroup.VisibilityConfigPropertyOutputReference | AwsWafv2RuleGroup.VisibilityConfigProperty): any;
export declare function awsWafv2RuleGroupVisibilityConfigPropertyToHclTerraform(struct?: AwsWafv2RuleGroup.VisibilityConfigPropertyOutputReference | AwsWafv2RuleGroup.VisibilityConfigProperty): any;
export declare namespace AwsWafv2RuleGroup {
    interface CustomResponseBodyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#content AwsWafv2RuleGroup#content}
        */
        readonly content: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#content_type AwsWafv2RuleGroup#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#key AwsWafv2RuleGroup#key}
        */
        readonly key: string;
    }
    class CustomResponseBodyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomResponseBodyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomResponseBodyProperty | cdktn.IResolvable | undefined);
        private _content?;
        get content(): string;
        set content(value: string);
        get contentInput(): string | undefined;
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
    }
    class CustomResponseBodyPropertyList extends cdktn.ComplexList {
        internalValue?: CustomResponseBodyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomResponseBodyPropertyOutputReference;
    }
    interface RuleActionAllowCustomRequestHandlingInsertHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#name AwsWafv2RuleGroup#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#value AwsWafv2RuleGroup#value}
        */
        readonly value: string;
    }
    class RuleActionAllowCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleActionAllowCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RuleActionAllowCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: RuleActionAllowCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleActionAllowCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RuleActionAllowCustomRequestHandlingProperty {
        /**
        * insert_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#insert_header AwsWafv2RuleGroup#insert_header}
        */
        readonly insertHeader: RuleActionAllowCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
    }
    class RuleActionAllowCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionAllowCustomRequestHandlingProperty | undefined;
        set internalValue(value: RuleActionAllowCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RuleActionAllowCustomRequestHandlingInsertHeaderPropertyList;
        putInsertHeader(value: RuleActionAllowCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable): void;
        get insertHeaderInput(): cdktn.IResolvable | RuleActionAllowCustomRequestHandlingInsertHeaderProperty[] | undefined;
    }
    interface AllowProperty {
        /**
        * custom_request_handling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#custom_request_handling AwsWafv2RuleGroup#custom_request_handling}
        */
        readonly customRequestHandling?: RuleActionAllowCustomRequestHandlingProperty;
    }
    class AllowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AllowProperty | undefined;
        set internalValue(value: AllowProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RuleActionAllowCustomRequestHandlingPropertyOutputReference;
        putCustomRequestHandling(value: RuleActionAllowCustomRequestHandlingProperty): void;
        resetCustomRequestHandling(): void;
        get customRequestHandlingInput(): RuleActionAllowCustomRequestHandlingProperty | undefined;
    }
    interface ResponseHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#name AwsWafv2RuleGroup#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#value AwsWafv2RuleGroup#value}
        */
        readonly value: string;
    }
    class ResponseHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResponseHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResponseHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResponseHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: ResponseHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResponseHeaderPropertyOutputReference;
    }
    interface CustomResponseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#custom_response_body_key AwsWafv2RuleGroup#custom_response_body_key}
        */
        readonly customResponseBodyKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#response_code AwsWafv2RuleGroup#response_code}
        */
        readonly responseCode: number;
        /**
        * response_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#response_header AwsWafv2RuleGroup#response_header}
        */
        readonly responseHeader?: ResponseHeaderProperty[] | cdktn.IResolvable;
    }
    class CustomResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomResponseProperty | undefined;
        set internalValue(value: CustomResponseProperty | undefined);
        private _customResponseBodyKey?;
        get customResponseBodyKey(): string;
        set customResponseBodyKey(value: string);
        resetCustomResponseBodyKey(): void;
        get customResponseBodyKeyInput(): string | undefined;
        private _responseCode?;
        get responseCode(): number;
        set responseCode(value: number);
        get responseCodeInput(): number | undefined;
        private _responseHeader;
        get responseHeader(): ResponseHeaderPropertyList;
        putResponseHeader(value: ResponseHeaderProperty[] | cdktn.IResolvable): void;
        resetResponseHeader(): void;
        get responseHeaderInput(): cdktn.IResolvable | ResponseHeaderProperty[] | undefined;
    }
    interface BlockProperty {
        /**
        * custom_response block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#custom_response AwsWafv2RuleGroup#custom_response}
        */
        readonly customResponse?: CustomResponseProperty;
    }
    class BlockPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BlockProperty | undefined;
        set internalValue(value: BlockProperty | undefined);
        private _customResponse;
        get customResponse(): CustomResponsePropertyOutputReference;
        putCustomResponse(value: CustomResponseProperty): void;
        resetCustomResponse(): void;
        get customResponseInput(): CustomResponseProperty | undefined;
    }
    interface RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#name AwsWafv2RuleGroup#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#value AwsWafv2RuleGroup#value}
        */
        readonly value: string;
    }
    class RuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RuleActionCaptchaCustomRequestHandlingProperty {
        /**
        * insert_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#insert_header AwsWafv2RuleGroup#insert_header}
        */
        readonly insertHeader: RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
    }
    class RuleActionCaptchaCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionCaptchaCustomRequestHandlingProperty | undefined;
        set internalValue(value: RuleActionCaptchaCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RuleActionCaptchaCustomRequestHandlingInsertHeaderPropertyList;
        putInsertHeader(value: RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable): void;
        get insertHeaderInput(): cdktn.IResolvable | RuleActionCaptchaCustomRequestHandlingInsertHeaderProperty[] | undefined;
    }
    interface CaptchaProperty {
        /**
        * custom_request_handling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#custom_request_handling AwsWafv2RuleGroup#custom_request_handling}
        */
        readonly customRequestHandling?: RuleActionCaptchaCustomRequestHandlingProperty;
    }
    class CaptchaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CaptchaProperty | undefined;
        set internalValue(value: CaptchaProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RuleActionCaptchaCustomRequestHandlingPropertyOutputReference;
        putCustomRequestHandling(value: RuleActionCaptchaCustomRequestHandlingProperty): void;
        resetCustomRequestHandling(): void;
        get customRequestHandlingInput(): RuleActionCaptchaCustomRequestHandlingProperty | undefined;
    }
    interface RuleActionChallengeCustomRequestHandlingInsertHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#name AwsWafv2RuleGroup#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#value AwsWafv2RuleGroup#value}
        */
        readonly value: string;
    }
    class RuleActionChallengeCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleActionChallengeCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleActionChallengeCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RuleActionChallengeCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: RuleActionChallengeCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleActionChallengeCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RuleActionChallengeCustomRequestHandlingProperty {
        /**
        * insert_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#insert_header AwsWafv2RuleGroup#insert_header}
        */
        readonly insertHeader: RuleActionChallengeCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
    }
    class RuleActionChallengeCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionChallengeCustomRequestHandlingProperty | undefined;
        set internalValue(value: RuleActionChallengeCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RuleActionChallengeCustomRequestHandlingInsertHeaderPropertyList;
        putInsertHeader(value: RuleActionChallengeCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable): void;
        get insertHeaderInput(): cdktn.IResolvable | RuleActionChallengeCustomRequestHandlingInsertHeaderProperty[] | undefined;
    }
    interface ChallengeProperty {
        /**
        * custom_request_handling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#custom_request_handling AwsWafv2RuleGroup#custom_request_handling}
        */
        readonly customRequestHandling?: RuleActionChallengeCustomRequestHandlingProperty;
    }
    class ChallengePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ChallengeProperty | undefined;
        set internalValue(value: ChallengeProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RuleActionChallengeCustomRequestHandlingPropertyOutputReference;
        putCustomRequestHandling(value: RuleActionChallengeCustomRequestHandlingProperty): void;
        resetCustomRequestHandling(): void;
        get customRequestHandlingInput(): RuleActionChallengeCustomRequestHandlingProperty | undefined;
    }
    interface RuleActionCountCustomRequestHandlingInsertHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#name AwsWafv2RuleGroup#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#value AwsWafv2RuleGroup#value}
        */
        readonly value: string;
    }
    class RuleActionCountCustomRequestHandlingInsertHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleActionCountCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleActionCountCustomRequestHandlingInsertHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RuleActionCountCustomRequestHandlingInsertHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: RuleActionCountCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleActionCountCustomRequestHandlingInsertHeaderPropertyOutputReference;
    }
    interface RuleActionCountCustomRequestHandlingProperty {
        /**
        * insert_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#insert_header AwsWafv2RuleGroup#insert_header}
        */
        readonly insertHeader: RuleActionCountCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable;
    }
    class RuleActionCountCustomRequestHandlingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleActionCountCustomRequestHandlingProperty | undefined;
        set internalValue(value: RuleActionCountCustomRequestHandlingProperty | undefined);
        private _insertHeader;
        get insertHeader(): RuleActionCountCustomRequestHandlingInsertHeaderPropertyList;
        putInsertHeader(value: RuleActionCountCustomRequestHandlingInsertHeaderProperty[] | cdktn.IResolvable): void;
        get insertHeaderInput(): cdktn.IResolvable | RuleActionCountCustomRequestHandlingInsertHeaderProperty[] | undefined;
    }
    interface CountProperty {
        /**
        * custom_request_handling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#custom_request_handling AwsWafv2RuleGroup#custom_request_handling}
        */
        readonly customRequestHandling?: RuleActionCountCustomRequestHandlingProperty;
    }
    class CountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CountProperty | undefined;
        set internalValue(value: CountProperty | undefined);
        private _customRequestHandling;
        get customRequestHandling(): RuleActionCountCustomRequestHandlingPropertyOutputReference;
        putCustomRequestHandling(value: RuleActionCountCustomRequestHandlingProperty): void;
        resetCustomRequestHandling(): void;
        get customRequestHandlingInput(): RuleActionCountCustomRequestHandlingProperty | undefined;
    }
    interface ActionProperty {
        /**
        * allow block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#allow AwsWafv2RuleGroup#allow}
        */
        readonly allow?: AllowProperty;
        /**
        * block block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#block AwsWafv2RuleGroup#block}
        */
        readonly block?: BlockProperty;
        /**
        * captcha block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#captcha AwsWafv2RuleGroup#captcha}
        */
        readonly captcha?: CaptchaProperty;
        /**
        * challenge block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#challenge AwsWafv2RuleGroup#challenge}
        */
        readonly challenge?: ChallengeProperty;
        /**
        * count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#count AwsWafv2RuleGroup#count}
        */
        readonly count?: CountProperty;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionProperty | undefined;
        set internalValue(value: ActionProperty | undefined);
        private _allow;
        get allow(): AllowPropertyOutputReference;
        putAllow(value: AllowProperty): void;
        resetAllow(): void;
        get allowInput(): AllowProperty | undefined;
        private _block;
        get block(): BlockPropertyOutputReference;
        putBlock(value: BlockProperty): void;
        resetBlock(): void;
        get blockInput(): BlockProperty | undefined;
        private _captcha;
        get captcha(): CaptchaPropertyOutputReference;
        putCaptcha(value: CaptchaProperty): void;
        resetCaptcha(): void;
        get captchaInput(): CaptchaProperty | undefined;
        private _challenge;
        get challenge(): ChallengePropertyOutputReference;
        putChallenge(value: ChallengeProperty): void;
        resetChallenge(): void;
        get challengeInput(): ChallengeProperty | undefined;
        private _count;
        get count(): CountPropertyOutputReference;
        putCount(value: CountProperty): void;
        resetCount(): void;
        get countInput(): CountProperty | undefined;
    }
    interface ImmunityTimePropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#immunity_time AwsWafv2RuleGroup#immunity_time}
        */
        readonly immunityTime?: number;
    }
    class ImmunityTimePropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImmunityTimePropertyProperty | undefined;
        set internalValue(value: ImmunityTimePropertyProperty | undefined);
        private _immunityTime?;
        get immunityTime(): number;
        set immunityTime(value: number);
        resetImmunityTime(): void;
        get immunityTimeInput(): number | undefined;
    }
    interface CaptchaConfigProperty {
        /**
        * immunity_time_property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#immunity_time_property AwsWafv2RuleGroup#immunity_time_property}
        */
        readonly immunityTimeProperty?: ImmunityTimePropertyProperty;
    }
    class CaptchaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CaptchaConfigProperty | undefined;
        set internalValue(value: CaptchaConfigProperty | undefined);
        private _immunityTimeProperty;
        get immunityTimeProperty(): ImmunityTimePropertyPropertyOutputReference;
        putImmunityTimeProperty(value: ImmunityTimePropertyProperty): void;
        resetImmunityTimeProperty(): void;
        get immunityTimePropertyInput(): ImmunityTimePropertyProperty | undefined;
    }
    interface RuleLabelProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#name AwsWafv2RuleGroup#name}
        */
        readonly name: string;
    }
    class RuleLabelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleLabelProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleLabelProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class RuleLabelPropertyList extends cdktn.ComplexList {
        internalValue?: RuleLabelProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleLabelPropertyOutputReference;
    }
    interface RuleVisibilityConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#cloudwatch_metrics_enabled AwsWafv2RuleGroup#cloudwatch_metrics_enabled}
        */
        readonly cloudwatchMetricsEnabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#metric_name AwsWafv2RuleGroup#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#sampled_requests_enabled AwsWafv2RuleGroup#sampled_requests_enabled}
        */
        readonly sampledRequestsEnabled: boolean | cdktn.IResolvable;
    }
    class RuleVisibilityConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleVisibilityConfigProperty | undefined;
        set internalValue(value: RuleVisibilityConfigProperty | undefined);
        private _cloudwatchMetricsEnabled?;
        get cloudwatchMetricsEnabled(): boolean | cdktn.IResolvable;
        set cloudwatchMetricsEnabled(value: boolean | cdktn.IResolvable);
        get cloudwatchMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _sampledRequestsEnabled?;
        get sampledRequestsEnabled(): boolean | cdktn.IResolvable;
        set sampledRequestsEnabled(value: boolean | cdktn.IResolvable);
        get sampledRequestsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#name AwsWafv2RuleGroup#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#priority AwsWafv2RuleGroup#priority}
        */
        readonly priority: number;
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#action AwsWafv2RuleGroup#action}
        */
        readonly action: ActionProperty;
        /**
        * captcha_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#captcha_config AwsWafv2RuleGroup#captcha_config}
        */
        readonly captchaConfig?: CaptchaConfigProperty;
        /**
        * rule_label block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#rule_label AwsWafv2RuleGroup#rule_label}
        */
        readonly ruleLabel?: RuleLabelProperty[] | cdktn.IResolvable;
        /**
        * statement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#statement AwsWafv2RuleGroup#statement}
        */
        readonly statement?: any;
        /**
        * visibility_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#visibility_config AwsWafv2RuleGroup#visibility_config}
        */
        readonly visibilityConfig: RuleVisibilityConfigProperty;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        get priorityInput(): number | undefined;
        private _action;
        get action(): ActionPropertyOutputReference;
        putAction(value: ActionProperty): void;
        get actionInput(): ActionProperty | undefined;
        private _captchaConfig;
        get captchaConfig(): CaptchaConfigPropertyOutputReference;
        putCaptchaConfig(value: CaptchaConfigProperty): void;
        resetCaptchaConfig(): void;
        get captchaConfigInput(): CaptchaConfigProperty | undefined;
        private _ruleLabel;
        get ruleLabel(): RuleLabelPropertyList;
        putRuleLabel(value: RuleLabelProperty[] | cdktn.IResolvable): void;
        resetRuleLabel(): void;
        get ruleLabelInput(): cdktn.IResolvable | RuleLabelProperty[] | undefined;
        private _statement?;
        get statement(): any;
        set statement(value: any);
        resetStatement(): void;
        get statementInput(): any;
        private _visibilityConfig;
        get visibilityConfig(): RuleVisibilityConfigPropertyOutputReference;
        putVisibilityConfig(value: RuleVisibilityConfigProperty): void;
        get visibilityConfigInput(): RuleVisibilityConfigProperty | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
    interface VisibilityConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#cloudwatch_metrics_enabled AwsWafv2RuleGroup#cloudwatch_metrics_enabled}
        */
        readonly cloudwatchMetricsEnabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#metric_name AwsWafv2RuleGroup#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_rule_group#sampled_requests_enabled AwsWafv2RuleGroup#sampled_requests_enabled}
        */
        readonly sampledRequestsEnabled: boolean | cdktn.IResolvable;
    }
    class VisibilityConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VisibilityConfigProperty | undefined;
        set internalValue(value: VisibilityConfigProperty | undefined);
        private _cloudwatchMetricsEnabled?;
        get cloudwatchMetricsEnabled(): boolean | cdktn.IResolvable;
        set cloudwatchMetricsEnabled(value: boolean | cdktn.IResolvable);
        get cloudwatchMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _sampledRequestsEnabled?;
        get sampledRequestsEnabled(): boolean | cdktn.IResolvable;
        set sampledRequestsEnabled(value: boolean | cdktn.IResolvable);
        get sampledRequestsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
}
