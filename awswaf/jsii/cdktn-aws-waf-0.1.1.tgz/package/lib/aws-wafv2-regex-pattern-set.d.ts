import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWafv2RegexPatternSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_regex_pattern_set#description AwsWafv2RegexPatternSet#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_regex_pattern_set#id AwsWafv2RegexPatternSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_regex_pattern_set#name AwsWafv2RegexPatternSet#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_regex_pattern_set#name_prefix AwsWafv2RegexPatternSet#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_regex_pattern_set#region AwsWafv2RegexPatternSet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_regex_pattern_set#scope AwsWafv2RegexPatternSet#scope}
    */
    readonly scope: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_regex_pattern_set#tags AwsWafv2RegexPatternSet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_regex_pattern_set#tags_all AwsWafv2RegexPatternSet#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * regular_expression block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_regex_pattern_set#regular_expression AwsWafv2RegexPatternSet#regular_expression}
    */
    readonly regularExpression?: AwsWafv2RegexPatternSet.RegularExpressionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_regex_pattern_set aws_wafv2_regex_pattern_set}
*/
export declare class AwsWafv2RegexPatternSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_wafv2_regex_pattern_set";
    /**
    * Generates CDKTN code for importing a AwsWafv2RegexPatternSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWafv2RegexPatternSet to import
    * @param importFromId The id of the existing AwsWafv2RegexPatternSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_regex_pattern_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWafv2RegexPatternSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_regex_pattern_set aws_wafv2_regex_pattern_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWafv2RegexPatternSetConfig
    */
    constructor(scope: Construct, id: string, config: AwsWafv2RegexPatternSetConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lockToken(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _regularExpression;
    get regularExpression(): AwsWafv2RegexPatternSet.RegularExpressionPropertyList;
    putRegularExpression(value: AwsWafv2RegexPatternSet.RegularExpressionProperty[] | cdktn.IResolvable): void;
    resetRegularExpression(): void;
    get regularExpressionInput(): cdktn.IResolvable | AwsWafv2RegexPatternSet.RegularExpressionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWafv2RegexPatternSetRegularExpressionPropertyToTerraform(struct?: AwsWafv2RegexPatternSet.RegularExpressionProperty | cdktn.IResolvable): any;
export declare function awsWafv2RegexPatternSetRegularExpressionPropertyToHclTerraform(struct?: AwsWafv2RegexPatternSet.RegularExpressionProperty | cdktn.IResolvable): any;
export declare namespace AwsWafv2RegexPatternSet {
    interface RegularExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafv2_regex_pattern_set#regex_string AwsWafv2RegexPatternSet#regex_string}
        */
        readonly regexString: string;
    }
    class RegularExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegularExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RegularExpressionProperty | cdktn.IResolvable | undefined);
        private _regexString?;
        get regexString(): string;
        set regexString(value: string);
        get regexStringInput(): string | undefined;
    }
    class RegularExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RegularExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegularExpressionPropertyOutputReference;
    }
}
