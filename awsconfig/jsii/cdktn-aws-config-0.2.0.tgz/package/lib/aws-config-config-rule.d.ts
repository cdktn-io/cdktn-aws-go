import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfConfigRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#description TfConfigRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#id TfConfigRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#input_parameters TfConfigRule#input_parameters}
    */
    readonly inputParameters?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#maximum_execution_frequency TfConfigRule#maximum_execution_frequency}
    */
    readonly maximumExecutionFrequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#name TfConfigRule#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#region TfConfigRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#tags TfConfigRule#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#tags_all TfConfigRule#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * evaluation_mode block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#evaluation_mode TfConfigRule#evaluation_mode}
    */
    readonly evaluationMode?: TfConfigRule.EvaluationModeProperty[] | cdktn.IResolvable;
    /**
    * scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#scope TfConfigRule#scope}
    */
    readonly scope?: TfConfigRule.ScopeProperty;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#source TfConfigRule#source}
    */
    readonly source: TfConfigRule.SourceProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule aws_config_config_rule}
*/
export declare class TfConfigRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_config_config_rule";
    /**
    * Generates CDKTN code for importing a TfConfigRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfConfigRule to import
    * @param importFromId The id of the existing TfConfigRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfConfigRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule aws_config_config_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfConfigRuleConfig
    */
    constructor(scope: Construct, id: string, config: TfConfigRuleConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputParameters?;
    get inputParameters(): string;
    set inputParameters(value: string);
    resetInputParameters(): void;
    get inputParametersInput(): string | undefined;
    private _maximumExecutionFrequency?;
    get maximumExecutionFrequency(): string;
    set maximumExecutionFrequency(value: string);
    resetMaximumExecutionFrequency(): void;
    get maximumExecutionFrequencyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get ruleId(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _evaluationMode;
    get evaluationMode(): TfConfigRule.EvaluationModePropertyList;
    putEvaluationMode(value: TfConfigRule.EvaluationModeProperty[] | cdktn.IResolvable): void;
    resetEvaluationMode(): void;
    get evaluationModeInput(): cdktn.IResolvable | TfConfigRule.EvaluationModeProperty[] | undefined;
    private _scope;
    get scope(): TfConfigRule.ScopePropertyOutputReference;
    putScope(value: TfConfigRule.ScopeProperty): void;
    resetScope(): void;
    get scopeInput(): TfConfigRule.ScopeProperty | undefined;
    private _source;
    get source(): TfConfigRule.SourcePropertyOutputReference;
    putSource(value: TfConfigRule.SourceProperty): void;
    get sourceInput(): TfConfigRule.SourceProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfConfigRuleEvaluationModePropertyToTerraform(struct?: TfConfigRule.EvaluationModeProperty | cdktn.IResolvable): any;
export declare function tfConfigRuleEvaluationModePropertyToHclTerraform(struct?: TfConfigRule.EvaluationModeProperty | cdktn.IResolvable): any;
export declare function tfConfigRuleScopePropertyToTerraform(struct?: TfConfigRule.ScopePropertyOutputReference | TfConfigRule.ScopeProperty): any;
export declare function tfConfigRuleScopePropertyToHclTerraform(struct?: TfConfigRule.ScopePropertyOutputReference | TfConfigRule.ScopeProperty): any;
export declare function tfConfigRuleCustomPolicyDetailsPropertyToTerraform(struct?: TfConfigRule.CustomPolicyDetailsPropertyOutputReference | TfConfigRule.CustomPolicyDetailsProperty): any;
export declare function tfConfigRuleCustomPolicyDetailsPropertyToHclTerraform(struct?: TfConfigRule.CustomPolicyDetailsPropertyOutputReference | TfConfigRule.CustomPolicyDetailsProperty): any;
export declare function tfConfigRuleSourceDetailPropertyToTerraform(struct?: TfConfigRule.SourceDetailProperty | cdktn.IResolvable): any;
export declare function tfConfigRuleSourceDetailPropertyToHclTerraform(struct?: TfConfigRule.SourceDetailProperty | cdktn.IResolvable): any;
export declare function tfConfigRuleSourcePropertyToTerraform(struct?: TfConfigRule.SourcePropertyOutputReference | TfConfigRule.SourceProperty): any;
export declare function tfConfigRuleSourcePropertyToHclTerraform(struct?: TfConfigRule.SourcePropertyOutputReference | TfConfigRule.SourceProperty): any;
export declare namespace TfConfigRule {
    interface EvaluationModeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#mode TfConfigRule#mode}
        */
        readonly mode?: string;
    }
    class EvaluationModePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationModeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluationModeProperty | cdktn.IResolvable | undefined);
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
    }
    class EvaluationModePropertyList extends cdktn.ComplexList {
        internalValue?: EvaluationModeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationModePropertyOutputReference;
    }
    interface ScopeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#compliance_resource_id TfConfigRule#compliance_resource_id}
        */
        readonly complianceResourceId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#compliance_resource_types TfConfigRule#compliance_resource_types}
        */
        readonly complianceResourceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#tag_key TfConfigRule#tag_key}
        */
        readonly tagKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#tag_value TfConfigRule#tag_value}
        */
        readonly tagValue?: string;
    }
    class ScopePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScopeProperty | undefined;
        set internalValue(value: ScopeProperty | undefined);
        private _complianceResourceId?;
        get complianceResourceId(): string;
        set complianceResourceId(value: string);
        resetComplianceResourceId(): void;
        get complianceResourceIdInput(): string | undefined;
        private _complianceResourceTypes?;
        get complianceResourceTypes(): string[];
        set complianceResourceTypes(value: string[]);
        resetComplianceResourceTypes(): void;
        get complianceResourceTypesInput(): string[] | undefined;
        private _tagKey?;
        get tagKey(): string;
        set tagKey(value: string);
        resetTagKey(): void;
        get tagKeyInput(): string | undefined;
        private _tagValue?;
        get tagValue(): string;
        set tagValue(value: string);
        resetTagValue(): void;
        get tagValueInput(): string | undefined;
    }
    interface CustomPolicyDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#enable_debug_log_delivery TfConfigRule#enable_debug_log_delivery}
        */
        readonly enableDebugLogDelivery?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#policy_runtime TfConfigRule#policy_runtime}
        */
        readonly policyRuntime: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#policy_text TfConfigRule#policy_text}
        */
        readonly policyText: string;
    }
    class CustomPolicyDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomPolicyDetailsProperty | undefined;
        set internalValue(value: CustomPolicyDetailsProperty | undefined);
        private _enableDebugLogDelivery?;
        get enableDebugLogDelivery(): boolean | cdktn.IResolvable;
        set enableDebugLogDelivery(value: boolean | cdktn.IResolvable);
        resetEnableDebugLogDelivery(): void;
        get enableDebugLogDeliveryInput(): boolean | cdktn.IResolvable | undefined;
        private _policyRuntime?;
        get policyRuntime(): string;
        set policyRuntime(value: string);
        get policyRuntimeInput(): string | undefined;
        private _policyText?;
        get policyText(): string;
        set policyText(value: string);
        get policyTextInput(): string | undefined;
    }
    interface SourceDetailProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#event_source TfConfigRule#event_source}
        */
        readonly eventSource?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#maximum_execution_frequency TfConfigRule#maximum_execution_frequency}
        */
        readonly maximumExecutionFrequency?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#message_type TfConfigRule#message_type}
        */
        readonly messageType?: string;
    }
    class SourceDetailPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceDetailProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceDetailProperty | cdktn.IResolvable | undefined);
        private _eventSource?;
        get eventSource(): string;
        set eventSource(value: string);
        resetEventSource(): void;
        get eventSourceInput(): string | undefined;
        private _maximumExecutionFrequency?;
        get maximumExecutionFrequency(): string;
        set maximumExecutionFrequency(value: string);
        resetMaximumExecutionFrequency(): void;
        get maximumExecutionFrequencyInput(): string | undefined;
        private _messageType?;
        get messageType(): string;
        set messageType(value: string);
        resetMessageType(): void;
        get messageTypeInput(): string | undefined;
    }
    class SourceDetailPropertyList extends cdktn.ComplexList {
        internalValue?: SourceDetailProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceDetailPropertyOutputReference;
    }
    interface SourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#owner TfConfigRule#owner}
        */
        readonly owner: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#source_identifier TfConfigRule#source_identifier}
        */
        readonly sourceIdentifier?: string;
        /**
        * custom_policy_details block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#custom_policy_details TfConfigRule#custom_policy_details}
        */
        readonly customPolicyDetails?: CustomPolicyDetailsProperty;
        /**
        * source_detail block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#source_detail TfConfigRule#source_detail}
        */
        readonly sourceDetail?: SourceDetailProperty[] | cdktn.IResolvable;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceProperty | undefined;
        set internalValue(value: SourceProperty | undefined);
        private _owner?;
        get owner(): string;
        set owner(value: string);
        get ownerInput(): string | undefined;
        private _sourceIdentifier?;
        get sourceIdentifier(): string;
        set sourceIdentifier(value: string);
        resetSourceIdentifier(): void;
        get sourceIdentifierInput(): string | undefined;
        private _customPolicyDetails;
        get customPolicyDetails(): CustomPolicyDetailsPropertyOutputReference;
        putCustomPolicyDetails(value: CustomPolicyDetailsProperty): void;
        resetCustomPolicyDetails(): void;
        get customPolicyDetailsInput(): CustomPolicyDetailsProperty | undefined;
        private _sourceDetail;
        get sourceDetail(): SourceDetailPropertyList;
        putSourceDetail(value: SourceDetailProperty[] | cdktn.IResolvable): void;
        resetSourceDetail(): void;
        get sourceDetailInput(): cdktn.IResolvable | SourceDetailProperty[] | undefined;
    }
}
