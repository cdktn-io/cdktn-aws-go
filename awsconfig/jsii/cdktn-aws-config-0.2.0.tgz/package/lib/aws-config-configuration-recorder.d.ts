import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfConfigurationRecorderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#id TfConfigurationRecorder#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#name TfConfigurationRecorder#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#region TfConfigurationRecorder#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#role_arn TfConfigurationRecorder#role_arn}
    */
    readonly roleArn: string;
    /**
    * recording_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#recording_group TfConfigurationRecorder#recording_group}
    */
    readonly recordingGroup?: TfConfigurationRecorder.RecordingGroupProperty;
    /**
    * recording_mode block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#recording_mode TfConfigurationRecorder#recording_mode}
    */
    readonly recordingMode?: TfConfigurationRecorder.RecordingModeProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder aws_config_configuration_recorder}
*/
export declare class TfConfigurationRecorder extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_config_configuration_recorder";
    /**
    * Generates CDKTN code for importing a TfConfigurationRecorder resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfConfigurationRecorder to import
    * @param importFromId The id of the existing TfConfigurationRecorder that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfConfigurationRecorder to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder aws_config_configuration_recorder} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfConfigurationRecorderConfig
    */
    constructor(scope: Construct, id: string, config: TfConfigurationRecorderConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _recordingGroup;
    get recordingGroup(): TfConfigurationRecorder.RecordingGroupPropertyOutputReference;
    putRecordingGroup(value: TfConfigurationRecorder.RecordingGroupProperty): void;
    resetRecordingGroup(): void;
    get recordingGroupInput(): TfConfigurationRecorder.RecordingGroupProperty | undefined;
    private _recordingMode;
    get recordingMode(): TfConfigurationRecorder.RecordingModePropertyOutputReference;
    putRecordingMode(value: TfConfigurationRecorder.RecordingModeProperty): void;
    resetRecordingMode(): void;
    get recordingModeInput(): TfConfigurationRecorder.RecordingModeProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfConfigurationRecorderExclusionByResourceTypesPropertyToTerraform(struct?: TfConfigurationRecorder.ExclusionByResourceTypesProperty | cdktn.IResolvable): any;
export declare function tfConfigurationRecorderExclusionByResourceTypesPropertyToHclTerraform(struct?: TfConfigurationRecorder.ExclusionByResourceTypesProperty | cdktn.IResolvable): any;
export declare function tfConfigurationRecorderRecordingStrategyPropertyToTerraform(struct?: TfConfigurationRecorder.RecordingStrategyProperty | cdktn.IResolvable): any;
export declare function tfConfigurationRecorderRecordingStrategyPropertyToHclTerraform(struct?: TfConfigurationRecorder.RecordingStrategyProperty | cdktn.IResolvable): any;
export declare function tfConfigurationRecorderRecordingGroupPropertyToTerraform(struct?: TfConfigurationRecorder.RecordingGroupPropertyOutputReference | TfConfigurationRecorder.RecordingGroupProperty): any;
export declare function tfConfigurationRecorderRecordingGroupPropertyToHclTerraform(struct?: TfConfigurationRecorder.RecordingGroupPropertyOutputReference | TfConfigurationRecorder.RecordingGroupProperty): any;
export declare function tfConfigurationRecorderRecordingModeOverridePropertyToTerraform(struct?: TfConfigurationRecorder.RecordingModeOverridePropertyOutputReference | TfConfigurationRecorder.RecordingModeOverrideProperty): any;
export declare function tfConfigurationRecorderRecordingModeOverridePropertyToHclTerraform(struct?: TfConfigurationRecorder.RecordingModeOverridePropertyOutputReference | TfConfigurationRecorder.RecordingModeOverrideProperty): any;
export declare function tfConfigurationRecorderRecordingModePropertyToTerraform(struct?: TfConfigurationRecorder.RecordingModePropertyOutputReference | TfConfigurationRecorder.RecordingModeProperty): any;
export declare function tfConfigurationRecorderRecordingModePropertyToHclTerraform(struct?: TfConfigurationRecorder.RecordingModePropertyOutputReference | TfConfigurationRecorder.RecordingModeProperty): any;
export declare namespace TfConfigurationRecorder {
    interface ExclusionByResourceTypesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#resource_types TfConfigurationRecorder#resource_types}
        */
        readonly resourceTypes?: string[];
    }
    class ExclusionByResourceTypesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExclusionByResourceTypesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExclusionByResourceTypesProperty | cdktn.IResolvable | undefined);
        private _resourceTypes?;
        get resourceTypes(): string[];
        set resourceTypes(value: string[]);
        resetResourceTypes(): void;
        get resourceTypesInput(): string[] | undefined;
    }
    class ExclusionByResourceTypesPropertyList extends cdktn.ComplexList {
        internalValue?: ExclusionByResourceTypesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExclusionByResourceTypesPropertyOutputReference;
    }
    interface RecordingStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#use_only TfConfigurationRecorder#use_only}
        */
        readonly useOnly?: string;
    }
    class RecordingStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecordingStrategyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecordingStrategyProperty | cdktn.IResolvable | undefined);
        private _useOnly?;
        get useOnly(): string;
        set useOnly(value: string);
        resetUseOnly(): void;
        get useOnlyInput(): string | undefined;
    }
    class RecordingStrategyPropertyList extends cdktn.ComplexList {
        internalValue?: RecordingStrategyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecordingStrategyPropertyOutputReference;
    }
    interface RecordingGroupProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#all_supported TfConfigurationRecorder#all_supported}
        */
        readonly allSupported?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#include_global_resource_types TfConfigurationRecorder#include_global_resource_types}
        */
        readonly includeGlobalResourceTypes?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#resource_types TfConfigurationRecorder#resource_types}
        */
        readonly resourceTypes?: string[];
        /**
        * exclusion_by_resource_types block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#exclusion_by_resource_types TfConfigurationRecorder#exclusion_by_resource_types}
        */
        readonly exclusionByResourceTypes?: ExclusionByResourceTypesProperty[] | cdktn.IResolvable;
        /**
        * recording_strategy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#recording_strategy TfConfigurationRecorder#recording_strategy}
        */
        readonly recordingStrategy?: RecordingStrategyProperty[] | cdktn.IResolvable;
    }
    class RecordingGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RecordingGroupProperty | undefined;
        set internalValue(value: RecordingGroupProperty | undefined);
        private _allSupported?;
        get allSupported(): boolean | cdktn.IResolvable;
        set allSupported(value: boolean | cdktn.IResolvable);
        resetAllSupported(): void;
        get allSupportedInput(): boolean | cdktn.IResolvable | undefined;
        private _includeGlobalResourceTypes?;
        get includeGlobalResourceTypes(): boolean | cdktn.IResolvable;
        set includeGlobalResourceTypes(value: boolean | cdktn.IResolvable);
        resetIncludeGlobalResourceTypes(): void;
        get includeGlobalResourceTypesInput(): boolean | cdktn.IResolvable | undefined;
        private _resourceTypes?;
        get resourceTypes(): string[];
        set resourceTypes(value: string[]);
        resetResourceTypes(): void;
        get resourceTypesInput(): string[] | undefined;
        private _exclusionByResourceTypes;
        get exclusionByResourceTypes(): ExclusionByResourceTypesPropertyList;
        putExclusionByResourceTypes(value: ExclusionByResourceTypesProperty[] | cdktn.IResolvable): void;
        resetExclusionByResourceTypes(): void;
        get exclusionByResourceTypesInput(): cdktn.IResolvable | ExclusionByResourceTypesProperty[] | undefined;
        private _recordingStrategy;
        get recordingStrategy(): RecordingStrategyPropertyList;
        putRecordingStrategy(value: RecordingStrategyProperty[] | cdktn.IResolvable): void;
        resetRecordingStrategy(): void;
        get recordingStrategyInput(): cdktn.IResolvable | RecordingStrategyProperty[] | undefined;
    }
    interface RecordingModeOverrideProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#description TfConfigurationRecorder#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#recording_frequency TfConfigurationRecorder#recording_frequency}
        */
        readonly recordingFrequency: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#resource_types TfConfigurationRecorder#resource_types}
        */
        readonly resourceTypes: string[];
    }
    class RecordingModeOverridePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RecordingModeOverrideProperty | undefined;
        set internalValue(value: RecordingModeOverrideProperty | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _recordingFrequency?;
        get recordingFrequency(): string;
        set recordingFrequency(value: string);
        get recordingFrequencyInput(): string | undefined;
        private _resourceTypes?;
        get resourceTypes(): string[];
        set resourceTypes(value: string[]);
        get resourceTypesInput(): string[] | undefined;
    }
    interface RecordingModeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#recording_frequency TfConfigurationRecorder#recording_frequency}
        */
        readonly recordingFrequency?: string;
        /**
        * recording_mode_override block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_recorder#recording_mode_override TfConfigurationRecorder#recording_mode_override}
        */
        readonly recordingModeOverride?: RecordingModeOverrideProperty;
    }
    class RecordingModePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RecordingModeProperty | undefined;
        set internalValue(value: RecordingModeProperty | undefined);
        private _recordingFrequency?;
        get recordingFrequency(): string;
        set recordingFrequency(value: string);
        resetRecordingFrequency(): void;
        get recordingFrequencyInput(): string | undefined;
        private _recordingModeOverride;
        get recordingModeOverride(): RecordingModeOverridePropertyOutputReference;
        putRecordingModeOverride(value: RecordingModeOverrideProperty): void;
        resetRecordingModeOverride(): void;
        get recordingModeOverrideInput(): RecordingModeOverrideProperty | undefined;
    }
}
