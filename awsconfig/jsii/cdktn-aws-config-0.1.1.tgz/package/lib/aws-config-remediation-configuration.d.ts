import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsConfigRemediationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#automatic AwsConfigRemediationConfiguration#automatic}
    */
    readonly automatic?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#config_rule_name AwsConfigRemediationConfiguration#config_rule_name}
    */
    readonly configRuleName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#id AwsConfigRemediationConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#maximum_automatic_attempts AwsConfigRemediationConfiguration#maximum_automatic_attempts}
    */
    readonly maximumAutomaticAttempts?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#region AwsConfigRemediationConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#resource_type AwsConfigRemediationConfiguration#resource_type}
    */
    readonly resourceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#retry_attempt_seconds AwsConfigRemediationConfiguration#retry_attempt_seconds}
    */
    readonly retryAttemptSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#target_id AwsConfigRemediationConfiguration#target_id}
    */
    readonly targetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#target_type AwsConfigRemediationConfiguration#target_type}
    */
    readonly targetType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#target_version AwsConfigRemediationConfiguration#target_version}
    */
    readonly targetVersion?: string;
    /**
    * execution_controls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#execution_controls AwsConfigRemediationConfiguration#execution_controls}
    */
    readonly executionControls?: AwsConfigRemediationConfiguration.ExecutionControlsProperty;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#parameter AwsConfigRemediationConfiguration#parameter}
    */
    readonly parameter?: AwsConfigRemediationConfiguration.ParameterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration aws_config_remediation_configuration}
*/
export declare class AwsConfigRemediationConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_config_remediation_configuration";
    /**
    * Generates CDKTN code for importing a AwsConfigRemediationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsConfigRemediationConfiguration to import
    * @param importFromId The id of the existing AwsConfigRemediationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsConfigRemediationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration aws_config_remediation_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsConfigRemediationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsConfigRemediationConfigurationConfig);
    get arn(): string;
    private _automatic?;
    get automatic(): boolean | cdktn.IResolvable;
    set automatic(value: boolean | cdktn.IResolvable);
    resetAutomatic(): void;
    get automaticInput(): boolean | cdktn.IResolvable | undefined;
    private _configRuleName?;
    get configRuleName(): string;
    set configRuleName(value: string);
    get configRuleNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maximumAutomaticAttempts?;
    get maximumAutomaticAttempts(): number;
    set maximumAutomaticAttempts(value: number);
    resetMaximumAutomaticAttempts(): void;
    get maximumAutomaticAttemptsInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    resetResourceType(): void;
    get resourceTypeInput(): string | undefined;
    private _retryAttemptSeconds?;
    get retryAttemptSeconds(): number;
    set retryAttemptSeconds(value: number);
    resetRetryAttemptSeconds(): void;
    get retryAttemptSecondsInput(): number | undefined;
    private _targetId?;
    get targetId(): string;
    set targetId(value: string);
    get targetIdInput(): string | undefined;
    private _targetType?;
    get targetType(): string;
    set targetType(value: string);
    get targetTypeInput(): string | undefined;
    private _targetVersion?;
    get targetVersion(): string;
    set targetVersion(value: string);
    resetTargetVersion(): void;
    get targetVersionInput(): string | undefined;
    private _executionControls;
    get executionControls(): AwsConfigRemediationConfiguration.ExecutionControlsPropertyOutputReference;
    putExecutionControls(value: AwsConfigRemediationConfiguration.ExecutionControlsProperty): void;
    resetExecutionControls(): void;
    get executionControlsInput(): AwsConfigRemediationConfiguration.ExecutionControlsProperty | undefined;
    private _parameter;
    get parameter(): AwsConfigRemediationConfiguration.ParameterPropertyList;
    putParameter(value: AwsConfigRemediationConfiguration.ParameterProperty[] | cdktn.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktn.IResolvable | AwsConfigRemediationConfiguration.ParameterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsConfigRemediationConfigurationSsmControlsPropertyToTerraform(struct?: AwsConfigRemediationConfiguration.SsmControlsPropertyOutputReference | AwsConfigRemediationConfiguration.SsmControlsProperty): any;
export declare function awsConfigRemediationConfigurationSsmControlsPropertyToHclTerraform(struct?: AwsConfigRemediationConfiguration.SsmControlsPropertyOutputReference | AwsConfigRemediationConfiguration.SsmControlsProperty): any;
export declare function awsConfigRemediationConfigurationExecutionControlsPropertyToTerraform(struct?: AwsConfigRemediationConfiguration.ExecutionControlsPropertyOutputReference | AwsConfigRemediationConfiguration.ExecutionControlsProperty): any;
export declare function awsConfigRemediationConfigurationExecutionControlsPropertyToHclTerraform(struct?: AwsConfigRemediationConfiguration.ExecutionControlsPropertyOutputReference | AwsConfigRemediationConfiguration.ExecutionControlsProperty): any;
export declare function awsConfigRemediationConfigurationParameterPropertyToTerraform(struct?: AwsConfigRemediationConfiguration.ParameterProperty | cdktn.IResolvable): any;
export declare function awsConfigRemediationConfigurationParameterPropertyToHclTerraform(struct?: AwsConfigRemediationConfiguration.ParameterProperty | cdktn.IResolvable): any;
export declare namespace AwsConfigRemediationConfiguration {
    interface SsmControlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#concurrent_execution_rate_percentage AwsConfigRemediationConfiguration#concurrent_execution_rate_percentage}
        */
        readonly concurrentExecutionRatePercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#error_percentage AwsConfigRemediationConfiguration#error_percentage}
        */
        readonly errorPercentage?: number;
    }
    class SsmControlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SsmControlsProperty | undefined;
        set internalValue(value: SsmControlsProperty | undefined);
        private _concurrentExecutionRatePercentage?;
        get concurrentExecutionRatePercentage(): number;
        set concurrentExecutionRatePercentage(value: number);
        resetConcurrentExecutionRatePercentage(): void;
        get concurrentExecutionRatePercentageInput(): number | undefined;
        private _errorPercentage?;
        get errorPercentage(): number;
        set errorPercentage(value: number);
        resetErrorPercentage(): void;
        get errorPercentageInput(): number | undefined;
    }
    interface ExecutionControlsProperty {
        /**
        * ssm_controls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#ssm_controls AwsConfigRemediationConfiguration#ssm_controls}
        */
        readonly ssmControls?: SsmControlsProperty;
    }
    class ExecutionControlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExecutionControlsProperty | undefined;
        set internalValue(value: ExecutionControlsProperty | undefined);
        private _ssmControls;
        get ssmControls(): SsmControlsPropertyOutputReference;
        putSsmControls(value: SsmControlsProperty): void;
        resetSsmControls(): void;
        get ssmControlsInput(): SsmControlsProperty | undefined;
    }
    interface ParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#name AwsConfigRemediationConfiguration#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#resource_value AwsConfigRemediationConfiguration#resource_value}
        */
        readonly resourceValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#static_value AwsConfigRemediationConfiguration#static_value}
        */
        readonly staticValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_remediation_configuration#static_values AwsConfigRemediationConfiguration#static_values}
        */
        readonly staticValues?: string[];
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _resourceValue?;
        get resourceValue(): string;
        set resourceValue(value: string);
        resetResourceValue(): void;
        get resourceValueInput(): string | undefined;
        private _staticValue?;
        get staticValue(): string;
        set staticValue(value: string);
        resetStaticValue(): void;
        get staticValueInput(): string | undefined;
        private _staticValues?;
        get staticValues(): string[];
        set staticValues(value: string[]);
        resetStaticValues(): void;
        get staticValuesInput(): string[] | undefined;
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        internalValue?: ParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
}
