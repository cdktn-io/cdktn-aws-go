import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsConfigConfigRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#description AwsConfigConfigRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#id AwsConfigConfigRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#input_parameters AwsConfigConfigRule#input_parameters}
    */
    readonly inputParameters?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#maximum_execution_frequency AwsConfigConfigRule#maximum_execution_frequency}
    */
    readonly maximumExecutionFrequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#name AwsConfigConfigRule#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#region AwsConfigConfigRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#tags AwsConfigConfigRule#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#tags_all AwsConfigConfigRule#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * evaluation_mode block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#evaluation_mode AwsConfigConfigRule#evaluation_mode}
    */
    readonly evaluationMode?: AwsConfigConfigRule.EvaluationModeProperty[] | cdktn.IResolvable;
    /**
    * scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#scope AwsConfigConfigRule#scope}
    */
    readonly scope?: AwsConfigConfigRule.ScopeProperty;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#source AwsConfigConfigRule#source}
    */
    readonly source: AwsConfigConfigRule.SourceProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule aws_config_config_rule}
*/
export declare class AwsConfigConfigRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_config_config_rule";
    /**
    * Generates CDKTN code for importing a AwsConfigConfigRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsConfigConfigRule to import
    * @param importFromId The id of the existing AwsConfigConfigRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsConfigConfigRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule aws_config_config_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsConfigConfigRuleConfig
    */
    constructor(scope: Construct, id: string, config: AwsConfigConfigRuleConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputParameters?;
    get inputParameters(): string;
    set inputParameters(value: string);
    resetInputParameters(): void;
    get inputParametersInput(): string | undefined;
    private _maximumExecutionFrequency?;
    get maximumExecutionFrequency(): string;
    set maximumExecutionFrequency(value: string);
    resetMaximumExecutionFrequency(): void;
    get maximumExecutionFrequencyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get ruleId(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _evaluationMode;
    get evaluationMode(): AwsConfigConfigRule.EvaluationModePropertyList;
    putEvaluationMode(value: AwsConfigConfigRule.EvaluationModeProperty[] | cdktn.IResolvable): void;
    resetEvaluationMode(): void;
    get evaluationModeInput(): cdktn.IResolvable | AwsConfigConfigRule.EvaluationModeProperty[] | undefined;
    private _scope;
    get scope(): AwsConfigConfigRule.ScopePropertyOutputReference;
    putScope(value: AwsConfigConfigRule.ScopeProperty): void;
    resetScope(): void;
    get scopeInput(): AwsConfigConfigRule.ScopeProperty | undefined;
    private _source;
    get source(): AwsConfigConfigRule.SourcePropertyOutputReference;
    putSource(value: AwsConfigConfigRule.SourceProperty): void;
    get sourceInput(): AwsConfigConfigRule.SourceProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsConfigConfigRuleEvaluationModePropertyToTerraform(struct?: AwsConfigConfigRule.EvaluationModeProperty | cdktn.IResolvable): any;
export declare function awsConfigConfigRuleEvaluationModePropertyToHclTerraform(struct?: AwsConfigConfigRule.EvaluationModeProperty | cdktn.IResolvable): any;
export declare function awsConfigConfigRuleScopePropertyToTerraform(struct?: AwsConfigConfigRule.ScopePropertyOutputReference | AwsConfigConfigRule.ScopeProperty): any;
export declare function awsConfigConfigRuleScopePropertyToHclTerraform(struct?: AwsConfigConfigRule.ScopePropertyOutputReference | AwsConfigConfigRule.ScopeProperty): any;
export declare function awsConfigConfigRuleCustomPolicyDetailsPropertyToTerraform(struct?: AwsConfigConfigRule.CustomPolicyDetailsPropertyOutputReference | AwsConfigConfigRule.CustomPolicyDetailsProperty): any;
export declare function awsConfigConfigRuleCustomPolicyDetailsPropertyToHclTerraform(struct?: AwsConfigConfigRule.CustomPolicyDetailsPropertyOutputReference | AwsConfigConfigRule.CustomPolicyDetailsProperty): any;
export declare function awsConfigConfigRuleSourceDetailPropertyToTerraform(struct?: AwsConfigConfigRule.SourceDetailProperty | cdktn.IResolvable): any;
export declare function awsConfigConfigRuleSourceDetailPropertyToHclTerraform(struct?: AwsConfigConfigRule.SourceDetailProperty | cdktn.IResolvable): any;
export declare function awsConfigConfigRuleSourcePropertyToTerraform(struct?: AwsConfigConfigRule.SourcePropertyOutputReference | AwsConfigConfigRule.SourceProperty): any;
export declare function awsConfigConfigRuleSourcePropertyToHclTerraform(struct?: AwsConfigConfigRule.SourcePropertyOutputReference | AwsConfigConfigRule.SourceProperty): any;
export declare namespace AwsConfigConfigRule {
    interface EvaluationModeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#mode AwsConfigConfigRule#mode}
        */
        readonly mode?: string;
    }
    class EvaluationModePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationModeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluationModeProperty | cdktn.IResolvable | undefined);
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
    }
    class EvaluationModePropertyList extends cdktn.ComplexList {
        internalValue?: EvaluationModeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationModePropertyOutputReference;
    }
    interface ScopeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#compliance_resource_id AwsConfigConfigRule#compliance_resource_id}
        */
        readonly complianceResourceId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#compliance_resource_types AwsConfigConfigRule#compliance_resource_types}
        */
        readonly complianceResourceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#tag_key AwsConfigConfigRule#tag_key}
        */
        readonly tagKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#tag_value AwsConfigConfigRule#tag_value}
        */
        readonly tagValue?: string;
    }
    class ScopePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScopeProperty | undefined;
        set internalValue(value: ScopeProperty | undefined);
        private _complianceResourceId?;
        get complianceResourceId(): string;
        set complianceResourceId(value: string);
        resetComplianceResourceId(): void;
        get complianceResourceIdInput(): string | undefined;
        private _complianceResourceTypes?;
        get complianceResourceTypes(): string[];
        set complianceResourceTypes(value: string[]);
        resetComplianceResourceTypes(): void;
        get complianceResourceTypesInput(): string[] | undefined;
        private _tagKey?;
        get tagKey(): string;
        set tagKey(value: string);
        resetTagKey(): void;
        get tagKeyInput(): string | undefined;
        private _tagValue?;
        get tagValue(): string;
        set tagValue(value: string);
        resetTagValue(): void;
        get tagValueInput(): string | undefined;
    }
    interface CustomPolicyDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#enable_debug_log_delivery AwsConfigConfigRule#enable_debug_log_delivery}
        */
        readonly enableDebugLogDelivery?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#policy_runtime AwsConfigConfigRule#policy_runtime}
        */
        readonly policyRuntime: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#policy_text AwsConfigConfigRule#policy_text}
        */
        readonly policyText: string;
    }
    class CustomPolicyDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomPolicyDetailsProperty | undefined;
        set internalValue(value: CustomPolicyDetailsProperty | undefined);
        private _enableDebugLogDelivery?;
        get enableDebugLogDelivery(): boolean | cdktn.IResolvable;
        set enableDebugLogDelivery(value: boolean | cdktn.IResolvable);
        resetEnableDebugLogDelivery(): void;
        get enableDebugLogDeliveryInput(): boolean | cdktn.IResolvable | undefined;
        private _policyRuntime?;
        get policyRuntime(): string;
        set policyRuntime(value: string);
        get policyRuntimeInput(): string | undefined;
        private _policyText?;
        get policyText(): string;
        set policyText(value: string);
        get policyTextInput(): string | undefined;
    }
    interface SourceDetailProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#event_source AwsConfigConfigRule#event_source}
        */
        readonly eventSource?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#maximum_execution_frequency AwsConfigConfigRule#maximum_execution_frequency}
        */
        readonly maximumExecutionFrequency?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#message_type AwsConfigConfigRule#message_type}
        */
        readonly messageType?: string;
    }
    class SourceDetailPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceDetailProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceDetailProperty | cdktn.IResolvable | undefined);
        private _eventSource?;
        get eventSource(): string;
        set eventSource(value: string);
        resetEventSource(): void;
        get eventSourceInput(): string | undefined;
        private _maximumExecutionFrequency?;
        get maximumExecutionFrequency(): string;
        set maximumExecutionFrequency(value: string);
        resetMaximumExecutionFrequency(): void;
        get maximumExecutionFrequencyInput(): string | undefined;
        private _messageType?;
        get messageType(): string;
        set messageType(value: string);
        resetMessageType(): void;
        get messageTypeInput(): string | undefined;
    }
    class SourceDetailPropertyList extends cdktn.ComplexList {
        internalValue?: SourceDetailProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceDetailPropertyOutputReference;
    }
    interface SourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#owner AwsConfigConfigRule#owner}
        */
        readonly owner: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#source_identifier AwsConfigConfigRule#source_identifier}
        */
        readonly sourceIdentifier?: string;
        /**
        * custom_policy_details block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#custom_policy_details AwsConfigConfigRule#custom_policy_details}
        */
        readonly customPolicyDetails?: CustomPolicyDetailsProperty;
        /**
        * source_detail block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#source_detail AwsConfigConfigRule#source_detail}
        */
        readonly sourceDetail?: SourceDetailProperty[] | cdktn.IResolvable;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceProperty | undefined;
        set internalValue(value: SourceProperty | undefined);
        private _owner?;
        get owner(): string;
        set owner(value: string);
        get ownerInput(): string | undefined;
        private _sourceIdentifier?;
        get sourceIdentifier(): string;
        set sourceIdentifier(value: string);
        resetSourceIdentifier(): void;
        get sourceIdentifierInput(): string | undefined;
        private _customPolicyDetails;
        get customPolicyDetails(): CustomPolicyDetailsPropertyOutputReference;
        putCustomPolicyDetails(value: CustomPolicyDetailsProperty): void;
        resetCustomPolicyDetails(): void;
        get customPolicyDetailsInput(): CustomPolicyDetailsProperty | undefined;
        private _sourceDetail;
        get sourceDetail(): SourceDetailPropertyList;
        putSourceDetail(value: SourceDetailProperty[] | cdktn.IResolvable): void;
        resetSourceDetail(): void;
        get sourceDetailInput(): cdktn.IResolvable | SourceDetailProperty[] | undefined;
    }
}
