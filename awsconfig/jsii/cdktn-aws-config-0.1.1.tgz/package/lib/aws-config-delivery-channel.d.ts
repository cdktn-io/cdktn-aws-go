import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsConfigDeliveryChannelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_delivery_channel#id AwsConfigDeliveryChannel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_delivery_channel#name AwsConfigDeliveryChannel#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_delivery_channel#region AwsConfigDeliveryChannel#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_delivery_channel#s3_bucket_name AwsConfigDeliveryChannel#s3_bucket_name}
    */
    readonly s3BucketName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_delivery_channel#s3_key_prefix AwsConfigDeliveryChannel#s3_key_prefix}
    */
    readonly s3KeyPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_delivery_channel#s3_kms_key_arn AwsConfigDeliveryChannel#s3_kms_key_arn}
    */
    readonly s3KmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_delivery_channel#sns_topic_arn AwsConfigDeliveryChannel#sns_topic_arn}
    */
    readonly snsTopicArn?: string;
    /**
    * snapshot_delivery_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_delivery_channel#snapshot_delivery_properties AwsConfigDeliveryChannel#snapshot_delivery_properties}
    */
    readonly snapshotDeliveryProperties?: AwsConfigDeliveryChannel.SnapshotDeliveryPropertiesProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_delivery_channel aws_config_delivery_channel}
*/
export declare class AwsConfigDeliveryChannel extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_config_delivery_channel";
    /**
    * Generates CDKTN code for importing a AwsConfigDeliveryChannel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsConfigDeliveryChannel to import
    * @param importFromId The id of the existing AwsConfigDeliveryChannel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_delivery_channel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsConfigDeliveryChannel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_delivery_channel aws_config_delivery_channel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsConfigDeliveryChannelConfig
    */
    constructor(scope: Construct, id: string, config: AwsConfigDeliveryChannelConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _s3BucketName?;
    get s3BucketName(): string;
    set s3BucketName(value: string);
    get s3BucketNameInput(): string | undefined;
    private _s3KeyPrefix?;
    get s3KeyPrefix(): string;
    set s3KeyPrefix(value: string);
    resetS3KeyPrefix(): void;
    get s3KeyPrefixInput(): string | undefined;
    private _s3KmsKeyArn?;
    get s3KmsKeyArn(): string;
    set s3KmsKeyArn(value: string);
    resetS3KmsKeyArn(): void;
    get s3KmsKeyArnInput(): string | undefined;
    private _snsTopicArn?;
    get snsTopicArn(): string;
    set snsTopicArn(value: string);
    resetSnsTopicArn(): void;
    get snsTopicArnInput(): string | undefined;
    private _snapshotDeliveryProperties;
    get snapshotDeliveryProperties(): AwsConfigDeliveryChannel.SnapshotDeliveryPropertiesPropertyOutputReference;
    putSnapshotDeliveryProperties(value: AwsConfigDeliveryChannel.SnapshotDeliveryPropertiesProperty): void;
    resetSnapshotDeliveryProperties(): void;
    get snapshotDeliveryPropertiesInput(): AwsConfigDeliveryChannel.SnapshotDeliveryPropertiesProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsConfigDeliveryChannelSnapshotDeliveryPropertiesPropertyToTerraform(struct?: AwsConfigDeliveryChannel.SnapshotDeliveryPropertiesPropertyOutputReference | AwsConfigDeliveryChannel.SnapshotDeliveryPropertiesProperty): any;
export declare function awsConfigDeliveryChannelSnapshotDeliveryPropertiesPropertyToHclTerraform(struct?: AwsConfigDeliveryChannel.SnapshotDeliveryPropertiesPropertyOutputReference | AwsConfigDeliveryChannel.SnapshotDeliveryPropertiesProperty): any;
export declare namespace AwsConfigDeliveryChannel {
    interface SnapshotDeliveryPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_delivery_channel#delivery_frequency AwsConfigDeliveryChannel#delivery_frequency}
        */
        readonly deliveryFrequency?: string;
    }
    class SnapshotDeliveryPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnapshotDeliveryPropertiesProperty | undefined;
        set internalValue(value: SnapshotDeliveryPropertiesProperty | undefined);
        private _deliveryFrequency?;
        get deliveryFrequency(): string;
        set deliveryFrequency(value: string);
        resetDeliveryFrequency(): void;
        get deliveryFrequencyInput(): string | undefined;
    }
}
