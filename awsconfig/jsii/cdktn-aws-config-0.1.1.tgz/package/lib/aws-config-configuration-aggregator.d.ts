import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsConfigConfigurationAggregatorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_aggregator#id AwsConfigConfigurationAggregator#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_aggregator#name AwsConfigConfigurationAggregator#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_aggregator#region AwsConfigConfigurationAggregator#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_aggregator#tags AwsConfigConfigurationAggregator#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_aggregator#tags_all AwsConfigConfigurationAggregator#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * account_aggregation_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_aggregator#account_aggregation_source AwsConfigConfigurationAggregator#account_aggregation_source}
    */
    readonly accountAggregationSource?: AwsConfigConfigurationAggregator.AccountAggregationSourceProperty;
    /**
    * organization_aggregation_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_aggregator#organization_aggregation_source AwsConfigConfigurationAggregator#organization_aggregation_source}
    */
    readonly organizationAggregationSource?: AwsConfigConfigurationAggregator.OrganizationAggregationSourceProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_aggregator aws_config_configuration_aggregator}
*/
export declare class AwsConfigConfigurationAggregator extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_config_configuration_aggregator";
    /**
    * Generates CDKTN code for importing a AwsConfigConfigurationAggregator resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsConfigConfigurationAggregator to import
    * @param importFromId The id of the existing AwsConfigConfigurationAggregator that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_aggregator#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsConfigConfigurationAggregator to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_aggregator aws_config_configuration_aggregator} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsConfigConfigurationAggregatorConfig
    */
    constructor(scope: Construct, id: string, config: AwsConfigConfigurationAggregatorConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _accountAggregationSource;
    get accountAggregationSource(): AwsConfigConfigurationAggregator.AccountAggregationSourcePropertyOutputReference;
    putAccountAggregationSource(value: AwsConfigConfigurationAggregator.AccountAggregationSourceProperty): void;
    resetAccountAggregationSource(): void;
    get accountAggregationSourceInput(): AwsConfigConfigurationAggregator.AccountAggregationSourceProperty | undefined;
    private _organizationAggregationSource;
    get organizationAggregationSource(): AwsConfigConfigurationAggregator.OrganizationAggregationSourcePropertyOutputReference;
    putOrganizationAggregationSource(value: AwsConfigConfigurationAggregator.OrganizationAggregationSourceProperty): void;
    resetOrganizationAggregationSource(): void;
    get organizationAggregationSourceInput(): AwsConfigConfigurationAggregator.OrganizationAggregationSourceProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsConfigConfigurationAggregatorAccountAggregationSourcePropertyToTerraform(struct?: AwsConfigConfigurationAggregator.AccountAggregationSourcePropertyOutputReference | AwsConfigConfigurationAggregator.AccountAggregationSourceProperty): any;
export declare function awsConfigConfigurationAggregatorAccountAggregationSourcePropertyToHclTerraform(struct?: AwsConfigConfigurationAggregator.AccountAggregationSourcePropertyOutputReference | AwsConfigConfigurationAggregator.AccountAggregationSourceProperty): any;
export declare function awsConfigConfigurationAggregatorOrganizationAggregationSourcePropertyToTerraform(struct?: AwsConfigConfigurationAggregator.OrganizationAggregationSourcePropertyOutputReference | AwsConfigConfigurationAggregator.OrganizationAggregationSourceProperty): any;
export declare function awsConfigConfigurationAggregatorOrganizationAggregationSourcePropertyToHclTerraform(struct?: AwsConfigConfigurationAggregator.OrganizationAggregationSourcePropertyOutputReference | AwsConfigConfigurationAggregator.OrganizationAggregationSourceProperty): any;
export declare namespace AwsConfigConfigurationAggregator {
    interface AccountAggregationSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_aggregator#account_ids AwsConfigConfigurationAggregator#account_ids}
        */
        readonly accountIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_aggregator#all_regions AwsConfigConfigurationAggregator#all_regions}
        */
        readonly allRegions?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_aggregator#regions AwsConfigConfigurationAggregator#regions}
        */
        readonly regions?: string[];
    }
    class AccountAggregationSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccountAggregationSourceProperty | undefined;
        set internalValue(value: AccountAggregationSourceProperty | undefined);
        private _accountIds?;
        get accountIds(): string[];
        set accountIds(value: string[]);
        get accountIdsInput(): string[] | undefined;
        private _allRegions?;
        get allRegions(): boolean | cdktn.IResolvable;
        set allRegions(value: boolean | cdktn.IResolvable);
        resetAllRegions(): void;
        get allRegionsInput(): boolean | cdktn.IResolvable | undefined;
        private _regions?;
        get regions(): string[];
        set regions(value: string[]);
        resetRegions(): void;
        get regionsInput(): string[] | undefined;
    }
    interface OrganizationAggregationSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_aggregator#all_regions AwsConfigConfigurationAggregator#all_regions}
        */
        readonly allRegions?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_aggregator#regions AwsConfigConfigurationAggregator#regions}
        */
        readonly regions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_configuration_aggregator#role_arn AwsConfigConfigurationAggregator#role_arn}
        */
        readonly roleArn: string;
    }
    class OrganizationAggregationSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OrganizationAggregationSourceProperty | undefined;
        set internalValue(value: OrganizationAggregationSourceProperty | undefined);
        private _allRegions?;
        get allRegions(): boolean | cdktn.IResolvable;
        set allRegions(value: boolean | cdktn.IResolvable);
        resetAllRegions(): void;
        get allRegionsInput(): boolean | cdktn.IResolvable | undefined;
        private _regions?;
        get regions(): string[];
        set regions(value: string[]);
        resetRegions(): void;
        get regionsInput(): string[] | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
}
