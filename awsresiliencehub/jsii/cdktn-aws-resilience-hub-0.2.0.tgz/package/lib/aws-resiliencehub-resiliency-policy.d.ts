import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfResiliencyPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a high-level geographical location constraint for where resilience policy data can be stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#data_location_constraint TfResiliencyPolicy#data_location_constraint}
    */
    readonly dataLocationConstraint?: string;
    /**
    * The description for the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#description TfResiliencyPolicy#description}
    */
    readonly description?: string;
    /**
    * The name of the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#name TfResiliencyPolicy#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#region TfResiliencyPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#tags TfResiliencyPolicy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * The tier for the resiliency policy, ranging from the highest severity (MissionCritical) to lowest (NonCritical).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#tier TfResiliencyPolicy#tier}
    */
    readonly tier: string;
    /**
    * policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#policy TfResiliencyPolicy#policy}
    */
    readonly policy?: TfResiliencyPolicy.PolicyProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#timeouts TfResiliencyPolicy#timeouts}
    */
    readonly timeouts?: TfResiliencyPolicy.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy aws_resiliencehub_resiliency_policy}
*/
export declare class TfResiliencyPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_resiliencehub_resiliency_policy";
    /**
    * Generates CDKTN code for importing a TfResiliencyPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfResiliencyPolicy to import
    * @param importFromId The id of the existing TfResiliencyPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfResiliencyPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy aws_resiliencehub_resiliency_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfResiliencyPolicyConfig
    */
    constructor(scope: Construct, id: string, config: TfResiliencyPolicyConfig);
    get arn(): string;
    private _dataLocationConstraint?;
    get dataLocationConstraint(): string;
    set dataLocationConstraint(value: string);
    resetDataLocationConstraint(): void;
    get dataLocationConstraintInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get estimatedCostTier(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _tier?;
    get tier(): string;
    set tier(value: string);
    get tierInput(): string | undefined;
    private _policy;
    get policy(): TfResiliencyPolicy.PolicyPropertyList;
    putPolicy(value: TfResiliencyPolicy.PolicyProperty[] | cdktn.IResolvable): void;
    resetPolicy(): void;
    get policyInput(): cdktn.IResolvable | TfResiliencyPolicy.PolicyProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfResiliencyPolicy.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfResiliencyPolicy.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfResiliencyPolicy.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfResiliencyPolicyAzPropertyToTerraform(struct?: TfResiliencyPolicy.AzProperty | cdktn.IResolvable): any;
export declare function tfResiliencyPolicyAzPropertyToHclTerraform(struct?: TfResiliencyPolicy.AzProperty | cdktn.IResolvable): any;
export declare function tfResiliencyPolicyHardwarePropertyToTerraform(struct?: TfResiliencyPolicy.HardwareProperty | cdktn.IResolvable): any;
export declare function tfResiliencyPolicyHardwarePropertyToHclTerraform(struct?: TfResiliencyPolicy.HardwareProperty | cdktn.IResolvable): any;
export declare function tfResiliencyPolicyRegionPropertyToTerraform(struct?: TfResiliencyPolicy.RegionProperty | cdktn.IResolvable): any;
export declare function tfResiliencyPolicyRegionPropertyToHclTerraform(struct?: TfResiliencyPolicy.RegionProperty | cdktn.IResolvable): any;
export declare function tfResiliencyPolicySoftwarePropertyToTerraform(struct?: TfResiliencyPolicy.SoftwareProperty | cdktn.IResolvable): any;
export declare function tfResiliencyPolicySoftwarePropertyToHclTerraform(struct?: TfResiliencyPolicy.SoftwareProperty | cdktn.IResolvable): any;
export declare function tfResiliencyPolicyPolicyPropertyToTerraform(struct?: TfResiliencyPolicy.PolicyProperty | cdktn.IResolvable): any;
export declare function tfResiliencyPolicyPolicyPropertyToHclTerraform(struct?: TfResiliencyPolicy.PolicyProperty | cdktn.IResolvable): any;
export declare function tfResiliencyPolicyTimeoutsPropertyToTerraform(struct?: TfResiliencyPolicy.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfResiliencyPolicyTimeoutsPropertyToHclTerraform(struct?: TfResiliencyPolicy.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfResiliencyPolicy {
    interface AzProperty {
        /**
        * Recovery Point Objective (RPO) as a Go duration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#rpo TfResiliencyPolicy#rpo}
        */
        readonly rpo: string;
        /**
        * Recovery Time Objective (RTO) as a Go duration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#rto TfResiliencyPolicy#rto}
        */
        readonly rto: string;
    }
    class AzPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AzProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AzProperty | cdktn.IResolvable | undefined);
        private _rpo?;
        get rpo(): string;
        set rpo(value: string);
        get rpoInput(): string | undefined;
        private _rto?;
        get rto(): string;
        set rto(value: string);
        get rtoInput(): string | undefined;
    }
    class AzPropertyList extends cdktn.ComplexList {
        internalValue?: AzProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AzPropertyOutputReference;
    }
    interface HardwareProperty {
        /**
        * Recovery Point Objective (RPO) as a Go duration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#rpo TfResiliencyPolicy#rpo}
        */
        readonly rpo: string;
        /**
        * Recovery Time Objective (RTO) as a Go duration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#rto TfResiliencyPolicy#rto}
        */
        readonly rto: string;
    }
    class HardwarePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HardwareProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HardwareProperty | cdktn.IResolvable | undefined);
        private _rpo?;
        get rpo(): string;
        set rpo(value: string);
        get rpoInput(): string | undefined;
        private _rto?;
        get rto(): string;
        set rto(value: string);
        get rtoInput(): string | undefined;
    }
    class HardwarePropertyList extends cdktn.ComplexList {
        internalValue?: HardwareProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HardwarePropertyOutputReference;
    }
    interface RegionProperty {
        /**
        * Recovery Point Objective (RPO) as a Go duration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#rpo TfResiliencyPolicy#rpo}
        */
        readonly rpo?: string;
        /**
        * Recovery Time Objective (RTO) as a Go duration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#rto TfResiliencyPolicy#rto}
        */
        readonly rto?: string;
    }
    class RegionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RegionProperty | cdktn.IResolvable | undefined);
        private _rpo?;
        get rpo(): string;
        set rpo(value: string);
        resetRpo(): void;
        get rpoInput(): string | undefined;
        private _rto?;
        get rto(): string;
        set rto(value: string);
        resetRto(): void;
        get rtoInput(): string | undefined;
    }
    class RegionPropertyList extends cdktn.ComplexList {
        internalValue?: RegionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegionPropertyOutputReference;
    }
    interface SoftwareProperty {
        /**
        * Recovery Point Objective (RPO) as a Go duration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#rpo TfResiliencyPolicy#rpo}
        */
        readonly rpo: string;
        /**
        * Recovery Time Objective (RTO) as a Go duration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#rto TfResiliencyPolicy#rto}
        */
        readonly rto: string;
    }
    class SoftwarePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SoftwareProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SoftwareProperty | cdktn.IResolvable | undefined);
        private _rpo?;
        get rpo(): string;
        set rpo(value: string);
        get rpoInput(): string | undefined;
        private _rto?;
        get rto(): string;
        set rto(value: string);
        get rtoInput(): string | undefined;
    }
    class SoftwarePropertyList extends cdktn.ComplexList {
        internalValue?: SoftwareProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SoftwarePropertyOutputReference;
    }
    interface PolicyProperty {
        /**
        * az block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#az TfResiliencyPolicy#az}
        */
        readonly az?: AzProperty[] | cdktn.IResolvable;
        /**
        * hardware block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#hardware TfResiliencyPolicy#hardware}
        */
        readonly hardware?: HardwareProperty[] | cdktn.IResolvable;
        /**
        * region block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#region TfResiliencyPolicy#region}
        */
        readonly region?: RegionProperty[] | cdktn.IResolvable;
        /**
        * software block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#software TfResiliencyPolicy#software}
        */
        readonly softwareAttribute?: SoftwareProperty[] | cdktn.IResolvable;
    }
    class PolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolicyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PolicyProperty | cdktn.IResolvable | undefined);
        private _az;
        get az(): AzPropertyList;
        putAz(value: AzProperty[] | cdktn.IResolvable): void;
        resetAz(): void;
        get azInput(): cdktn.IResolvable | AzProperty[] | undefined;
        private _hardware;
        get hardware(): HardwarePropertyList;
        putHardware(value: HardwareProperty[] | cdktn.IResolvable): void;
        resetHardware(): void;
        get hardwareInput(): cdktn.IResolvable | HardwareProperty[] | undefined;
        private _region;
        get region(): RegionPropertyList;
        putRegion(value: RegionProperty[] | cdktn.IResolvable): void;
        resetRegion(): void;
        get regionInput(): cdktn.IResolvable | RegionProperty[] | undefined;
        private _software;
        get softwareAttribute(): SoftwarePropertyList;
        putSoftwareAttribute(value: SoftwareProperty[] | cdktn.IResolvable): void;
        resetSoftwareAttribute(): void;
        get softwareAttributeInput(): cdktn.IResolvable | SoftwareProperty[] | undefined;
    }
    class PolicyPropertyList extends cdktn.ComplexList {
        internalValue?: PolicyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolicyPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#create TfResiliencyPolicy#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#delete TfResiliencyPolicy#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#update TfResiliencyPolicy#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
