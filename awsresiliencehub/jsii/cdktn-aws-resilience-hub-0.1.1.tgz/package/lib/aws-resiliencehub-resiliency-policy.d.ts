import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsResiliencehubResiliencyPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies a high-level geographical location constraint for where resilience policy data can be stored.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#data_location_constraint AwsResiliencehubResiliencyPolicy#data_location_constraint}
    */
    readonly dataLocationConstraint?: string;
    /**
    * The description for the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#description AwsResiliencehubResiliencyPolicy#description}
    */
    readonly description?: string;
    /**
    * The name of the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#name AwsResiliencehubResiliencyPolicy#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#region AwsResiliencehubResiliencyPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#tags AwsResiliencehubResiliencyPolicy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * The tier for the resiliency policy, ranging from the highest severity (MissionCritical) to lowest (NonCritical).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#tier AwsResiliencehubResiliencyPolicy#tier}
    */
    readonly tier: string;
    /**
    * policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#policy AwsResiliencehubResiliencyPolicy#policy}
    */
    readonly policy?: AwsResiliencehubResiliencyPolicy.PolicyProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#timeouts AwsResiliencehubResiliencyPolicy#timeouts}
    */
    readonly timeouts?: AwsResiliencehubResiliencyPolicy.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy aws_resiliencehub_resiliency_policy}
*/
export declare class AwsResiliencehubResiliencyPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_resiliencehub_resiliency_policy";
    /**
    * Generates CDKTN code for importing a AwsResiliencehubResiliencyPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsResiliencehubResiliencyPolicy to import
    * @param importFromId The id of the existing AwsResiliencehubResiliencyPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsResiliencehubResiliencyPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy aws_resiliencehub_resiliency_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsResiliencehubResiliencyPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsResiliencehubResiliencyPolicyConfig);
    get arn(): string;
    private _dataLocationConstraint?;
    get dataLocationConstraint(): string;
    set dataLocationConstraint(value: string);
    resetDataLocationConstraint(): void;
    get dataLocationConstraintInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get estimatedCostTier(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _tier?;
    get tier(): string;
    set tier(value: string);
    get tierInput(): string | undefined;
    private _policy;
    get policy(): AwsResiliencehubResiliencyPolicy.PolicyPropertyList;
    putPolicy(value: AwsResiliencehubResiliencyPolicy.PolicyProperty[] | cdktn.IResolvable): void;
    resetPolicy(): void;
    get policyInput(): cdktn.IResolvable | AwsResiliencehubResiliencyPolicy.PolicyProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsResiliencehubResiliencyPolicy.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsResiliencehubResiliencyPolicy.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsResiliencehubResiliencyPolicy.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsResiliencehubResiliencyPolicyAzPropertyToTerraform(struct?: AwsResiliencehubResiliencyPolicy.AzProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubResiliencyPolicyAzPropertyToHclTerraform(struct?: AwsResiliencehubResiliencyPolicy.AzProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubResiliencyPolicyHardwarePropertyToTerraform(struct?: AwsResiliencehubResiliencyPolicy.HardwareProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubResiliencyPolicyHardwarePropertyToHclTerraform(struct?: AwsResiliencehubResiliencyPolicy.HardwareProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubResiliencyPolicyRegionPropertyToTerraform(struct?: AwsResiliencehubResiliencyPolicy.RegionProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubResiliencyPolicyRegionPropertyToHclTerraform(struct?: AwsResiliencehubResiliencyPolicy.RegionProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubResiliencyPolicySoftwarePropertyToTerraform(struct?: AwsResiliencehubResiliencyPolicy.SoftwareProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubResiliencyPolicySoftwarePropertyToHclTerraform(struct?: AwsResiliencehubResiliencyPolicy.SoftwareProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubResiliencyPolicyPolicyPropertyToTerraform(struct?: AwsResiliencehubResiliencyPolicy.PolicyProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubResiliencyPolicyPolicyPropertyToHclTerraform(struct?: AwsResiliencehubResiliencyPolicy.PolicyProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubResiliencyPolicyTimeoutsPropertyToTerraform(struct?: AwsResiliencehubResiliencyPolicy.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsResiliencehubResiliencyPolicyTimeoutsPropertyToHclTerraform(struct?: AwsResiliencehubResiliencyPolicy.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsResiliencehubResiliencyPolicy {
    interface AzProperty {
        /**
        * Recovery Point Objective (RPO) as a Go duration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#rpo AwsResiliencehubResiliencyPolicy#rpo}
        */
        readonly rpo: string;
        /**
        * Recovery Time Objective (RTO) as a Go duration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#rto AwsResiliencehubResiliencyPolicy#rto}
        */
        readonly rto: string;
    }
    class AzPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AzProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AzProperty | cdktn.IResolvable | undefined);
        private _rpo?;
        get rpo(): string;
        set rpo(value: string);
        get rpoInput(): string | undefined;
        private _rto?;
        get rto(): string;
        set rto(value: string);
        get rtoInput(): string | undefined;
    }
    class AzPropertyList extends cdktn.ComplexList {
        internalValue?: AzProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AzPropertyOutputReference;
    }
    interface HardwareProperty {
        /**
        * Recovery Point Objective (RPO) as a Go duration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#rpo AwsResiliencehubResiliencyPolicy#rpo}
        */
        readonly rpo: string;
        /**
        * Recovery Time Objective (RTO) as a Go duration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#rto AwsResiliencehubResiliencyPolicy#rto}
        */
        readonly rto: string;
    }
    class HardwarePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HardwareProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HardwareProperty | cdktn.IResolvable | undefined);
        private _rpo?;
        get rpo(): string;
        set rpo(value: string);
        get rpoInput(): string | undefined;
        private _rto?;
        get rto(): string;
        set rto(value: string);
        get rtoInput(): string | undefined;
    }
    class HardwarePropertyList extends cdktn.ComplexList {
        internalValue?: HardwareProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HardwarePropertyOutputReference;
    }
    interface RegionProperty {
        /**
        * Recovery Point Objective (RPO) as a Go duration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#rpo AwsResiliencehubResiliencyPolicy#rpo}
        */
        readonly rpo?: string;
        /**
        * Recovery Time Objective (RTO) as a Go duration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#rto AwsResiliencehubResiliencyPolicy#rto}
        */
        readonly rto?: string;
    }
    class RegionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RegionProperty | cdktn.IResolvable | undefined);
        private _rpo?;
        get rpo(): string;
        set rpo(value: string);
        resetRpo(): void;
        get rpoInput(): string | undefined;
        private _rto?;
        get rto(): string;
        set rto(value: string);
        resetRto(): void;
        get rtoInput(): string | undefined;
    }
    class RegionPropertyList extends cdktn.ComplexList {
        internalValue?: RegionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegionPropertyOutputReference;
    }
    interface SoftwareProperty {
        /**
        * Recovery Point Objective (RPO) as a Go duration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#rpo AwsResiliencehubResiliencyPolicy#rpo}
        */
        readonly rpo: string;
        /**
        * Recovery Time Objective (RTO) as a Go duration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#rto AwsResiliencehubResiliencyPolicy#rto}
        */
        readonly rto: string;
    }
    class SoftwarePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SoftwareProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SoftwareProperty | cdktn.IResolvable | undefined);
        private _rpo?;
        get rpo(): string;
        set rpo(value: string);
        get rpoInput(): string | undefined;
        private _rto?;
        get rto(): string;
        set rto(value: string);
        get rtoInput(): string | undefined;
    }
    class SoftwarePropertyList extends cdktn.ComplexList {
        internalValue?: SoftwareProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SoftwarePropertyOutputReference;
    }
    interface PolicyProperty {
        /**
        * az block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#az AwsResiliencehubResiliencyPolicy#az}
        */
        readonly az?: AzProperty[] | cdktn.IResolvable;
        /**
        * hardware block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#hardware AwsResiliencehubResiliencyPolicy#hardware}
        */
        readonly hardware?: HardwareProperty[] | cdktn.IResolvable;
        /**
        * region block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#region AwsResiliencehubResiliencyPolicy#region}
        */
        readonly region?: RegionProperty[] | cdktn.IResolvable;
        /**
        * software block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#software AwsResiliencehubResiliencyPolicy#software}
        */
        readonly softwareAttribute?: SoftwareProperty[] | cdktn.IResolvable;
    }
    class PolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolicyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PolicyProperty | cdktn.IResolvable | undefined);
        private _az;
        get az(): AzPropertyList;
        putAz(value: AzProperty[] | cdktn.IResolvable): void;
        resetAz(): void;
        get azInput(): cdktn.IResolvable | AzProperty[] | undefined;
        private _hardware;
        get hardware(): HardwarePropertyList;
        putHardware(value: HardwareProperty[] | cdktn.IResolvable): void;
        resetHardware(): void;
        get hardwareInput(): cdktn.IResolvable | HardwareProperty[] | undefined;
        private _region;
        get region(): RegionPropertyList;
        putRegion(value: RegionProperty[] | cdktn.IResolvable): void;
        resetRegion(): void;
        get regionInput(): cdktn.IResolvable | RegionProperty[] | undefined;
        private _software;
        get softwareAttribute(): SoftwarePropertyList;
        putSoftwareAttribute(value: SoftwareProperty[] | cdktn.IResolvable): void;
        resetSoftwareAttribute(): void;
        get softwareAttributeInput(): cdktn.IResolvable | SoftwareProperty[] | undefined;
    }
    class PolicyPropertyList extends cdktn.ComplexList {
        internalValue?: PolicyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolicyPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#create AwsResiliencehubResiliencyPolicy#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#delete AwsResiliencehubResiliencyPolicy#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehub_resiliency_policy#update AwsResiliencehubResiliencyPolicy#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
