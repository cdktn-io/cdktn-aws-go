import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Primary email address used to register the group with WorkMail.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_group#email AwsGroup#email}
    */
    readonly email: string;
    /**
    * Whether to hide the group from the global address list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_group#hidden_from_global_address_list AwsGroup#hidden_from_global_address_list}
    */
    readonly hiddenFromGlobalAddressList?: boolean | cdktn.IResolvable;
    /**
    * Name of the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_group#name AwsGroup#name}
    */
    readonly name: string;
    /**
    * Identifier of the WorkMail organization where the group is managed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_group#organization_id AwsGroup#organization_id}
    */
    readonly organizationId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_group#region AwsGroup#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_group aws_workmail_group}
*/
export declare class AwsGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_workmail_group";
    /**
    * Generates CDKTN code for importing a AwsGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGroup to import
    * @param importFromId The id of the existing AwsGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/workmail_group aws_workmail_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsGroupConfig);
    get disabledDate(): string;
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
    get enabledDate(): string;
    get groupId(): string;
    private _hiddenFromGlobalAddressList?;
    get hiddenFromGlobalAddressList(): boolean | cdktn.IResolvable;
    set hiddenFromGlobalAddressList(value: boolean | cdktn.IResolvable);
    resetHiddenFromGlobalAddressList(): void;
    get hiddenFromGlobalAddressListInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get state(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
