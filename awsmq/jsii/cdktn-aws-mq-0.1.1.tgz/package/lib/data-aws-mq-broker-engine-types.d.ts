import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsMqBrokerEngineTypesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker_engine_types#engine_type DataAwsMqBrokerEngineTypes#engine_type}
    */
    readonly engineType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker_engine_types#id DataAwsMqBrokerEngineTypes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker_engine_types#region DataAwsMqBrokerEngineTypes#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker_engine_types aws_mq_broker_engine_types}
*/
export declare class DataAwsMqBrokerEngineTypes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_mq_broker_engine_types";
    /**
    * Generates CDKTN code for importing a DataAwsMqBrokerEngineTypes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsMqBrokerEngineTypes to import
    * @param importFromId The id of the existing DataAwsMqBrokerEngineTypes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker_engine_types#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsMqBrokerEngineTypes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/mq_broker_engine_types aws_mq_broker_engine_types} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsMqBrokerEngineTypesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsMqBrokerEngineTypesConfig);
    private _brokerEngineTypes;
    get brokerEngineTypes(): DataAwsMqBrokerEngineTypes.BrokerEngineTypesPropertyList;
    private _engineType?;
    get engineType(): string;
    set engineType(value: string);
    resetEngineType(): void;
    get engineTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsMqBrokerEngineTypesEngineVersionsPropertyToTerraform(struct?: DataAwsMqBrokerEngineTypes.EngineVersionsProperty): any;
export declare function dataAwsMqBrokerEngineTypesEngineVersionsPropertyToHclTerraform(struct?: DataAwsMqBrokerEngineTypes.EngineVersionsProperty): any;
export declare function dataAwsMqBrokerEngineTypesBrokerEngineTypesPropertyToTerraform(struct?: DataAwsMqBrokerEngineTypes.BrokerEngineTypesProperty): any;
export declare function dataAwsMqBrokerEngineTypesBrokerEngineTypesPropertyToHclTerraform(struct?: DataAwsMqBrokerEngineTypes.BrokerEngineTypesProperty): any;
export declare namespace DataAwsMqBrokerEngineTypes {
    interface EngineVersionsProperty {
    }
    class EngineVersionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EngineVersionsProperty | undefined;
        set internalValue(value: EngineVersionsProperty | undefined);
        get name(): string;
    }
    class EngineVersionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EngineVersionsPropertyOutputReference;
    }
    interface BrokerEngineTypesProperty {
    }
    class BrokerEngineTypesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BrokerEngineTypesProperty | undefined;
        set internalValue(value: BrokerEngineTypesProperty | undefined);
        get engineType(): string;
        private _engineVersions;
        get engineVersions(): EngineVersionsPropertyList;
    }
    class BrokerEngineTypesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BrokerEngineTypesPropertyOutputReference;
    }
}
