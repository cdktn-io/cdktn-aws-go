import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfBrokerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#apply_immediately TfBroker#apply_immediately}
    */
    readonly applyImmediately?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#authentication_strategy TfBroker#authentication_strategy}
    */
    readonly authenticationStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#auto_minor_version_upgrade TfBroker#auto_minor_version_upgrade}
    */
    readonly autoMinorVersionUpgrade?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#broker_name TfBroker#broker_name}
    */
    readonly brokerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#data_replication_mode TfBroker#data_replication_mode}
    */
    readonly dataReplicationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#data_replication_primary_broker_arn TfBroker#data_replication_primary_broker_arn}
    */
    readonly dataReplicationPrimaryBrokerArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#deployment_mode TfBroker#deployment_mode}
    */
    readonly deploymentMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#engine_type TfBroker#engine_type}
    */
    readonly engineType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#engine_version TfBroker#engine_version}
    */
    readonly engineVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#host_instance_type TfBroker#host_instance_type}
    */
    readonly hostInstanceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#id TfBroker#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#publicly_accessible TfBroker#publicly_accessible}
    */
    readonly publiclyAccessible?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#region TfBroker#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#resource_share_arns TfBroker#resource_share_arns}
    */
    readonly resourceShareArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#security_groups TfBroker#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#storage_type TfBroker#storage_type}
    */
    readonly storageType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#subnet_ids TfBroker#subnet_ids}
    */
    readonly subnetIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#tags TfBroker#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#tags_all TfBroker#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#configuration TfBroker#configuration}
    */
    readonly configuration?: TfBroker.ConfigurationProperty;
    /**
    * encryption_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#encryption_options TfBroker#encryption_options}
    */
    readonly encryptionOptions?: TfBroker.EncryptionOptionsProperty;
    /**
    * ldap_server_metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#ldap_server_metadata TfBroker#ldap_server_metadata}
    */
    readonly ldapServerMetadata?: TfBroker.LdapServerMetadataProperty;
    /**
    * logs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#logs TfBroker#logs}
    */
    readonly logs?: TfBroker.LogsProperty;
    /**
    * maintenance_window_start_time block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#maintenance_window_start_time TfBroker#maintenance_window_start_time}
    */
    readonly maintenanceWindowStartTime?: TfBroker.MaintenanceWindowStartTimeProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#timeouts TfBroker#timeouts}
    */
    readonly timeouts?: TfBroker.TimeoutsProperty;
    /**
    * user block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#user TfBroker#user}
    */
    readonly user?: TfBroker.UserProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker aws_mq_broker}
*/
export declare class TfBroker extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_mq_broker";
    /**
    * Generates CDKTN code for importing a TfBroker resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfBroker to import
    * @param importFromId The id of the existing TfBroker that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfBroker to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker aws_mq_broker} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfBrokerConfig
    */
    constructor(scope: Construct, id: string, config: TfBrokerConfig);
    private _applyImmediately?;
    get applyImmediately(): boolean | cdktn.IResolvable;
    set applyImmediately(value: boolean | cdktn.IResolvable);
    resetApplyImmediately(): void;
    get applyImmediatelyInput(): boolean | cdktn.IResolvable | undefined;
    get arn(): string;
    private _authenticationStrategy?;
    get authenticationStrategy(): string;
    set authenticationStrategy(value: string);
    resetAuthenticationStrategy(): void;
    get authenticationStrategyInput(): string | undefined;
    private _autoMinorVersionUpgrade?;
    get autoMinorVersionUpgrade(): boolean | cdktn.IResolvable;
    set autoMinorVersionUpgrade(value: boolean | cdktn.IResolvable);
    resetAutoMinorVersionUpgrade(): void;
    get autoMinorVersionUpgradeInput(): boolean | cdktn.IResolvable | undefined;
    private _brokerName?;
    get brokerName(): string;
    set brokerName(value: string);
    get brokerNameInput(): string | undefined;
    private _dataReplicationMode?;
    get dataReplicationMode(): string;
    set dataReplicationMode(value: string);
    resetDataReplicationMode(): void;
    get dataReplicationModeInput(): string | undefined;
    private _dataReplicationPrimaryBrokerArn?;
    get dataReplicationPrimaryBrokerArn(): string;
    set dataReplicationPrimaryBrokerArn(value: string);
    resetDataReplicationPrimaryBrokerArn(): void;
    get dataReplicationPrimaryBrokerArnInput(): string | undefined;
    private _deploymentMode?;
    get deploymentMode(): string;
    set deploymentMode(value: string);
    resetDeploymentMode(): void;
    get deploymentModeInput(): string | undefined;
    private _engineType?;
    get engineType(): string;
    set engineType(value: string);
    get engineTypeInput(): string | undefined;
    private _engineVersion?;
    get engineVersion(): string;
    set engineVersion(value: string);
    get engineVersionInput(): string | undefined;
    private _hostInstanceType?;
    get hostInstanceType(): string;
    set hostInstanceType(value: string);
    get hostInstanceTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instances;
    get instances(): TfBroker.InstancesPropertyList;
    get pendingDataReplicationMode(): string;
    private _publiclyAccessible?;
    get publiclyAccessible(): boolean | cdktn.IResolvable;
    set publiclyAccessible(value: boolean | cdktn.IResolvable);
    resetPubliclyAccessible(): void;
    get publiclyAccessibleInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceShareArns?;
    get resourceShareArns(): string[];
    set resourceShareArns(value: string[]);
    resetResourceShareArns(): void;
    get resourceShareArnsInput(): string[] | undefined;
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _sharedResources;
    get sharedResources(): TfBroker.SharedResourcesPropertyList;
    private _storageType?;
    get storageType(): string;
    set storageType(value: string);
    resetStorageType(): void;
    get storageTypeInput(): string | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _configuration;
    get configuration(): TfBroker.ConfigurationPropertyOutputReference;
    putConfiguration(value: TfBroker.ConfigurationProperty): void;
    resetConfiguration(): void;
    get configurationInput(): TfBroker.ConfigurationProperty | undefined;
    private _encryptionOptions;
    get encryptionOptions(): TfBroker.EncryptionOptionsPropertyOutputReference;
    putEncryptionOptions(value: TfBroker.EncryptionOptionsProperty): void;
    resetEncryptionOptions(): void;
    get encryptionOptionsInput(): TfBroker.EncryptionOptionsProperty | undefined;
    private _ldapServerMetadata;
    get ldapServerMetadata(): TfBroker.LdapServerMetadataPropertyOutputReference;
    putLdapServerMetadata(value: TfBroker.LdapServerMetadataProperty): void;
    resetLdapServerMetadata(): void;
    get ldapServerMetadataInput(): TfBroker.LdapServerMetadataProperty | undefined;
    private _logs;
    get logs(): TfBroker.LogsPropertyOutputReference;
    putLogs(value: TfBroker.LogsProperty): void;
    resetLogs(): void;
    get logsInput(): TfBroker.LogsProperty | undefined;
    private _maintenanceWindowStartTime;
    get maintenanceWindowStartTime(): TfBroker.MaintenanceWindowStartTimePropertyOutputReference;
    putMaintenanceWindowStartTime(value: TfBroker.MaintenanceWindowStartTimeProperty): void;
    resetMaintenanceWindowStartTime(): void;
    get maintenanceWindowStartTimeInput(): TfBroker.MaintenanceWindowStartTimeProperty | undefined;
    private _timeouts;
    get timeouts(): TfBroker.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfBroker.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfBroker.TimeoutsProperty | undefined;
    private _user;
    get user(): TfBroker.UserPropertyList;
    putUser(value: TfBroker.UserProperty[] | cdktn.IResolvable): void;
    resetUser(): void;
    get userInput(): cdktn.IResolvable | TfBroker.UserProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfBrokerInstancesPropertyToTerraform(struct?: TfBroker.InstancesProperty): any;
export declare function tfBrokerInstancesPropertyToHclTerraform(struct?: TfBroker.InstancesProperty): any;
export declare function tfBrokerSharedResourcesPropertyToTerraform(struct?: TfBroker.SharedResourcesProperty): any;
export declare function tfBrokerSharedResourcesPropertyToHclTerraform(struct?: TfBroker.SharedResourcesProperty): any;
export declare function tfBrokerConfigurationPropertyToTerraform(struct?: TfBroker.ConfigurationPropertyOutputReference | TfBroker.ConfigurationProperty): any;
export declare function tfBrokerConfigurationPropertyToHclTerraform(struct?: TfBroker.ConfigurationPropertyOutputReference | TfBroker.ConfigurationProperty): any;
export declare function tfBrokerEncryptionOptionsPropertyToTerraform(struct?: TfBroker.EncryptionOptionsPropertyOutputReference | TfBroker.EncryptionOptionsProperty): any;
export declare function tfBrokerEncryptionOptionsPropertyToHclTerraform(struct?: TfBroker.EncryptionOptionsPropertyOutputReference | TfBroker.EncryptionOptionsProperty): any;
export declare function tfBrokerLdapServerMetadataPropertyToTerraform(struct?: TfBroker.LdapServerMetadataPropertyOutputReference | TfBroker.LdapServerMetadataProperty): any;
export declare function tfBrokerLdapServerMetadataPropertyToHclTerraform(struct?: TfBroker.LdapServerMetadataPropertyOutputReference | TfBroker.LdapServerMetadataProperty): any;
export declare function tfBrokerLogsPropertyToTerraform(struct?: TfBroker.LogsPropertyOutputReference | TfBroker.LogsProperty): any;
export declare function tfBrokerLogsPropertyToHclTerraform(struct?: TfBroker.LogsPropertyOutputReference | TfBroker.LogsProperty): any;
export declare function tfBrokerMaintenanceWindowStartTimePropertyToTerraform(struct?: TfBroker.MaintenanceWindowStartTimePropertyOutputReference | TfBroker.MaintenanceWindowStartTimeProperty): any;
export declare function tfBrokerMaintenanceWindowStartTimePropertyToHclTerraform(struct?: TfBroker.MaintenanceWindowStartTimePropertyOutputReference | TfBroker.MaintenanceWindowStartTimeProperty): any;
export declare function tfBrokerTimeoutsPropertyToTerraform(struct?: TfBroker.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfBrokerTimeoutsPropertyToHclTerraform(struct?: TfBroker.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfBrokerUserPropertyToTerraform(struct?: TfBroker.UserProperty | cdktn.IResolvable): any;
export declare function tfBrokerUserPropertyToHclTerraform(struct?: TfBroker.UserProperty | cdktn.IResolvable): any;
export declare namespace TfBroker {
    interface InstancesProperty {
    }
    class InstancesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstancesProperty | undefined;
        set internalValue(value: InstancesProperty | undefined);
        get consoleUrl(): string;
        get endpoints(): string[];
        get ipAddress(): string;
    }
    class InstancesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstancesPropertyOutputReference;
    }
    interface SharedResourcesProperty {
    }
    class SharedResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SharedResourcesProperty | undefined;
        set internalValue(value: SharedResourcesProperty | undefined);
        get dnsNames(): string[];
        get resourceArn(): string;
        get status(): string;
        get type(): string;
    }
    class SharedResourcesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SharedResourcesPropertyOutputReference;
    }
    interface ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#id TfBroker#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#revision TfBroker#revision}
        */
        readonly revision?: number;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationProperty | undefined;
        set internalValue(value: ConfigurationProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _revision?;
        get revision(): number;
        set revision(value: number);
        resetRevision(): void;
        get revisionInput(): number | undefined;
    }
    interface EncryptionOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#kms_key_id TfBroker#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#use_aws_owned_key TfBroker#use_aws_owned_key}
        */
        readonly useAwsOwnedKey?: boolean | cdktn.IResolvable;
    }
    class EncryptionOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionOptionsProperty | undefined;
        set internalValue(value: EncryptionOptionsProperty | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _useAwsOwnedKey?;
        get useAwsOwnedKey(): boolean | cdktn.IResolvable;
        set useAwsOwnedKey(value: boolean | cdktn.IResolvable);
        resetUseAwsOwnedKey(): void;
        get useAwsOwnedKeyInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface LdapServerMetadataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#hosts TfBroker#hosts}
        */
        readonly hosts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#role_base TfBroker#role_base}
        */
        readonly roleBase?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#role_name TfBroker#role_name}
        */
        readonly roleName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#role_search_matching TfBroker#role_search_matching}
        */
        readonly roleSearchMatching?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#role_search_subtree TfBroker#role_search_subtree}
        */
        readonly roleSearchSubtree?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#service_account_password TfBroker#service_account_password}
        */
        readonly serviceAccountPassword?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#service_account_username TfBroker#service_account_username}
        */
        readonly serviceAccountUsername?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#user_base TfBroker#user_base}
        */
        readonly userBase?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#user_role_name TfBroker#user_role_name}
        */
        readonly userRoleName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#user_search_matching TfBroker#user_search_matching}
        */
        readonly userSearchMatching?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#user_search_subtree TfBroker#user_search_subtree}
        */
        readonly userSearchSubtree?: boolean | cdktn.IResolvable;
    }
    class LdapServerMetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LdapServerMetadataProperty | undefined;
        set internalValue(value: LdapServerMetadataProperty | undefined);
        private _hosts?;
        get hosts(): string[];
        set hosts(value: string[]);
        resetHosts(): void;
        get hostsInput(): string[] | undefined;
        private _roleBase?;
        get roleBase(): string;
        set roleBase(value: string);
        resetRoleBase(): void;
        get roleBaseInput(): string | undefined;
        private _roleName?;
        get roleName(): string;
        set roleName(value: string);
        resetRoleName(): void;
        get roleNameInput(): string | undefined;
        private _roleSearchMatching?;
        get roleSearchMatching(): string;
        set roleSearchMatching(value: string);
        resetRoleSearchMatching(): void;
        get roleSearchMatchingInput(): string | undefined;
        private _roleSearchSubtree?;
        get roleSearchSubtree(): boolean | cdktn.IResolvable;
        set roleSearchSubtree(value: boolean | cdktn.IResolvable);
        resetRoleSearchSubtree(): void;
        get roleSearchSubtreeInput(): boolean | cdktn.IResolvable | undefined;
        private _serviceAccountPassword?;
        get serviceAccountPassword(): string;
        set serviceAccountPassword(value: string);
        resetServiceAccountPassword(): void;
        get serviceAccountPasswordInput(): string | undefined;
        private _serviceAccountUsername?;
        get serviceAccountUsername(): string;
        set serviceAccountUsername(value: string);
        resetServiceAccountUsername(): void;
        get serviceAccountUsernameInput(): string | undefined;
        private _userBase?;
        get userBase(): string;
        set userBase(value: string);
        resetUserBase(): void;
        get userBaseInput(): string | undefined;
        private _userRoleName?;
        get userRoleName(): string;
        set userRoleName(value: string);
        resetUserRoleName(): void;
        get userRoleNameInput(): string | undefined;
        private _userSearchMatching?;
        get userSearchMatching(): string;
        set userSearchMatching(value: string);
        resetUserSearchMatching(): void;
        get userSearchMatchingInput(): string | undefined;
        private _userSearchSubtree?;
        get userSearchSubtree(): boolean | cdktn.IResolvable;
        set userSearchSubtree(value: boolean | cdktn.IResolvable);
        resetUserSearchSubtree(): void;
        get userSearchSubtreeInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface LogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#audit TfBroker#audit}
        */
        readonly audit?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#general TfBroker#general}
        */
        readonly general?: boolean | cdktn.IResolvable;
    }
    class LogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LogsProperty | undefined;
        set internalValue(value: LogsProperty | undefined);
        private _audit?;
        get audit(): string;
        set audit(value: string);
        resetAudit(): void;
        get auditInput(): string | undefined;
        private _general?;
        get general(): boolean | cdktn.IResolvable;
        set general(value: boolean | cdktn.IResolvable);
        resetGeneral(): void;
        get generalInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface MaintenanceWindowStartTimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#day_of_week TfBroker#day_of_week}
        */
        readonly dayOfWeek: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#time_of_day TfBroker#time_of_day}
        */
        readonly timeOfDay: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#time_zone TfBroker#time_zone}
        */
        readonly timeZone: string;
    }
    class MaintenanceWindowStartTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaintenanceWindowStartTimeProperty | undefined;
        set internalValue(value: MaintenanceWindowStartTimeProperty | undefined);
        private _dayOfWeek?;
        get dayOfWeek(): string;
        set dayOfWeek(value: string);
        get dayOfWeekInput(): string | undefined;
        private _timeOfDay?;
        get timeOfDay(): string;
        set timeOfDay(value: string);
        get timeOfDayInput(): string | undefined;
        private _timeZone?;
        get timeZone(): string;
        set timeZone(value: string);
        get timeZoneInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#create TfBroker#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#delete TfBroker#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#update TfBroker#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface UserProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#console_access TfBroker#console_access}
        */
        readonly consoleAccess?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#groups TfBroker#groups}
        */
        readonly groups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#password TfBroker#password}
        */
        readonly password: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#replication_user TfBroker#replication_user}
        */
        readonly replicationUser?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mq_broker#username TfBroker#username}
        */
        readonly username: string;
    }
    class UserPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UserProperty | cdktn.IResolvable | undefined);
        private _consoleAccess?;
        get consoleAccess(): boolean | cdktn.IResolvable;
        set consoleAccess(value: boolean | cdktn.IResolvable);
        resetConsoleAccess(): void;
        get consoleAccessInput(): boolean | cdktn.IResolvable | undefined;
        private _groups?;
        get groups(): string[];
        set groups(value: string[]);
        resetGroups(): void;
        get groupsInput(): string[] | undefined;
        private _password?;
        get password(): string;
        set password(value: string);
        get passwordInput(): string | undefined;
        private _replicationUser?;
        get replicationUser(): boolean | cdktn.IResolvable;
        set replicationUser(value: boolean | cdktn.IResolvable);
        resetReplicationUser(): void;
        get replicationUserInput(): boolean | cdktn.IResolvable | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        get usernameInput(): string | undefined;
    }
    class UserPropertyList extends cdktn.ComplexList {
        internalValue?: UserProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserPropertyOutputReference;
    }
}
