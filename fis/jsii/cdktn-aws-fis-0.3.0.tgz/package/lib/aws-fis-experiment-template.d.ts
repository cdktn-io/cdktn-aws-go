import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsExperimentTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#description AwsExperimentTemplate#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#id AwsExperimentTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#region AwsExperimentTemplate#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#role_arn AwsExperimentTemplate#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#tags AwsExperimentTemplate#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#tags_all AwsExperimentTemplate#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#action AwsExperimentTemplate#action}
    */
    readonly action: AwsExperimentTemplate.ActionProperty[] | cdktn.IResolvable;
    /**
    * experiment_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#experiment_options AwsExperimentTemplate#experiment_options}
    */
    readonly experimentOptions?: AwsExperimentTemplate.ExperimentOptionsProperty;
    /**
    * experiment_report_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#experiment_report_configuration AwsExperimentTemplate#experiment_report_configuration}
    */
    readonly experimentReportConfiguration?: AwsExperimentTemplate.ExperimentReportConfigurationProperty;
    /**
    * log_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#log_configuration AwsExperimentTemplate#log_configuration}
    */
    readonly logConfiguration?: AwsExperimentTemplate.LogConfigurationProperty;
    /**
    * stop_condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#stop_condition AwsExperimentTemplate#stop_condition}
    */
    readonly stopCondition: AwsExperimentTemplate.StopConditionProperty[] | cdktn.IResolvable;
    /**
    * target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#target AwsExperimentTemplate#target}
    */
    readonly target?: AwsExperimentTemplate.TargetProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#timeouts AwsExperimentTemplate#timeouts}
    */
    readonly timeouts?: AwsExperimentTemplate.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template aws_fis_experiment_template}
*/
export declare class AwsExperimentTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_fis_experiment_template";
    /**
    * Generates CDKTN code for importing a AwsExperimentTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsExperimentTemplate to import
    * @param importFromId The id of the existing AwsExperimentTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsExperimentTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template aws_fis_experiment_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsExperimentTemplateConfig
    */
    constructor(scope: Construct, id: string, config: AwsExperimentTemplateConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _action;
    get action(): AwsExperimentTemplate.ActionPropertyList;
    putAction(value: AwsExperimentTemplate.ActionProperty[] | cdktn.IResolvable): void;
    get actionInput(): cdktn.IResolvable | AwsExperimentTemplate.ActionProperty[] | undefined;
    private _experimentOptions;
    get experimentOptions(): AwsExperimentTemplate.ExperimentOptionsPropertyOutputReference;
    putExperimentOptions(value: AwsExperimentTemplate.ExperimentOptionsProperty): void;
    resetExperimentOptions(): void;
    get experimentOptionsInput(): AwsExperimentTemplate.ExperimentOptionsProperty | undefined;
    private _experimentReportConfiguration;
    get experimentReportConfiguration(): AwsExperimentTemplate.ExperimentReportConfigurationPropertyOutputReference;
    putExperimentReportConfiguration(value: AwsExperimentTemplate.ExperimentReportConfigurationProperty): void;
    resetExperimentReportConfiguration(): void;
    get experimentReportConfigurationInput(): AwsExperimentTemplate.ExperimentReportConfigurationProperty | undefined;
    private _logConfiguration;
    get logConfiguration(): AwsExperimentTemplate.LogConfigurationPropertyOutputReference;
    putLogConfiguration(value: AwsExperimentTemplate.LogConfigurationProperty): void;
    resetLogConfiguration(): void;
    get logConfigurationInput(): AwsExperimentTemplate.LogConfigurationProperty | undefined;
    private _stopCondition;
    get stopCondition(): AwsExperimentTemplate.StopConditionPropertyList;
    putStopCondition(value: AwsExperimentTemplate.StopConditionProperty[] | cdktn.IResolvable): void;
    get stopConditionInput(): cdktn.IResolvable | AwsExperimentTemplate.StopConditionProperty[] | undefined;
    private _target;
    get target(): AwsExperimentTemplate.TargetPropertyList;
    putTarget(value: AwsExperimentTemplate.TargetProperty[] | cdktn.IResolvable): void;
    resetTarget(): void;
    get targetInput(): cdktn.IResolvable | AwsExperimentTemplate.TargetProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsExperimentTemplate.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsExperimentTemplate.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsExperimentTemplate.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsExperimentTemplateParameterPropertyToTerraform(struct?: AwsExperimentTemplate.ParameterProperty | cdktn.IResolvable): any;
export declare function awsExperimentTemplateParameterPropertyToHclTerraform(struct?: AwsExperimentTemplate.ParameterProperty | cdktn.IResolvable): any;
export declare function awsExperimentTemplateActionTargetPropertyToTerraform(struct?: AwsExperimentTemplate.ActionTargetPropertyOutputReference | AwsExperimentTemplate.ActionTargetProperty): any;
export declare function awsExperimentTemplateActionTargetPropertyToHclTerraform(struct?: AwsExperimentTemplate.ActionTargetPropertyOutputReference | AwsExperimentTemplate.ActionTargetProperty): any;
export declare function awsExperimentTemplateActionPropertyToTerraform(struct?: AwsExperimentTemplate.ActionProperty | cdktn.IResolvable): any;
export declare function awsExperimentTemplateActionPropertyToHclTerraform(struct?: AwsExperimentTemplate.ActionProperty | cdktn.IResolvable): any;
export declare function awsExperimentTemplateExperimentOptionsPropertyToTerraform(struct?: AwsExperimentTemplate.ExperimentOptionsPropertyOutputReference | AwsExperimentTemplate.ExperimentOptionsProperty): any;
export declare function awsExperimentTemplateExperimentOptionsPropertyToHclTerraform(struct?: AwsExperimentTemplate.ExperimentOptionsPropertyOutputReference | AwsExperimentTemplate.ExperimentOptionsProperty): any;
export declare function awsExperimentTemplateCloudwatchDashboardPropertyToTerraform(struct?: AwsExperimentTemplate.CloudwatchDashboardProperty | cdktn.IResolvable): any;
export declare function awsExperimentTemplateCloudwatchDashboardPropertyToHclTerraform(struct?: AwsExperimentTemplate.CloudwatchDashboardProperty | cdktn.IResolvable): any;
export declare function awsExperimentTemplateDataSourcesPropertyToTerraform(struct?: AwsExperimentTemplate.DataSourcesPropertyOutputReference | AwsExperimentTemplate.DataSourcesProperty): any;
export declare function awsExperimentTemplateDataSourcesPropertyToHclTerraform(struct?: AwsExperimentTemplate.DataSourcesPropertyOutputReference | AwsExperimentTemplate.DataSourcesProperty): any;
export declare function awsExperimentTemplateExperimentReportConfigurationOutputsS3ConfigurationPropertyToTerraform(struct?: AwsExperimentTemplate.ExperimentReportConfigurationOutputsS3ConfigurationPropertyOutputReference | AwsExperimentTemplate.ExperimentReportConfigurationOutputsS3ConfigurationProperty): any;
export declare function awsExperimentTemplateExperimentReportConfigurationOutputsS3ConfigurationPropertyToHclTerraform(struct?: AwsExperimentTemplate.ExperimentReportConfigurationOutputsS3ConfigurationPropertyOutputReference | AwsExperimentTemplate.ExperimentReportConfigurationOutputsS3ConfigurationProperty): any;
export declare function awsExperimentTemplateOutputsPropertyToTerraform(struct?: AwsExperimentTemplate.OutputsPropertyOutputReference | AwsExperimentTemplate.OutputsProperty): any;
export declare function awsExperimentTemplateOutputsPropertyToHclTerraform(struct?: AwsExperimentTemplate.OutputsPropertyOutputReference | AwsExperimentTemplate.OutputsProperty): any;
export declare function awsExperimentTemplateExperimentReportConfigurationPropertyToTerraform(struct?: AwsExperimentTemplate.ExperimentReportConfigurationPropertyOutputReference | AwsExperimentTemplate.ExperimentReportConfigurationProperty): any;
export declare function awsExperimentTemplateExperimentReportConfigurationPropertyToHclTerraform(struct?: AwsExperimentTemplate.ExperimentReportConfigurationPropertyOutputReference | AwsExperimentTemplate.ExperimentReportConfigurationProperty): any;
export declare function awsExperimentTemplateCloudwatchLogsConfigurationPropertyToTerraform(struct?: AwsExperimentTemplate.CloudwatchLogsConfigurationPropertyOutputReference | AwsExperimentTemplate.CloudwatchLogsConfigurationProperty): any;
export declare function awsExperimentTemplateCloudwatchLogsConfigurationPropertyToHclTerraform(struct?: AwsExperimentTemplate.CloudwatchLogsConfigurationPropertyOutputReference | AwsExperimentTemplate.CloudwatchLogsConfigurationProperty): any;
export declare function awsExperimentTemplateLogConfigurationS3ConfigurationPropertyToTerraform(struct?: AwsExperimentTemplate.LogConfigurationS3ConfigurationPropertyOutputReference | AwsExperimentTemplate.LogConfigurationS3ConfigurationProperty): any;
export declare function awsExperimentTemplateLogConfigurationS3ConfigurationPropertyToHclTerraform(struct?: AwsExperimentTemplate.LogConfigurationS3ConfigurationPropertyOutputReference | AwsExperimentTemplate.LogConfigurationS3ConfigurationProperty): any;
export declare function awsExperimentTemplateLogConfigurationPropertyToTerraform(struct?: AwsExperimentTemplate.LogConfigurationPropertyOutputReference | AwsExperimentTemplate.LogConfigurationProperty): any;
export declare function awsExperimentTemplateLogConfigurationPropertyToHclTerraform(struct?: AwsExperimentTemplate.LogConfigurationPropertyOutputReference | AwsExperimentTemplate.LogConfigurationProperty): any;
export declare function awsExperimentTemplateStopConditionPropertyToTerraform(struct?: AwsExperimentTemplate.StopConditionProperty | cdktn.IResolvable): any;
export declare function awsExperimentTemplateStopConditionPropertyToHclTerraform(struct?: AwsExperimentTemplate.StopConditionProperty | cdktn.IResolvable): any;
export declare function awsExperimentTemplateFilterPropertyToTerraform(struct?: AwsExperimentTemplate.FilterProperty | cdktn.IResolvable): any;
export declare function awsExperimentTemplateFilterPropertyToHclTerraform(struct?: AwsExperimentTemplate.FilterProperty | cdktn.IResolvable): any;
export declare function awsExperimentTemplateResourceTagPropertyToTerraform(struct?: AwsExperimentTemplate.ResourceTagProperty | cdktn.IResolvable): any;
export declare function awsExperimentTemplateResourceTagPropertyToHclTerraform(struct?: AwsExperimentTemplate.ResourceTagProperty | cdktn.IResolvable): any;
export declare function awsExperimentTemplateTargetPropertyToTerraform(struct?: AwsExperimentTemplate.TargetProperty | cdktn.IResolvable): any;
export declare function awsExperimentTemplateTargetPropertyToHclTerraform(struct?: AwsExperimentTemplate.TargetProperty | cdktn.IResolvable): any;
export declare function awsExperimentTemplateTimeoutsPropertyToTerraform(struct?: AwsExperimentTemplate.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsExperimentTemplateTimeoutsPropertyToHclTerraform(struct?: AwsExperimentTemplate.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsExperimentTemplate {
    interface ParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#key AwsExperimentTemplate#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#value AwsExperimentTemplate#value}
        */
        readonly value: string;
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        internalValue?: ParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
    interface ActionTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#key AwsExperimentTemplate#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#value AwsExperimentTemplate#value}
        */
        readonly value: string;
    }
    class ActionTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionTargetProperty | undefined;
        set internalValue(value: ActionTargetProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    interface ActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#action_id AwsExperimentTemplate#action_id}
        */
        readonly actionId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#description AwsExperimentTemplate#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#name AwsExperimentTemplate#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#start_after AwsExperimentTemplate#start_after}
        */
        readonly startAfter?: string[];
        /**
        * parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#parameter AwsExperimentTemplate#parameter}
        */
        readonly parameter?: ParameterProperty[] | cdktn.IResolvable;
        /**
        * target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#target AwsExperimentTemplate#target}
        */
        readonly target?: ActionTargetProperty;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionProperty | cdktn.IResolvable | undefined);
        private _actionId?;
        get actionId(): string;
        set actionId(value: string);
        get actionIdInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _startAfter?;
        get startAfter(): string[];
        set startAfter(value: string[]);
        resetStartAfter(): void;
        get startAfterInput(): string[] | undefined;
        private _parameter;
        get parameter(): ParameterPropertyList;
        putParameter(value: ParameterProperty[] | cdktn.IResolvable): void;
        resetParameter(): void;
        get parameterInput(): cdktn.IResolvable | ParameterProperty[] | undefined;
        private _target;
        get target(): ActionTargetPropertyOutputReference;
        putTarget(value: ActionTargetProperty): void;
        resetTarget(): void;
        get targetInput(): ActionTargetProperty | undefined;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface ExperimentOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#account_targeting AwsExperimentTemplate#account_targeting}
        */
        readonly accountTargeting?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#empty_target_resolution_mode AwsExperimentTemplate#empty_target_resolution_mode}
        */
        readonly emptyTargetResolutionMode?: string;
    }
    class ExperimentOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExperimentOptionsProperty | undefined;
        set internalValue(value: ExperimentOptionsProperty | undefined);
        private _accountTargeting?;
        get accountTargeting(): string;
        set accountTargeting(value: string);
        resetAccountTargeting(): void;
        get accountTargetingInput(): string | undefined;
        private _emptyTargetResolutionMode?;
        get emptyTargetResolutionMode(): string;
        set emptyTargetResolutionMode(value: string);
        resetEmptyTargetResolutionMode(): void;
        get emptyTargetResolutionModeInput(): string | undefined;
    }
    interface CloudwatchDashboardProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#dashboard_arn AwsExperimentTemplate#dashboard_arn}
        */
        readonly dashboardArn?: string;
    }
    class CloudwatchDashboardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchDashboardProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchDashboardProperty | cdktn.IResolvable | undefined);
        private _dashboardArn?;
        get dashboardArn(): string;
        set dashboardArn(value: string);
        resetDashboardArn(): void;
        get dashboardArnInput(): string | undefined;
    }
    class CloudwatchDashboardPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchDashboardProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchDashboardPropertyOutputReference;
    }
    interface DataSourcesProperty {
        /**
        * cloudwatch_dashboard block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#cloudwatch_dashboard AwsExperimentTemplate#cloudwatch_dashboard}
        */
        readonly cloudwatchDashboard?: CloudwatchDashboardProperty[] | cdktn.IResolvable;
    }
    class DataSourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataSourcesProperty | undefined;
        set internalValue(value: DataSourcesProperty | undefined);
        private _cloudwatchDashboard;
        get cloudwatchDashboard(): CloudwatchDashboardPropertyList;
        putCloudwatchDashboard(value: CloudwatchDashboardProperty[] | cdktn.IResolvable): void;
        resetCloudwatchDashboard(): void;
        get cloudwatchDashboardInput(): cdktn.IResolvable | CloudwatchDashboardProperty[] | undefined;
    }
    interface ExperimentReportConfigurationOutputsS3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#bucket_name AwsExperimentTemplate#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#prefix AwsExperimentTemplate#prefix}
        */
        readonly prefix?: string;
    }
    class ExperimentReportConfigurationOutputsS3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExperimentReportConfigurationOutputsS3ConfigurationProperty | undefined;
        set internalValue(value: ExperimentReportConfigurationOutputsS3ConfigurationProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface OutputsProperty {
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#s3_configuration AwsExperimentTemplate#s3_configuration}
        */
        readonly s3Configuration?: ExperimentReportConfigurationOutputsS3ConfigurationProperty;
    }
    class OutputsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutputsProperty | undefined;
        set internalValue(value: OutputsProperty | undefined);
        private _s3Configuration;
        get s3Configuration(): ExperimentReportConfigurationOutputsS3ConfigurationPropertyOutputReference;
        putS3Configuration(value: ExperimentReportConfigurationOutputsS3ConfigurationProperty): void;
        resetS3Configuration(): void;
        get s3ConfigurationInput(): ExperimentReportConfigurationOutputsS3ConfigurationProperty | undefined;
    }
    interface ExperimentReportConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#post_experiment_duration AwsExperimentTemplate#post_experiment_duration}
        */
        readonly postExperimentDuration?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#pre_experiment_duration AwsExperimentTemplate#pre_experiment_duration}
        */
        readonly preExperimentDuration?: string;
        /**
        * data_sources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#data_sources AwsExperimentTemplate#data_sources}
        */
        readonly dataSources?: DataSourcesProperty;
        /**
        * outputs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#outputs AwsExperimentTemplate#outputs}
        */
        readonly outputs?: OutputsProperty;
    }
    class ExperimentReportConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExperimentReportConfigurationProperty | undefined;
        set internalValue(value: ExperimentReportConfigurationProperty | undefined);
        private _postExperimentDuration?;
        get postExperimentDuration(): string;
        set postExperimentDuration(value: string);
        resetPostExperimentDuration(): void;
        get postExperimentDurationInput(): string | undefined;
        private _preExperimentDuration?;
        get preExperimentDuration(): string;
        set preExperimentDuration(value: string);
        resetPreExperimentDuration(): void;
        get preExperimentDurationInput(): string | undefined;
        private _dataSources;
        get dataSources(): DataSourcesPropertyOutputReference;
        putDataSources(value: DataSourcesProperty): void;
        resetDataSources(): void;
        get dataSourcesInput(): DataSourcesProperty | undefined;
        private _outputs;
        get outputs(): OutputsPropertyOutputReference;
        putOutputs(value: OutputsProperty): void;
        resetOutputs(): void;
        get outputsInput(): OutputsProperty | undefined;
    }
    interface CloudwatchLogsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#log_group_arn AwsExperimentTemplate#log_group_arn}
        */
        readonly logGroupArn: string;
    }
    class CloudwatchLogsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLogsConfigurationProperty | undefined;
        set internalValue(value: CloudwatchLogsConfigurationProperty | undefined);
        private _logGroupArn?;
        get logGroupArn(): string;
        set logGroupArn(value: string);
        get logGroupArnInput(): string | undefined;
    }
    interface LogConfigurationS3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#bucket_name AwsExperimentTemplate#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#prefix AwsExperimentTemplate#prefix}
        */
        readonly prefix?: string;
    }
    class LogConfigurationS3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LogConfigurationS3ConfigurationProperty | undefined;
        set internalValue(value: LogConfigurationS3ConfigurationProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface LogConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#log_schema_version AwsExperimentTemplate#log_schema_version}
        */
        readonly logSchemaVersion: number;
        /**
        * cloudwatch_logs_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#cloudwatch_logs_configuration AwsExperimentTemplate#cloudwatch_logs_configuration}
        */
        readonly cloudwatchLogsConfiguration?: CloudwatchLogsConfigurationProperty;
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#s3_configuration AwsExperimentTemplate#s3_configuration}
        */
        readonly s3Configuration?: LogConfigurationS3ConfigurationProperty;
    }
    class LogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LogConfigurationProperty | undefined;
        set internalValue(value: LogConfigurationProperty | undefined);
        private _logSchemaVersion?;
        get logSchemaVersion(): number;
        set logSchemaVersion(value: number);
        get logSchemaVersionInput(): number | undefined;
        private _cloudwatchLogsConfiguration;
        get cloudwatchLogsConfiguration(): CloudwatchLogsConfigurationPropertyOutputReference;
        putCloudwatchLogsConfiguration(value: CloudwatchLogsConfigurationProperty): void;
        resetCloudwatchLogsConfiguration(): void;
        get cloudwatchLogsConfigurationInput(): CloudwatchLogsConfigurationProperty | undefined;
        private _s3Configuration;
        get s3Configuration(): LogConfigurationS3ConfigurationPropertyOutputReference;
        putS3Configuration(value: LogConfigurationS3ConfigurationProperty): void;
        resetS3Configuration(): void;
        get s3ConfigurationInput(): LogConfigurationS3ConfigurationProperty | undefined;
    }
    interface StopConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#source AwsExperimentTemplate#source}
        */
        readonly source: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#value AwsExperimentTemplate#value}
        */
        readonly value?: string;
    }
    class StopConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StopConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StopConditionProperty | cdktn.IResolvable | undefined);
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class StopConditionPropertyList extends cdktn.ComplexList {
        internalValue?: StopConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StopConditionPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#path AwsExperimentTemplate#path}
        */
        readonly path: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#values AwsExperimentTemplate#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface ResourceTagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#key AwsExperimentTemplate#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#value AwsExperimentTemplate#value}
        */
        readonly value: string;
    }
    class ResourceTagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceTagProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceTagProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceTagPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceTagProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceTagPropertyOutputReference;
    }
    interface TargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#name AwsExperimentTemplate#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#parameters AwsExperimentTemplate#parameters}
        */
        readonly parameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#resource_arns AwsExperimentTemplate#resource_arns}
        */
        readonly resourceArns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#resource_type AwsExperimentTemplate#resource_type}
        */
        readonly resourceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#selection_mode AwsExperimentTemplate#selection_mode}
        */
        readonly selectionMode: string;
        /**
        * filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#filter AwsExperimentTemplate#filter}
        */
        readonly filter?: FilterProperty[] | cdktn.IResolvable;
        /**
        * resource_tag block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#resource_tag AwsExperimentTemplate#resource_tag}
        */
        readonly resourceTag?: ResourceTagProperty[] | cdktn.IResolvable;
    }
    class TargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _parameters?;
        get parameters(): {
            [key: string]: string;
        };
        set parameters(value: {
            [key: string]: string;
        });
        resetParameters(): void;
        get parametersInput(): {
            [key: string]: string;
        } | undefined;
        private _resourceArns?;
        get resourceArns(): string[];
        set resourceArns(value: string[]);
        resetResourceArns(): void;
        get resourceArnsInput(): string[] | undefined;
        private _resourceType?;
        get resourceType(): string;
        set resourceType(value: string);
        get resourceTypeInput(): string | undefined;
        private _selectionMode?;
        get selectionMode(): string;
        set selectionMode(value: string);
        get selectionModeInput(): string | undefined;
        private _filter;
        get filter(): FilterPropertyList;
        putFilter(value: FilterProperty[] | cdktn.IResolvable): void;
        resetFilter(): void;
        get filterInput(): cdktn.IResolvable | FilterProperty[] | undefined;
        private _resourceTag;
        get resourceTag(): ResourceTagPropertyList;
        putResourceTag(value: ResourceTagProperty[] | cdktn.IResolvable): void;
        resetResourceTag(): void;
        get resourceTagInput(): cdktn.IResolvable | ResourceTagProperty[] | undefined;
    }
    class TargetPropertyList extends cdktn.ComplexList {
        internalValue?: TargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#create AwsExperimentTemplate#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#delete AwsExperimentTemplate#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_experiment_template#update AwsExperimentTemplate#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
