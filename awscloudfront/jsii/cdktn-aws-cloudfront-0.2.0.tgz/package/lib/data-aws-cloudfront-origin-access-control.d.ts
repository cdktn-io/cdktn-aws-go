import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfOriginAccessControlConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_origin_access_control#id DataTfOriginAccessControl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_origin_access_control aws_cloudfront_origin_access_control}
*/
export declare class DataTfOriginAccessControl extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cloudfront_origin_access_control";
    /**
    * Generates CDKTN code for importing a DataTfOriginAccessControl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfOriginAccessControl to import
    * @param importFromId The id of the existing DataTfOriginAccessControl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_origin_access_control#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfOriginAccessControl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_origin_access_control aws_cloudfront_origin_access_control} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfOriginAccessControlConfig
    */
    constructor(scope: Construct, id: string, config: DataTfOriginAccessControlConfig);
    get arn(): string;
    get description(): string;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get name(): string;
    get originAccessControlOriginType(): string;
    get signingBehavior(): string;
    get signingProtocol(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
