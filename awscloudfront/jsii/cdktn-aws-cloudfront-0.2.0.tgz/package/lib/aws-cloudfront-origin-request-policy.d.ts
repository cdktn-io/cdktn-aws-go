import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfOriginRequestPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#comment TfOriginRequestPolicy#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#id TfOriginRequestPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#name TfOriginRequestPolicy#name}
    */
    readonly name: string;
    /**
    * cookies_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#cookies_config TfOriginRequestPolicy#cookies_config}
    */
    readonly cookiesConfig: TfOriginRequestPolicy.CookiesConfigProperty;
    /**
    * headers_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#headers_config TfOriginRequestPolicy#headers_config}
    */
    readonly headersConfig: TfOriginRequestPolicy.HeadersConfigProperty;
    /**
    * query_strings_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#query_strings_config TfOriginRequestPolicy#query_strings_config}
    */
    readonly queryStringsConfig: TfOriginRequestPolicy.QueryStringsConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy aws_cloudfront_origin_request_policy}
*/
export declare class TfOriginRequestPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_origin_request_policy";
    /**
    * Generates CDKTN code for importing a TfOriginRequestPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfOriginRequestPolicy to import
    * @param importFromId The id of the existing TfOriginRequestPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfOriginRequestPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy aws_cloudfront_origin_request_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfOriginRequestPolicyConfig
    */
    constructor(scope: Construct, id: string, config: TfOriginRequestPolicyConfig);
    get arn(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _cookiesConfig;
    get cookiesConfig(): TfOriginRequestPolicy.CookiesConfigPropertyOutputReference;
    putCookiesConfig(value: TfOriginRequestPolicy.CookiesConfigProperty): void;
    get cookiesConfigInput(): TfOriginRequestPolicy.CookiesConfigProperty | undefined;
    private _headersConfig;
    get headersConfig(): TfOriginRequestPolicy.HeadersConfigPropertyOutputReference;
    putHeadersConfig(value: TfOriginRequestPolicy.HeadersConfigProperty): void;
    get headersConfigInput(): TfOriginRequestPolicy.HeadersConfigProperty | undefined;
    private _queryStringsConfig;
    get queryStringsConfig(): TfOriginRequestPolicy.QueryStringsConfigPropertyOutputReference;
    putQueryStringsConfig(value: TfOriginRequestPolicy.QueryStringsConfigProperty): void;
    get queryStringsConfigInput(): TfOriginRequestPolicy.QueryStringsConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfOriginRequestPolicyCookiesPropertyToTerraform(struct?: TfOriginRequestPolicy.CookiesPropertyOutputReference | TfOriginRequestPolicy.CookiesProperty): any;
export declare function tfOriginRequestPolicyCookiesPropertyToHclTerraform(struct?: TfOriginRequestPolicy.CookiesPropertyOutputReference | TfOriginRequestPolicy.CookiesProperty): any;
export declare function tfOriginRequestPolicyCookiesConfigPropertyToTerraform(struct?: TfOriginRequestPolicy.CookiesConfigPropertyOutputReference | TfOriginRequestPolicy.CookiesConfigProperty): any;
export declare function tfOriginRequestPolicyCookiesConfigPropertyToHclTerraform(struct?: TfOriginRequestPolicy.CookiesConfigPropertyOutputReference | TfOriginRequestPolicy.CookiesConfigProperty): any;
export declare function tfOriginRequestPolicyHeadersPropertyToTerraform(struct?: TfOriginRequestPolicy.HeadersPropertyOutputReference | TfOriginRequestPolicy.HeadersProperty): any;
export declare function tfOriginRequestPolicyHeadersPropertyToHclTerraform(struct?: TfOriginRequestPolicy.HeadersPropertyOutputReference | TfOriginRequestPolicy.HeadersProperty): any;
export declare function tfOriginRequestPolicyHeadersConfigPropertyToTerraform(struct?: TfOriginRequestPolicy.HeadersConfigPropertyOutputReference | TfOriginRequestPolicy.HeadersConfigProperty): any;
export declare function tfOriginRequestPolicyHeadersConfigPropertyToHclTerraform(struct?: TfOriginRequestPolicy.HeadersConfigPropertyOutputReference | TfOriginRequestPolicy.HeadersConfigProperty): any;
export declare function tfOriginRequestPolicyQueryStringsPropertyToTerraform(struct?: TfOriginRequestPolicy.QueryStringsPropertyOutputReference | TfOriginRequestPolicy.QueryStringsProperty): any;
export declare function tfOriginRequestPolicyQueryStringsPropertyToHclTerraform(struct?: TfOriginRequestPolicy.QueryStringsPropertyOutputReference | TfOriginRequestPolicy.QueryStringsProperty): any;
export declare function tfOriginRequestPolicyQueryStringsConfigPropertyToTerraform(struct?: TfOriginRequestPolicy.QueryStringsConfigPropertyOutputReference | TfOriginRequestPolicy.QueryStringsConfigProperty): any;
export declare function tfOriginRequestPolicyQueryStringsConfigPropertyToHclTerraform(struct?: TfOriginRequestPolicy.QueryStringsConfigPropertyOutputReference | TfOriginRequestPolicy.QueryStringsConfigProperty): any;
export declare namespace TfOriginRequestPolicy {
    interface CookiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#items TfOriginRequestPolicy#items}
        */
        readonly items?: string[];
    }
    class CookiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CookiesProperty | undefined;
        set internalValue(value: CookiesProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface CookiesConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#cookie_behavior TfOriginRequestPolicy#cookie_behavior}
        */
        readonly cookieBehavior: string;
        /**
        * cookies block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#cookies TfOriginRequestPolicy#cookies}
        */
        readonly cookies?: CookiesProperty;
    }
    class CookiesConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CookiesConfigProperty | undefined;
        set internalValue(value: CookiesConfigProperty | undefined);
        private _cookieBehavior?;
        get cookieBehavior(): string;
        set cookieBehavior(value: string);
        get cookieBehaviorInput(): string | undefined;
        private _cookies;
        get cookies(): CookiesPropertyOutputReference;
        putCookies(value: CookiesProperty): void;
        resetCookies(): void;
        get cookiesInput(): CookiesProperty | undefined;
    }
    interface HeadersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#items TfOriginRequestPolicy#items}
        */
        readonly items?: string[];
    }
    class HeadersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HeadersProperty | undefined;
        set internalValue(value: HeadersProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface HeadersConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#header_behavior TfOriginRequestPolicy#header_behavior}
        */
        readonly headerBehavior?: string;
        /**
        * headers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#headers TfOriginRequestPolicy#headers}
        */
        readonly headers?: HeadersProperty;
    }
    class HeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HeadersConfigProperty | undefined;
        set internalValue(value: HeadersConfigProperty | undefined);
        private _headerBehavior?;
        get headerBehavior(): string;
        set headerBehavior(value: string);
        resetHeaderBehavior(): void;
        get headerBehaviorInput(): string | undefined;
        private _headers;
        get headers(): HeadersPropertyOutputReference;
        putHeaders(value: HeadersProperty): void;
        resetHeaders(): void;
        get headersInput(): HeadersProperty | undefined;
    }
    interface QueryStringsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#items TfOriginRequestPolicy#items}
        */
        readonly items?: string[];
    }
    class QueryStringsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QueryStringsProperty | undefined;
        set internalValue(value: QueryStringsProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface QueryStringsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#query_string_behavior TfOriginRequestPolicy#query_string_behavior}
        */
        readonly queryStringBehavior: string;
        /**
        * query_strings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#query_strings TfOriginRequestPolicy#query_strings}
        */
        readonly queryStrings?: QueryStringsProperty;
    }
    class QueryStringsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QueryStringsConfigProperty | undefined;
        set internalValue(value: QueryStringsConfigProperty | undefined);
        private _queryStringBehavior?;
        get queryStringBehavior(): string;
        set queryStringBehavior(value: string);
        get queryStringBehaviorInput(): string | undefined;
        private _queryStrings;
        get queryStrings(): QueryStringsPropertyOutputReference;
        putQueryStrings(value: QueryStringsProperty): void;
        resetQueryStrings(): void;
        get queryStringsInput(): QueryStringsProperty | undefined;
    }
}
