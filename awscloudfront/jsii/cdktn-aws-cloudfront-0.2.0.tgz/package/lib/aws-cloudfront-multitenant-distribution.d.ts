import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfMultitenantDistributionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#comment TfMultitenantDistribution#comment}
    */
    readonly comment: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#default_root_object TfMultitenantDistribution#default_root_object}
    */
    readonly defaultRootObject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#enabled TfMultitenantDistribution#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#http_version TfMultitenantDistribution#http_version}
    */
    readonly httpVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#tags TfMultitenantDistribution#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#web_acl_id TfMultitenantDistribution#web_acl_id}
    */
    readonly webAclId?: string;
    /**
    * active_trusted_key_groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#active_trusted_key_groups TfMultitenantDistribution#active_trusted_key_groups}
    */
    readonly activeTrustedKeyGroups?: TfMultitenantDistribution.ActiveTrustedKeyGroupsProperty[] | cdktn.IResolvable;
    /**
    * cache_behavior block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#cache_behavior TfMultitenantDistribution#cache_behavior}
    */
    readonly cacheBehavior?: TfMultitenantDistribution.CacheBehaviorProperty[] | cdktn.IResolvable;
    /**
    * custom_error_response block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#custom_error_response TfMultitenantDistribution#custom_error_response}
    */
    readonly customErrorResponse?: TfMultitenantDistribution.CustomErrorResponseProperty[] | cdktn.IResolvable;
    /**
    * default_cache_behavior block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#default_cache_behavior TfMultitenantDistribution#default_cache_behavior}
    */
    readonly defaultCacheBehavior?: TfMultitenantDistribution.DefaultCacheBehaviorProperty[] | cdktn.IResolvable;
    /**
    * origin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#origin TfMultitenantDistribution#origin}
    */
    readonly origin?: TfMultitenantDistribution.OriginProperty[] | cdktn.IResolvable;
    /**
    * origin_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#origin_group TfMultitenantDistribution#origin_group}
    */
    readonly originGroup?: TfMultitenantDistribution.OriginGroupProperty[] | cdktn.IResolvable;
    /**
    * restrictions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#restrictions TfMultitenantDistribution#restrictions}
    */
    readonly restrictions?: TfMultitenantDistribution.RestrictionsProperty[] | cdktn.IResolvable;
    /**
    * tenant_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#tenant_config TfMultitenantDistribution#tenant_config}
    */
    readonly tenantConfig?: TfMultitenantDistribution.TenantConfigProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#timeouts TfMultitenantDistribution#timeouts}
    */
    readonly timeouts?: TfMultitenantDistribution.TimeoutsProperty;
    /**
    * viewer_certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#viewer_certificate TfMultitenantDistribution#viewer_certificate}
    */
    readonly viewerCertificate?: TfMultitenantDistribution.ViewerCertificateProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution aws_cloudfront_multitenant_distribution}
*/
export declare class TfMultitenantDistribution extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_multitenant_distribution";
    /**
    * Generates CDKTN code for importing a TfMultitenantDistribution resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfMultitenantDistribution to import
    * @param importFromId The id of the existing TfMultitenantDistribution that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfMultitenantDistribution to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution aws_cloudfront_multitenant_distribution} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfMultitenantDistributionConfig
    */
    constructor(scope: Construct, id: string, config: TfMultitenantDistributionConfig);
    get arn(): string;
    get callerReference(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    get commentInput(): string | undefined;
    get connectionMode(): string;
    private _defaultRootObject?;
    get defaultRootObject(): string;
    set defaultRootObject(value: string);
    resetDefaultRootObject(): void;
    get defaultRootObjectInput(): string | undefined;
    get domainName(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get etag(): string;
    private _httpVersion?;
    get httpVersion(): string;
    set httpVersion(value: string);
    resetHttpVersion(): void;
    get httpVersionInput(): string | undefined;
    get id(): string;
    get inProgressInvalidationBatches(): number;
    get lastModifiedTime(): string;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _webAclId?;
    get webAclId(): string;
    set webAclId(value: string);
    resetWebAclId(): void;
    get webAclIdInput(): string | undefined;
    private _activeTrustedKeyGroups;
    get activeTrustedKeyGroups(): TfMultitenantDistribution.ActiveTrustedKeyGroupsPropertyList;
    putActiveTrustedKeyGroups(value: TfMultitenantDistribution.ActiveTrustedKeyGroupsProperty[] | cdktn.IResolvable): void;
    resetActiveTrustedKeyGroups(): void;
    get activeTrustedKeyGroupsInput(): cdktn.IResolvable | TfMultitenantDistribution.ActiveTrustedKeyGroupsProperty[] | undefined;
    private _cacheBehavior;
    get cacheBehavior(): TfMultitenantDistribution.CacheBehaviorPropertyList;
    putCacheBehavior(value: TfMultitenantDistribution.CacheBehaviorProperty[] | cdktn.IResolvable): void;
    resetCacheBehavior(): void;
    get cacheBehaviorInput(): cdktn.IResolvable | TfMultitenantDistribution.CacheBehaviorProperty[] | undefined;
    private _customErrorResponse;
    get customErrorResponse(): TfMultitenantDistribution.CustomErrorResponsePropertyList;
    putCustomErrorResponse(value: TfMultitenantDistribution.CustomErrorResponseProperty[] | cdktn.IResolvable): void;
    resetCustomErrorResponse(): void;
    get customErrorResponseInput(): cdktn.IResolvable | TfMultitenantDistribution.CustomErrorResponseProperty[] | undefined;
    private _defaultCacheBehavior;
    get defaultCacheBehavior(): TfMultitenantDistribution.DefaultCacheBehaviorPropertyList;
    putDefaultCacheBehavior(value: TfMultitenantDistribution.DefaultCacheBehaviorProperty[] | cdktn.IResolvable): void;
    resetDefaultCacheBehavior(): void;
    get defaultCacheBehaviorInput(): cdktn.IResolvable | TfMultitenantDistribution.DefaultCacheBehaviorProperty[] | undefined;
    private _origin;
    get origin(): TfMultitenantDistribution.OriginPropertyList;
    putOrigin(value: TfMultitenantDistribution.OriginProperty[] | cdktn.IResolvable): void;
    resetOrigin(): void;
    get originInput(): cdktn.IResolvable | TfMultitenantDistribution.OriginProperty[] | undefined;
    private _originGroup;
    get originGroup(): TfMultitenantDistribution.OriginGroupPropertyList;
    putOriginGroup(value: TfMultitenantDistribution.OriginGroupProperty[] | cdktn.IResolvable): void;
    resetOriginGroup(): void;
    get originGroupInput(): cdktn.IResolvable | TfMultitenantDistribution.OriginGroupProperty[] | undefined;
    private _restrictions;
    get restrictions(): TfMultitenantDistribution.RestrictionsPropertyList;
    putRestrictions(value: TfMultitenantDistribution.RestrictionsProperty[] | cdktn.IResolvable): void;
    resetRestrictions(): void;
    get restrictionsInput(): cdktn.IResolvable | TfMultitenantDistribution.RestrictionsProperty[] | undefined;
    private _tenantConfig;
    get tenantConfig(): TfMultitenantDistribution.TenantConfigPropertyList;
    putTenantConfig(value: TfMultitenantDistribution.TenantConfigProperty[] | cdktn.IResolvable): void;
    resetTenantConfig(): void;
    get tenantConfigInput(): cdktn.IResolvable | TfMultitenantDistribution.TenantConfigProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfMultitenantDistribution.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfMultitenantDistribution.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfMultitenantDistribution.TimeoutsProperty | undefined;
    private _viewerCertificate;
    get viewerCertificate(): TfMultitenantDistribution.ViewerCertificatePropertyList;
    putViewerCertificate(value: TfMultitenantDistribution.ViewerCertificateProperty[] | cdktn.IResolvable): void;
    resetViewerCertificate(): void;
    get viewerCertificateInput(): cdktn.IResolvable | TfMultitenantDistribution.ViewerCertificateProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfMultitenantDistributionItemsPropertyToTerraform(struct?: TfMultitenantDistribution.ItemsProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionItemsPropertyToHclTerraform(struct?: TfMultitenantDistribution.ItemsProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionActiveTrustedKeyGroupsPropertyToTerraform(struct?: TfMultitenantDistribution.ActiveTrustedKeyGroupsProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionActiveTrustedKeyGroupsPropertyToHclTerraform(struct?: TfMultitenantDistribution.ActiveTrustedKeyGroupsProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionCacheBehaviorAllowedMethodsPropertyToTerraform(struct?: TfMultitenantDistribution.CacheBehaviorAllowedMethodsProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionCacheBehaviorAllowedMethodsPropertyToHclTerraform(struct?: TfMultitenantDistribution.CacheBehaviorAllowedMethodsProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionCacheBehaviorFunctionAssociationPropertyToTerraform(struct?: TfMultitenantDistribution.CacheBehaviorFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionCacheBehaviorFunctionAssociationPropertyToHclTerraform(struct?: TfMultitenantDistribution.CacheBehaviorFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionCacheBehaviorLambdaFunctionAssociationPropertyToTerraform(struct?: TfMultitenantDistribution.CacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionCacheBehaviorLambdaFunctionAssociationPropertyToHclTerraform(struct?: TfMultitenantDistribution.CacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionCacheBehaviorTrustedKeyGroupsPropertyToTerraform(struct?: TfMultitenantDistribution.CacheBehaviorTrustedKeyGroupsProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionCacheBehaviorTrustedKeyGroupsPropertyToHclTerraform(struct?: TfMultitenantDistribution.CacheBehaviorTrustedKeyGroupsProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionCacheBehaviorPropertyToTerraform(struct?: TfMultitenantDistribution.CacheBehaviorProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionCacheBehaviorPropertyToHclTerraform(struct?: TfMultitenantDistribution.CacheBehaviorProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionCustomErrorResponsePropertyToTerraform(struct?: TfMultitenantDistribution.CustomErrorResponseProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionCustomErrorResponsePropertyToHclTerraform(struct?: TfMultitenantDistribution.CustomErrorResponseProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionDefaultCacheBehaviorAllowedMethodsPropertyToTerraform(struct?: TfMultitenantDistribution.DefaultCacheBehaviorAllowedMethodsProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionDefaultCacheBehaviorAllowedMethodsPropertyToHclTerraform(struct?: TfMultitenantDistribution.DefaultCacheBehaviorAllowedMethodsProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionDefaultCacheBehaviorFunctionAssociationPropertyToTerraform(struct?: TfMultitenantDistribution.DefaultCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionDefaultCacheBehaviorFunctionAssociationPropertyToHclTerraform(struct?: TfMultitenantDistribution.DefaultCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociationPropertyToTerraform(struct?: TfMultitenantDistribution.DefaultCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionDefaultCacheBehaviorLambdaFunctionAssociationPropertyToHclTerraform(struct?: TfMultitenantDistribution.DefaultCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroupsPropertyToTerraform(struct?: TfMultitenantDistribution.DefaultCacheBehaviorTrustedKeyGroupsProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionDefaultCacheBehaviorTrustedKeyGroupsPropertyToHclTerraform(struct?: TfMultitenantDistribution.DefaultCacheBehaviorTrustedKeyGroupsProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionDefaultCacheBehaviorPropertyToTerraform(struct?: TfMultitenantDistribution.DefaultCacheBehaviorProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionDefaultCacheBehaviorPropertyToHclTerraform(struct?: TfMultitenantDistribution.DefaultCacheBehaviorProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionCustomHeaderPropertyToTerraform(struct?: TfMultitenantDistribution.CustomHeaderProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionCustomHeaderPropertyToHclTerraform(struct?: TfMultitenantDistribution.CustomHeaderProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionOriginMtlsConfigPropertyToTerraform(struct?: TfMultitenantDistribution.OriginMtlsConfigProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionOriginMtlsConfigPropertyToHclTerraform(struct?: TfMultitenantDistribution.OriginMtlsConfigProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionCustomOriginConfigPropertyToTerraform(struct?: TfMultitenantDistribution.CustomOriginConfigProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionCustomOriginConfigPropertyToHclTerraform(struct?: TfMultitenantDistribution.CustomOriginConfigProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionOriginShieldPropertyToTerraform(struct?: TfMultitenantDistribution.OriginShieldProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionOriginShieldPropertyToHclTerraform(struct?: TfMultitenantDistribution.OriginShieldProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionVpcOriginConfigPropertyToTerraform(struct?: TfMultitenantDistribution.VpcOriginConfigProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionVpcOriginConfigPropertyToHclTerraform(struct?: TfMultitenantDistribution.VpcOriginConfigProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionOriginPropertyToTerraform(struct?: TfMultitenantDistribution.OriginProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionOriginPropertyToHclTerraform(struct?: TfMultitenantDistribution.OriginProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionFailoverCriteriaPropertyToTerraform(struct?: TfMultitenantDistribution.FailoverCriteriaProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionFailoverCriteriaPropertyToHclTerraform(struct?: TfMultitenantDistribution.FailoverCriteriaProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionMemberPropertyToTerraform(struct?: TfMultitenantDistribution.MemberProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionMemberPropertyToHclTerraform(struct?: TfMultitenantDistribution.MemberProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionOriginGroupPropertyToTerraform(struct?: TfMultitenantDistribution.OriginGroupProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionOriginGroupPropertyToHclTerraform(struct?: TfMultitenantDistribution.OriginGroupProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionGeoRestrictionPropertyToTerraform(struct?: TfMultitenantDistribution.GeoRestrictionProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionGeoRestrictionPropertyToHclTerraform(struct?: TfMultitenantDistribution.GeoRestrictionProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionRestrictionsPropertyToTerraform(struct?: TfMultitenantDistribution.RestrictionsProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionRestrictionsPropertyToHclTerraform(struct?: TfMultitenantDistribution.RestrictionsProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionStringSchemaPropertyToTerraform(struct?: TfMultitenantDistribution.StringSchemaProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionStringSchemaPropertyToHclTerraform(struct?: TfMultitenantDistribution.StringSchemaProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionDefinitionPropertyToTerraform(struct?: TfMultitenantDistribution.DefinitionProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionDefinitionPropertyToHclTerraform(struct?: TfMultitenantDistribution.DefinitionProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionParameterDefinitionPropertyToTerraform(struct?: TfMultitenantDistribution.ParameterDefinitionProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionParameterDefinitionPropertyToHclTerraform(struct?: TfMultitenantDistribution.ParameterDefinitionProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionTenantConfigPropertyToTerraform(struct?: TfMultitenantDistribution.TenantConfigProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionTenantConfigPropertyToHclTerraform(struct?: TfMultitenantDistribution.TenantConfigProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionTimeoutsPropertyToTerraform(struct?: TfMultitenantDistribution.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionTimeoutsPropertyToHclTerraform(struct?: TfMultitenantDistribution.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionViewerCertificatePropertyToTerraform(struct?: TfMultitenantDistribution.ViewerCertificateProperty | cdktn.IResolvable): any;
export declare function tfMultitenantDistributionViewerCertificatePropertyToHclTerraform(struct?: TfMultitenantDistribution.ViewerCertificateProperty | cdktn.IResolvable): any;
export declare namespace TfMultitenantDistribution {
    interface ItemsProperty {
    }
    class ItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ItemsProperty | cdktn.IResolvable | undefined);
        get keyGroupId(): string;
        get keyPairIds(): string[];
    }
    class ItemsPropertyList extends cdktn.ComplexList {
        internalValue?: ItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ItemsPropertyOutputReference;
    }
    interface ActiveTrustedKeyGroupsProperty {
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#items TfMultitenantDistribution#items}
        */
        readonly items?: ItemsProperty[] | cdktn.IResolvable;
    }
    class ActiveTrustedKeyGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActiveTrustedKeyGroupsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActiveTrustedKeyGroupsProperty | cdktn.IResolvable | undefined);
        get enabled(): cdktn.IResolvable;
        private _items;
        get items(): ItemsPropertyList;
        putItems(value: ItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | ItemsProperty[] | undefined;
    }
    class ActiveTrustedKeyGroupsPropertyList extends cdktn.ComplexList {
        internalValue?: ActiveTrustedKeyGroupsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActiveTrustedKeyGroupsPropertyOutputReference;
    }
    interface CacheBehaviorAllowedMethodsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#cached_methods TfMultitenantDistribution#cached_methods}
        */
        readonly cachedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#items TfMultitenantDistribution#items}
        */
        readonly items: string[];
    }
    class CacheBehaviorAllowedMethodsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CacheBehaviorAllowedMethodsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CacheBehaviorAllowedMethodsProperty | cdktn.IResolvable | undefined);
        private _cachedMethods?;
        get cachedMethods(): string[];
        set cachedMethods(value: string[]);
        get cachedMethodsInput(): string[] | undefined;
        private _items?;
        get items(): string[];
        set items(value: string[]);
        get itemsInput(): string[] | undefined;
    }
    class CacheBehaviorAllowedMethodsPropertyList extends cdktn.ComplexList {
        internalValue?: CacheBehaviorAllowedMethodsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CacheBehaviorAllowedMethodsPropertyOutputReference;
    }
    interface CacheBehaviorFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#event_type TfMultitenantDistribution#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#function_arn TfMultitenantDistribution#function_arn}
        */
        readonly functionArn: string;
    }
    class CacheBehaviorFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CacheBehaviorFunctionAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CacheBehaviorFunctionAssociationProperty | cdktn.IResolvable | undefined);
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
    }
    class CacheBehaviorFunctionAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: CacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CacheBehaviorFunctionAssociationPropertyOutputReference;
    }
    interface CacheBehaviorLambdaFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#event_type TfMultitenantDistribution#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#include_body TfMultitenantDistribution#include_body}
        */
        readonly includeBody?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#lambda_function_arn TfMultitenantDistribution#lambda_function_arn}
        */
        readonly lambdaFunctionArn: string;
    }
    class CacheBehaviorLambdaFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable | undefined);
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _includeBody?;
        get includeBody(): boolean | cdktn.IResolvable;
        set includeBody(value: boolean | cdktn.IResolvable);
        resetIncludeBody(): void;
        get includeBodyInput(): boolean | cdktn.IResolvable | undefined;
        private _lambdaFunctionArn?;
        get lambdaFunctionArn(): string;
        set lambdaFunctionArn(value: string);
        get lambdaFunctionArnInput(): string | undefined;
    }
    class CacheBehaviorLambdaFunctionAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: CacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CacheBehaviorLambdaFunctionAssociationPropertyOutputReference;
    }
    interface CacheBehaviorTrustedKeyGroupsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#enabled TfMultitenantDistribution#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#items TfMultitenantDistribution#items}
        */
        readonly items?: string[];
    }
    class CacheBehaviorTrustedKeyGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CacheBehaviorTrustedKeyGroupsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CacheBehaviorTrustedKeyGroupsProperty | cdktn.IResolvable | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    class CacheBehaviorTrustedKeyGroupsPropertyList extends cdktn.ComplexList {
        internalValue?: CacheBehaviorTrustedKeyGroupsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CacheBehaviorTrustedKeyGroupsPropertyOutputReference;
    }
    interface CacheBehaviorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#cache_policy_id TfMultitenantDistribution#cache_policy_id}
        */
        readonly cachePolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#compress TfMultitenantDistribution#compress}
        */
        readonly compress?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#field_level_encryption_id TfMultitenantDistribution#field_level_encryption_id}
        */
        readonly fieldLevelEncryptionId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#origin_request_policy_id TfMultitenantDistribution#origin_request_policy_id}
        */
        readonly originRequestPolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#path_pattern TfMultitenantDistribution#path_pattern}
        */
        readonly pathPattern: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#realtime_log_config_arn TfMultitenantDistribution#realtime_log_config_arn}
        */
        readonly realtimeLogConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#response_headers_policy_id TfMultitenantDistribution#response_headers_policy_id}
        */
        readonly responseHeadersPolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#target_origin_id TfMultitenantDistribution#target_origin_id}
        */
        readonly targetOriginId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#viewer_protocol_policy TfMultitenantDistribution#viewer_protocol_policy}
        */
        readonly viewerProtocolPolicy: string;
        /**
        * allowed_methods block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#allowed_methods TfMultitenantDistribution#allowed_methods}
        */
        readonly allowedMethods?: CacheBehaviorAllowedMethodsProperty[] | cdktn.IResolvable;
        /**
        * function_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#function_association TfMultitenantDistribution#function_association}
        */
        readonly functionAssociation?: CacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * lambda_function_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#lambda_function_association TfMultitenantDistribution#lambda_function_association}
        */
        readonly lambdaFunctionAssociation?: CacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * trusted_key_groups block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#trusted_key_groups TfMultitenantDistribution#trusted_key_groups}
        */
        readonly trustedKeyGroups?: CacheBehaviorTrustedKeyGroupsProperty[] | cdktn.IResolvable;
    }
    class CacheBehaviorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CacheBehaviorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CacheBehaviorProperty | cdktn.IResolvable | undefined);
        private _cachePolicyId?;
        get cachePolicyId(): string;
        set cachePolicyId(value: string);
        resetCachePolicyId(): void;
        get cachePolicyIdInput(): string | undefined;
        private _compress?;
        get compress(): boolean | cdktn.IResolvable;
        set compress(value: boolean | cdktn.IResolvable);
        resetCompress(): void;
        get compressInput(): boolean | cdktn.IResolvable | undefined;
        private _fieldLevelEncryptionId?;
        get fieldLevelEncryptionId(): string;
        set fieldLevelEncryptionId(value: string);
        resetFieldLevelEncryptionId(): void;
        get fieldLevelEncryptionIdInput(): string | undefined;
        private _originRequestPolicyId?;
        get originRequestPolicyId(): string;
        set originRequestPolicyId(value: string);
        resetOriginRequestPolicyId(): void;
        get originRequestPolicyIdInput(): string | undefined;
        private _pathPattern?;
        get pathPattern(): string;
        set pathPattern(value: string);
        get pathPatternInput(): string | undefined;
        private _realtimeLogConfigArn?;
        get realtimeLogConfigArn(): string;
        set realtimeLogConfigArn(value: string);
        resetRealtimeLogConfigArn(): void;
        get realtimeLogConfigArnInput(): string | undefined;
        private _responseHeadersPolicyId?;
        get responseHeadersPolicyId(): string;
        set responseHeadersPolicyId(value: string);
        resetResponseHeadersPolicyId(): void;
        get responseHeadersPolicyIdInput(): string | undefined;
        private _targetOriginId?;
        get targetOriginId(): string;
        set targetOriginId(value: string);
        get targetOriginIdInput(): string | undefined;
        private _viewerProtocolPolicy?;
        get viewerProtocolPolicy(): string;
        set viewerProtocolPolicy(value: string);
        get viewerProtocolPolicyInput(): string | undefined;
        private _allowedMethods;
        get allowedMethods(): CacheBehaviorAllowedMethodsPropertyList;
        putAllowedMethods(value: CacheBehaviorAllowedMethodsProperty[] | cdktn.IResolvable): void;
        resetAllowedMethods(): void;
        get allowedMethodsInput(): cdktn.IResolvable | CacheBehaviorAllowedMethodsProperty[] | undefined;
        private _functionAssociation;
        get functionAssociation(): CacheBehaviorFunctionAssociationPropertyList;
        putFunctionAssociation(value: CacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable): void;
        resetFunctionAssociation(): void;
        get functionAssociationInput(): cdktn.IResolvable | CacheBehaviorFunctionAssociationProperty[] | undefined;
        private _lambdaFunctionAssociation;
        get lambdaFunctionAssociation(): CacheBehaviorLambdaFunctionAssociationPropertyList;
        putLambdaFunctionAssociation(value: CacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable): void;
        resetLambdaFunctionAssociation(): void;
        get lambdaFunctionAssociationInput(): cdktn.IResolvable | CacheBehaviorLambdaFunctionAssociationProperty[] | undefined;
        private _trustedKeyGroups;
        get trustedKeyGroups(): CacheBehaviorTrustedKeyGroupsPropertyList;
        putTrustedKeyGroups(value: CacheBehaviorTrustedKeyGroupsProperty[] | cdktn.IResolvable): void;
        resetTrustedKeyGroups(): void;
        get trustedKeyGroupsInput(): cdktn.IResolvable | CacheBehaviorTrustedKeyGroupsProperty[] | undefined;
    }
    class CacheBehaviorPropertyList extends cdktn.ComplexList {
        internalValue?: CacheBehaviorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CacheBehaviorPropertyOutputReference;
    }
    interface CustomErrorResponseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#error_caching_min_ttl TfMultitenantDistribution#error_caching_min_ttl}
        */
        readonly errorCachingMinTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#error_code TfMultitenantDistribution#error_code}
        */
        readonly errorCode: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#response_code TfMultitenantDistribution#response_code}
        */
        readonly responseCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#response_page_path TfMultitenantDistribution#response_page_path}
        */
        readonly responsePagePath?: string;
    }
    class CustomErrorResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomErrorResponseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomErrorResponseProperty | cdktn.IResolvable | undefined);
        private _errorCachingMinTtl?;
        get errorCachingMinTtl(): number;
        set errorCachingMinTtl(value: number);
        resetErrorCachingMinTtl(): void;
        get errorCachingMinTtlInput(): number | undefined;
        private _errorCode?;
        get errorCode(): number;
        set errorCode(value: number);
        get errorCodeInput(): number | undefined;
        private _responseCode?;
        get responseCode(): string;
        set responseCode(value: string);
        resetResponseCode(): void;
        get responseCodeInput(): string | undefined;
        private _responsePagePath?;
        get responsePagePath(): string;
        set responsePagePath(value: string);
        resetResponsePagePath(): void;
        get responsePagePathInput(): string | undefined;
    }
    class CustomErrorResponsePropertyList extends cdktn.ComplexList {
        internalValue?: CustomErrorResponseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomErrorResponsePropertyOutputReference;
    }
    interface DefaultCacheBehaviorAllowedMethodsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#cached_methods TfMultitenantDistribution#cached_methods}
        */
        readonly cachedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#items TfMultitenantDistribution#items}
        */
        readonly items: string[];
    }
    class DefaultCacheBehaviorAllowedMethodsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultCacheBehaviorAllowedMethodsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultCacheBehaviorAllowedMethodsProperty | cdktn.IResolvable | undefined);
        private _cachedMethods?;
        get cachedMethods(): string[];
        set cachedMethods(value: string[]);
        get cachedMethodsInput(): string[] | undefined;
        private _items?;
        get items(): string[];
        set items(value: string[]);
        get itemsInput(): string[] | undefined;
    }
    class DefaultCacheBehaviorAllowedMethodsPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultCacheBehaviorAllowedMethodsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultCacheBehaviorAllowedMethodsPropertyOutputReference;
    }
    interface DefaultCacheBehaviorFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#event_type TfMultitenantDistribution#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#function_arn TfMultitenantDistribution#function_arn}
        */
        readonly functionArn: string;
    }
    class DefaultCacheBehaviorFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable | undefined);
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
    }
    class DefaultCacheBehaviorFunctionAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultCacheBehaviorFunctionAssociationPropertyOutputReference;
    }
    interface DefaultCacheBehaviorLambdaFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#event_type TfMultitenantDistribution#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#include_body TfMultitenantDistribution#include_body}
        */
        readonly includeBody?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#lambda_function_arn TfMultitenantDistribution#lambda_function_arn}
        */
        readonly lambdaFunctionArn: string;
    }
    class DefaultCacheBehaviorLambdaFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable | undefined);
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _includeBody?;
        get includeBody(): boolean | cdktn.IResolvable;
        set includeBody(value: boolean | cdktn.IResolvable);
        resetIncludeBody(): void;
        get includeBodyInput(): boolean | cdktn.IResolvable | undefined;
        private _lambdaFunctionArn?;
        get lambdaFunctionArn(): string;
        set lambdaFunctionArn(value: string);
        get lambdaFunctionArnInput(): string | undefined;
    }
    class DefaultCacheBehaviorLambdaFunctionAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultCacheBehaviorLambdaFunctionAssociationPropertyOutputReference;
    }
    interface DefaultCacheBehaviorTrustedKeyGroupsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#enabled TfMultitenantDistribution#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#items TfMultitenantDistribution#items}
        */
        readonly items?: string[];
    }
    class DefaultCacheBehaviorTrustedKeyGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultCacheBehaviorTrustedKeyGroupsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultCacheBehaviorTrustedKeyGroupsProperty | cdktn.IResolvable | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    class DefaultCacheBehaviorTrustedKeyGroupsPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultCacheBehaviorTrustedKeyGroupsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultCacheBehaviorTrustedKeyGroupsPropertyOutputReference;
    }
    interface DefaultCacheBehaviorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#cache_policy_id TfMultitenantDistribution#cache_policy_id}
        */
        readonly cachePolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#compress TfMultitenantDistribution#compress}
        */
        readonly compress?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#field_level_encryption_id TfMultitenantDistribution#field_level_encryption_id}
        */
        readonly fieldLevelEncryptionId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#origin_request_policy_id TfMultitenantDistribution#origin_request_policy_id}
        */
        readonly originRequestPolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#realtime_log_config_arn TfMultitenantDistribution#realtime_log_config_arn}
        */
        readonly realtimeLogConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#response_headers_policy_id TfMultitenantDistribution#response_headers_policy_id}
        */
        readonly responseHeadersPolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#target_origin_id TfMultitenantDistribution#target_origin_id}
        */
        readonly targetOriginId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#viewer_protocol_policy TfMultitenantDistribution#viewer_protocol_policy}
        */
        readonly viewerProtocolPolicy: string;
        /**
        * allowed_methods block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#allowed_methods TfMultitenantDistribution#allowed_methods}
        */
        readonly allowedMethods?: DefaultCacheBehaviorAllowedMethodsProperty[] | cdktn.IResolvable;
        /**
        * function_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#function_association TfMultitenantDistribution#function_association}
        */
        readonly functionAssociation?: DefaultCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * lambda_function_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#lambda_function_association TfMultitenantDistribution#lambda_function_association}
        */
        readonly lambdaFunctionAssociation?: DefaultCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * trusted_key_groups block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#trusted_key_groups TfMultitenantDistribution#trusted_key_groups}
        */
        readonly trustedKeyGroups?: DefaultCacheBehaviorTrustedKeyGroupsProperty[] | cdktn.IResolvable;
    }
    class DefaultCacheBehaviorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultCacheBehaviorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultCacheBehaviorProperty | cdktn.IResolvable | undefined);
        private _cachePolicyId?;
        get cachePolicyId(): string;
        set cachePolicyId(value: string);
        resetCachePolicyId(): void;
        get cachePolicyIdInput(): string | undefined;
        private _compress?;
        get compress(): boolean | cdktn.IResolvable;
        set compress(value: boolean | cdktn.IResolvable);
        resetCompress(): void;
        get compressInput(): boolean | cdktn.IResolvable | undefined;
        private _fieldLevelEncryptionId?;
        get fieldLevelEncryptionId(): string;
        set fieldLevelEncryptionId(value: string);
        resetFieldLevelEncryptionId(): void;
        get fieldLevelEncryptionIdInput(): string | undefined;
        private _originRequestPolicyId?;
        get originRequestPolicyId(): string;
        set originRequestPolicyId(value: string);
        resetOriginRequestPolicyId(): void;
        get originRequestPolicyIdInput(): string | undefined;
        private _realtimeLogConfigArn?;
        get realtimeLogConfigArn(): string;
        set realtimeLogConfigArn(value: string);
        resetRealtimeLogConfigArn(): void;
        get realtimeLogConfigArnInput(): string | undefined;
        private _responseHeadersPolicyId?;
        get responseHeadersPolicyId(): string;
        set responseHeadersPolicyId(value: string);
        resetResponseHeadersPolicyId(): void;
        get responseHeadersPolicyIdInput(): string | undefined;
        private _targetOriginId?;
        get targetOriginId(): string;
        set targetOriginId(value: string);
        get targetOriginIdInput(): string | undefined;
        private _viewerProtocolPolicy?;
        get viewerProtocolPolicy(): string;
        set viewerProtocolPolicy(value: string);
        get viewerProtocolPolicyInput(): string | undefined;
        private _allowedMethods;
        get allowedMethods(): DefaultCacheBehaviorAllowedMethodsPropertyList;
        putAllowedMethods(value: DefaultCacheBehaviorAllowedMethodsProperty[] | cdktn.IResolvable): void;
        resetAllowedMethods(): void;
        get allowedMethodsInput(): cdktn.IResolvable | DefaultCacheBehaviorAllowedMethodsProperty[] | undefined;
        private _functionAssociation;
        get functionAssociation(): DefaultCacheBehaviorFunctionAssociationPropertyList;
        putFunctionAssociation(value: DefaultCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable): void;
        resetFunctionAssociation(): void;
        get functionAssociationInput(): cdktn.IResolvable | DefaultCacheBehaviorFunctionAssociationProperty[] | undefined;
        private _lambdaFunctionAssociation;
        get lambdaFunctionAssociation(): DefaultCacheBehaviorLambdaFunctionAssociationPropertyList;
        putLambdaFunctionAssociation(value: DefaultCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable): void;
        resetLambdaFunctionAssociation(): void;
        get lambdaFunctionAssociationInput(): cdktn.IResolvable | DefaultCacheBehaviorLambdaFunctionAssociationProperty[] | undefined;
        private _trustedKeyGroups;
        get trustedKeyGroups(): DefaultCacheBehaviorTrustedKeyGroupsPropertyList;
        putTrustedKeyGroups(value: DefaultCacheBehaviorTrustedKeyGroupsProperty[] | cdktn.IResolvable): void;
        resetTrustedKeyGroups(): void;
        get trustedKeyGroupsInput(): cdktn.IResolvable | DefaultCacheBehaviorTrustedKeyGroupsProperty[] | undefined;
    }
    class DefaultCacheBehaviorPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultCacheBehaviorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultCacheBehaviorPropertyOutputReference;
    }
    interface CustomHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#header_name TfMultitenantDistribution#header_name}
        */
        readonly headerName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#header_value TfMultitenantDistribution#header_value}
        */
        readonly headerValue: string;
    }
    class CustomHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomHeaderProperty | cdktn.IResolvable | undefined);
        private _headerName?;
        get headerName(): string;
        set headerName(value: string);
        get headerNameInput(): string | undefined;
        private _headerValue?;
        get headerValue(): string;
        set headerValue(value: string);
        get headerValueInput(): string | undefined;
    }
    class CustomHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: CustomHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomHeaderPropertyOutputReference;
    }
    interface OriginMtlsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#client_certificate_arn TfMultitenantDistribution#client_certificate_arn}
        */
        readonly clientCertificateArn: string;
    }
    class OriginMtlsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OriginMtlsConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OriginMtlsConfigProperty | cdktn.IResolvable | undefined);
        private _clientCertificateArn?;
        get clientCertificateArn(): string;
        set clientCertificateArn(value: string);
        get clientCertificateArnInput(): string | undefined;
    }
    class OriginMtlsConfigPropertyList extends cdktn.ComplexList {
        internalValue?: OriginMtlsConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OriginMtlsConfigPropertyOutputReference;
    }
    interface CustomOriginConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#http_port TfMultitenantDistribution#http_port}
        */
        readonly httpPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#https_port TfMultitenantDistribution#https_port}
        */
        readonly httpsPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#ip_address_type TfMultitenantDistribution#ip_address_type}
        */
        readonly ipAddressType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#origin_keepalive_timeout TfMultitenantDistribution#origin_keepalive_timeout}
        */
        readonly originKeepaliveTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#origin_protocol_policy TfMultitenantDistribution#origin_protocol_policy}
        */
        readonly originProtocolPolicy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#origin_read_timeout TfMultitenantDistribution#origin_read_timeout}
        */
        readonly originReadTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#origin_ssl_protocols TfMultitenantDistribution#origin_ssl_protocols}
        */
        readonly originSslProtocols: string[];
        /**
        * origin_mtls_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#origin_mtls_config TfMultitenantDistribution#origin_mtls_config}
        */
        readonly originMtlsConfig?: OriginMtlsConfigProperty[] | cdktn.IResolvable;
    }
    class CustomOriginConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomOriginConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomOriginConfigProperty | cdktn.IResolvable | undefined);
        private _httpPort?;
        get httpPort(): number;
        set httpPort(value: number);
        get httpPortInput(): number | undefined;
        private _httpsPort?;
        get httpsPort(): number;
        set httpsPort(value: number);
        get httpsPortInput(): number | undefined;
        private _ipAddressType?;
        get ipAddressType(): string;
        set ipAddressType(value: string);
        resetIpAddressType(): void;
        get ipAddressTypeInput(): string | undefined;
        private _originKeepaliveTimeout?;
        get originKeepaliveTimeout(): number;
        set originKeepaliveTimeout(value: number);
        resetOriginKeepaliveTimeout(): void;
        get originKeepaliveTimeoutInput(): number | undefined;
        private _originProtocolPolicy?;
        get originProtocolPolicy(): string;
        set originProtocolPolicy(value: string);
        get originProtocolPolicyInput(): string | undefined;
        private _originReadTimeout?;
        get originReadTimeout(): number;
        set originReadTimeout(value: number);
        resetOriginReadTimeout(): void;
        get originReadTimeoutInput(): number | undefined;
        private _originSslProtocols?;
        get originSslProtocols(): string[];
        set originSslProtocols(value: string[]);
        get originSslProtocolsInput(): string[] | undefined;
        private _originMtlsConfig;
        get originMtlsConfig(): OriginMtlsConfigPropertyList;
        putOriginMtlsConfig(value: OriginMtlsConfigProperty[] | cdktn.IResolvable): void;
        resetOriginMtlsConfig(): void;
        get originMtlsConfigInput(): cdktn.IResolvable | OriginMtlsConfigProperty[] | undefined;
    }
    class CustomOriginConfigPropertyList extends cdktn.ComplexList {
        internalValue?: CustomOriginConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomOriginConfigPropertyOutputReference;
    }
    interface OriginShieldProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#enabled TfMultitenantDistribution#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#origin_shield_region TfMultitenantDistribution#origin_shield_region}
        */
        readonly originShieldRegion?: string;
    }
    class OriginShieldPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OriginShieldProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OriginShieldProperty | cdktn.IResolvable | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _originShieldRegion?;
        get originShieldRegion(): string;
        set originShieldRegion(value: string);
        resetOriginShieldRegion(): void;
        get originShieldRegionInput(): string | undefined;
    }
    class OriginShieldPropertyList extends cdktn.ComplexList {
        internalValue?: OriginShieldProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OriginShieldPropertyOutputReference;
    }
    interface VpcOriginConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#origin_keepalive_timeout TfMultitenantDistribution#origin_keepalive_timeout}
        */
        readonly originKeepaliveTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#origin_read_timeout TfMultitenantDistribution#origin_read_timeout}
        */
        readonly originReadTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#vpc_origin_id TfMultitenantDistribution#vpc_origin_id}
        */
        readonly vpcOriginId: string;
    }
    class VpcOriginConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcOriginConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcOriginConfigProperty | cdktn.IResolvable | undefined);
        private _originKeepaliveTimeout?;
        get originKeepaliveTimeout(): number;
        set originKeepaliveTimeout(value: number);
        resetOriginKeepaliveTimeout(): void;
        get originKeepaliveTimeoutInput(): number | undefined;
        private _originReadTimeout?;
        get originReadTimeout(): number;
        set originReadTimeout(value: number);
        resetOriginReadTimeout(): void;
        get originReadTimeoutInput(): number | undefined;
        private _vpcOriginId?;
        get vpcOriginId(): string;
        set vpcOriginId(value: string);
        get vpcOriginIdInput(): string | undefined;
    }
    class VpcOriginConfigPropertyList extends cdktn.ComplexList {
        internalValue?: VpcOriginConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcOriginConfigPropertyOutputReference;
    }
    interface OriginProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#connection_attempts TfMultitenantDistribution#connection_attempts}
        */
        readonly connectionAttempts?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#connection_timeout TfMultitenantDistribution#connection_timeout}
        */
        readonly connectionTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#domain_name TfMultitenantDistribution#domain_name}
        */
        readonly domainName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#id TfMultitenantDistribution#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#origin_access_control_id TfMultitenantDistribution#origin_access_control_id}
        */
        readonly originAccessControlId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#origin_path TfMultitenantDistribution#origin_path}
        */
        readonly originPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#response_completion_timeout TfMultitenantDistribution#response_completion_timeout}
        */
        readonly responseCompletionTimeout?: number;
        /**
        * custom_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#custom_header TfMultitenantDistribution#custom_header}
        */
        readonly customHeader?: CustomHeaderProperty[] | cdktn.IResolvable;
        /**
        * custom_origin_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#custom_origin_config TfMultitenantDistribution#custom_origin_config}
        */
        readonly customOriginConfig?: CustomOriginConfigProperty[] | cdktn.IResolvable;
        /**
        * origin_shield block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#origin_shield TfMultitenantDistribution#origin_shield}
        */
        readonly originShield?: OriginShieldProperty[] | cdktn.IResolvable;
        /**
        * vpc_origin_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#vpc_origin_config TfMultitenantDistribution#vpc_origin_config}
        */
        readonly vpcOriginConfig?: VpcOriginConfigProperty[] | cdktn.IResolvable;
    }
    class OriginPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OriginProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OriginProperty | cdktn.IResolvable | undefined);
        private _connectionAttempts?;
        get connectionAttempts(): number;
        set connectionAttempts(value: number);
        resetConnectionAttempts(): void;
        get connectionAttemptsInput(): number | undefined;
        private _connectionTimeout?;
        get connectionTimeout(): number;
        set connectionTimeout(value: number);
        resetConnectionTimeout(): void;
        get connectionTimeoutInput(): number | undefined;
        private _domainName?;
        get domainName(): string;
        set domainName(value: string);
        get domainNameInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _originAccessControlId?;
        get originAccessControlId(): string;
        set originAccessControlId(value: string);
        resetOriginAccessControlId(): void;
        get originAccessControlIdInput(): string | undefined;
        private _originPath?;
        get originPath(): string;
        set originPath(value: string);
        resetOriginPath(): void;
        get originPathInput(): string | undefined;
        private _responseCompletionTimeout?;
        get responseCompletionTimeout(): number;
        set responseCompletionTimeout(value: number);
        resetResponseCompletionTimeout(): void;
        get responseCompletionTimeoutInput(): number | undefined;
        private _customHeader;
        get customHeader(): CustomHeaderPropertyList;
        putCustomHeader(value: CustomHeaderProperty[] | cdktn.IResolvable): void;
        resetCustomHeader(): void;
        get customHeaderInput(): cdktn.IResolvable | CustomHeaderProperty[] | undefined;
        private _customOriginConfig;
        get customOriginConfig(): CustomOriginConfigPropertyList;
        putCustomOriginConfig(value: CustomOriginConfigProperty[] | cdktn.IResolvable): void;
        resetCustomOriginConfig(): void;
        get customOriginConfigInput(): cdktn.IResolvable | CustomOriginConfigProperty[] | undefined;
        private _originShield;
        get originShield(): OriginShieldPropertyList;
        putOriginShield(value: OriginShieldProperty[] | cdktn.IResolvable): void;
        resetOriginShield(): void;
        get originShieldInput(): cdktn.IResolvable | OriginShieldProperty[] | undefined;
        private _vpcOriginConfig;
        get vpcOriginConfig(): VpcOriginConfigPropertyList;
        putVpcOriginConfig(value: VpcOriginConfigProperty[] | cdktn.IResolvable): void;
        resetVpcOriginConfig(): void;
        get vpcOriginConfigInput(): cdktn.IResolvable | VpcOriginConfigProperty[] | undefined;
    }
    class OriginPropertyList extends cdktn.ComplexList {
        internalValue?: OriginProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OriginPropertyOutputReference;
    }
    interface FailoverCriteriaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#status_codes TfMultitenantDistribution#status_codes}
        */
        readonly statusCodes: number[];
    }
    class FailoverCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FailoverCriteriaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FailoverCriteriaProperty | cdktn.IResolvable | undefined);
        private _statusCodes?;
        get statusCodes(): number[];
        set statusCodes(value: number[]);
        get statusCodesInput(): number[] | undefined;
    }
    class FailoverCriteriaPropertyList extends cdktn.ComplexList {
        internalValue?: FailoverCriteriaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FailoverCriteriaPropertyOutputReference;
    }
    interface MemberProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#origin_id TfMultitenantDistribution#origin_id}
        */
        readonly originId: string;
    }
    class MemberPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemberProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MemberProperty | cdktn.IResolvable | undefined);
        private _originId?;
        get originId(): string;
        set originId(value: string);
        get originIdInput(): string | undefined;
    }
    class MemberPropertyList extends cdktn.ComplexList {
        internalValue?: MemberProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemberPropertyOutputReference;
    }
    interface OriginGroupProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#id TfMultitenantDistribution#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * failover_criteria block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#failover_criteria TfMultitenantDistribution#failover_criteria}
        */
        readonly failoverCriteria?: FailoverCriteriaProperty[] | cdktn.IResolvable;
        /**
        * member block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#member TfMultitenantDistribution#member}
        */
        readonly member?: MemberProperty[] | cdktn.IResolvable;
    }
    class OriginGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OriginGroupProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OriginGroupProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _failoverCriteria;
        get failoverCriteria(): FailoverCriteriaPropertyList;
        putFailoverCriteria(value: FailoverCriteriaProperty[] | cdktn.IResolvable): void;
        resetFailoverCriteria(): void;
        get failoverCriteriaInput(): cdktn.IResolvable | FailoverCriteriaProperty[] | undefined;
        private _member;
        get member(): MemberPropertyList;
        putMember(value: MemberProperty[] | cdktn.IResolvable): void;
        resetMember(): void;
        get memberInput(): cdktn.IResolvable | MemberProperty[] | undefined;
    }
    class OriginGroupPropertyList extends cdktn.ComplexList {
        internalValue?: OriginGroupProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OriginGroupPropertyOutputReference;
    }
    interface GeoRestrictionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#items TfMultitenantDistribution#items}
        */
        readonly items?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#restriction_type TfMultitenantDistribution#restriction_type}
        */
        readonly restrictionType: string;
    }
    class GeoRestrictionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GeoRestrictionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GeoRestrictionProperty | cdktn.IResolvable | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
        private _restrictionType?;
        get restrictionType(): string;
        set restrictionType(value: string);
        get restrictionTypeInput(): string | undefined;
    }
    class GeoRestrictionPropertyList extends cdktn.ComplexList {
        internalValue?: GeoRestrictionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GeoRestrictionPropertyOutputReference;
    }
    interface RestrictionsProperty {
        /**
        * geo_restriction block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#geo_restriction TfMultitenantDistribution#geo_restriction}
        */
        readonly geoRestriction?: GeoRestrictionProperty[] | cdktn.IResolvable;
    }
    class RestrictionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RestrictionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RestrictionsProperty | cdktn.IResolvable | undefined);
        private _geoRestriction;
        get geoRestriction(): GeoRestrictionPropertyList;
        putGeoRestriction(value: GeoRestrictionProperty[] | cdktn.IResolvable): void;
        resetGeoRestriction(): void;
        get geoRestrictionInput(): cdktn.IResolvable | GeoRestrictionProperty[] | undefined;
    }
    class RestrictionsPropertyList extends cdktn.ComplexList {
        internalValue?: RestrictionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RestrictionsPropertyOutputReference;
    }
    interface StringSchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#comment TfMultitenantDistribution#comment}
        */
        readonly comment?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#default_value TfMultitenantDistribution#default_value}
        */
        readonly defaultValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#required TfMultitenantDistribution#required}
        */
        readonly required: boolean | cdktn.IResolvable;
    }
    class StringSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StringSchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StringSchemaProperty | cdktn.IResolvable | undefined);
        private _comment?;
        get comment(): string;
        set comment(value: string);
        resetComment(): void;
        get commentInput(): string | undefined;
        private _defaultValue?;
        get defaultValue(): string;
        set defaultValue(value: string);
        resetDefaultValue(): void;
        get defaultValueInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
    }
    class StringSchemaPropertyList extends cdktn.ComplexList {
        internalValue?: StringSchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StringSchemaPropertyOutputReference;
    }
    interface DefinitionProperty {
        /**
        * string_schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#string_schema TfMultitenantDistribution#string_schema}
        */
        readonly stringSchema?: StringSchemaProperty[] | cdktn.IResolvable;
    }
    class DefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionProperty | cdktn.IResolvable | undefined);
        private _stringSchema;
        get stringSchema(): StringSchemaPropertyList;
        putStringSchema(value: StringSchemaProperty[] | cdktn.IResolvable): void;
        resetStringSchema(): void;
        get stringSchemaInput(): cdktn.IResolvable | StringSchemaProperty[] | undefined;
    }
    class DefinitionPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionPropertyOutputReference;
    }
    interface ParameterDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#name TfMultitenantDistribution#name}
        */
        readonly name: string;
        /**
        * definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#definition TfMultitenantDistribution#definition}
        */
        readonly definition?: DefinitionProperty[] | cdktn.IResolvable;
    }
    class ParameterDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterDefinitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterDefinitionProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _definition;
        get definition(): DefinitionPropertyList;
        putDefinition(value: DefinitionProperty[] | cdktn.IResolvable): void;
        resetDefinition(): void;
        get definitionInput(): cdktn.IResolvable | DefinitionProperty[] | undefined;
    }
    class ParameterDefinitionPropertyList extends cdktn.ComplexList {
        internalValue?: ParameterDefinitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterDefinitionPropertyOutputReference;
    }
    interface TenantConfigProperty {
        /**
        * parameter_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#parameter_definition TfMultitenantDistribution#parameter_definition}
        */
        readonly parameterDefinition?: ParameterDefinitionProperty[] | cdktn.IResolvable;
    }
    class TenantConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TenantConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TenantConfigProperty | cdktn.IResolvable | undefined);
        private _parameterDefinition;
        get parameterDefinition(): ParameterDefinitionPropertyList;
        putParameterDefinition(value: ParameterDefinitionProperty[] | cdktn.IResolvable): void;
        resetParameterDefinition(): void;
        get parameterDefinitionInput(): cdktn.IResolvable | ParameterDefinitionProperty[] | undefined;
    }
    class TenantConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TenantConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TenantConfigPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#create TfMultitenantDistribution#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#delete TfMultitenantDistribution#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#update TfMultitenantDistribution#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface ViewerCertificateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#acm_certificate_arn TfMultitenantDistribution#acm_certificate_arn}
        */
        readonly acmCertificateArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#cloudfront_default_certificate TfMultitenantDistribution#cloudfront_default_certificate}
        */
        readonly cloudfrontDefaultCertificate?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#minimum_protocol_version TfMultitenantDistribution#minimum_protocol_version}
        */
        readonly minimumProtocolVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_multitenant_distribution#ssl_support_method TfMultitenantDistribution#ssl_support_method}
        */
        readonly sslSupportMethod?: string;
    }
    class ViewerCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ViewerCertificateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ViewerCertificateProperty | cdktn.IResolvable | undefined);
        private _acmCertificateArn?;
        get acmCertificateArn(): string;
        set acmCertificateArn(value: string);
        resetAcmCertificateArn(): void;
        get acmCertificateArnInput(): string | undefined;
        private _cloudfrontDefaultCertificate?;
        get cloudfrontDefaultCertificate(): boolean | cdktn.IResolvable;
        set cloudfrontDefaultCertificate(value: boolean | cdktn.IResolvable);
        resetCloudfrontDefaultCertificate(): void;
        get cloudfrontDefaultCertificateInput(): boolean | cdktn.IResolvable | undefined;
        private _minimumProtocolVersion?;
        get minimumProtocolVersion(): string;
        set minimumProtocolVersion(value: string);
        resetMinimumProtocolVersion(): void;
        get minimumProtocolVersionInput(): string | undefined;
        private _sslSupportMethod?;
        get sslSupportMethod(): string;
        set sslSupportMethod(value: string);
        resetSslSupportMethod(): void;
        get sslSupportMethodInput(): string | undefined;
    }
    class ViewerCertificatePropertyList extends cdktn.ComplexList {
        internalValue?: ViewerCertificateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ViewerCertificatePropertyOutputReference;
    }
}
