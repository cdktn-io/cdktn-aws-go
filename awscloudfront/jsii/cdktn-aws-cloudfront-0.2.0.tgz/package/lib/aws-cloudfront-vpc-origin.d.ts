import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfVpcOriginConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#tags TfVpcOrigin#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#timeouts TfVpcOrigin#timeouts}
    */
    readonly timeouts?: TfVpcOrigin.TimeoutsProperty;
    /**
    * vpc_origin_endpoint_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#vpc_origin_endpoint_config TfVpcOrigin#vpc_origin_endpoint_config}
    */
    readonly vpcOriginEndpointConfig?: TfVpcOrigin.VpcOriginEndpointConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin aws_cloudfront_vpc_origin}
*/
export declare class TfVpcOrigin extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_vpc_origin";
    /**
    * Generates CDKTN code for importing a TfVpcOrigin resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfVpcOrigin to import
    * @param importFromId The id of the existing TfVpcOrigin that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfVpcOrigin to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin aws_cloudfront_vpc_origin} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfVpcOriginConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfVpcOriginConfig);
    get arn(): string;
    get etag(): string;
    get id(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): TfVpcOrigin.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfVpcOrigin.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfVpcOrigin.TimeoutsProperty | undefined;
    private _vpcOriginEndpointConfig;
    get vpcOriginEndpointConfig(): TfVpcOrigin.VpcOriginEndpointConfigPropertyList;
    putVpcOriginEndpointConfig(value: TfVpcOrigin.VpcOriginEndpointConfigProperty[] | cdktn.IResolvable): void;
    resetVpcOriginEndpointConfig(): void;
    get vpcOriginEndpointConfigInput(): cdktn.IResolvable | TfVpcOrigin.VpcOriginEndpointConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfVpcOriginTimeoutsPropertyToTerraform(struct?: TfVpcOrigin.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfVpcOriginTimeoutsPropertyToHclTerraform(struct?: TfVpcOrigin.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfVpcOriginOriginSslProtocolsPropertyToTerraform(struct?: TfVpcOrigin.OriginSslProtocolsProperty | cdktn.IResolvable): any;
export declare function tfVpcOriginOriginSslProtocolsPropertyToHclTerraform(struct?: TfVpcOrigin.OriginSslProtocolsProperty | cdktn.IResolvable): any;
export declare function tfVpcOriginVpcOriginEndpointConfigPropertyToTerraform(struct?: TfVpcOrigin.VpcOriginEndpointConfigProperty | cdktn.IResolvable): any;
export declare function tfVpcOriginVpcOriginEndpointConfigPropertyToHclTerraform(struct?: TfVpcOrigin.VpcOriginEndpointConfigProperty | cdktn.IResolvable): any;
export declare namespace TfVpcOrigin {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#create TfVpcOrigin#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#delete TfVpcOrigin#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#update TfVpcOrigin#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface OriginSslProtocolsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#items TfVpcOrigin#items}
        */
        readonly items: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#quantity TfVpcOrigin#quantity}
        */
        readonly quantity: number;
    }
    class OriginSslProtocolsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OriginSslProtocolsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OriginSslProtocolsProperty | cdktn.IResolvable | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        get itemsInput(): string[] | undefined;
        private _quantity?;
        get quantity(): number;
        set quantity(value: number);
        get quantityInput(): number | undefined;
    }
    class OriginSslProtocolsPropertyList extends cdktn.ComplexList {
        internalValue?: OriginSslProtocolsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OriginSslProtocolsPropertyOutputReference;
    }
    interface VpcOriginEndpointConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#arn TfVpcOrigin#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#http_port TfVpcOrigin#http_port}
        */
        readonly httpPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#https_port TfVpcOrigin#https_port}
        */
        readonly httpsPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#name TfVpcOrigin#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#origin_protocol_policy TfVpcOrigin#origin_protocol_policy}
        */
        readonly originProtocolPolicy: string;
        /**
        * origin_ssl_protocols block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_vpc_origin#origin_ssl_protocols TfVpcOrigin#origin_ssl_protocols}
        */
        readonly originSslProtocols?: OriginSslProtocolsProperty[] | cdktn.IResolvable;
    }
    class VpcOriginEndpointConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcOriginEndpointConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcOriginEndpointConfigProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _httpPort?;
        get httpPort(): number;
        set httpPort(value: number);
        get httpPortInput(): number | undefined;
        private _httpsPort?;
        get httpsPort(): number;
        set httpsPort(value: number);
        get httpsPortInput(): number | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _originProtocolPolicy?;
        get originProtocolPolicy(): string;
        set originProtocolPolicy(value: string);
        get originProtocolPolicyInput(): string | undefined;
        private _originSslProtocols;
        get originSslProtocols(): OriginSslProtocolsPropertyList;
        putOriginSslProtocols(value: OriginSslProtocolsProperty[] | cdktn.IResolvable): void;
        resetOriginSslProtocols(): void;
        get originSslProtocolsInput(): cdktn.IResolvable | OriginSslProtocolsProperty[] | undefined;
    }
    class VpcOriginEndpointConfigPropertyList extends cdktn.ComplexList {
        internalValue?: VpcOriginEndpointConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcOriginEndpointConfigPropertyOutputReference;
    }
}
