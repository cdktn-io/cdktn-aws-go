import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfConnectionFunctionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_function#connection_function_code TfConnectionFunction#connection_function_code}
    */
    readonly connectionFunctionCode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_function#name TfConnectionFunction#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_function#publish TfConnectionFunction#publish}
    */
    readonly publish?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_function#tags TfConnectionFunction#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * connection_function_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_function#connection_function_config TfConnectionFunction#connection_function_config}
    */
    readonly connectionFunctionConfig?: TfConnectionFunction.ConnectionFunctionConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_function aws_cloudfront_connection_function}
*/
export declare class TfConnectionFunction extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_connection_function";
    /**
    * Generates CDKTN code for importing a TfConnectionFunction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfConnectionFunction to import
    * @param importFromId The id of the existing TfConnectionFunction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_function#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfConnectionFunction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_function aws_cloudfront_connection_function} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfConnectionFunctionConfig
    */
    constructor(scope: Construct, id: string, config: TfConnectionFunctionConfig);
    get connectionFunctionArn(): string;
    private _connectionFunctionCode?;
    get connectionFunctionCode(): string;
    set connectionFunctionCode(value: string);
    get connectionFunctionCodeInput(): string | undefined;
    get etag(): string;
    get id(): string;
    get liveStageEtag(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _publish?;
    get publish(): boolean | cdktn.IResolvable;
    set publish(value: boolean | cdktn.IResolvable);
    resetPublish(): void;
    get publishInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _connectionFunctionConfig;
    get connectionFunctionConfig(): TfConnectionFunction.ConnectionFunctionConfigPropertyList;
    putConnectionFunctionConfig(value: TfConnectionFunction.ConnectionFunctionConfigProperty[] | cdktn.IResolvable): void;
    resetConnectionFunctionConfig(): void;
    get connectionFunctionConfigInput(): cdktn.IResolvable | TfConnectionFunction.ConnectionFunctionConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfConnectionFunctionKeyValueStoreAssociationPropertyToTerraform(struct?: TfConnectionFunction.KeyValueStoreAssociationProperty | cdktn.IResolvable): any;
export declare function tfConnectionFunctionKeyValueStoreAssociationPropertyToHclTerraform(struct?: TfConnectionFunction.KeyValueStoreAssociationProperty | cdktn.IResolvable): any;
export declare function tfConnectionFunctionConnectionFunctionConfigPropertyToTerraform(struct?: TfConnectionFunction.ConnectionFunctionConfigProperty | cdktn.IResolvable): any;
export declare function tfConnectionFunctionConnectionFunctionConfigPropertyToHclTerraform(struct?: TfConnectionFunction.ConnectionFunctionConfigProperty | cdktn.IResolvable): any;
export declare namespace TfConnectionFunction {
    interface KeyValueStoreAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_function#key_value_store_arn TfConnectionFunction#key_value_store_arn}
        */
        readonly keyValueStoreArn: string;
    }
    class KeyValueStoreAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KeyValueStoreAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KeyValueStoreAssociationProperty | cdktn.IResolvable | undefined);
        private _keyValueStoreArn?;
        get keyValueStoreArn(): string;
        set keyValueStoreArn(value: string);
        get keyValueStoreArnInput(): string | undefined;
    }
    class KeyValueStoreAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: KeyValueStoreAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KeyValueStoreAssociationPropertyOutputReference;
    }
    interface ConnectionFunctionConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_function#comment TfConnectionFunction#comment}
        */
        readonly comment: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_function#runtime TfConnectionFunction#runtime}
        */
        readonly runtime: string;
        /**
        * key_value_store_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_connection_function#key_value_store_association TfConnectionFunction#key_value_store_association}
        */
        readonly keyValueStoreAssociation?: KeyValueStoreAssociationProperty[] | cdktn.IResolvable;
    }
    class ConnectionFunctionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectionFunctionConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConnectionFunctionConfigProperty | cdktn.IResolvable | undefined);
        private _comment?;
        get comment(): string;
        set comment(value: string);
        get commentInput(): string | undefined;
        private _runtime?;
        get runtime(): string;
        set runtime(value: string);
        get runtimeInput(): string | undefined;
        private _keyValueStoreAssociation;
        get keyValueStoreAssociation(): KeyValueStoreAssociationPropertyList;
        putKeyValueStoreAssociation(value: KeyValueStoreAssociationProperty[] | cdktn.IResolvable): void;
        resetKeyValueStoreAssociation(): void;
        get keyValueStoreAssociationInput(): cdktn.IResolvable | KeyValueStoreAssociationProperty[] | undefined;
    }
    class ConnectionFunctionConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ConnectionFunctionConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectionFunctionConfigPropertyOutputReference;
    }
}
