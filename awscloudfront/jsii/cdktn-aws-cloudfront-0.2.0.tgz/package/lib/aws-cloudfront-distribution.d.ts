import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfDistributionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#aliases TfDistribution#aliases}
    */
    readonly aliases?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#anycast_ip_list_id TfDistribution#anycast_ip_list_id}
    */
    readonly anycastIpListId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#comment TfDistribution#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#continuous_deployment_policy_id TfDistribution#continuous_deployment_policy_id}
    */
    readonly continuousDeploymentPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#default_root_object TfDistribution#default_root_object}
    */
    readonly defaultRootObject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#enabled TfDistribution#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#http_version TfDistribution#http_version}
    */
    readonly httpVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#id TfDistribution#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#is_ipv6_enabled TfDistribution#is_ipv6_enabled}
    */
    readonly isIpv6Enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#price_class TfDistribution#price_class}
    */
    readonly priceClass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#retain_on_delete TfDistribution#retain_on_delete}
    */
    readonly retainOnDelete?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#staging TfDistribution#staging}
    */
    readonly staging?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#tags TfDistribution#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#tags_all TfDistribution#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#wait_for_deployment TfDistribution#wait_for_deployment}
    */
    readonly waitForDeployment?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#web_acl_id TfDistribution#web_acl_id}
    */
    readonly webAclId?: string;
    /**
    * cache_tag_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cache_tag_config TfDistribution#cache_tag_config}
    */
    readonly cacheTagConfig?: TfDistribution.CacheTagConfigProperty;
    /**
    * connection_function_association block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#connection_function_association TfDistribution#connection_function_association}
    */
    readonly connectionFunctionAssociation?: TfDistribution.ConnectionFunctionAssociationProperty;
    /**
    * custom_error_response block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#custom_error_response TfDistribution#custom_error_response}
    */
    readonly customErrorResponse?: TfDistribution.CustomErrorResponseProperty[] | cdktn.IResolvable;
    /**
    * default_cache_behavior block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#default_cache_behavior TfDistribution#default_cache_behavior}
    */
    readonly defaultCacheBehavior: TfDistribution.DefaultCacheBehaviorProperty;
    /**
    * logging_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#logging_config TfDistribution#logging_config}
    */
    readonly loggingConfig?: TfDistribution.LoggingConfigProperty;
    /**
    * ordered_cache_behavior block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#ordered_cache_behavior TfDistribution#ordered_cache_behavior}
    */
    readonly orderedCacheBehavior?: TfDistribution.OrderedCacheBehaviorProperty[] | cdktn.IResolvable;
    /**
    * origin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin TfDistribution#origin}
    */
    readonly origin: TfDistribution.OriginProperty[] | cdktn.IResolvable;
    /**
    * origin_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_group TfDistribution#origin_group}
    */
    readonly originGroup?: TfDistribution.OriginGroupProperty[] | cdktn.IResolvable;
    /**
    * restrictions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#restrictions TfDistribution#restrictions}
    */
    readonly restrictions: TfDistribution.RestrictionsProperty;
    /**
    * viewer_certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#viewer_certificate TfDistribution#viewer_certificate}
    */
    readonly viewerCertificate: TfDistribution.ViewerCertificateProperty;
    /**
    * viewer_mtls_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#viewer_mtls_config TfDistribution#viewer_mtls_config}
    */
    readonly viewerMtlsConfig?: TfDistribution.ViewerMtlsConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution aws_cloudfront_distribution}
*/
export declare class TfDistribution extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_distribution";
    /**
    * Generates CDKTN code for importing a TfDistribution resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfDistribution to import
    * @param importFromId The id of the existing TfDistribution that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfDistribution to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution aws_cloudfront_distribution} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfDistributionConfig
    */
    constructor(scope: Construct, id: string, config: TfDistributionConfig);
    private _aliases?;
    get aliases(): string[];
    set aliases(value: string[]);
    resetAliases(): void;
    get aliasesInput(): string[] | undefined;
    private _anycastIpListId?;
    get anycastIpListId(): string;
    set anycastIpListId(value: string);
    resetAnycastIpListId(): void;
    get anycastIpListIdInput(): string | undefined;
    get arn(): string;
    get callerReference(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _continuousDeploymentPolicyId?;
    get continuousDeploymentPolicyId(): string;
    set continuousDeploymentPolicyId(value: string);
    resetContinuousDeploymentPolicyId(): void;
    get continuousDeploymentPolicyIdInput(): string | undefined;
    private _defaultRootObject?;
    get defaultRootObject(): string;
    set defaultRootObject(value: string);
    resetDefaultRootObject(): void;
    get defaultRootObjectInput(): string | undefined;
    get domainName(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get etag(): string;
    get hostedZoneId(): string;
    private _httpVersion?;
    get httpVersion(): string;
    set httpVersion(value: string);
    resetHttpVersion(): void;
    get httpVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get inProgressValidationBatches(): number;
    private _isIpv6Enabled?;
    get isIpv6Enabled(): boolean | cdktn.IResolvable;
    set isIpv6Enabled(value: boolean | cdktn.IResolvable);
    resetIsIpv6Enabled(): void;
    get isIpv6EnabledInput(): boolean | cdktn.IResolvable | undefined;
    get lastModifiedTime(): string;
    get loggingV1Enabled(): cdktn.IResolvable;
    private _priceClass?;
    get priceClass(): string;
    set priceClass(value: string);
    resetPriceClass(): void;
    get priceClassInput(): string | undefined;
    private _retainOnDelete?;
    get retainOnDelete(): boolean | cdktn.IResolvable;
    set retainOnDelete(value: boolean | cdktn.IResolvable);
    resetRetainOnDelete(): void;
    get retainOnDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _staging?;
    get staging(): boolean | cdktn.IResolvable;
    set staging(value: boolean | cdktn.IResolvable);
    resetStaging(): void;
    get stagingInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _trustedKeyGroups;
    get trustedKeyGroups(): TfDistribution.TrustedKeyGroupsPropertyList;
    private _trustedSigners;
    get trustedSigners(): TfDistribution.TrustedSignersPropertyList;
    private _waitForDeployment?;
    get waitForDeployment(): boolean | cdktn.IResolvable;
    set waitForDeployment(value: boolean | cdktn.IResolvable);
    resetWaitForDeployment(): void;
    get waitForDeploymentInput(): boolean | cdktn.IResolvable | undefined;
    private _webAclId?;
    get webAclId(): string;
    set webAclId(value: string);
    resetWebAclId(): void;
    get webAclIdInput(): string | undefined;
    private _cacheTagConfig;
    get cacheTagConfig(): TfDistribution.CacheTagConfigPropertyOutputReference;
    putCacheTagConfig(value: TfDistribution.CacheTagConfigProperty): void;
    resetCacheTagConfig(): void;
    get cacheTagConfigInput(): TfDistribution.CacheTagConfigProperty | undefined;
    private _connectionFunctionAssociation;
    get connectionFunctionAssociation(): TfDistribution.ConnectionFunctionAssociationPropertyOutputReference;
    putConnectionFunctionAssociation(value: TfDistribution.ConnectionFunctionAssociationProperty): void;
    resetConnectionFunctionAssociation(): void;
    get connectionFunctionAssociationInput(): TfDistribution.ConnectionFunctionAssociationProperty | undefined;
    private _customErrorResponse;
    get customErrorResponse(): TfDistribution.CustomErrorResponsePropertyList;
    putCustomErrorResponse(value: TfDistribution.CustomErrorResponseProperty[] | cdktn.IResolvable): void;
    resetCustomErrorResponse(): void;
    get customErrorResponseInput(): cdktn.IResolvable | TfDistribution.CustomErrorResponseProperty[] | undefined;
    private _defaultCacheBehavior;
    get defaultCacheBehavior(): TfDistribution.DefaultCacheBehaviorPropertyOutputReference;
    putDefaultCacheBehavior(value: TfDistribution.DefaultCacheBehaviorProperty): void;
    get defaultCacheBehaviorInput(): TfDistribution.DefaultCacheBehaviorProperty | undefined;
    private _loggingConfig;
    get loggingConfig(): TfDistribution.LoggingConfigPropertyOutputReference;
    putLoggingConfig(value: TfDistribution.LoggingConfigProperty): void;
    resetLoggingConfig(): void;
    get loggingConfigInput(): TfDistribution.LoggingConfigProperty | undefined;
    private _orderedCacheBehavior;
    get orderedCacheBehavior(): TfDistribution.OrderedCacheBehaviorPropertyList;
    putOrderedCacheBehavior(value: TfDistribution.OrderedCacheBehaviorProperty[] | cdktn.IResolvable): void;
    resetOrderedCacheBehavior(): void;
    get orderedCacheBehaviorInput(): cdktn.IResolvable | TfDistribution.OrderedCacheBehaviorProperty[] | undefined;
    private _origin;
    get origin(): TfDistribution.OriginPropertyList;
    putOrigin(value: TfDistribution.OriginProperty[] | cdktn.IResolvable): void;
    get originInput(): cdktn.IResolvable | TfDistribution.OriginProperty[] | undefined;
    private _originGroup;
    get originGroup(): TfDistribution.OriginGroupPropertyList;
    putOriginGroup(value: TfDistribution.OriginGroupProperty[] | cdktn.IResolvable): void;
    resetOriginGroup(): void;
    get originGroupInput(): cdktn.IResolvable | TfDistribution.OriginGroupProperty[] | undefined;
    private _restrictions;
    get restrictions(): TfDistribution.RestrictionsPropertyOutputReference;
    putRestrictions(value: TfDistribution.RestrictionsProperty): void;
    get restrictionsInput(): TfDistribution.RestrictionsProperty | undefined;
    private _viewerCertificate;
    get viewerCertificate(): TfDistribution.ViewerCertificatePropertyOutputReference;
    putViewerCertificate(value: TfDistribution.ViewerCertificateProperty): void;
    get viewerCertificateInput(): TfDistribution.ViewerCertificateProperty | undefined;
    private _viewerMtlsConfig;
    get viewerMtlsConfig(): TfDistribution.ViewerMtlsConfigPropertyOutputReference;
    putViewerMtlsConfig(value: TfDistribution.ViewerMtlsConfigProperty): void;
    resetViewerMtlsConfig(): void;
    get viewerMtlsConfigInput(): TfDistribution.ViewerMtlsConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfDistributionTrustedKeyGroupsItemsPropertyToTerraform(struct?: TfDistribution.TrustedKeyGroupsItemsProperty): any;
export declare function tfDistributionTrustedKeyGroupsItemsPropertyToHclTerraform(struct?: TfDistribution.TrustedKeyGroupsItemsProperty): any;
export declare function tfDistributionTrustedKeyGroupsPropertyToTerraform(struct?: TfDistribution.TrustedKeyGroupsProperty): any;
export declare function tfDistributionTrustedKeyGroupsPropertyToHclTerraform(struct?: TfDistribution.TrustedKeyGroupsProperty): any;
export declare function tfDistributionTrustedSignersItemsPropertyToTerraform(struct?: TfDistribution.TrustedSignersItemsProperty): any;
export declare function tfDistributionTrustedSignersItemsPropertyToHclTerraform(struct?: TfDistribution.TrustedSignersItemsProperty): any;
export declare function tfDistributionTrustedSignersPropertyToTerraform(struct?: TfDistribution.TrustedSignersProperty): any;
export declare function tfDistributionTrustedSignersPropertyToHclTerraform(struct?: TfDistribution.TrustedSignersProperty): any;
export declare function tfDistributionCacheTagConfigPropertyToTerraform(struct?: TfDistribution.CacheTagConfigPropertyOutputReference | TfDistribution.CacheTagConfigProperty): any;
export declare function tfDistributionCacheTagConfigPropertyToHclTerraform(struct?: TfDistribution.CacheTagConfigPropertyOutputReference | TfDistribution.CacheTagConfigProperty): any;
export declare function tfDistributionConnectionFunctionAssociationPropertyToTerraform(struct?: TfDistribution.ConnectionFunctionAssociationPropertyOutputReference | TfDistribution.ConnectionFunctionAssociationProperty): any;
export declare function tfDistributionConnectionFunctionAssociationPropertyToHclTerraform(struct?: TfDistribution.ConnectionFunctionAssociationPropertyOutputReference | TfDistribution.ConnectionFunctionAssociationProperty): any;
export declare function tfDistributionCustomErrorResponsePropertyToTerraform(struct?: TfDistribution.CustomErrorResponseProperty | cdktn.IResolvable): any;
export declare function tfDistributionCustomErrorResponsePropertyToHclTerraform(struct?: TfDistribution.CustomErrorResponseProperty | cdktn.IResolvable): any;
export declare function tfDistributionDefaultCacheBehaviorForwardedValuesCookiesPropertyToTerraform(struct?: TfDistribution.DefaultCacheBehaviorForwardedValuesCookiesPropertyOutputReference | TfDistribution.DefaultCacheBehaviorForwardedValuesCookiesProperty): any;
export declare function tfDistributionDefaultCacheBehaviorForwardedValuesCookiesPropertyToHclTerraform(struct?: TfDistribution.DefaultCacheBehaviorForwardedValuesCookiesPropertyOutputReference | TfDistribution.DefaultCacheBehaviorForwardedValuesCookiesProperty): any;
export declare function tfDistributionDefaultCacheBehaviorForwardedValuesPropertyToTerraform(struct?: TfDistribution.DefaultCacheBehaviorForwardedValuesPropertyOutputReference | TfDistribution.DefaultCacheBehaviorForwardedValuesProperty): any;
export declare function tfDistributionDefaultCacheBehaviorForwardedValuesPropertyToHclTerraform(struct?: TfDistribution.DefaultCacheBehaviorForwardedValuesPropertyOutputReference | TfDistribution.DefaultCacheBehaviorForwardedValuesProperty): any;
export declare function tfDistributionDefaultCacheBehaviorFunctionAssociationPropertyToTerraform(struct?: TfDistribution.DefaultCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function tfDistributionDefaultCacheBehaviorFunctionAssociationPropertyToHclTerraform(struct?: TfDistribution.DefaultCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function tfDistributionDefaultCacheBehaviorGrpcConfigPropertyToTerraform(struct?: TfDistribution.DefaultCacheBehaviorGrpcConfigPropertyOutputReference | TfDistribution.DefaultCacheBehaviorGrpcConfigProperty): any;
export declare function tfDistributionDefaultCacheBehaviorGrpcConfigPropertyToHclTerraform(struct?: TfDistribution.DefaultCacheBehaviorGrpcConfigPropertyOutputReference | TfDistribution.DefaultCacheBehaviorGrpcConfigProperty): any;
export declare function tfDistributionDefaultCacheBehaviorLambdaFunctionAssociationPropertyToTerraform(struct?: TfDistribution.DefaultCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function tfDistributionDefaultCacheBehaviorLambdaFunctionAssociationPropertyToHclTerraform(struct?: TfDistribution.DefaultCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function tfDistributionDefaultCacheBehaviorPropertyToTerraform(struct?: TfDistribution.DefaultCacheBehaviorPropertyOutputReference | TfDistribution.DefaultCacheBehaviorProperty): any;
export declare function tfDistributionDefaultCacheBehaviorPropertyToHclTerraform(struct?: TfDistribution.DefaultCacheBehaviorPropertyOutputReference | TfDistribution.DefaultCacheBehaviorProperty): any;
export declare function tfDistributionLoggingConfigPropertyToTerraform(struct?: TfDistribution.LoggingConfigPropertyOutputReference | TfDistribution.LoggingConfigProperty): any;
export declare function tfDistributionLoggingConfigPropertyToHclTerraform(struct?: TfDistribution.LoggingConfigPropertyOutputReference | TfDistribution.LoggingConfigProperty): any;
export declare function tfDistributionOrderedCacheBehaviorForwardedValuesCookiesPropertyToTerraform(struct?: TfDistribution.OrderedCacheBehaviorForwardedValuesCookiesPropertyOutputReference | TfDistribution.OrderedCacheBehaviorForwardedValuesCookiesProperty): any;
export declare function tfDistributionOrderedCacheBehaviorForwardedValuesCookiesPropertyToHclTerraform(struct?: TfDistribution.OrderedCacheBehaviorForwardedValuesCookiesPropertyOutputReference | TfDistribution.OrderedCacheBehaviorForwardedValuesCookiesProperty): any;
export declare function tfDistributionOrderedCacheBehaviorForwardedValuesPropertyToTerraform(struct?: TfDistribution.OrderedCacheBehaviorForwardedValuesPropertyOutputReference | TfDistribution.OrderedCacheBehaviorForwardedValuesProperty): any;
export declare function tfDistributionOrderedCacheBehaviorForwardedValuesPropertyToHclTerraform(struct?: TfDistribution.OrderedCacheBehaviorForwardedValuesPropertyOutputReference | TfDistribution.OrderedCacheBehaviorForwardedValuesProperty): any;
export declare function tfDistributionOrderedCacheBehaviorFunctionAssociationPropertyToTerraform(struct?: TfDistribution.OrderedCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function tfDistributionOrderedCacheBehaviorFunctionAssociationPropertyToHclTerraform(struct?: TfDistribution.OrderedCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function tfDistributionOrderedCacheBehaviorGrpcConfigPropertyToTerraform(struct?: TfDistribution.OrderedCacheBehaviorGrpcConfigPropertyOutputReference | TfDistribution.OrderedCacheBehaviorGrpcConfigProperty): any;
export declare function tfDistributionOrderedCacheBehaviorGrpcConfigPropertyToHclTerraform(struct?: TfDistribution.OrderedCacheBehaviorGrpcConfigPropertyOutputReference | TfDistribution.OrderedCacheBehaviorGrpcConfigProperty): any;
export declare function tfDistributionOrderedCacheBehaviorLambdaFunctionAssociationPropertyToTerraform(struct?: TfDistribution.OrderedCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function tfDistributionOrderedCacheBehaviorLambdaFunctionAssociationPropertyToHclTerraform(struct?: TfDistribution.OrderedCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function tfDistributionOrderedCacheBehaviorPropertyToTerraform(struct?: TfDistribution.OrderedCacheBehaviorProperty | cdktn.IResolvable): any;
export declare function tfDistributionOrderedCacheBehaviorPropertyToHclTerraform(struct?: TfDistribution.OrderedCacheBehaviorProperty | cdktn.IResolvable): any;
export declare function tfDistributionCustomHeaderPropertyToTerraform(struct?: TfDistribution.CustomHeaderProperty | cdktn.IResolvable): any;
export declare function tfDistributionCustomHeaderPropertyToHclTerraform(struct?: TfDistribution.CustomHeaderProperty | cdktn.IResolvable): any;
export declare function tfDistributionOriginMtlsConfigPropertyToTerraform(struct?: TfDistribution.OriginMtlsConfigPropertyOutputReference | TfDistribution.OriginMtlsConfigProperty): any;
export declare function tfDistributionOriginMtlsConfigPropertyToHclTerraform(struct?: TfDistribution.OriginMtlsConfigPropertyOutputReference | TfDistribution.OriginMtlsConfigProperty): any;
export declare function tfDistributionCustomOriginConfigPropertyToTerraform(struct?: TfDistribution.CustomOriginConfigPropertyOutputReference | TfDistribution.CustomOriginConfigProperty): any;
export declare function tfDistributionCustomOriginConfigPropertyToHclTerraform(struct?: TfDistribution.CustomOriginConfigPropertyOutputReference | TfDistribution.CustomOriginConfigProperty): any;
export declare function tfDistributionOriginShieldPropertyToTerraform(struct?: TfDistribution.OriginShieldPropertyOutputReference | TfDistribution.OriginShieldProperty): any;
export declare function tfDistributionOriginShieldPropertyToHclTerraform(struct?: TfDistribution.OriginShieldPropertyOutputReference | TfDistribution.OriginShieldProperty): any;
export declare function tfDistributionS3OriginConfigPropertyToTerraform(struct?: TfDistribution.S3OriginConfigPropertyOutputReference | TfDistribution.S3OriginConfigProperty): any;
export declare function tfDistributionS3OriginConfigPropertyToHclTerraform(struct?: TfDistribution.S3OriginConfigPropertyOutputReference | TfDistribution.S3OriginConfigProperty): any;
export declare function tfDistributionVpcOriginConfigPropertyToTerraform(struct?: TfDistribution.VpcOriginConfigPropertyOutputReference | TfDistribution.VpcOriginConfigProperty): any;
export declare function tfDistributionVpcOriginConfigPropertyToHclTerraform(struct?: TfDistribution.VpcOriginConfigPropertyOutputReference | TfDistribution.VpcOriginConfigProperty): any;
export declare function tfDistributionOriginPropertyToTerraform(struct?: TfDistribution.OriginProperty | cdktn.IResolvable): any;
export declare function tfDistributionOriginPropertyToHclTerraform(struct?: TfDistribution.OriginProperty | cdktn.IResolvable): any;
export declare function tfDistributionFailoverCriteriaPropertyToTerraform(struct?: TfDistribution.FailoverCriteriaPropertyOutputReference | TfDistribution.FailoverCriteriaProperty): any;
export declare function tfDistributionFailoverCriteriaPropertyToHclTerraform(struct?: TfDistribution.FailoverCriteriaPropertyOutputReference | TfDistribution.FailoverCriteriaProperty): any;
export declare function tfDistributionMemberPropertyToTerraform(struct?: TfDistribution.MemberProperty | cdktn.IResolvable): any;
export declare function tfDistributionMemberPropertyToHclTerraform(struct?: TfDistribution.MemberProperty | cdktn.IResolvable): any;
export declare function tfDistributionOriginGroupPropertyToTerraform(struct?: TfDistribution.OriginGroupProperty | cdktn.IResolvable): any;
export declare function tfDistributionOriginGroupPropertyToHclTerraform(struct?: TfDistribution.OriginGroupProperty | cdktn.IResolvable): any;
export declare function tfDistributionGeoRestrictionPropertyToTerraform(struct?: TfDistribution.GeoRestrictionPropertyOutputReference | TfDistribution.GeoRestrictionProperty): any;
export declare function tfDistributionGeoRestrictionPropertyToHclTerraform(struct?: TfDistribution.GeoRestrictionPropertyOutputReference | TfDistribution.GeoRestrictionProperty): any;
export declare function tfDistributionRestrictionsPropertyToTerraform(struct?: TfDistribution.RestrictionsPropertyOutputReference | TfDistribution.RestrictionsProperty): any;
export declare function tfDistributionRestrictionsPropertyToHclTerraform(struct?: TfDistribution.RestrictionsPropertyOutputReference | TfDistribution.RestrictionsProperty): any;
export declare function tfDistributionViewerCertificatePropertyToTerraform(struct?: TfDistribution.ViewerCertificatePropertyOutputReference | TfDistribution.ViewerCertificateProperty): any;
export declare function tfDistributionViewerCertificatePropertyToHclTerraform(struct?: TfDistribution.ViewerCertificatePropertyOutputReference | TfDistribution.ViewerCertificateProperty): any;
export declare function tfDistributionTrustStoreConfigPropertyToTerraform(struct?: TfDistribution.TrustStoreConfigPropertyOutputReference | TfDistribution.TrustStoreConfigProperty): any;
export declare function tfDistributionTrustStoreConfigPropertyToHclTerraform(struct?: TfDistribution.TrustStoreConfigPropertyOutputReference | TfDistribution.TrustStoreConfigProperty): any;
export declare function tfDistributionViewerMtlsConfigPropertyToTerraform(struct?: TfDistribution.ViewerMtlsConfigPropertyOutputReference | TfDistribution.ViewerMtlsConfigProperty): any;
export declare function tfDistributionViewerMtlsConfigPropertyToHclTerraform(struct?: TfDistribution.ViewerMtlsConfigPropertyOutputReference | TfDistribution.ViewerMtlsConfigProperty): any;
export declare namespace TfDistribution {
    interface TrustedKeyGroupsItemsProperty {
    }
    class TrustedKeyGroupsItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrustedKeyGroupsItemsProperty | undefined;
        set internalValue(value: TrustedKeyGroupsItemsProperty | undefined);
        get keyGroupId(): string;
        get keyPairIds(): string[];
    }
    class TrustedKeyGroupsItemsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrustedKeyGroupsItemsPropertyOutputReference;
    }
    interface TrustedKeyGroupsProperty {
    }
    class TrustedKeyGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrustedKeyGroupsProperty | undefined;
        set internalValue(value: TrustedKeyGroupsProperty | undefined);
        get enabled(): cdktn.IResolvable;
        private _items;
        get items(): TrustedKeyGroupsItemsPropertyList;
    }
    class TrustedKeyGroupsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrustedKeyGroupsPropertyOutputReference;
    }
    interface TrustedSignersItemsProperty {
    }
    class TrustedSignersItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrustedSignersItemsProperty | undefined;
        set internalValue(value: TrustedSignersItemsProperty | undefined);
        get awsAccountNumber(): string;
        get keyPairIds(): string[];
    }
    class TrustedSignersItemsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrustedSignersItemsPropertyOutputReference;
    }
    interface TrustedSignersProperty {
    }
    class TrustedSignersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrustedSignersProperty | undefined;
        set internalValue(value: TrustedSignersProperty | undefined);
        get enabled(): cdktn.IResolvable;
        private _items;
        get items(): TrustedSignersItemsPropertyList;
    }
    class TrustedSignersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrustedSignersPropertyOutputReference;
    }
    interface CacheTagConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#header_name TfDistribution#header_name}
        */
        readonly headerName: string;
    }
    class CacheTagConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CacheTagConfigProperty | undefined;
        set internalValue(value: CacheTagConfigProperty | undefined);
        private _headerName?;
        get headerName(): string;
        set headerName(value: string);
        get headerNameInput(): string | undefined;
    }
    interface ConnectionFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#id TfDistribution#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
    }
    class ConnectionFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectionFunctionAssociationProperty | undefined;
        set internalValue(value: ConnectionFunctionAssociationProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
    }
    interface CustomErrorResponseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#error_caching_min_ttl TfDistribution#error_caching_min_ttl}
        */
        readonly errorCachingMinTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#error_code TfDistribution#error_code}
        */
        readonly errorCode: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#response_code TfDistribution#response_code}
        */
        readonly responseCode?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#response_page_path TfDistribution#response_page_path}
        */
        readonly responsePagePath?: string;
    }
    class CustomErrorResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomErrorResponseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomErrorResponseProperty | cdktn.IResolvable | undefined);
        private _errorCachingMinTtl?;
        get errorCachingMinTtl(): number;
        set errorCachingMinTtl(value: number);
        resetErrorCachingMinTtl(): void;
        get errorCachingMinTtlInput(): number | undefined;
        private _errorCode?;
        get errorCode(): number;
        set errorCode(value: number);
        get errorCodeInput(): number | undefined;
        private _responseCode?;
        get responseCode(): number;
        set responseCode(value: number);
        resetResponseCode(): void;
        get responseCodeInput(): number | undefined;
        private _responsePagePath?;
        get responsePagePath(): string;
        set responsePagePath(value: string);
        resetResponsePagePath(): void;
        get responsePagePathInput(): string | undefined;
    }
    class CustomErrorResponsePropertyList extends cdktn.ComplexList {
        internalValue?: CustomErrorResponseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomErrorResponsePropertyOutputReference;
    }
    interface DefaultCacheBehaviorForwardedValuesCookiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#forward TfDistribution#forward}
        */
        readonly forward: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#whitelisted_names TfDistribution#whitelisted_names}
        */
        readonly whitelistedNames?: string[];
    }
    class DefaultCacheBehaviorForwardedValuesCookiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultCacheBehaviorForwardedValuesCookiesProperty | undefined;
        set internalValue(value: DefaultCacheBehaviorForwardedValuesCookiesProperty | undefined);
        private _forward?;
        get forward(): string;
        set forward(value: string);
        get forwardInput(): string | undefined;
        private _whitelistedNames?;
        get whitelistedNames(): string[];
        set whitelistedNames(value: string[]);
        resetWhitelistedNames(): void;
        get whitelistedNamesInput(): string[] | undefined;
    }
    interface DefaultCacheBehaviorForwardedValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#headers TfDistribution#headers}
        */
        readonly headers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#query_string TfDistribution#query_string}
        */
        readonly queryString: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#query_string_cache_keys TfDistribution#query_string_cache_keys}
        */
        readonly queryStringCacheKeys?: string[];
        /**
        * cookies block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cookies TfDistribution#cookies}
        */
        readonly cookies: DefaultCacheBehaviorForwardedValuesCookiesProperty;
    }
    class DefaultCacheBehaviorForwardedValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultCacheBehaviorForwardedValuesProperty | undefined;
        set internalValue(value: DefaultCacheBehaviorForwardedValuesProperty | undefined);
        private _headers?;
        get headers(): string[];
        set headers(value: string[]);
        resetHeaders(): void;
        get headersInput(): string[] | undefined;
        private _queryString?;
        get queryString(): boolean | cdktn.IResolvable;
        set queryString(value: boolean | cdktn.IResolvable);
        get queryStringInput(): boolean | cdktn.IResolvable | undefined;
        private _queryStringCacheKeys?;
        get queryStringCacheKeys(): string[];
        set queryStringCacheKeys(value: string[]);
        resetQueryStringCacheKeys(): void;
        get queryStringCacheKeysInput(): string[] | undefined;
        private _cookies;
        get cookies(): DefaultCacheBehaviorForwardedValuesCookiesPropertyOutputReference;
        putCookies(value: DefaultCacheBehaviorForwardedValuesCookiesProperty): void;
        get cookiesInput(): DefaultCacheBehaviorForwardedValuesCookiesProperty | undefined;
    }
    interface DefaultCacheBehaviorFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#event_type TfDistribution#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#function_arn TfDistribution#function_arn}
        */
        readonly functionArn: string;
    }
    class DefaultCacheBehaviorFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable | undefined);
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
    }
    class DefaultCacheBehaviorFunctionAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultCacheBehaviorFunctionAssociationPropertyOutputReference;
    }
    interface DefaultCacheBehaviorGrpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#enabled TfDistribution#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class DefaultCacheBehaviorGrpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultCacheBehaviorGrpcConfigProperty | undefined;
        set internalValue(value: DefaultCacheBehaviorGrpcConfigProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DefaultCacheBehaviorLambdaFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#event_type TfDistribution#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#include_body TfDistribution#include_body}
        */
        readonly includeBody?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#lambda_arn TfDistribution#lambda_arn}
        */
        readonly lambdaArn: string;
    }
    class DefaultCacheBehaviorLambdaFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable | undefined);
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _includeBody?;
        get includeBody(): boolean | cdktn.IResolvable;
        set includeBody(value: boolean | cdktn.IResolvable);
        resetIncludeBody(): void;
        get includeBodyInput(): boolean | cdktn.IResolvable | undefined;
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
    }
    class DefaultCacheBehaviorLambdaFunctionAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultCacheBehaviorLambdaFunctionAssociationPropertyOutputReference;
    }
    interface DefaultCacheBehaviorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#allowed_methods TfDistribution#allowed_methods}
        */
        readonly allowedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cache_policy_id TfDistribution#cache_policy_id}
        */
        readonly cachePolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cached_methods TfDistribution#cached_methods}
        */
        readonly cachedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#compress TfDistribution#compress}
        */
        readonly compress?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#default_ttl TfDistribution#default_ttl}
        */
        readonly defaultTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#field_level_encryption_id TfDistribution#field_level_encryption_id}
        */
        readonly fieldLevelEncryptionId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#max_ttl TfDistribution#max_ttl}
        */
        readonly maxTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#min_ttl TfDistribution#min_ttl}
        */
        readonly minTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_request_policy_id TfDistribution#origin_request_policy_id}
        */
        readonly originRequestPolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#realtime_log_config_arn TfDistribution#realtime_log_config_arn}
        */
        readonly realtimeLogConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#response_headers_policy_id TfDistribution#response_headers_policy_id}
        */
        readonly responseHeadersPolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#smooth_streaming TfDistribution#smooth_streaming}
        */
        readonly smoothStreaming?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#target_origin_id TfDistribution#target_origin_id}
        */
        readonly targetOriginId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trusted_key_groups TfDistribution#trusted_key_groups}
        */
        readonly trustedKeyGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trusted_signers TfDistribution#trusted_signers}
        */
        readonly trustedSigners?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#viewer_protocol_policy TfDistribution#viewer_protocol_policy}
        */
        readonly viewerProtocolPolicy: string;
        /**
        * forwarded_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#forwarded_values TfDistribution#forwarded_values}
        */
        readonly forwardedValues?: DefaultCacheBehaviorForwardedValuesProperty;
        /**
        * function_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#function_association TfDistribution#function_association}
        */
        readonly functionAssociation?: DefaultCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * grpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#grpc_config TfDistribution#grpc_config}
        */
        readonly grpcConfig?: DefaultCacheBehaviorGrpcConfigProperty;
        /**
        * lambda_function_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#lambda_function_association TfDistribution#lambda_function_association}
        */
        readonly lambdaFunctionAssociation?: DefaultCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable;
    }
    class DefaultCacheBehaviorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultCacheBehaviorProperty | undefined;
        set internalValue(value: DefaultCacheBehaviorProperty | undefined);
        private _allowedMethods?;
        get allowedMethods(): string[];
        set allowedMethods(value: string[]);
        get allowedMethodsInput(): string[] | undefined;
        private _cachePolicyId?;
        get cachePolicyId(): string;
        set cachePolicyId(value: string);
        resetCachePolicyId(): void;
        get cachePolicyIdInput(): string | undefined;
        private _cachedMethods?;
        get cachedMethods(): string[];
        set cachedMethods(value: string[]);
        get cachedMethodsInput(): string[] | undefined;
        private _compress?;
        get compress(): boolean | cdktn.IResolvable;
        set compress(value: boolean | cdktn.IResolvable);
        resetCompress(): void;
        get compressInput(): boolean | cdktn.IResolvable | undefined;
        private _defaultTtl?;
        get defaultTtl(): number;
        set defaultTtl(value: number);
        resetDefaultTtl(): void;
        get defaultTtlInput(): number | undefined;
        private _fieldLevelEncryptionId?;
        get fieldLevelEncryptionId(): string;
        set fieldLevelEncryptionId(value: string);
        resetFieldLevelEncryptionId(): void;
        get fieldLevelEncryptionIdInput(): string | undefined;
        private _maxTtl?;
        get maxTtl(): number;
        set maxTtl(value: number);
        resetMaxTtl(): void;
        get maxTtlInput(): number | undefined;
        private _minTtl?;
        get minTtl(): number;
        set minTtl(value: number);
        resetMinTtl(): void;
        get minTtlInput(): number | undefined;
        private _originRequestPolicyId?;
        get originRequestPolicyId(): string;
        set originRequestPolicyId(value: string);
        resetOriginRequestPolicyId(): void;
        get originRequestPolicyIdInput(): string | undefined;
        private _realtimeLogConfigArn?;
        get realtimeLogConfigArn(): string;
        set realtimeLogConfigArn(value: string);
        resetRealtimeLogConfigArn(): void;
        get realtimeLogConfigArnInput(): string | undefined;
        private _responseHeadersPolicyId?;
        get responseHeadersPolicyId(): string;
        set responseHeadersPolicyId(value: string);
        resetResponseHeadersPolicyId(): void;
        get responseHeadersPolicyIdInput(): string | undefined;
        private _smoothStreaming?;
        get smoothStreaming(): boolean | cdktn.IResolvable;
        set smoothStreaming(value: boolean | cdktn.IResolvable);
        resetSmoothStreaming(): void;
        get smoothStreamingInput(): boolean | cdktn.IResolvable | undefined;
        private _targetOriginId?;
        get targetOriginId(): string;
        set targetOriginId(value: string);
        get targetOriginIdInput(): string | undefined;
        private _trustedKeyGroups?;
        get trustedKeyGroups(): string[];
        set trustedKeyGroups(value: string[]);
        resetTrustedKeyGroups(): void;
        get trustedKeyGroupsInput(): string[] | undefined;
        private _trustedSigners?;
        get trustedSigners(): string[];
        set trustedSigners(value: string[]);
        resetTrustedSigners(): void;
        get trustedSignersInput(): string[] | undefined;
        private _viewerProtocolPolicy?;
        get viewerProtocolPolicy(): string;
        set viewerProtocolPolicy(value: string);
        get viewerProtocolPolicyInput(): string | undefined;
        private _forwardedValues;
        get forwardedValues(): DefaultCacheBehaviorForwardedValuesPropertyOutputReference;
        putForwardedValues(value: DefaultCacheBehaviorForwardedValuesProperty): void;
        resetForwardedValues(): void;
        get forwardedValuesInput(): DefaultCacheBehaviorForwardedValuesProperty | undefined;
        private _functionAssociation;
        get functionAssociation(): DefaultCacheBehaviorFunctionAssociationPropertyList;
        putFunctionAssociation(value: DefaultCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable): void;
        resetFunctionAssociation(): void;
        get functionAssociationInput(): cdktn.IResolvable | DefaultCacheBehaviorFunctionAssociationProperty[] | undefined;
        private _grpcConfig;
        get grpcConfig(): DefaultCacheBehaviorGrpcConfigPropertyOutputReference;
        putGrpcConfig(value: DefaultCacheBehaviorGrpcConfigProperty): void;
        resetGrpcConfig(): void;
        get grpcConfigInput(): DefaultCacheBehaviorGrpcConfigProperty | undefined;
        private _lambdaFunctionAssociation;
        get lambdaFunctionAssociation(): DefaultCacheBehaviorLambdaFunctionAssociationPropertyList;
        putLambdaFunctionAssociation(value: DefaultCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable): void;
        resetLambdaFunctionAssociation(): void;
        get lambdaFunctionAssociationInput(): cdktn.IResolvable | DefaultCacheBehaviorLambdaFunctionAssociationProperty[] | undefined;
    }
    interface LoggingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#bucket TfDistribution#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#include_cookies TfDistribution#include_cookies}
        */
        readonly includeCookies?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#prefix TfDistribution#prefix}
        */
        readonly prefix?: string;
    }
    class LoggingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingConfigProperty | undefined;
        set internalValue(value: LoggingConfigProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _includeCookies?;
        get includeCookies(): boolean | cdktn.IResolvable;
        set includeCookies(value: boolean | cdktn.IResolvable);
        resetIncludeCookies(): void;
        get includeCookiesInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface OrderedCacheBehaviorForwardedValuesCookiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#forward TfDistribution#forward}
        */
        readonly forward: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#whitelisted_names TfDistribution#whitelisted_names}
        */
        readonly whitelistedNames?: string[];
    }
    class OrderedCacheBehaviorForwardedValuesCookiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OrderedCacheBehaviorForwardedValuesCookiesProperty | undefined;
        set internalValue(value: OrderedCacheBehaviorForwardedValuesCookiesProperty | undefined);
        private _forward?;
        get forward(): string;
        set forward(value: string);
        get forwardInput(): string | undefined;
        private _whitelistedNames?;
        get whitelistedNames(): string[];
        set whitelistedNames(value: string[]);
        resetWhitelistedNames(): void;
        get whitelistedNamesInput(): string[] | undefined;
    }
    interface OrderedCacheBehaviorForwardedValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#headers TfDistribution#headers}
        */
        readonly headers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#query_string TfDistribution#query_string}
        */
        readonly queryString: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#query_string_cache_keys TfDistribution#query_string_cache_keys}
        */
        readonly queryStringCacheKeys?: string[];
        /**
        * cookies block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cookies TfDistribution#cookies}
        */
        readonly cookies: OrderedCacheBehaviorForwardedValuesCookiesProperty;
    }
    class OrderedCacheBehaviorForwardedValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OrderedCacheBehaviorForwardedValuesProperty | undefined;
        set internalValue(value: OrderedCacheBehaviorForwardedValuesProperty | undefined);
        private _headers?;
        get headers(): string[];
        set headers(value: string[]);
        resetHeaders(): void;
        get headersInput(): string[] | undefined;
        private _queryString?;
        get queryString(): boolean | cdktn.IResolvable;
        set queryString(value: boolean | cdktn.IResolvable);
        get queryStringInput(): boolean | cdktn.IResolvable | undefined;
        private _queryStringCacheKeys?;
        get queryStringCacheKeys(): string[];
        set queryStringCacheKeys(value: string[]);
        resetQueryStringCacheKeys(): void;
        get queryStringCacheKeysInput(): string[] | undefined;
        private _cookies;
        get cookies(): OrderedCacheBehaviorForwardedValuesCookiesPropertyOutputReference;
        putCookies(value: OrderedCacheBehaviorForwardedValuesCookiesProperty): void;
        get cookiesInput(): OrderedCacheBehaviorForwardedValuesCookiesProperty | undefined;
    }
    interface OrderedCacheBehaviorFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#event_type TfDistribution#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#function_arn TfDistribution#function_arn}
        */
        readonly functionArn: string;
    }
    class OrderedCacheBehaviorFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrderedCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrderedCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable | undefined);
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
    }
    class OrderedCacheBehaviorFunctionAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: OrderedCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrderedCacheBehaviorFunctionAssociationPropertyOutputReference;
    }
    interface OrderedCacheBehaviorGrpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#enabled TfDistribution#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class OrderedCacheBehaviorGrpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OrderedCacheBehaviorGrpcConfigProperty | undefined;
        set internalValue(value: OrderedCacheBehaviorGrpcConfigProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface OrderedCacheBehaviorLambdaFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#event_type TfDistribution#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#include_body TfDistribution#include_body}
        */
        readonly includeBody?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#lambda_arn TfDistribution#lambda_arn}
        */
        readonly lambdaArn: string;
    }
    class OrderedCacheBehaviorLambdaFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrderedCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrderedCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable | undefined);
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _includeBody?;
        get includeBody(): boolean | cdktn.IResolvable;
        set includeBody(value: boolean | cdktn.IResolvable);
        resetIncludeBody(): void;
        get includeBodyInput(): boolean | cdktn.IResolvable | undefined;
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
    }
    class OrderedCacheBehaviorLambdaFunctionAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: OrderedCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrderedCacheBehaviorLambdaFunctionAssociationPropertyOutputReference;
    }
    interface OrderedCacheBehaviorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#allowed_methods TfDistribution#allowed_methods}
        */
        readonly allowedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cache_policy_id TfDistribution#cache_policy_id}
        */
        readonly cachePolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cached_methods TfDistribution#cached_methods}
        */
        readonly cachedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#compress TfDistribution#compress}
        */
        readonly compress?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#default_ttl TfDistribution#default_ttl}
        */
        readonly defaultTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#field_level_encryption_id TfDistribution#field_level_encryption_id}
        */
        readonly fieldLevelEncryptionId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#max_ttl TfDistribution#max_ttl}
        */
        readonly maxTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#min_ttl TfDistribution#min_ttl}
        */
        readonly minTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_request_policy_id TfDistribution#origin_request_policy_id}
        */
        readonly originRequestPolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#path_pattern TfDistribution#path_pattern}
        */
        readonly pathPattern: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#realtime_log_config_arn TfDistribution#realtime_log_config_arn}
        */
        readonly realtimeLogConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#response_headers_policy_id TfDistribution#response_headers_policy_id}
        */
        readonly responseHeadersPolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#smooth_streaming TfDistribution#smooth_streaming}
        */
        readonly smoothStreaming?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#target_origin_id TfDistribution#target_origin_id}
        */
        readonly targetOriginId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trusted_key_groups TfDistribution#trusted_key_groups}
        */
        readonly trustedKeyGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trusted_signers TfDistribution#trusted_signers}
        */
        readonly trustedSigners?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#viewer_protocol_policy TfDistribution#viewer_protocol_policy}
        */
        readonly viewerProtocolPolicy: string;
        /**
        * forwarded_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#forwarded_values TfDistribution#forwarded_values}
        */
        readonly forwardedValues?: OrderedCacheBehaviorForwardedValuesProperty;
        /**
        * function_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#function_association TfDistribution#function_association}
        */
        readonly functionAssociation?: OrderedCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * grpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#grpc_config TfDistribution#grpc_config}
        */
        readonly grpcConfig?: OrderedCacheBehaviorGrpcConfigProperty;
        /**
        * lambda_function_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#lambda_function_association TfDistribution#lambda_function_association}
        */
        readonly lambdaFunctionAssociation?: OrderedCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable;
    }
    class OrderedCacheBehaviorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrderedCacheBehaviorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrderedCacheBehaviorProperty | cdktn.IResolvable | undefined);
        private _allowedMethods?;
        get allowedMethods(): string[];
        set allowedMethods(value: string[]);
        get allowedMethodsInput(): string[] | undefined;
        private _cachePolicyId?;
        get cachePolicyId(): string;
        set cachePolicyId(value: string);
        resetCachePolicyId(): void;
        get cachePolicyIdInput(): string | undefined;
        private _cachedMethods?;
        get cachedMethods(): string[];
        set cachedMethods(value: string[]);
        get cachedMethodsInput(): string[] | undefined;
        private _compress?;
        get compress(): boolean | cdktn.IResolvable;
        set compress(value: boolean | cdktn.IResolvable);
        resetCompress(): void;
        get compressInput(): boolean | cdktn.IResolvable | undefined;
        private _defaultTtl?;
        get defaultTtl(): number;
        set defaultTtl(value: number);
        resetDefaultTtl(): void;
        get defaultTtlInput(): number | undefined;
        private _fieldLevelEncryptionId?;
        get fieldLevelEncryptionId(): string;
        set fieldLevelEncryptionId(value: string);
        resetFieldLevelEncryptionId(): void;
        get fieldLevelEncryptionIdInput(): string | undefined;
        private _maxTtl?;
        get maxTtl(): number;
        set maxTtl(value: number);
        resetMaxTtl(): void;
        get maxTtlInput(): number | undefined;
        private _minTtl?;
        get minTtl(): number;
        set minTtl(value: number);
        resetMinTtl(): void;
        get minTtlInput(): number | undefined;
        private _originRequestPolicyId?;
        get originRequestPolicyId(): string;
        set originRequestPolicyId(value: string);
        resetOriginRequestPolicyId(): void;
        get originRequestPolicyIdInput(): string | undefined;
        private _pathPattern?;
        get pathPattern(): string;
        set pathPattern(value: string);
        get pathPatternInput(): string | undefined;
        private _realtimeLogConfigArn?;
        get realtimeLogConfigArn(): string;
        set realtimeLogConfigArn(value: string);
        resetRealtimeLogConfigArn(): void;
        get realtimeLogConfigArnInput(): string | undefined;
        private _responseHeadersPolicyId?;
        get responseHeadersPolicyId(): string;
        set responseHeadersPolicyId(value: string);
        resetResponseHeadersPolicyId(): void;
        get responseHeadersPolicyIdInput(): string | undefined;
        private _smoothStreaming?;
        get smoothStreaming(): boolean | cdktn.IResolvable;
        set smoothStreaming(value: boolean | cdktn.IResolvable);
        resetSmoothStreaming(): void;
        get smoothStreamingInput(): boolean | cdktn.IResolvable | undefined;
        private _targetOriginId?;
        get targetOriginId(): string;
        set targetOriginId(value: string);
        get targetOriginIdInput(): string | undefined;
        private _trustedKeyGroups?;
        get trustedKeyGroups(): string[];
        set trustedKeyGroups(value: string[]);
        resetTrustedKeyGroups(): void;
        get trustedKeyGroupsInput(): string[] | undefined;
        private _trustedSigners?;
        get trustedSigners(): string[];
        set trustedSigners(value: string[]);
        resetTrustedSigners(): void;
        get trustedSignersInput(): string[] | undefined;
        private _viewerProtocolPolicy?;
        get viewerProtocolPolicy(): string;
        set viewerProtocolPolicy(value: string);
        get viewerProtocolPolicyInput(): string | undefined;
        private _forwardedValues;
        get forwardedValues(): OrderedCacheBehaviorForwardedValuesPropertyOutputReference;
        putForwardedValues(value: OrderedCacheBehaviorForwardedValuesProperty): void;
        resetForwardedValues(): void;
        get forwardedValuesInput(): OrderedCacheBehaviorForwardedValuesProperty | undefined;
        private _functionAssociation;
        get functionAssociation(): OrderedCacheBehaviorFunctionAssociationPropertyList;
        putFunctionAssociation(value: OrderedCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable): void;
        resetFunctionAssociation(): void;
        get functionAssociationInput(): cdktn.IResolvable | OrderedCacheBehaviorFunctionAssociationProperty[] | undefined;
        private _grpcConfig;
        get grpcConfig(): OrderedCacheBehaviorGrpcConfigPropertyOutputReference;
        putGrpcConfig(value: OrderedCacheBehaviorGrpcConfigProperty): void;
        resetGrpcConfig(): void;
        get grpcConfigInput(): OrderedCacheBehaviorGrpcConfigProperty | undefined;
        private _lambdaFunctionAssociation;
        get lambdaFunctionAssociation(): OrderedCacheBehaviorLambdaFunctionAssociationPropertyList;
        putLambdaFunctionAssociation(value: OrderedCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable): void;
        resetLambdaFunctionAssociation(): void;
        get lambdaFunctionAssociationInput(): cdktn.IResolvable | OrderedCacheBehaviorLambdaFunctionAssociationProperty[] | undefined;
    }
    class OrderedCacheBehaviorPropertyList extends cdktn.ComplexList {
        internalValue?: OrderedCacheBehaviorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrderedCacheBehaviorPropertyOutputReference;
    }
    interface CustomHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#name TfDistribution#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#value TfDistribution#value}
        */
        readonly value: string;
    }
    class CustomHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class CustomHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: CustomHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomHeaderPropertyOutputReference;
    }
    interface OriginMtlsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#client_certificate_arn TfDistribution#client_certificate_arn}
        */
        readonly clientCertificateArn: string;
    }
    class OriginMtlsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OriginMtlsConfigProperty | undefined;
        set internalValue(value: OriginMtlsConfigProperty | undefined);
        private _clientCertificateArn?;
        get clientCertificateArn(): string;
        set clientCertificateArn(value: string);
        get clientCertificateArnInput(): string | undefined;
    }
    interface CustomOriginConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#http_port TfDistribution#http_port}
        */
        readonly httpPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#https_port TfDistribution#https_port}
        */
        readonly httpsPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#ip_address_type TfDistribution#ip_address_type}
        */
        readonly ipAddressType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_keepalive_timeout TfDistribution#origin_keepalive_timeout}
        */
        readonly originKeepaliveTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_protocol_policy TfDistribution#origin_protocol_policy}
        */
        readonly originProtocolPolicy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_read_timeout TfDistribution#origin_read_timeout}
        */
        readonly originReadTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_ssl_protocols TfDistribution#origin_ssl_protocols}
        */
        readonly originSslProtocols: string[];
        /**
        * origin_mtls_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_mtls_config TfDistribution#origin_mtls_config}
        */
        readonly originMtlsConfig?: OriginMtlsConfigProperty;
    }
    class CustomOriginConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomOriginConfigProperty | undefined;
        set internalValue(value: CustomOriginConfigProperty | undefined);
        private _httpPort?;
        get httpPort(): number;
        set httpPort(value: number);
        get httpPortInput(): number | undefined;
        private _httpsPort?;
        get httpsPort(): number;
        set httpsPort(value: number);
        get httpsPortInput(): number | undefined;
        private _ipAddressType?;
        get ipAddressType(): string;
        set ipAddressType(value: string);
        resetIpAddressType(): void;
        get ipAddressTypeInput(): string | undefined;
        private _originKeepaliveTimeout?;
        get originKeepaliveTimeout(): number;
        set originKeepaliveTimeout(value: number);
        resetOriginKeepaliveTimeout(): void;
        get originKeepaliveTimeoutInput(): number | undefined;
        private _originProtocolPolicy?;
        get originProtocolPolicy(): string;
        set originProtocolPolicy(value: string);
        get originProtocolPolicyInput(): string | undefined;
        private _originReadTimeout?;
        get originReadTimeout(): number;
        set originReadTimeout(value: number);
        resetOriginReadTimeout(): void;
        get originReadTimeoutInput(): number | undefined;
        private _originSslProtocols?;
        get originSslProtocols(): string[];
        set originSslProtocols(value: string[]);
        get originSslProtocolsInput(): string[] | undefined;
        private _originMtlsConfig;
        get originMtlsConfig(): OriginMtlsConfigPropertyOutputReference;
        putOriginMtlsConfig(value: OriginMtlsConfigProperty): void;
        resetOriginMtlsConfig(): void;
        get originMtlsConfigInput(): OriginMtlsConfigProperty | undefined;
    }
    interface OriginShieldProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#enabled TfDistribution#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_shield_region TfDistribution#origin_shield_region}
        */
        readonly originShieldRegion?: string;
    }
    class OriginShieldPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OriginShieldProperty | undefined;
        set internalValue(value: OriginShieldProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _originShieldRegion?;
        get originShieldRegion(): string;
        set originShieldRegion(value: string);
        resetOriginShieldRegion(): void;
        get originShieldRegionInput(): string | undefined;
    }
    interface S3OriginConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_access_identity TfDistribution#origin_access_identity}
        */
        readonly originAccessIdentity: string;
    }
    class S3OriginConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3OriginConfigProperty | undefined;
        set internalValue(value: S3OriginConfigProperty | undefined);
        private _originAccessIdentity?;
        get originAccessIdentity(): string;
        set originAccessIdentity(value: string);
        get originAccessIdentityInput(): string | undefined;
    }
    interface VpcOriginConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_keepalive_timeout TfDistribution#origin_keepalive_timeout}
        */
        readonly originKeepaliveTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_read_timeout TfDistribution#origin_read_timeout}
        */
        readonly originReadTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#owner_account_id TfDistribution#owner_account_id}
        */
        readonly ownerAccountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#vpc_origin_id TfDistribution#vpc_origin_id}
        */
        readonly vpcOriginId: string;
    }
    class VpcOriginConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcOriginConfigProperty | undefined;
        set internalValue(value: VpcOriginConfigProperty | undefined);
        private _originKeepaliveTimeout?;
        get originKeepaliveTimeout(): number;
        set originKeepaliveTimeout(value: number);
        resetOriginKeepaliveTimeout(): void;
        get originKeepaliveTimeoutInput(): number | undefined;
        private _originReadTimeout?;
        get originReadTimeout(): number;
        set originReadTimeout(value: number);
        resetOriginReadTimeout(): void;
        get originReadTimeoutInput(): number | undefined;
        private _ownerAccountId?;
        get ownerAccountId(): string;
        set ownerAccountId(value: string);
        resetOwnerAccountId(): void;
        get ownerAccountIdInput(): string | undefined;
        private _vpcOriginId?;
        get vpcOriginId(): string;
        set vpcOriginId(value: string);
        get vpcOriginIdInput(): string | undefined;
    }
    interface OriginProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#connection_attempts TfDistribution#connection_attempts}
        */
        readonly connectionAttempts?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#connection_timeout TfDistribution#connection_timeout}
        */
        readonly connectionTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#domain_name TfDistribution#domain_name}
        */
        readonly domainName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_access_control_id TfDistribution#origin_access_control_id}
        */
        readonly originAccessControlId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_id TfDistribution#origin_id}
        */
        readonly originId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_path TfDistribution#origin_path}
        */
        readonly originPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#response_completion_timeout TfDistribution#response_completion_timeout}
        */
        readonly responseCompletionTimeout?: number;
        /**
        * custom_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#custom_header TfDistribution#custom_header}
        */
        readonly customHeader?: CustomHeaderProperty[] | cdktn.IResolvable;
        /**
        * custom_origin_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#custom_origin_config TfDistribution#custom_origin_config}
        */
        readonly customOriginConfig?: CustomOriginConfigProperty;
        /**
        * origin_shield block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_shield TfDistribution#origin_shield}
        */
        readonly originShield?: OriginShieldProperty;
        /**
        * s3_origin_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#s3_origin_config TfDistribution#s3_origin_config}
        */
        readonly s3OriginConfig?: S3OriginConfigProperty;
        /**
        * vpc_origin_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#vpc_origin_config TfDistribution#vpc_origin_config}
        */
        readonly vpcOriginConfig?: VpcOriginConfigProperty;
    }
    class OriginPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OriginProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OriginProperty | cdktn.IResolvable | undefined);
        private _connectionAttempts?;
        get connectionAttempts(): number;
        set connectionAttempts(value: number);
        resetConnectionAttempts(): void;
        get connectionAttemptsInput(): number | undefined;
        private _connectionTimeout?;
        get connectionTimeout(): number;
        set connectionTimeout(value: number);
        resetConnectionTimeout(): void;
        get connectionTimeoutInput(): number | undefined;
        private _domainName?;
        get domainName(): string;
        set domainName(value: string);
        get domainNameInput(): string | undefined;
        private _originAccessControlId?;
        get originAccessControlId(): string;
        set originAccessControlId(value: string);
        resetOriginAccessControlId(): void;
        get originAccessControlIdInput(): string | undefined;
        private _originId?;
        get originId(): string;
        set originId(value: string);
        get originIdInput(): string | undefined;
        private _originPath?;
        get originPath(): string;
        set originPath(value: string);
        resetOriginPath(): void;
        get originPathInput(): string | undefined;
        private _responseCompletionTimeout?;
        get responseCompletionTimeout(): number;
        set responseCompletionTimeout(value: number);
        resetResponseCompletionTimeout(): void;
        get responseCompletionTimeoutInput(): number | undefined;
        private _customHeader;
        get customHeader(): CustomHeaderPropertyList;
        putCustomHeader(value: CustomHeaderProperty[] | cdktn.IResolvable): void;
        resetCustomHeader(): void;
        get customHeaderInput(): cdktn.IResolvable | CustomHeaderProperty[] | undefined;
        private _customOriginConfig;
        get customOriginConfig(): CustomOriginConfigPropertyOutputReference;
        putCustomOriginConfig(value: CustomOriginConfigProperty): void;
        resetCustomOriginConfig(): void;
        get customOriginConfigInput(): CustomOriginConfigProperty | undefined;
        private _originShield;
        get originShield(): OriginShieldPropertyOutputReference;
        putOriginShield(value: OriginShieldProperty): void;
        resetOriginShield(): void;
        get originShieldInput(): OriginShieldProperty | undefined;
        private _s3OriginConfig;
        get s3OriginConfig(): S3OriginConfigPropertyOutputReference;
        putS3OriginConfig(value: S3OriginConfigProperty): void;
        resetS3OriginConfig(): void;
        get s3OriginConfigInput(): S3OriginConfigProperty | undefined;
        private _vpcOriginConfig;
        get vpcOriginConfig(): VpcOriginConfigPropertyOutputReference;
        putVpcOriginConfig(value: VpcOriginConfigProperty): void;
        resetVpcOriginConfig(): void;
        get vpcOriginConfigInput(): VpcOriginConfigProperty | undefined;
    }
    class OriginPropertyList extends cdktn.ComplexList {
        internalValue?: OriginProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OriginPropertyOutputReference;
    }
    interface FailoverCriteriaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#status_codes TfDistribution#status_codes}
        */
        readonly statusCodes: number[];
    }
    class FailoverCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FailoverCriteriaProperty | undefined;
        set internalValue(value: FailoverCriteriaProperty | undefined);
        private _statusCodes?;
        get statusCodes(): number[];
        set statusCodes(value: number[]);
        get statusCodesInput(): number[] | undefined;
    }
    interface MemberProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_id TfDistribution#origin_id}
        */
        readonly originId: string;
    }
    class MemberPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemberProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MemberProperty | cdktn.IResolvable | undefined);
        private _originId?;
        get originId(): string;
        set originId(value: string);
        get originIdInput(): string | undefined;
    }
    class MemberPropertyList extends cdktn.ComplexList {
        internalValue?: MemberProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemberPropertyOutputReference;
    }
    interface OriginGroupProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_id TfDistribution#origin_id}
        */
        readonly originId: string;
        /**
        * failover_criteria block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#failover_criteria TfDistribution#failover_criteria}
        */
        readonly failoverCriteria: FailoverCriteriaProperty;
        /**
        * member block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#member TfDistribution#member}
        */
        readonly member: MemberProperty[] | cdktn.IResolvable;
    }
    class OriginGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OriginGroupProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OriginGroupProperty | cdktn.IResolvable | undefined);
        private _originId?;
        get originId(): string;
        set originId(value: string);
        get originIdInput(): string | undefined;
        private _failoverCriteria;
        get failoverCriteria(): FailoverCriteriaPropertyOutputReference;
        putFailoverCriteria(value: FailoverCriteriaProperty): void;
        get failoverCriteriaInput(): FailoverCriteriaProperty | undefined;
        private _member;
        get member(): MemberPropertyList;
        putMember(value: MemberProperty[] | cdktn.IResolvable): void;
        get memberInput(): cdktn.IResolvable | MemberProperty[] | undefined;
    }
    class OriginGroupPropertyList extends cdktn.ComplexList {
        internalValue?: OriginGroupProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OriginGroupPropertyOutputReference;
    }
    interface GeoRestrictionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#locations TfDistribution#locations}
        */
        readonly locations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#restriction_type TfDistribution#restriction_type}
        */
        readonly restrictionType: string;
    }
    class GeoRestrictionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GeoRestrictionProperty | undefined;
        set internalValue(value: GeoRestrictionProperty | undefined);
        private _locations?;
        get locations(): string[];
        set locations(value: string[]);
        resetLocations(): void;
        get locationsInput(): string[] | undefined;
        private _restrictionType?;
        get restrictionType(): string;
        set restrictionType(value: string);
        get restrictionTypeInput(): string | undefined;
    }
    interface RestrictionsProperty {
        /**
        * geo_restriction block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#geo_restriction TfDistribution#geo_restriction}
        */
        readonly geoRestriction: GeoRestrictionProperty;
    }
    class RestrictionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RestrictionsProperty | undefined;
        set internalValue(value: RestrictionsProperty | undefined);
        private _geoRestriction;
        get geoRestriction(): GeoRestrictionPropertyOutputReference;
        putGeoRestriction(value: GeoRestrictionProperty): void;
        get geoRestrictionInput(): GeoRestrictionProperty | undefined;
    }
    interface ViewerCertificateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#acm_certificate_arn TfDistribution#acm_certificate_arn}
        */
        readonly acmCertificateArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cloudfront_default_certificate TfDistribution#cloudfront_default_certificate}
        */
        readonly cloudfrontDefaultCertificate?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#iam_certificate_id TfDistribution#iam_certificate_id}
        */
        readonly iamCertificateId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#minimum_protocol_version TfDistribution#minimum_protocol_version}
        */
        readonly minimumProtocolVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#ssl_support_method TfDistribution#ssl_support_method}
        */
        readonly sslSupportMethod?: string;
    }
    class ViewerCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ViewerCertificateProperty | undefined;
        set internalValue(value: ViewerCertificateProperty | undefined);
        private _acmCertificateArn?;
        get acmCertificateArn(): string;
        set acmCertificateArn(value: string);
        resetAcmCertificateArn(): void;
        get acmCertificateArnInput(): string | undefined;
        private _cloudfrontDefaultCertificate?;
        get cloudfrontDefaultCertificate(): boolean | cdktn.IResolvable;
        set cloudfrontDefaultCertificate(value: boolean | cdktn.IResolvable);
        resetCloudfrontDefaultCertificate(): void;
        get cloudfrontDefaultCertificateInput(): boolean | cdktn.IResolvable | undefined;
        private _iamCertificateId?;
        get iamCertificateId(): string;
        set iamCertificateId(value: string);
        resetIamCertificateId(): void;
        get iamCertificateIdInput(): string | undefined;
        private _minimumProtocolVersion?;
        get minimumProtocolVersion(): string;
        set minimumProtocolVersion(value: string);
        resetMinimumProtocolVersion(): void;
        get minimumProtocolVersionInput(): string | undefined;
        private _sslSupportMethod?;
        get sslSupportMethod(): string;
        set sslSupportMethod(value: string);
        resetSslSupportMethod(): void;
        get sslSupportMethodInput(): string | undefined;
    }
    interface TrustStoreConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#advertise_trust_store_ca_names TfDistribution#advertise_trust_store_ca_names}
        */
        readonly advertiseTrustStoreCaNames?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#ignore_certificate_expiry TfDistribution#ignore_certificate_expiry}
        */
        readonly ignoreCertificateExpiry?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trust_store_id TfDistribution#trust_store_id}
        */
        readonly trustStoreId: string;
    }
    class TrustStoreConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TrustStoreConfigProperty | undefined;
        set internalValue(value: TrustStoreConfigProperty | undefined);
        private _advertiseTrustStoreCaNames?;
        get advertiseTrustStoreCaNames(): boolean | cdktn.IResolvable;
        set advertiseTrustStoreCaNames(value: boolean | cdktn.IResolvable);
        resetAdvertiseTrustStoreCaNames(): void;
        get advertiseTrustStoreCaNamesInput(): boolean | cdktn.IResolvable | undefined;
        private _ignoreCertificateExpiry?;
        get ignoreCertificateExpiry(): boolean | cdktn.IResolvable;
        set ignoreCertificateExpiry(value: boolean | cdktn.IResolvable);
        resetIgnoreCertificateExpiry(): void;
        get ignoreCertificateExpiryInput(): boolean | cdktn.IResolvable | undefined;
        private _trustStoreId?;
        get trustStoreId(): string;
        set trustStoreId(value: string);
        get trustStoreIdInput(): string | undefined;
    }
    interface ViewerMtlsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#mode TfDistribution#mode}
        */
        readonly mode?: string;
        /**
        * trust_store_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trust_store_config TfDistribution#trust_store_config}
        */
        readonly trustStoreConfig?: TrustStoreConfigProperty;
    }
    class ViewerMtlsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ViewerMtlsConfigProperty | undefined;
        set internalValue(value: ViewerMtlsConfigProperty | undefined);
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
        private _trustStoreConfig;
        get trustStoreConfig(): TrustStoreConfigPropertyOutputReference;
        putTrustStoreConfig(value: TrustStoreConfigProperty): void;
        resetTrustStoreConfig(): void;
        get trustStoreConfigInput(): TrustStoreConfigProperty | undefined;
    }
}
