import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfResponseHeadersPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#comment TfResponseHeadersPolicy#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#id TfResponseHeadersPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#name TfResponseHeadersPolicy#name}
    */
    readonly name: string;
    /**
    * cors_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#cors_config TfResponseHeadersPolicy#cors_config}
    */
    readonly corsConfig?: TfResponseHeadersPolicy.CorsConfigProperty;
    /**
    * custom_headers_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#custom_headers_config TfResponseHeadersPolicy#custom_headers_config}
    */
    readonly customHeadersConfig?: TfResponseHeadersPolicy.CustomHeadersConfigProperty;
    /**
    * remove_headers_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#remove_headers_config TfResponseHeadersPolicy#remove_headers_config}
    */
    readonly removeHeadersConfig?: TfResponseHeadersPolicy.RemoveHeadersConfigProperty;
    /**
    * security_headers_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#security_headers_config TfResponseHeadersPolicy#security_headers_config}
    */
    readonly securityHeadersConfig?: TfResponseHeadersPolicy.SecurityHeadersConfigProperty;
    /**
    * server_timing_headers_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#server_timing_headers_config TfResponseHeadersPolicy#server_timing_headers_config}
    */
    readonly serverTimingHeadersConfig?: TfResponseHeadersPolicy.ServerTimingHeadersConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy aws_cloudfront_response_headers_policy}
*/
export declare class TfResponseHeadersPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_response_headers_policy";
    /**
    * Generates CDKTN code for importing a TfResponseHeadersPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfResponseHeadersPolicy to import
    * @param importFromId The id of the existing TfResponseHeadersPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfResponseHeadersPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy aws_cloudfront_response_headers_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfResponseHeadersPolicyConfig
    */
    constructor(scope: Construct, id: string, config: TfResponseHeadersPolicyConfig);
    get arn(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _corsConfig;
    get corsConfig(): TfResponseHeadersPolicy.CorsConfigPropertyOutputReference;
    putCorsConfig(value: TfResponseHeadersPolicy.CorsConfigProperty): void;
    resetCorsConfig(): void;
    get corsConfigInput(): TfResponseHeadersPolicy.CorsConfigProperty | undefined;
    private _customHeadersConfig;
    get customHeadersConfig(): TfResponseHeadersPolicy.CustomHeadersConfigPropertyOutputReference;
    putCustomHeadersConfig(value: TfResponseHeadersPolicy.CustomHeadersConfigProperty): void;
    resetCustomHeadersConfig(): void;
    get customHeadersConfigInput(): TfResponseHeadersPolicy.CustomHeadersConfigProperty | undefined;
    private _removeHeadersConfig;
    get removeHeadersConfig(): TfResponseHeadersPolicy.RemoveHeadersConfigPropertyOutputReference;
    putRemoveHeadersConfig(value: TfResponseHeadersPolicy.RemoveHeadersConfigProperty): void;
    resetRemoveHeadersConfig(): void;
    get removeHeadersConfigInput(): TfResponseHeadersPolicy.RemoveHeadersConfigProperty | undefined;
    private _securityHeadersConfig;
    get securityHeadersConfig(): TfResponseHeadersPolicy.SecurityHeadersConfigPropertyOutputReference;
    putSecurityHeadersConfig(value: TfResponseHeadersPolicy.SecurityHeadersConfigProperty): void;
    resetSecurityHeadersConfig(): void;
    get securityHeadersConfigInput(): TfResponseHeadersPolicy.SecurityHeadersConfigProperty | undefined;
    private _serverTimingHeadersConfig;
    get serverTimingHeadersConfig(): TfResponseHeadersPolicy.ServerTimingHeadersConfigPropertyOutputReference;
    putServerTimingHeadersConfig(value: TfResponseHeadersPolicy.ServerTimingHeadersConfigProperty): void;
    resetServerTimingHeadersConfig(): void;
    get serverTimingHeadersConfigInput(): TfResponseHeadersPolicy.ServerTimingHeadersConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfResponseHeadersPolicyAccessControlAllowHeadersPropertyToTerraform(struct?: TfResponseHeadersPolicy.AccessControlAllowHeadersPropertyOutputReference | TfResponseHeadersPolicy.AccessControlAllowHeadersProperty): any;
export declare function tfResponseHeadersPolicyAccessControlAllowHeadersPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.AccessControlAllowHeadersPropertyOutputReference | TfResponseHeadersPolicy.AccessControlAllowHeadersProperty): any;
export declare function tfResponseHeadersPolicyAccessControlAllowMethodsPropertyToTerraform(struct?: TfResponseHeadersPolicy.AccessControlAllowMethodsPropertyOutputReference | TfResponseHeadersPolicy.AccessControlAllowMethodsProperty): any;
export declare function tfResponseHeadersPolicyAccessControlAllowMethodsPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.AccessControlAllowMethodsPropertyOutputReference | TfResponseHeadersPolicy.AccessControlAllowMethodsProperty): any;
export declare function tfResponseHeadersPolicyAccessControlAllowOriginsPropertyToTerraform(struct?: TfResponseHeadersPolicy.AccessControlAllowOriginsPropertyOutputReference | TfResponseHeadersPolicy.AccessControlAllowOriginsProperty): any;
export declare function tfResponseHeadersPolicyAccessControlAllowOriginsPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.AccessControlAllowOriginsPropertyOutputReference | TfResponseHeadersPolicy.AccessControlAllowOriginsProperty): any;
export declare function tfResponseHeadersPolicyAccessControlExposeHeadersPropertyToTerraform(struct?: TfResponseHeadersPolicy.AccessControlExposeHeadersPropertyOutputReference | TfResponseHeadersPolicy.AccessControlExposeHeadersProperty): any;
export declare function tfResponseHeadersPolicyAccessControlExposeHeadersPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.AccessControlExposeHeadersPropertyOutputReference | TfResponseHeadersPolicy.AccessControlExposeHeadersProperty): any;
export declare function tfResponseHeadersPolicyCorsConfigPropertyToTerraform(struct?: TfResponseHeadersPolicy.CorsConfigPropertyOutputReference | TfResponseHeadersPolicy.CorsConfigProperty): any;
export declare function tfResponseHeadersPolicyCorsConfigPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.CorsConfigPropertyOutputReference | TfResponseHeadersPolicy.CorsConfigProperty): any;
export declare function tfResponseHeadersPolicyCustomHeadersConfigItemsPropertyToTerraform(struct?: TfResponseHeadersPolicy.CustomHeadersConfigItemsProperty | cdktn.IResolvable): any;
export declare function tfResponseHeadersPolicyCustomHeadersConfigItemsPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.CustomHeadersConfigItemsProperty | cdktn.IResolvable): any;
export declare function tfResponseHeadersPolicyCustomHeadersConfigPropertyToTerraform(struct?: TfResponseHeadersPolicy.CustomHeadersConfigPropertyOutputReference | TfResponseHeadersPolicy.CustomHeadersConfigProperty): any;
export declare function tfResponseHeadersPolicyCustomHeadersConfigPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.CustomHeadersConfigPropertyOutputReference | TfResponseHeadersPolicy.CustomHeadersConfigProperty): any;
export declare function tfResponseHeadersPolicyRemoveHeadersConfigItemsPropertyToTerraform(struct?: TfResponseHeadersPolicy.RemoveHeadersConfigItemsProperty | cdktn.IResolvable): any;
export declare function tfResponseHeadersPolicyRemoveHeadersConfigItemsPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.RemoveHeadersConfigItemsProperty | cdktn.IResolvable): any;
export declare function tfResponseHeadersPolicyRemoveHeadersConfigPropertyToTerraform(struct?: TfResponseHeadersPolicy.RemoveHeadersConfigPropertyOutputReference | TfResponseHeadersPolicy.RemoveHeadersConfigProperty): any;
export declare function tfResponseHeadersPolicyRemoveHeadersConfigPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.RemoveHeadersConfigPropertyOutputReference | TfResponseHeadersPolicy.RemoveHeadersConfigProperty): any;
export declare function tfResponseHeadersPolicyContentSecurityPolicyPropertyToTerraform(struct?: TfResponseHeadersPolicy.ContentSecurityPolicyPropertyOutputReference | TfResponseHeadersPolicy.ContentSecurityPolicyProperty): any;
export declare function tfResponseHeadersPolicyContentSecurityPolicyPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.ContentSecurityPolicyPropertyOutputReference | TfResponseHeadersPolicy.ContentSecurityPolicyProperty): any;
export declare function tfResponseHeadersPolicyContentTypeOptionsPropertyToTerraform(struct?: TfResponseHeadersPolicy.ContentTypeOptionsPropertyOutputReference | TfResponseHeadersPolicy.ContentTypeOptionsProperty): any;
export declare function tfResponseHeadersPolicyContentTypeOptionsPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.ContentTypeOptionsPropertyOutputReference | TfResponseHeadersPolicy.ContentTypeOptionsProperty): any;
export declare function tfResponseHeadersPolicyFrameOptionsPropertyToTerraform(struct?: TfResponseHeadersPolicy.FrameOptionsPropertyOutputReference | TfResponseHeadersPolicy.FrameOptionsProperty): any;
export declare function tfResponseHeadersPolicyFrameOptionsPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.FrameOptionsPropertyOutputReference | TfResponseHeadersPolicy.FrameOptionsProperty): any;
export declare function tfResponseHeadersPolicyReferrerPolicyPropertyToTerraform(struct?: TfResponseHeadersPolicy.ReferrerPolicyPropertyOutputReference | TfResponseHeadersPolicy.ReferrerPolicyProperty): any;
export declare function tfResponseHeadersPolicyReferrerPolicyPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.ReferrerPolicyPropertyOutputReference | TfResponseHeadersPolicy.ReferrerPolicyProperty): any;
export declare function tfResponseHeadersPolicyStrictTransportSecurityPropertyToTerraform(struct?: TfResponseHeadersPolicy.StrictTransportSecurityPropertyOutputReference | TfResponseHeadersPolicy.StrictTransportSecurityProperty): any;
export declare function tfResponseHeadersPolicyStrictTransportSecurityPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.StrictTransportSecurityPropertyOutputReference | TfResponseHeadersPolicy.StrictTransportSecurityProperty): any;
export declare function tfResponseHeadersPolicyXssProtectionPropertyToTerraform(struct?: TfResponseHeadersPolicy.XssProtectionPropertyOutputReference | TfResponseHeadersPolicy.XssProtectionProperty): any;
export declare function tfResponseHeadersPolicyXssProtectionPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.XssProtectionPropertyOutputReference | TfResponseHeadersPolicy.XssProtectionProperty): any;
export declare function tfResponseHeadersPolicySecurityHeadersConfigPropertyToTerraform(struct?: TfResponseHeadersPolicy.SecurityHeadersConfigPropertyOutputReference | TfResponseHeadersPolicy.SecurityHeadersConfigProperty): any;
export declare function tfResponseHeadersPolicySecurityHeadersConfigPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.SecurityHeadersConfigPropertyOutputReference | TfResponseHeadersPolicy.SecurityHeadersConfigProperty): any;
export declare function tfResponseHeadersPolicyServerTimingHeadersConfigPropertyToTerraform(struct?: TfResponseHeadersPolicy.ServerTimingHeadersConfigPropertyOutputReference | TfResponseHeadersPolicy.ServerTimingHeadersConfigProperty): any;
export declare function tfResponseHeadersPolicyServerTimingHeadersConfigPropertyToHclTerraform(struct?: TfResponseHeadersPolicy.ServerTimingHeadersConfigPropertyOutputReference | TfResponseHeadersPolicy.ServerTimingHeadersConfigProperty): any;
export declare namespace TfResponseHeadersPolicy {
    interface AccessControlAllowHeadersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#items TfResponseHeadersPolicy#items}
        */
        readonly items?: string[];
    }
    class AccessControlAllowHeadersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessControlAllowHeadersProperty | undefined;
        set internalValue(value: AccessControlAllowHeadersProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface AccessControlAllowMethodsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#items TfResponseHeadersPolicy#items}
        */
        readonly items?: string[];
    }
    class AccessControlAllowMethodsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessControlAllowMethodsProperty | undefined;
        set internalValue(value: AccessControlAllowMethodsProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface AccessControlAllowOriginsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#items TfResponseHeadersPolicy#items}
        */
        readonly items?: string[];
    }
    class AccessControlAllowOriginsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessControlAllowOriginsProperty | undefined;
        set internalValue(value: AccessControlAllowOriginsProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface AccessControlExposeHeadersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#items TfResponseHeadersPolicy#items}
        */
        readonly items?: string[];
    }
    class AccessControlExposeHeadersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessControlExposeHeadersProperty | undefined;
        set internalValue(value: AccessControlExposeHeadersProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface CorsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#access_control_allow_credentials TfResponseHeadersPolicy#access_control_allow_credentials}
        */
        readonly accessControlAllowCredentials: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#access_control_max_age_sec TfResponseHeadersPolicy#access_control_max_age_sec}
        */
        readonly accessControlMaxAgeSec?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#origin_override TfResponseHeadersPolicy#origin_override}
        */
        readonly originOverride: boolean | cdktn.IResolvable;
        /**
        * access_control_allow_headers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#access_control_allow_headers TfResponseHeadersPolicy#access_control_allow_headers}
        */
        readonly accessControlAllowHeaders: AccessControlAllowHeadersProperty;
        /**
        * access_control_allow_methods block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#access_control_allow_methods TfResponseHeadersPolicy#access_control_allow_methods}
        */
        readonly accessControlAllowMethods: AccessControlAllowMethodsProperty;
        /**
        * access_control_allow_origins block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#access_control_allow_origins TfResponseHeadersPolicy#access_control_allow_origins}
        */
        readonly accessControlAllowOrigins: AccessControlAllowOriginsProperty;
        /**
        * access_control_expose_headers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#access_control_expose_headers TfResponseHeadersPolicy#access_control_expose_headers}
        */
        readonly accessControlExposeHeaders?: AccessControlExposeHeadersProperty;
    }
    class CorsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CorsConfigProperty | undefined;
        set internalValue(value: CorsConfigProperty | undefined);
        private _accessControlAllowCredentials?;
        get accessControlAllowCredentials(): boolean | cdktn.IResolvable;
        set accessControlAllowCredentials(value: boolean | cdktn.IResolvable);
        get accessControlAllowCredentialsInput(): boolean | cdktn.IResolvable | undefined;
        private _accessControlMaxAgeSec?;
        get accessControlMaxAgeSec(): number;
        set accessControlMaxAgeSec(value: number);
        resetAccessControlMaxAgeSec(): void;
        get accessControlMaxAgeSecInput(): number | undefined;
        private _originOverride?;
        get originOverride(): boolean | cdktn.IResolvable;
        set originOverride(value: boolean | cdktn.IResolvable);
        get originOverrideInput(): boolean | cdktn.IResolvable | undefined;
        private _accessControlAllowHeaders;
        get accessControlAllowHeaders(): AccessControlAllowHeadersPropertyOutputReference;
        putAccessControlAllowHeaders(value: AccessControlAllowHeadersProperty): void;
        get accessControlAllowHeadersInput(): AccessControlAllowHeadersProperty | undefined;
        private _accessControlAllowMethods;
        get accessControlAllowMethods(): AccessControlAllowMethodsPropertyOutputReference;
        putAccessControlAllowMethods(value: AccessControlAllowMethodsProperty): void;
        get accessControlAllowMethodsInput(): AccessControlAllowMethodsProperty | undefined;
        private _accessControlAllowOrigins;
        get accessControlAllowOrigins(): AccessControlAllowOriginsPropertyOutputReference;
        putAccessControlAllowOrigins(value: AccessControlAllowOriginsProperty): void;
        get accessControlAllowOriginsInput(): AccessControlAllowOriginsProperty | undefined;
        private _accessControlExposeHeaders;
        get accessControlExposeHeaders(): AccessControlExposeHeadersPropertyOutputReference;
        putAccessControlExposeHeaders(value: AccessControlExposeHeadersProperty): void;
        resetAccessControlExposeHeaders(): void;
        get accessControlExposeHeadersInput(): AccessControlExposeHeadersProperty | undefined;
    }
    interface CustomHeadersConfigItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#header TfResponseHeadersPolicy#header}
        */
        readonly header: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#override TfResponseHeadersPolicy#override}
        */
        readonly override: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#value TfResponseHeadersPolicy#value}
        */
        readonly value: string;
    }
    class CustomHeadersConfigItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomHeadersConfigItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomHeadersConfigItemsProperty | cdktn.IResolvable | undefined);
        private _header?;
        get header(): string;
        set header(value: string);
        get headerInput(): string | undefined;
        private _override?;
        get override(): boolean | cdktn.IResolvable;
        set override(value: boolean | cdktn.IResolvable);
        get overrideInput(): boolean | cdktn.IResolvable | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class CustomHeadersConfigItemsPropertyList extends cdktn.ComplexList {
        internalValue?: CustomHeadersConfigItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomHeadersConfigItemsPropertyOutputReference;
    }
    interface CustomHeadersConfigProperty {
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#items TfResponseHeadersPolicy#items}
        */
        readonly items?: CustomHeadersConfigItemsProperty[] | cdktn.IResolvable;
    }
    class CustomHeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomHeadersConfigProperty | undefined;
        set internalValue(value: CustomHeadersConfigProperty | undefined);
        private _items;
        get items(): CustomHeadersConfigItemsPropertyList;
        putItems(value: CustomHeadersConfigItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | CustomHeadersConfigItemsProperty[] | undefined;
    }
    interface RemoveHeadersConfigItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#header TfResponseHeadersPolicy#header}
        */
        readonly header: string;
    }
    class RemoveHeadersConfigItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RemoveHeadersConfigItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RemoveHeadersConfigItemsProperty | cdktn.IResolvable | undefined);
        private _header?;
        get header(): string;
        set header(value: string);
        get headerInput(): string | undefined;
    }
    class RemoveHeadersConfigItemsPropertyList extends cdktn.ComplexList {
        internalValue?: RemoveHeadersConfigItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RemoveHeadersConfigItemsPropertyOutputReference;
    }
    interface RemoveHeadersConfigProperty {
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#items TfResponseHeadersPolicy#items}
        */
        readonly items?: RemoveHeadersConfigItemsProperty[] | cdktn.IResolvable;
    }
    class RemoveHeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RemoveHeadersConfigProperty | undefined;
        set internalValue(value: RemoveHeadersConfigProperty | undefined);
        private _items;
        get items(): RemoveHeadersConfigItemsPropertyList;
        putItems(value: RemoveHeadersConfigItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | RemoveHeadersConfigItemsProperty[] | undefined;
    }
    interface ContentSecurityPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#content_security_policy TfResponseHeadersPolicy#content_security_policy}
        */
        readonly contentSecurityPolicy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#override TfResponseHeadersPolicy#override}
        */
        readonly override: boolean | cdktn.IResolvable;
    }
    class ContentSecurityPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContentSecurityPolicyProperty | undefined;
        set internalValue(value: ContentSecurityPolicyProperty | undefined);
        private _contentSecurityPolicy?;
        get contentSecurityPolicy(): string;
        set contentSecurityPolicy(value: string);
        get contentSecurityPolicyInput(): string | undefined;
        private _override?;
        get override(): boolean | cdktn.IResolvable;
        set override(value: boolean | cdktn.IResolvable);
        get overrideInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ContentTypeOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#override TfResponseHeadersPolicy#override}
        */
        readonly override: boolean | cdktn.IResolvable;
    }
    class ContentTypeOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContentTypeOptionsProperty | undefined;
        set internalValue(value: ContentTypeOptionsProperty | undefined);
        private _override?;
        get override(): boolean | cdktn.IResolvable;
        set override(value: boolean | cdktn.IResolvable);
        get overrideInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface FrameOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#frame_option TfResponseHeadersPolicy#frame_option}
        */
        readonly frameOption: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#override TfResponseHeadersPolicy#override}
        */
        readonly override: boolean | cdktn.IResolvable;
    }
    class FrameOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FrameOptionsProperty | undefined;
        set internalValue(value: FrameOptionsProperty | undefined);
        private _frameOption?;
        get frameOption(): string;
        set frameOption(value: string);
        get frameOptionInput(): string | undefined;
        private _override?;
        get override(): boolean | cdktn.IResolvable;
        set override(value: boolean | cdktn.IResolvable);
        get overrideInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ReferrerPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#override TfResponseHeadersPolicy#override}
        */
        readonly override: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#referrer_policy TfResponseHeadersPolicy#referrer_policy}
        */
        readonly referrerPolicy: string;
    }
    class ReferrerPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReferrerPolicyProperty | undefined;
        set internalValue(value: ReferrerPolicyProperty | undefined);
        private _override?;
        get override(): boolean | cdktn.IResolvable;
        set override(value: boolean | cdktn.IResolvable);
        get overrideInput(): boolean | cdktn.IResolvable | undefined;
        private _referrerPolicy?;
        get referrerPolicy(): string;
        set referrerPolicy(value: string);
        get referrerPolicyInput(): string | undefined;
    }
    interface StrictTransportSecurityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#access_control_max_age_sec TfResponseHeadersPolicy#access_control_max_age_sec}
        */
        readonly accessControlMaxAgeSec: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#include_subdomains TfResponseHeadersPolicy#include_subdomains}
        */
        readonly includeSubdomains?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#override TfResponseHeadersPolicy#override}
        */
        readonly override: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#preload TfResponseHeadersPolicy#preload}
        */
        readonly preload?: boolean | cdktn.IResolvable;
    }
    class StrictTransportSecurityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StrictTransportSecurityProperty | undefined;
        set internalValue(value: StrictTransportSecurityProperty | undefined);
        private _accessControlMaxAgeSec?;
        get accessControlMaxAgeSec(): number;
        set accessControlMaxAgeSec(value: number);
        get accessControlMaxAgeSecInput(): number | undefined;
        private _includeSubdomains?;
        get includeSubdomains(): boolean | cdktn.IResolvable;
        set includeSubdomains(value: boolean | cdktn.IResolvable);
        resetIncludeSubdomains(): void;
        get includeSubdomainsInput(): boolean | cdktn.IResolvable | undefined;
        private _override?;
        get override(): boolean | cdktn.IResolvable;
        set override(value: boolean | cdktn.IResolvable);
        get overrideInput(): boolean | cdktn.IResolvable | undefined;
        private _preload?;
        get preload(): boolean | cdktn.IResolvable;
        set preload(value: boolean | cdktn.IResolvable);
        resetPreload(): void;
        get preloadInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface XssProtectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#mode_block TfResponseHeadersPolicy#mode_block}
        */
        readonly modeBlock?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#override TfResponseHeadersPolicy#override}
        */
        readonly override: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#protection TfResponseHeadersPolicy#protection}
        */
        readonly protection: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#report_uri TfResponseHeadersPolicy#report_uri}
        */
        readonly reportUri?: string;
    }
    class XssProtectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): XssProtectionProperty | undefined;
        set internalValue(value: XssProtectionProperty | undefined);
        private _modeBlock?;
        get modeBlock(): boolean | cdktn.IResolvable;
        set modeBlock(value: boolean | cdktn.IResolvable);
        resetModeBlock(): void;
        get modeBlockInput(): boolean | cdktn.IResolvable | undefined;
        private _override?;
        get override(): boolean | cdktn.IResolvable;
        set override(value: boolean | cdktn.IResolvable);
        get overrideInput(): boolean | cdktn.IResolvable | undefined;
        private _protection?;
        get protection(): boolean | cdktn.IResolvable;
        set protection(value: boolean | cdktn.IResolvable);
        get protectionInput(): boolean | cdktn.IResolvable | undefined;
        private _reportUri?;
        get reportUri(): string;
        set reportUri(value: string);
        resetReportUri(): void;
        get reportUriInput(): string | undefined;
    }
    interface SecurityHeadersConfigProperty {
        /**
        * content_security_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#content_security_policy TfResponseHeadersPolicy#content_security_policy}
        */
        readonly contentSecurityPolicy?: ContentSecurityPolicyProperty;
        /**
        * content_type_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#content_type_options TfResponseHeadersPolicy#content_type_options}
        */
        readonly contentTypeOptions?: ContentTypeOptionsProperty;
        /**
        * frame_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#frame_options TfResponseHeadersPolicy#frame_options}
        */
        readonly frameOptions?: FrameOptionsProperty;
        /**
        * referrer_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#referrer_policy TfResponseHeadersPolicy#referrer_policy}
        */
        readonly referrerPolicy?: ReferrerPolicyProperty;
        /**
        * strict_transport_security block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#strict_transport_security TfResponseHeadersPolicy#strict_transport_security}
        */
        readonly strictTransportSecurity?: StrictTransportSecurityProperty;
        /**
        * xss_protection block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#xss_protection TfResponseHeadersPolicy#xss_protection}
        */
        readonly xssProtection?: XssProtectionProperty;
    }
    class SecurityHeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecurityHeadersConfigProperty | undefined;
        set internalValue(value: SecurityHeadersConfigProperty | undefined);
        private _contentSecurityPolicy;
        get contentSecurityPolicy(): ContentSecurityPolicyPropertyOutputReference;
        putContentSecurityPolicy(value: ContentSecurityPolicyProperty): void;
        resetContentSecurityPolicy(): void;
        get contentSecurityPolicyInput(): ContentSecurityPolicyProperty | undefined;
        private _contentTypeOptions;
        get contentTypeOptions(): ContentTypeOptionsPropertyOutputReference;
        putContentTypeOptions(value: ContentTypeOptionsProperty): void;
        resetContentTypeOptions(): void;
        get contentTypeOptionsInput(): ContentTypeOptionsProperty | undefined;
        private _frameOptions;
        get frameOptions(): FrameOptionsPropertyOutputReference;
        putFrameOptions(value: FrameOptionsProperty): void;
        resetFrameOptions(): void;
        get frameOptionsInput(): FrameOptionsProperty | undefined;
        private _referrerPolicy;
        get referrerPolicy(): ReferrerPolicyPropertyOutputReference;
        putReferrerPolicy(value: ReferrerPolicyProperty): void;
        resetReferrerPolicy(): void;
        get referrerPolicyInput(): ReferrerPolicyProperty | undefined;
        private _strictTransportSecurity;
        get strictTransportSecurity(): StrictTransportSecurityPropertyOutputReference;
        putStrictTransportSecurity(value: StrictTransportSecurityProperty): void;
        resetStrictTransportSecurity(): void;
        get strictTransportSecurityInput(): StrictTransportSecurityProperty | undefined;
        private _xssProtection;
        get xssProtection(): XssProtectionPropertyOutputReference;
        putXssProtection(value: XssProtectionProperty): void;
        resetXssProtection(): void;
        get xssProtectionInput(): XssProtectionProperty | undefined;
    }
    interface ServerTimingHeadersConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#enabled TfResponseHeadersPolicy#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_response_headers_policy#sampling_rate TfResponseHeadersPolicy#sampling_rate}
        */
        readonly samplingRate: number;
    }
    class ServerTimingHeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServerTimingHeadersConfigProperty | undefined;
        set internalValue(value: ServerTimingHeadersConfigProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _samplingRate?;
        get samplingRate(): number;
        set samplingRate(value: number);
        get samplingRateInput(): number | undefined;
    }
}
