import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFieldLevelEncryptionProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#comment TfFieldLevelEncryptionProfile#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#id TfFieldLevelEncryptionProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#name TfFieldLevelEncryptionProfile#name}
    */
    readonly name: string;
    /**
    * encryption_entities block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#encryption_entities TfFieldLevelEncryptionProfile#encryption_entities}
    */
    readonly encryptionEntities: TfFieldLevelEncryptionProfile.EncryptionEntitiesProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile aws_cloudfront_field_level_encryption_profile}
*/
export declare class TfFieldLevelEncryptionProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_field_level_encryption_profile";
    /**
    * Generates CDKTN code for importing a TfFieldLevelEncryptionProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFieldLevelEncryptionProfile to import
    * @param importFromId The id of the existing TfFieldLevelEncryptionProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFieldLevelEncryptionProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile aws_cloudfront_field_level_encryption_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFieldLevelEncryptionProfileConfig
    */
    constructor(scope: Construct, id: string, config: TfFieldLevelEncryptionProfileConfig);
    get arn(): string;
    get callerReference(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _encryptionEntities;
    get encryptionEntities(): TfFieldLevelEncryptionProfile.EncryptionEntitiesPropertyOutputReference;
    putEncryptionEntities(value: TfFieldLevelEncryptionProfile.EncryptionEntitiesProperty): void;
    get encryptionEntitiesInput(): TfFieldLevelEncryptionProfile.EncryptionEntitiesProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfFieldLevelEncryptionProfileFieldPatternsPropertyToTerraform(struct?: TfFieldLevelEncryptionProfile.FieldPatternsPropertyOutputReference | TfFieldLevelEncryptionProfile.FieldPatternsProperty): any;
export declare function tfFieldLevelEncryptionProfileFieldPatternsPropertyToHclTerraform(struct?: TfFieldLevelEncryptionProfile.FieldPatternsPropertyOutputReference | TfFieldLevelEncryptionProfile.FieldPatternsProperty): any;
export declare function tfFieldLevelEncryptionProfileItemsPropertyToTerraform(struct?: TfFieldLevelEncryptionProfile.ItemsProperty | cdktn.IResolvable): any;
export declare function tfFieldLevelEncryptionProfileItemsPropertyToHclTerraform(struct?: TfFieldLevelEncryptionProfile.ItemsProperty | cdktn.IResolvable): any;
export declare function tfFieldLevelEncryptionProfileEncryptionEntitiesPropertyToTerraform(struct?: TfFieldLevelEncryptionProfile.EncryptionEntitiesPropertyOutputReference | TfFieldLevelEncryptionProfile.EncryptionEntitiesProperty): any;
export declare function tfFieldLevelEncryptionProfileEncryptionEntitiesPropertyToHclTerraform(struct?: TfFieldLevelEncryptionProfile.EncryptionEntitiesPropertyOutputReference | TfFieldLevelEncryptionProfile.EncryptionEntitiesProperty): any;
export declare namespace TfFieldLevelEncryptionProfile {
    interface FieldPatternsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#items TfFieldLevelEncryptionProfile#items}
        */
        readonly items?: string[];
    }
    class FieldPatternsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FieldPatternsProperty | undefined;
        set internalValue(value: FieldPatternsProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface ItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#provider_id TfFieldLevelEncryptionProfile#provider_id}
        */
        readonly providerId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#public_key_id TfFieldLevelEncryptionProfile#public_key_id}
        */
        readonly publicKeyId: string;
        /**
        * field_patterns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#field_patterns TfFieldLevelEncryptionProfile#field_patterns}
        */
        readonly fieldPatterns: FieldPatternsProperty;
    }
    class ItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ItemsProperty | cdktn.IResolvable | undefined);
        private _providerId?;
        get providerId(): string;
        set providerId(value: string);
        get providerIdInput(): string | undefined;
        private _publicKeyId?;
        get publicKeyId(): string;
        set publicKeyId(value: string);
        get publicKeyIdInput(): string | undefined;
        private _fieldPatterns;
        get fieldPatterns(): FieldPatternsPropertyOutputReference;
        putFieldPatterns(value: FieldPatternsProperty): void;
        get fieldPatternsInput(): FieldPatternsProperty | undefined;
    }
    class ItemsPropertyList extends cdktn.ComplexList {
        internalValue?: ItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ItemsPropertyOutputReference;
    }
    interface EncryptionEntitiesProperty {
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_profile#items TfFieldLevelEncryptionProfile#items}
        */
        readonly items?: ItemsProperty[] | cdktn.IResolvable;
    }
    class EncryptionEntitiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionEntitiesProperty | undefined;
        set internalValue(value: EncryptionEntitiesProperty | undefined);
        private _items;
        get items(): ItemsPropertyList;
        putItems(value: ItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | ItemsProperty[] | undefined;
    }
}
