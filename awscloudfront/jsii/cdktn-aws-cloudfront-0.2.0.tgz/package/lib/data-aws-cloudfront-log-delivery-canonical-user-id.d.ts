import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfLogDeliveryCanonicalUserIdConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_log_delivery_canonical_user_id#id DataTfLogDeliveryCanonicalUserId#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_log_delivery_canonical_user_id#region DataTfLogDeliveryCanonicalUserId#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_log_delivery_canonical_user_id aws_cloudfront_log_delivery_canonical_user_id}
*/
export declare class DataTfLogDeliveryCanonicalUserId extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cloudfront_log_delivery_canonical_user_id";
    /**
    * Generates CDKTN code for importing a DataTfLogDeliveryCanonicalUserId resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfLogDeliveryCanonicalUserId to import
    * @param importFromId The id of the existing DataTfLogDeliveryCanonicalUserId that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_log_delivery_canonical_user_id#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfLogDeliveryCanonicalUserId to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_log_delivery_canonical_user_id aws_cloudfront_log_delivery_canonical_user_id} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfLogDeliveryCanonicalUserIdConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfLogDeliveryCanonicalUserIdConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
