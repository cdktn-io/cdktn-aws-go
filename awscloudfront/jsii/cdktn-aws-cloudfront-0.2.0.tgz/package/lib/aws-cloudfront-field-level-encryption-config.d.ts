import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFieldLevelEncryptionConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config#comment TfFieldLevelEncryptionConfig#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config#id TfFieldLevelEncryptionConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * content_type_profile_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config#content_type_profile_config TfFieldLevelEncryptionConfig#content_type_profile_config}
    */
    readonly contentTypeProfileConfig: TfFieldLevelEncryptionConfig.ContentTypeProfileConfigProperty;
    /**
    * query_arg_profile_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config#query_arg_profile_config TfFieldLevelEncryptionConfig#query_arg_profile_config}
    */
    readonly queryArgProfileConfig: TfFieldLevelEncryptionConfig.QueryArgProfileConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config aws_cloudfront_field_level_encryption_config}
*/
export declare class TfFieldLevelEncryptionConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_field_level_encryption_config";
    /**
    * Generates CDKTN code for importing a TfFieldLevelEncryptionConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFieldLevelEncryptionConfig to import
    * @param importFromId The id of the existing TfFieldLevelEncryptionConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFieldLevelEncryptionConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config aws_cloudfront_field_level_encryption_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFieldLevelEncryptionConfigConfig
    */
    constructor(scope: Construct, id: string, config: TfFieldLevelEncryptionConfigConfig);
    get arn(): string;
    get callerReference(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _contentTypeProfileConfig;
    get contentTypeProfileConfig(): TfFieldLevelEncryptionConfig.ContentTypeProfileConfigPropertyOutputReference;
    putContentTypeProfileConfig(value: TfFieldLevelEncryptionConfig.ContentTypeProfileConfigProperty): void;
    get contentTypeProfileConfigInput(): TfFieldLevelEncryptionConfig.ContentTypeProfileConfigProperty | undefined;
    private _queryArgProfileConfig;
    get queryArgProfileConfig(): TfFieldLevelEncryptionConfig.QueryArgProfileConfigPropertyOutputReference;
    putQueryArgProfileConfig(value: TfFieldLevelEncryptionConfig.QueryArgProfileConfigProperty): void;
    get queryArgProfileConfigInput(): TfFieldLevelEncryptionConfig.QueryArgProfileConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfFieldLevelEncryptionConfigContentTypeProfileConfigContentTypeProfilesItemsPropertyToTerraform(struct?: TfFieldLevelEncryptionConfig.ContentTypeProfileConfigContentTypeProfilesItemsProperty | cdktn.IResolvable): any;
export declare function tfFieldLevelEncryptionConfigContentTypeProfileConfigContentTypeProfilesItemsPropertyToHclTerraform(struct?: TfFieldLevelEncryptionConfig.ContentTypeProfileConfigContentTypeProfilesItemsProperty | cdktn.IResolvable): any;
export declare function tfFieldLevelEncryptionConfigContentTypeProfilesPropertyToTerraform(struct?: TfFieldLevelEncryptionConfig.ContentTypeProfilesPropertyOutputReference | TfFieldLevelEncryptionConfig.ContentTypeProfilesProperty): any;
export declare function tfFieldLevelEncryptionConfigContentTypeProfilesPropertyToHclTerraform(struct?: TfFieldLevelEncryptionConfig.ContentTypeProfilesPropertyOutputReference | TfFieldLevelEncryptionConfig.ContentTypeProfilesProperty): any;
export declare function tfFieldLevelEncryptionConfigContentTypeProfileConfigPropertyToTerraform(struct?: TfFieldLevelEncryptionConfig.ContentTypeProfileConfigPropertyOutputReference | TfFieldLevelEncryptionConfig.ContentTypeProfileConfigProperty): any;
export declare function tfFieldLevelEncryptionConfigContentTypeProfileConfigPropertyToHclTerraform(struct?: TfFieldLevelEncryptionConfig.ContentTypeProfileConfigPropertyOutputReference | TfFieldLevelEncryptionConfig.ContentTypeProfileConfigProperty): any;
export declare function tfFieldLevelEncryptionConfigQueryArgProfileConfigQueryArgProfilesItemsPropertyToTerraform(struct?: TfFieldLevelEncryptionConfig.QueryArgProfileConfigQueryArgProfilesItemsProperty | cdktn.IResolvable): any;
export declare function tfFieldLevelEncryptionConfigQueryArgProfileConfigQueryArgProfilesItemsPropertyToHclTerraform(struct?: TfFieldLevelEncryptionConfig.QueryArgProfileConfigQueryArgProfilesItemsProperty | cdktn.IResolvable): any;
export declare function tfFieldLevelEncryptionConfigQueryArgProfilesPropertyToTerraform(struct?: TfFieldLevelEncryptionConfig.QueryArgProfilesPropertyOutputReference | TfFieldLevelEncryptionConfig.QueryArgProfilesProperty): any;
export declare function tfFieldLevelEncryptionConfigQueryArgProfilesPropertyToHclTerraform(struct?: TfFieldLevelEncryptionConfig.QueryArgProfilesPropertyOutputReference | TfFieldLevelEncryptionConfig.QueryArgProfilesProperty): any;
export declare function tfFieldLevelEncryptionConfigQueryArgProfileConfigPropertyToTerraform(struct?: TfFieldLevelEncryptionConfig.QueryArgProfileConfigPropertyOutputReference | TfFieldLevelEncryptionConfig.QueryArgProfileConfigProperty): any;
export declare function tfFieldLevelEncryptionConfigQueryArgProfileConfigPropertyToHclTerraform(struct?: TfFieldLevelEncryptionConfig.QueryArgProfileConfigPropertyOutputReference | TfFieldLevelEncryptionConfig.QueryArgProfileConfigProperty): any;
export declare namespace TfFieldLevelEncryptionConfig {
    interface ContentTypeProfileConfigContentTypeProfilesItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config#content_type TfFieldLevelEncryptionConfig#content_type}
        */
        readonly contentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config#format TfFieldLevelEncryptionConfig#format}
        */
        readonly format: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config#profile_id TfFieldLevelEncryptionConfig#profile_id}
        */
        readonly profileId?: string;
    }
    class ContentTypeProfileConfigContentTypeProfilesItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContentTypeProfileConfigContentTypeProfilesItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContentTypeProfileConfigContentTypeProfilesItemsProperty | cdktn.IResolvable | undefined);
        private _contentType?;
        get contentType(): string;
        set contentType(value: string);
        get contentTypeInput(): string | undefined;
        private _format?;
        get format(): string;
        set format(value: string);
        get formatInput(): string | undefined;
        private _profileId?;
        get profileId(): string;
        set profileId(value: string);
        resetProfileId(): void;
        get profileIdInput(): string | undefined;
    }
    class ContentTypeProfileConfigContentTypeProfilesItemsPropertyList extends cdktn.ComplexList {
        internalValue?: ContentTypeProfileConfigContentTypeProfilesItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContentTypeProfileConfigContentTypeProfilesItemsPropertyOutputReference;
    }
    interface ContentTypeProfilesProperty {
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config#items TfFieldLevelEncryptionConfig#items}
        */
        readonly items: ContentTypeProfileConfigContentTypeProfilesItemsProperty[] | cdktn.IResolvable;
    }
    class ContentTypeProfilesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContentTypeProfilesProperty | undefined;
        set internalValue(value: ContentTypeProfilesProperty | undefined);
        private _items;
        get items(): ContentTypeProfileConfigContentTypeProfilesItemsPropertyList;
        putItems(value: ContentTypeProfileConfigContentTypeProfilesItemsProperty[] | cdktn.IResolvable): void;
        get itemsInput(): cdktn.IResolvable | ContentTypeProfileConfigContentTypeProfilesItemsProperty[] | undefined;
    }
    interface ContentTypeProfileConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config#forward_when_content_type_is_unknown TfFieldLevelEncryptionConfig#forward_when_content_type_is_unknown}
        */
        readonly forwardWhenContentTypeIsUnknown: boolean | cdktn.IResolvable;
        /**
        * content_type_profiles block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config#content_type_profiles TfFieldLevelEncryptionConfig#content_type_profiles}
        */
        readonly contentTypeProfiles: ContentTypeProfilesProperty;
    }
    class ContentTypeProfileConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContentTypeProfileConfigProperty | undefined;
        set internalValue(value: ContentTypeProfileConfigProperty | undefined);
        private _forwardWhenContentTypeIsUnknown?;
        get forwardWhenContentTypeIsUnknown(): boolean | cdktn.IResolvable;
        set forwardWhenContentTypeIsUnknown(value: boolean | cdktn.IResolvable);
        get forwardWhenContentTypeIsUnknownInput(): boolean | cdktn.IResolvable | undefined;
        private _contentTypeProfiles;
        get contentTypeProfiles(): ContentTypeProfilesPropertyOutputReference;
        putContentTypeProfiles(value: ContentTypeProfilesProperty): void;
        get contentTypeProfilesInput(): ContentTypeProfilesProperty | undefined;
    }
    interface QueryArgProfileConfigQueryArgProfilesItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config#profile_id TfFieldLevelEncryptionConfig#profile_id}
        */
        readonly profileId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config#query_arg TfFieldLevelEncryptionConfig#query_arg}
        */
        readonly queryArg: string;
    }
    class QueryArgProfileConfigQueryArgProfilesItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): QueryArgProfileConfigQueryArgProfilesItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: QueryArgProfileConfigQueryArgProfilesItemsProperty | cdktn.IResolvable | undefined);
        private _profileId?;
        get profileId(): string;
        set profileId(value: string);
        get profileIdInput(): string | undefined;
        private _queryArg?;
        get queryArg(): string;
        set queryArg(value: string);
        get queryArgInput(): string | undefined;
    }
    class QueryArgProfileConfigQueryArgProfilesItemsPropertyList extends cdktn.ComplexList {
        internalValue?: QueryArgProfileConfigQueryArgProfilesItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): QueryArgProfileConfigQueryArgProfilesItemsPropertyOutputReference;
    }
    interface QueryArgProfilesProperty {
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config#items TfFieldLevelEncryptionConfig#items}
        */
        readonly items?: QueryArgProfileConfigQueryArgProfilesItemsProperty[] | cdktn.IResolvable;
    }
    class QueryArgProfilesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QueryArgProfilesProperty | undefined;
        set internalValue(value: QueryArgProfilesProperty | undefined);
        private _items;
        get items(): QueryArgProfileConfigQueryArgProfilesItemsPropertyList;
        putItems(value: QueryArgProfileConfigQueryArgProfilesItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | QueryArgProfileConfigQueryArgProfilesItemsProperty[] | undefined;
    }
    interface QueryArgProfileConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config#forward_when_query_arg_profile_is_unknown TfFieldLevelEncryptionConfig#forward_when_query_arg_profile_is_unknown}
        */
        readonly forwardWhenQueryArgProfileIsUnknown: boolean | cdktn.IResolvable;
        /**
        * query_arg_profiles block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_field_level_encryption_config#query_arg_profiles TfFieldLevelEncryptionConfig#query_arg_profiles}
        */
        readonly queryArgProfiles?: QueryArgProfilesProperty;
    }
    class QueryArgProfileConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QueryArgProfileConfigProperty | undefined;
        set internalValue(value: QueryArgProfileConfigProperty | undefined);
        private _forwardWhenQueryArgProfileIsUnknown?;
        get forwardWhenQueryArgProfileIsUnknown(): boolean | cdktn.IResolvable;
        set forwardWhenQueryArgProfileIsUnknown(value: boolean | cdktn.IResolvable);
        get forwardWhenQueryArgProfileIsUnknownInput(): boolean | cdktn.IResolvable | undefined;
        private _queryArgProfiles;
        get queryArgProfiles(): QueryArgProfilesPropertyOutputReference;
        putQueryArgProfiles(value: QueryArgProfilesProperty): void;
        resetQueryArgProfiles(): void;
        get queryArgProfilesInput(): QueryArgProfilesProperty | undefined;
    }
}
