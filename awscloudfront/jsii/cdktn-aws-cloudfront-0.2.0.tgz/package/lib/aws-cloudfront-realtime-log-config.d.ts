import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfRealtimeLogConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_realtime_log_config#fields TfRealtimeLogConfig#fields}
    */
    readonly fields: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_realtime_log_config#id TfRealtimeLogConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_realtime_log_config#name TfRealtimeLogConfig#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_realtime_log_config#sampling_rate TfRealtimeLogConfig#sampling_rate}
    */
    readonly samplingRate: number;
    /**
    * endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_realtime_log_config#endpoint TfRealtimeLogConfig#endpoint}
    */
    readonly endpoint: TfRealtimeLogConfig.EndpointProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_realtime_log_config aws_cloudfront_realtime_log_config}
*/
export declare class TfRealtimeLogConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_realtime_log_config";
    /**
    * Generates CDKTN code for importing a TfRealtimeLogConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfRealtimeLogConfig to import
    * @param importFromId The id of the existing TfRealtimeLogConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_realtime_log_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfRealtimeLogConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_realtime_log_config aws_cloudfront_realtime_log_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfRealtimeLogConfigConfig
    */
    constructor(scope: Construct, id: string, config: TfRealtimeLogConfigConfig);
    get arn(): string;
    private _fields?;
    get fields(): string[];
    set fields(value: string[]);
    get fieldsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _samplingRate?;
    get samplingRate(): number;
    set samplingRate(value: number);
    get samplingRateInput(): number | undefined;
    private _endpoint;
    get endpoint(): TfRealtimeLogConfig.EndpointPropertyOutputReference;
    putEndpoint(value: TfRealtimeLogConfig.EndpointProperty): void;
    get endpointInput(): TfRealtimeLogConfig.EndpointProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfRealtimeLogConfigKinesisStreamConfigPropertyToTerraform(struct?: TfRealtimeLogConfig.KinesisStreamConfigPropertyOutputReference | TfRealtimeLogConfig.KinesisStreamConfigProperty): any;
export declare function tfRealtimeLogConfigKinesisStreamConfigPropertyToHclTerraform(struct?: TfRealtimeLogConfig.KinesisStreamConfigPropertyOutputReference | TfRealtimeLogConfig.KinesisStreamConfigProperty): any;
export declare function tfRealtimeLogConfigEndpointPropertyToTerraform(struct?: TfRealtimeLogConfig.EndpointPropertyOutputReference | TfRealtimeLogConfig.EndpointProperty): any;
export declare function tfRealtimeLogConfigEndpointPropertyToHclTerraform(struct?: TfRealtimeLogConfig.EndpointPropertyOutputReference | TfRealtimeLogConfig.EndpointProperty): any;
export declare namespace TfRealtimeLogConfig {
    interface KinesisStreamConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_realtime_log_config#role_arn TfRealtimeLogConfig#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_realtime_log_config#stream_arn TfRealtimeLogConfig#stream_arn}
        */
        readonly streamArn: string;
    }
    class KinesisStreamConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisStreamConfigProperty | undefined;
        set internalValue(value: KinesisStreamConfigProperty | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _streamArn?;
        get streamArn(): string;
        set streamArn(value: string);
        get streamArnInput(): string | undefined;
    }
    interface EndpointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_realtime_log_config#stream_type TfRealtimeLogConfig#stream_type}
        */
        readonly streamType: string;
        /**
        * kinesis_stream_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_realtime_log_config#kinesis_stream_config TfRealtimeLogConfig#kinesis_stream_config}
        */
        readonly kinesisStreamConfig: KinesisStreamConfigProperty;
    }
    class EndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EndpointProperty | undefined;
        set internalValue(value: EndpointProperty | undefined);
        private _streamType?;
        get streamType(): string;
        set streamType(value: string);
        get streamTypeInput(): string | undefined;
        private _kinesisStreamConfig;
        get kinesisStreamConfig(): KinesisStreamConfigPropertyOutputReference;
        putKinesisStreamConfig(value: KinesisStreamConfigProperty): void;
        get kinesisStreamConfigInput(): KinesisStreamConfigProperty | undefined;
    }
}
