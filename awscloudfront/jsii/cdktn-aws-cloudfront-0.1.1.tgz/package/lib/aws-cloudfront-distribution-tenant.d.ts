import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCloudfrontDistributionTenantConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#connection_group_id AwsCloudfrontDistributionTenant#connection_group_id}
    */
    readonly connectionGroupId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#distribution_id AwsCloudfrontDistributionTenant#distribution_id}
    */
    readonly distributionId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#enabled AwsCloudfrontDistributionTenant#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#name AwsCloudfrontDistributionTenant#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#tags AwsCloudfrontDistributionTenant#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#wait_for_deployment AwsCloudfrontDistributionTenant#wait_for_deployment}
    */
    readonly waitForDeployment?: boolean | cdktn.IResolvable;
    /**
    * customizations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#customizations AwsCloudfrontDistributionTenant#customizations}
    */
    readonly customizations?: AwsCloudfrontDistributionTenant.CustomizationsProperty[] | cdktn.IResolvable;
    /**
    * domain block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#domain AwsCloudfrontDistributionTenant#domain}
    */
    readonly domain?: AwsCloudfrontDistributionTenant.DomainProperty[] | cdktn.IResolvable;
    /**
    * managed_certificate_request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#managed_certificate_request AwsCloudfrontDistributionTenant#managed_certificate_request}
    */
    readonly managedCertificateRequest?: AwsCloudfrontDistributionTenant.ManagedCertificateRequestProperty[] | cdktn.IResolvable;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#parameter AwsCloudfrontDistributionTenant#parameter}
    */
    readonly parameter?: AwsCloudfrontDistributionTenant.ParameterProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#timeouts AwsCloudfrontDistributionTenant#timeouts}
    */
    readonly timeouts?: AwsCloudfrontDistributionTenant.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant aws_cloudfront_distribution_tenant}
*/
export declare class AwsCloudfrontDistributionTenant extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_distribution_tenant";
    /**
    * Generates CDKTN code for importing a AwsCloudfrontDistributionTenant resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCloudfrontDistributionTenant to import
    * @param importFromId The id of the existing AwsCloudfrontDistributionTenant that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCloudfrontDistributionTenant to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant aws_cloudfront_distribution_tenant} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCloudfrontDistributionTenantConfig
    */
    constructor(scope: Construct, id: string, config: AwsCloudfrontDistributionTenantConfig);
    get arn(): string;
    private _connectionGroupId?;
    get connectionGroupId(): string;
    set connectionGroupId(value: string);
    resetConnectionGroupId(): void;
    get connectionGroupIdInput(): string | undefined;
    private _distributionId?;
    get distributionId(): string;
    set distributionId(value: string);
    get distributionIdInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get etag(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _waitForDeployment?;
    get waitForDeployment(): boolean | cdktn.IResolvable;
    set waitForDeployment(value: boolean | cdktn.IResolvable);
    resetWaitForDeployment(): void;
    get waitForDeploymentInput(): boolean | cdktn.IResolvable | undefined;
    private _customizations;
    get customizations(): AwsCloudfrontDistributionTenant.CustomizationsPropertyList;
    putCustomizations(value: AwsCloudfrontDistributionTenant.CustomizationsProperty[] | cdktn.IResolvable): void;
    resetCustomizations(): void;
    get customizationsInput(): cdktn.IResolvable | AwsCloudfrontDistributionTenant.CustomizationsProperty[] | undefined;
    private _domain;
    get domain(): AwsCloudfrontDistributionTenant.DomainPropertyList;
    putDomain(value: AwsCloudfrontDistributionTenant.DomainProperty[] | cdktn.IResolvable): void;
    resetDomain(): void;
    get domainInput(): cdktn.IResolvable | AwsCloudfrontDistributionTenant.DomainProperty[] | undefined;
    private _managedCertificateRequest;
    get managedCertificateRequest(): AwsCloudfrontDistributionTenant.ManagedCertificateRequestPropertyList;
    putManagedCertificateRequest(value: AwsCloudfrontDistributionTenant.ManagedCertificateRequestProperty[] | cdktn.IResolvable): void;
    resetManagedCertificateRequest(): void;
    get managedCertificateRequestInput(): cdktn.IResolvable | AwsCloudfrontDistributionTenant.ManagedCertificateRequestProperty[] | undefined;
    private _parameter;
    get parameter(): AwsCloudfrontDistributionTenant.ParameterPropertyList;
    putParameter(value: AwsCloudfrontDistributionTenant.ParameterProperty[] | cdktn.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktn.IResolvable | AwsCloudfrontDistributionTenant.ParameterProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsCloudfrontDistributionTenant.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsCloudfrontDistributionTenant.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsCloudfrontDistributionTenant.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCloudfrontDistributionTenantCertificatePropertyToTerraform(struct?: AwsCloudfrontDistributionTenant.CertificateProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionTenantCertificatePropertyToHclTerraform(struct?: AwsCloudfrontDistributionTenant.CertificateProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionTenantGeoRestrictionPropertyToTerraform(struct?: AwsCloudfrontDistributionTenant.GeoRestrictionProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionTenantGeoRestrictionPropertyToHclTerraform(struct?: AwsCloudfrontDistributionTenant.GeoRestrictionProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionTenantWebAclPropertyToTerraform(struct?: AwsCloudfrontDistributionTenant.WebAclProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionTenantWebAclPropertyToHclTerraform(struct?: AwsCloudfrontDistributionTenant.WebAclProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionTenantCustomizationsPropertyToTerraform(struct?: AwsCloudfrontDistributionTenant.CustomizationsProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionTenantCustomizationsPropertyToHclTerraform(struct?: AwsCloudfrontDistributionTenant.CustomizationsProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionTenantDomainPropertyToTerraform(struct?: AwsCloudfrontDistributionTenant.DomainProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionTenantDomainPropertyToHclTerraform(struct?: AwsCloudfrontDistributionTenant.DomainProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionTenantManagedCertificateRequestPropertyToTerraform(struct?: AwsCloudfrontDistributionTenant.ManagedCertificateRequestProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionTenantManagedCertificateRequestPropertyToHclTerraform(struct?: AwsCloudfrontDistributionTenant.ManagedCertificateRequestProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionTenantParameterPropertyToTerraform(struct?: AwsCloudfrontDistributionTenant.ParameterProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionTenantParameterPropertyToHclTerraform(struct?: AwsCloudfrontDistributionTenant.ParameterProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionTenantTimeoutsPropertyToTerraform(struct?: AwsCloudfrontDistributionTenant.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionTenantTimeoutsPropertyToHclTerraform(struct?: AwsCloudfrontDistributionTenant.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsCloudfrontDistributionTenant {
    interface CertificateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#arn AwsCloudfrontDistributionTenant#arn}
        */
        readonly arn?: string;
    }
    class CertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CertificateProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        resetArn(): void;
        get arnInput(): string | undefined;
    }
    class CertificatePropertyList extends cdktn.ComplexList {
        internalValue?: CertificateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificatePropertyOutputReference;
    }
    interface GeoRestrictionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#locations AwsCloudfrontDistributionTenant#locations}
        */
        readonly locations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#restriction_type AwsCloudfrontDistributionTenant#restriction_type}
        */
        readonly restrictionType?: string;
    }
    class GeoRestrictionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GeoRestrictionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GeoRestrictionProperty | cdktn.IResolvable | undefined);
        private _locations?;
        get locations(): string[];
        set locations(value: string[]);
        resetLocations(): void;
        get locationsInput(): string[] | undefined;
        private _restrictionType?;
        get restrictionType(): string;
        set restrictionType(value: string);
        resetRestrictionType(): void;
        get restrictionTypeInput(): string | undefined;
    }
    class GeoRestrictionPropertyList extends cdktn.ComplexList {
        internalValue?: GeoRestrictionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GeoRestrictionPropertyOutputReference;
    }
    interface WebAclProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#action AwsCloudfrontDistributionTenant#action}
        */
        readonly action?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#arn AwsCloudfrontDistributionTenant#arn}
        */
        readonly arn?: string;
    }
    class WebAclPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WebAclProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WebAclProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        resetAction(): void;
        get actionInput(): string | undefined;
        private _arn?;
        get arn(): string;
        set arn(value: string);
        resetArn(): void;
        get arnInput(): string | undefined;
    }
    class WebAclPropertyList extends cdktn.ComplexList {
        internalValue?: WebAclProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WebAclPropertyOutputReference;
    }
    interface CustomizationsProperty {
        /**
        * certificate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#certificate AwsCloudfrontDistributionTenant#certificate}
        */
        readonly certificate?: CertificateProperty[] | cdktn.IResolvable;
        /**
        * geo_restriction block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#geo_restriction AwsCloudfrontDistributionTenant#geo_restriction}
        */
        readonly geoRestriction?: GeoRestrictionProperty[] | cdktn.IResolvable;
        /**
        * web_acl block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#web_acl AwsCloudfrontDistributionTenant#web_acl}
        */
        readonly webAcl?: WebAclProperty[] | cdktn.IResolvable;
    }
    class CustomizationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomizationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomizationsProperty | cdktn.IResolvable | undefined);
        private _certificate;
        get certificate(): CertificatePropertyList;
        putCertificate(value: CertificateProperty[] | cdktn.IResolvable): void;
        resetCertificate(): void;
        get certificateInput(): cdktn.IResolvable | CertificateProperty[] | undefined;
        private _geoRestriction;
        get geoRestriction(): GeoRestrictionPropertyList;
        putGeoRestriction(value: GeoRestrictionProperty[] | cdktn.IResolvable): void;
        resetGeoRestriction(): void;
        get geoRestrictionInput(): cdktn.IResolvable | GeoRestrictionProperty[] | undefined;
        private _webAcl;
        get webAcl(): WebAclPropertyList;
        putWebAcl(value: WebAclProperty[] | cdktn.IResolvable): void;
        resetWebAcl(): void;
        get webAclInput(): cdktn.IResolvable | WebAclProperty[] | undefined;
    }
    class CustomizationsPropertyList extends cdktn.ComplexList {
        internalValue?: CustomizationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomizationsPropertyOutputReference;
    }
    interface DomainProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#domain AwsCloudfrontDistributionTenant#domain}
        */
        readonly domain: string;
    }
    class DomainPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DomainProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DomainProperty | cdktn.IResolvable | undefined);
        private _domain?;
        get domain(): string;
        set domain(value: string);
        get domainInput(): string | undefined;
        get status(): string;
    }
    class DomainPropertyList extends cdktn.ComplexList {
        internalValue?: DomainProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DomainPropertyOutputReference;
    }
    interface ManagedCertificateRequestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#certificate_transparency_logging_preference AwsCloudfrontDistributionTenant#certificate_transparency_logging_preference}
        */
        readonly certificateTransparencyLoggingPreference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#primary_domain_name AwsCloudfrontDistributionTenant#primary_domain_name}
        */
        readonly primaryDomainName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#validation_token_host AwsCloudfrontDistributionTenant#validation_token_host}
        */
        readonly validationTokenHost?: string;
    }
    class ManagedCertificateRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ManagedCertificateRequestProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ManagedCertificateRequestProperty | cdktn.IResolvable | undefined);
        private _certificateTransparencyLoggingPreference?;
        get certificateTransparencyLoggingPreference(): string;
        set certificateTransparencyLoggingPreference(value: string);
        resetCertificateTransparencyLoggingPreference(): void;
        get certificateTransparencyLoggingPreferenceInput(): string | undefined;
        private _primaryDomainName?;
        get primaryDomainName(): string;
        set primaryDomainName(value: string);
        resetPrimaryDomainName(): void;
        get primaryDomainNameInput(): string | undefined;
        private _validationTokenHost?;
        get validationTokenHost(): string;
        set validationTokenHost(value: string);
        resetValidationTokenHost(): void;
        get validationTokenHostInput(): string | undefined;
    }
    class ManagedCertificateRequestPropertyList extends cdktn.ComplexList {
        internalValue?: ManagedCertificateRequestProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ManagedCertificateRequestPropertyOutputReference;
    }
    interface ParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#name AwsCloudfrontDistributionTenant#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#value AwsCloudfrontDistributionTenant#value}
        */
        readonly value: string;
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        internalValue?: ParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#create AwsCloudfrontDistributionTenant#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#delete AwsCloudfrontDistributionTenant#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution_tenant#update AwsCloudfrontDistributionTenant#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
