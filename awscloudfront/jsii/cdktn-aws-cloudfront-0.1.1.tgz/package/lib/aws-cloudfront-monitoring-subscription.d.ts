import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCloudfrontMonitoringSubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_monitoring_subscription#distribution_id AwsCloudfrontMonitoringSubscription#distribution_id}
    */
    readonly distributionId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_monitoring_subscription#id AwsCloudfrontMonitoringSubscription#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * monitoring_subscription block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_monitoring_subscription#monitoring_subscription AwsCloudfrontMonitoringSubscription#monitoring_subscription}
    */
    readonly monitoringSubscription: AwsCloudfrontMonitoringSubscription.MonitoringSubscriptionProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_monitoring_subscription aws_cloudfront_monitoring_subscription}
*/
export declare class AwsCloudfrontMonitoringSubscription extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_monitoring_subscription";
    /**
    * Generates CDKTN code for importing a AwsCloudfrontMonitoringSubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCloudfrontMonitoringSubscription to import
    * @param importFromId The id of the existing AwsCloudfrontMonitoringSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_monitoring_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCloudfrontMonitoringSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_monitoring_subscription aws_cloudfront_monitoring_subscription} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCloudfrontMonitoringSubscriptionConfig
    */
    constructor(scope: Construct, id: string, config: AwsCloudfrontMonitoringSubscriptionConfig);
    private _distributionId?;
    get distributionId(): string;
    set distributionId(value: string);
    get distributionIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _monitoringSubscription;
    get monitoringSubscription(): AwsCloudfrontMonitoringSubscription.MonitoringSubscriptionPropertyOutputReference;
    putMonitoringSubscription(value: AwsCloudfrontMonitoringSubscription.MonitoringSubscriptionProperty): void;
    get monitoringSubscriptionInput(): AwsCloudfrontMonitoringSubscription.MonitoringSubscriptionProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCloudfrontMonitoringSubscriptionRealtimeMetricsSubscriptionConfigPropertyToTerraform(struct?: AwsCloudfrontMonitoringSubscription.RealtimeMetricsSubscriptionConfigPropertyOutputReference | AwsCloudfrontMonitoringSubscription.RealtimeMetricsSubscriptionConfigProperty): any;
export declare function awsCloudfrontMonitoringSubscriptionRealtimeMetricsSubscriptionConfigPropertyToHclTerraform(struct?: AwsCloudfrontMonitoringSubscription.RealtimeMetricsSubscriptionConfigPropertyOutputReference | AwsCloudfrontMonitoringSubscription.RealtimeMetricsSubscriptionConfigProperty): any;
export declare function awsCloudfrontMonitoringSubscriptionMonitoringSubscriptionPropertyToTerraform(struct?: AwsCloudfrontMonitoringSubscription.MonitoringSubscriptionPropertyOutputReference | AwsCloudfrontMonitoringSubscription.MonitoringSubscriptionProperty): any;
export declare function awsCloudfrontMonitoringSubscriptionMonitoringSubscriptionPropertyToHclTerraform(struct?: AwsCloudfrontMonitoringSubscription.MonitoringSubscriptionPropertyOutputReference | AwsCloudfrontMonitoringSubscription.MonitoringSubscriptionProperty): any;
export declare namespace AwsCloudfrontMonitoringSubscription {
    interface RealtimeMetricsSubscriptionConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_monitoring_subscription#realtime_metrics_subscription_status AwsCloudfrontMonitoringSubscription#realtime_metrics_subscription_status}
        */
        readonly realtimeMetricsSubscriptionStatus: string;
    }
    class RealtimeMetricsSubscriptionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RealtimeMetricsSubscriptionConfigProperty | undefined;
        set internalValue(value: RealtimeMetricsSubscriptionConfigProperty | undefined);
        private _realtimeMetricsSubscriptionStatus?;
        get realtimeMetricsSubscriptionStatus(): string;
        set realtimeMetricsSubscriptionStatus(value: string);
        get realtimeMetricsSubscriptionStatusInput(): string | undefined;
    }
    interface MonitoringSubscriptionProperty {
        /**
        * realtime_metrics_subscription_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_monitoring_subscription#realtime_metrics_subscription_config AwsCloudfrontMonitoringSubscription#realtime_metrics_subscription_config}
        */
        readonly realtimeMetricsSubscriptionConfig: RealtimeMetricsSubscriptionConfigProperty;
    }
    class MonitoringSubscriptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringSubscriptionProperty | undefined;
        set internalValue(value: MonitoringSubscriptionProperty | undefined);
        private _realtimeMetricsSubscriptionConfig;
        get realtimeMetricsSubscriptionConfig(): RealtimeMetricsSubscriptionConfigPropertyOutputReference;
        putRealtimeMetricsSubscriptionConfig(value: RealtimeMetricsSubscriptionConfigProperty): void;
        get realtimeMetricsSubscriptionConfigInput(): RealtimeMetricsSubscriptionConfigProperty | undefined;
    }
}
