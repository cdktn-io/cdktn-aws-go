import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCloudfrontOriginRequestPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#comment AwsCloudfrontOriginRequestPolicy#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#id AwsCloudfrontOriginRequestPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#name AwsCloudfrontOriginRequestPolicy#name}
    */
    readonly name: string;
    /**
    * cookies_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#cookies_config AwsCloudfrontOriginRequestPolicy#cookies_config}
    */
    readonly cookiesConfig: AwsCloudfrontOriginRequestPolicy.CookiesConfigProperty;
    /**
    * headers_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#headers_config AwsCloudfrontOriginRequestPolicy#headers_config}
    */
    readonly headersConfig: AwsCloudfrontOriginRequestPolicy.HeadersConfigProperty;
    /**
    * query_strings_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#query_strings_config AwsCloudfrontOriginRequestPolicy#query_strings_config}
    */
    readonly queryStringsConfig: AwsCloudfrontOriginRequestPolicy.QueryStringsConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy aws_cloudfront_origin_request_policy}
*/
export declare class AwsCloudfrontOriginRequestPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_origin_request_policy";
    /**
    * Generates CDKTN code for importing a AwsCloudfrontOriginRequestPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCloudfrontOriginRequestPolicy to import
    * @param importFromId The id of the existing AwsCloudfrontOriginRequestPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCloudfrontOriginRequestPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy aws_cloudfront_origin_request_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCloudfrontOriginRequestPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsCloudfrontOriginRequestPolicyConfig);
    get arn(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _cookiesConfig;
    get cookiesConfig(): AwsCloudfrontOriginRequestPolicy.CookiesConfigPropertyOutputReference;
    putCookiesConfig(value: AwsCloudfrontOriginRequestPolicy.CookiesConfigProperty): void;
    get cookiesConfigInput(): AwsCloudfrontOriginRequestPolicy.CookiesConfigProperty | undefined;
    private _headersConfig;
    get headersConfig(): AwsCloudfrontOriginRequestPolicy.HeadersConfigPropertyOutputReference;
    putHeadersConfig(value: AwsCloudfrontOriginRequestPolicy.HeadersConfigProperty): void;
    get headersConfigInput(): AwsCloudfrontOriginRequestPolicy.HeadersConfigProperty | undefined;
    private _queryStringsConfig;
    get queryStringsConfig(): AwsCloudfrontOriginRequestPolicy.QueryStringsConfigPropertyOutputReference;
    putQueryStringsConfig(value: AwsCloudfrontOriginRequestPolicy.QueryStringsConfigProperty): void;
    get queryStringsConfigInput(): AwsCloudfrontOriginRequestPolicy.QueryStringsConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCloudfrontOriginRequestPolicyCookiesPropertyToTerraform(struct?: AwsCloudfrontOriginRequestPolicy.CookiesPropertyOutputReference | AwsCloudfrontOriginRequestPolicy.CookiesProperty): any;
export declare function awsCloudfrontOriginRequestPolicyCookiesPropertyToHclTerraform(struct?: AwsCloudfrontOriginRequestPolicy.CookiesPropertyOutputReference | AwsCloudfrontOriginRequestPolicy.CookiesProperty): any;
export declare function awsCloudfrontOriginRequestPolicyCookiesConfigPropertyToTerraform(struct?: AwsCloudfrontOriginRequestPolicy.CookiesConfigPropertyOutputReference | AwsCloudfrontOriginRequestPolicy.CookiesConfigProperty): any;
export declare function awsCloudfrontOriginRequestPolicyCookiesConfigPropertyToHclTerraform(struct?: AwsCloudfrontOriginRequestPolicy.CookiesConfigPropertyOutputReference | AwsCloudfrontOriginRequestPolicy.CookiesConfigProperty): any;
export declare function awsCloudfrontOriginRequestPolicyHeadersPropertyToTerraform(struct?: AwsCloudfrontOriginRequestPolicy.HeadersPropertyOutputReference | AwsCloudfrontOriginRequestPolicy.HeadersProperty): any;
export declare function awsCloudfrontOriginRequestPolicyHeadersPropertyToHclTerraform(struct?: AwsCloudfrontOriginRequestPolicy.HeadersPropertyOutputReference | AwsCloudfrontOriginRequestPolicy.HeadersProperty): any;
export declare function awsCloudfrontOriginRequestPolicyHeadersConfigPropertyToTerraform(struct?: AwsCloudfrontOriginRequestPolicy.HeadersConfigPropertyOutputReference | AwsCloudfrontOriginRequestPolicy.HeadersConfigProperty): any;
export declare function awsCloudfrontOriginRequestPolicyHeadersConfigPropertyToHclTerraform(struct?: AwsCloudfrontOriginRequestPolicy.HeadersConfigPropertyOutputReference | AwsCloudfrontOriginRequestPolicy.HeadersConfigProperty): any;
export declare function awsCloudfrontOriginRequestPolicyQueryStringsPropertyToTerraform(struct?: AwsCloudfrontOriginRequestPolicy.QueryStringsPropertyOutputReference | AwsCloudfrontOriginRequestPolicy.QueryStringsProperty): any;
export declare function awsCloudfrontOriginRequestPolicyQueryStringsPropertyToHclTerraform(struct?: AwsCloudfrontOriginRequestPolicy.QueryStringsPropertyOutputReference | AwsCloudfrontOriginRequestPolicy.QueryStringsProperty): any;
export declare function awsCloudfrontOriginRequestPolicyQueryStringsConfigPropertyToTerraform(struct?: AwsCloudfrontOriginRequestPolicy.QueryStringsConfigPropertyOutputReference | AwsCloudfrontOriginRequestPolicy.QueryStringsConfigProperty): any;
export declare function awsCloudfrontOriginRequestPolicyQueryStringsConfigPropertyToHclTerraform(struct?: AwsCloudfrontOriginRequestPolicy.QueryStringsConfigPropertyOutputReference | AwsCloudfrontOriginRequestPolicy.QueryStringsConfigProperty): any;
export declare namespace AwsCloudfrontOriginRequestPolicy {
    interface CookiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#items AwsCloudfrontOriginRequestPolicy#items}
        */
        readonly items?: string[];
    }
    class CookiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CookiesProperty | undefined;
        set internalValue(value: CookiesProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface CookiesConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#cookie_behavior AwsCloudfrontOriginRequestPolicy#cookie_behavior}
        */
        readonly cookieBehavior: string;
        /**
        * cookies block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#cookies AwsCloudfrontOriginRequestPolicy#cookies}
        */
        readonly cookies?: CookiesProperty;
    }
    class CookiesConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CookiesConfigProperty | undefined;
        set internalValue(value: CookiesConfigProperty | undefined);
        private _cookieBehavior?;
        get cookieBehavior(): string;
        set cookieBehavior(value: string);
        get cookieBehaviorInput(): string | undefined;
        private _cookies;
        get cookies(): CookiesPropertyOutputReference;
        putCookies(value: CookiesProperty): void;
        resetCookies(): void;
        get cookiesInput(): CookiesProperty | undefined;
    }
    interface HeadersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#items AwsCloudfrontOriginRequestPolicy#items}
        */
        readonly items?: string[];
    }
    class HeadersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HeadersProperty | undefined;
        set internalValue(value: HeadersProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface HeadersConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#header_behavior AwsCloudfrontOriginRequestPolicy#header_behavior}
        */
        readonly headerBehavior?: string;
        /**
        * headers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#headers AwsCloudfrontOriginRequestPolicy#headers}
        */
        readonly headers?: HeadersProperty;
    }
    class HeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HeadersConfigProperty | undefined;
        set internalValue(value: HeadersConfigProperty | undefined);
        private _headerBehavior?;
        get headerBehavior(): string;
        set headerBehavior(value: string);
        resetHeaderBehavior(): void;
        get headerBehaviorInput(): string | undefined;
        private _headers;
        get headers(): HeadersPropertyOutputReference;
        putHeaders(value: HeadersProperty): void;
        resetHeaders(): void;
        get headersInput(): HeadersProperty | undefined;
    }
    interface QueryStringsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#items AwsCloudfrontOriginRequestPolicy#items}
        */
        readonly items?: string[];
    }
    class QueryStringsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QueryStringsProperty | undefined;
        set internalValue(value: QueryStringsProperty | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
    }
    interface QueryStringsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#query_string_behavior AwsCloudfrontOriginRequestPolicy#query_string_behavior}
        */
        readonly queryStringBehavior: string;
        /**
        * query_strings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_origin_request_policy#query_strings AwsCloudfrontOriginRequestPolicy#query_strings}
        */
        readonly queryStrings?: QueryStringsProperty;
    }
    class QueryStringsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QueryStringsConfigProperty | undefined;
        set internalValue(value: QueryStringsConfigProperty | undefined);
        private _queryStringBehavior?;
        get queryStringBehavior(): string;
        set queryStringBehavior(value: string);
        get queryStringBehaviorInput(): string | undefined;
        private _queryStrings;
        get queryStrings(): QueryStringsPropertyOutputReference;
        putQueryStrings(value: QueryStringsProperty): void;
        resetQueryStrings(): void;
        get queryStringsInput(): QueryStringsProperty | undefined;
    }
}
