import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCloudfrontOriginRequestPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_origin_request_policy#id DataAwsCloudfrontOriginRequestPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_origin_request_policy#name DataAwsCloudfrontOriginRequestPolicy#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_origin_request_policy aws_cloudfront_origin_request_policy}
*/
export declare class DataAwsCloudfrontOriginRequestPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cloudfront_origin_request_policy";
    /**
    * Generates CDKTN code for importing a DataAwsCloudfrontOriginRequestPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCloudfrontOriginRequestPolicy to import
    * @param importFromId The id of the existing DataAwsCloudfrontOriginRequestPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_origin_request_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCloudfrontOriginRequestPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_origin_request_policy aws_cloudfront_origin_request_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCloudfrontOriginRequestPolicyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsCloudfrontOriginRequestPolicyConfig);
    get arn(): string;
    get comment(): string;
    private _cookiesConfig;
    get cookiesConfig(): DataAwsCloudfrontOriginRequestPolicy.CookiesConfigPropertyList;
    get etag(): string;
    private _headersConfig;
    get headersConfig(): DataAwsCloudfrontOriginRequestPolicy.HeadersConfigPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _queryStringsConfig;
    get queryStringsConfig(): DataAwsCloudfrontOriginRequestPolicy.QueryStringsConfigPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsCloudfrontOriginRequestPolicyCookiesPropertyToTerraform(struct?: DataAwsCloudfrontOriginRequestPolicy.CookiesProperty): any;
export declare function dataAwsCloudfrontOriginRequestPolicyCookiesPropertyToHclTerraform(struct?: DataAwsCloudfrontOriginRequestPolicy.CookiesProperty): any;
export declare function dataAwsCloudfrontOriginRequestPolicyCookiesConfigPropertyToTerraform(struct?: DataAwsCloudfrontOriginRequestPolicy.CookiesConfigProperty): any;
export declare function dataAwsCloudfrontOriginRequestPolicyCookiesConfigPropertyToHclTerraform(struct?: DataAwsCloudfrontOriginRequestPolicy.CookiesConfigProperty): any;
export declare function dataAwsCloudfrontOriginRequestPolicyHeadersPropertyToTerraform(struct?: DataAwsCloudfrontOriginRequestPolicy.HeadersProperty): any;
export declare function dataAwsCloudfrontOriginRequestPolicyHeadersPropertyToHclTerraform(struct?: DataAwsCloudfrontOriginRequestPolicy.HeadersProperty): any;
export declare function dataAwsCloudfrontOriginRequestPolicyHeadersConfigPropertyToTerraform(struct?: DataAwsCloudfrontOriginRequestPolicy.HeadersConfigProperty): any;
export declare function dataAwsCloudfrontOriginRequestPolicyHeadersConfigPropertyToHclTerraform(struct?: DataAwsCloudfrontOriginRequestPolicy.HeadersConfigProperty): any;
export declare function dataAwsCloudfrontOriginRequestPolicyQueryStringsPropertyToTerraform(struct?: DataAwsCloudfrontOriginRequestPolicy.QueryStringsProperty): any;
export declare function dataAwsCloudfrontOriginRequestPolicyQueryStringsPropertyToHclTerraform(struct?: DataAwsCloudfrontOriginRequestPolicy.QueryStringsProperty): any;
export declare function dataAwsCloudfrontOriginRequestPolicyQueryStringsConfigPropertyToTerraform(struct?: DataAwsCloudfrontOriginRequestPolicy.QueryStringsConfigProperty): any;
export declare function dataAwsCloudfrontOriginRequestPolicyQueryStringsConfigPropertyToHclTerraform(struct?: DataAwsCloudfrontOriginRequestPolicy.QueryStringsConfigProperty): any;
export declare namespace DataAwsCloudfrontOriginRequestPolicy {
    interface CookiesProperty {
    }
    class CookiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CookiesProperty | undefined;
        set internalValue(value: CookiesProperty | undefined);
        get items(): string[];
    }
    class CookiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CookiesPropertyOutputReference;
    }
    interface CookiesConfigProperty {
    }
    class CookiesConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CookiesConfigProperty | undefined;
        set internalValue(value: CookiesConfigProperty | undefined);
        get cookieBehavior(): string;
        private _cookies;
        get cookies(): CookiesPropertyList;
    }
    class CookiesConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CookiesConfigPropertyOutputReference;
    }
    interface HeadersProperty {
    }
    class HeadersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HeadersProperty | undefined;
        set internalValue(value: HeadersProperty | undefined);
        get items(): string[];
    }
    class HeadersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HeadersPropertyOutputReference;
    }
    interface HeadersConfigProperty {
    }
    class HeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HeadersConfigProperty | undefined;
        set internalValue(value: HeadersConfigProperty | undefined);
        get headerBehavior(): string;
        private _headers;
        get headers(): HeadersPropertyList;
    }
    class HeadersConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HeadersConfigPropertyOutputReference;
    }
    interface QueryStringsProperty {
    }
    class QueryStringsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): QueryStringsProperty | undefined;
        set internalValue(value: QueryStringsProperty | undefined);
        get items(): string[];
    }
    class QueryStringsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): QueryStringsPropertyOutputReference;
    }
    interface QueryStringsConfigProperty {
    }
    class QueryStringsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): QueryStringsConfigProperty | undefined;
        set internalValue(value: QueryStringsConfigProperty | undefined);
        get queryStringBehavior(): string;
        private _queryStrings;
        get queryStrings(): QueryStringsPropertyList;
    }
    class QueryStringsConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): QueryStringsConfigPropertyOutputReference;
    }
}
