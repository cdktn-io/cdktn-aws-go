import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCloudfrontContinuousDeploymentPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy#enabled AwsCloudfrontContinuousDeploymentPolicy#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * staging_distribution_dns_names block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy#staging_distribution_dns_names AwsCloudfrontContinuousDeploymentPolicy#staging_distribution_dns_names}
    */
    readonly stagingDistributionDnsNames?: AwsCloudfrontContinuousDeploymentPolicy.StagingDistributionDnsNamesProperty[] | cdktn.IResolvable;
    /**
    * traffic_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy#traffic_config AwsCloudfrontContinuousDeploymentPolicy#traffic_config}
    */
    readonly trafficConfig?: AwsCloudfrontContinuousDeploymentPolicy.TrafficConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy aws_cloudfront_continuous_deployment_policy}
*/
export declare class AwsCloudfrontContinuousDeploymentPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_continuous_deployment_policy";
    /**
    * Generates CDKTN code for importing a AwsCloudfrontContinuousDeploymentPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCloudfrontContinuousDeploymentPolicy to import
    * @param importFromId The id of the existing AwsCloudfrontContinuousDeploymentPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCloudfrontContinuousDeploymentPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy aws_cloudfront_continuous_deployment_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCloudfrontContinuousDeploymentPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsCloudfrontContinuousDeploymentPolicyConfig);
    get arn(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get etag(): string;
    get id(): string;
    get lastModifiedTime(): string;
    private _stagingDistributionDnsNames;
    get stagingDistributionDnsNames(): AwsCloudfrontContinuousDeploymentPolicy.StagingDistributionDnsNamesPropertyList;
    putStagingDistributionDnsNames(value: AwsCloudfrontContinuousDeploymentPolicy.StagingDistributionDnsNamesProperty[] | cdktn.IResolvable): void;
    resetStagingDistributionDnsNames(): void;
    get stagingDistributionDnsNamesInput(): cdktn.IResolvable | AwsCloudfrontContinuousDeploymentPolicy.StagingDistributionDnsNamesProperty[] | undefined;
    private _trafficConfig;
    get trafficConfig(): AwsCloudfrontContinuousDeploymentPolicy.TrafficConfigPropertyList;
    putTrafficConfig(value: AwsCloudfrontContinuousDeploymentPolicy.TrafficConfigProperty[] | cdktn.IResolvable): void;
    resetTrafficConfig(): void;
    get trafficConfigInput(): cdktn.IResolvable | AwsCloudfrontContinuousDeploymentPolicy.TrafficConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCloudfrontContinuousDeploymentPolicyStagingDistributionDnsNamesPropertyToTerraform(struct?: AwsCloudfrontContinuousDeploymentPolicy.StagingDistributionDnsNamesProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontContinuousDeploymentPolicyStagingDistributionDnsNamesPropertyToHclTerraform(struct?: AwsCloudfrontContinuousDeploymentPolicy.StagingDistributionDnsNamesProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontContinuousDeploymentPolicySingleHeaderConfigPropertyToTerraform(struct?: AwsCloudfrontContinuousDeploymentPolicy.SingleHeaderConfigProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontContinuousDeploymentPolicySingleHeaderConfigPropertyToHclTerraform(struct?: AwsCloudfrontContinuousDeploymentPolicy.SingleHeaderConfigProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontContinuousDeploymentPolicySessionStickinessConfigPropertyToTerraform(struct?: AwsCloudfrontContinuousDeploymentPolicy.SessionStickinessConfigProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontContinuousDeploymentPolicySessionStickinessConfigPropertyToHclTerraform(struct?: AwsCloudfrontContinuousDeploymentPolicy.SessionStickinessConfigProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontContinuousDeploymentPolicySingleWeightConfigPropertyToTerraform(struct?: AwsCloudfrontContinuousDeploymentPolicy.SingleWeightConfigProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontContinuousDeploymentPolicySingleWeightConfigPropertyToHclTerraform(struct?: AwsCloudfrontContinuousDeploymentPolicy.SingleWeightConfigProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontContinuousDeploymentPolicyTrafficConfigPropertyToTerraform(struct?: AwsCloudfrontContinuousDeploymentPolicy.TrafficConfigProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontContinuousDeploymentPolicyTrafficConfigPropertyToHclTerraform(struct?: AwsCloudfrontContinuousDeploymentPolicy.TrafficConfigProperty | cdktn.IResolvable): any;
export declare namespace AwsCloudfrontContinuousDeploymentPolicy {
    interface StagingDistributionDnsNamesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy#items AwsCloudfrontContinuousDeploymentPolicy#items}
        */
        readonly items?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy#quantity AwsCloudfrontContinuousDeploymentPolicy#quantity}
        */
        readonly quantity: number;
    }
    class StagingDistributionDnsNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StagingDistributionDnsNamesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StagingDistributionDnsNamesProperty | cdktn.IResolvable | undefined);
        private _items?;
        get items(): string[];
        set items(value: string[]);
        resetItems(): void;
        get itemsInput(): string[] | undefined;
        private _quantity?;
        get quantity(): number;
        set quantity(value: number);
        get quantityInput(): number | undefined;
    }
    class StagingDistributionDnsNamesPropertyList extends cdktn.ComplexList {
        internalValue?: StagingDistributionDnsNamesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StagingDistributionDnsNamesPropertyOutputReference;
    }
    interface SingleHeaderConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy#header AwsCloudfrontContinuousDeploymentPolicy#header}
        */
        readonly header: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy#value AwsCloudfrontContinuousDeploymentPolicy#value}
        */
        readonly value: string;
    }
    class SingleHeaderConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SingleHeaderConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SingleHeaderConfigProperty | cdktn.IResolvable | undefined);
        private _header?;
        get header(): string;
        set header(value: string);
        get headerInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class SingleHeaderConfigPropertyList extends cdktn.ComplexList {
        internalValue?: SingleHeaderConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SingleHeaderConfigPropertyOutputReference;
    }
    interface SessionStickinessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy#idle_ttl AwsCloudfrontContinuousDeploymentPolicy#idle_ttl}
        */
        readonly idleTtl: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy#maximum_ttl AwsCloudfrontContinuousDeploymentPolicy#maximum_ttl}
        */
        readonly maximumTtl: number;
    }
    class SessionStickinessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SessionStickinessConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SessionStickinessConfigProperty | cdktn.IResolvable | undefined);
        private _idleTtl?;
        get idleTtl(): number;
        set idleTtl(value: number);
        get idleTtlInput(): number | undefined;
        private _maximumTtl?;
        get maximumTtl(): number;
        set maximumTtl(value: number);
        get maximumTtlInput(): number | undefined;
    }
    class SessionStickinessConfigPropertyList extends cdktn.ComplexList {
        internalValue?: SessionStickinessConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SessionStickinessConfigPropertyOutputReference;
    }
    interface SingleWeightConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy#weight AwsCloudfrontContinuousDeploymentPolicy#weight}
        */
        readonly weight: number;
        /**
        * session_stickiness_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy#session_stickiness_config AwsCloudfrontContinuousDeploymentPolicy#session_stickiness_config}
        */
        readonly sessionStickinessConfig?: SessionStickinessConfigProperty[] | cdktn.IResolvable;
    }
    class SingleWeightConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SingleWeightConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SingleWeightConfigProperty | cdktn.IResolvable | undefined);
        private _weight?;
        get weight(): number;
        set weight(value: number);
        get weightInput(): number | undefined;
        private _sessionStickinessConfig;
        get sessionStickinessConfig(): SessionStickinessConfigPropertyList;
        putSessionStickinessConfig(value: SessionStickinessConfigProperty[] | cdktn.IResolvable): void;
        resetSessionStickinessConfig(): void;
        get sessionStickinessConfigInput(): cdktn.IResolvable | SessionStickinessConfigProperty[] | undefined;
    }
    class SingleWeightConfigPropertyList extends cdktn.ComplexList {
        internalValue?: SingleWeightConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SingleWeightConfigPropertyOutputReference;
    }
    interface TrafficConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy#type AwsCloudfrontContinuousDeploymentPolicy#type}
        */
        readonly type: string;
        /**
        * single_header_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy#single_header_config AwsCloudfrontContinuousDeploymentPolicy#single_header_config}
        */
        readonly singleHeaderConfig?: SingleHeaderConfigProperty[] | cdktn.IResolvable;
        /**
        * single_weight_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_continuous_deployment_policy#single_weight_config AwsCloudfrontContinuousDeploymentPolicy#single_weight_config}
        */
        readonly singleWeightConfig?: SingleWeightConfigProperty[] | cdktn.IResolvable;
    }
    class TrafficConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrafficConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrafficConfigProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _singleHeaderConfig;
        get singleHeaderConfig(): SingleHeaderConfigPropertyList;
        putSingleHeaderConfig(value: SingleHeaderConfigProperty[] | cdktn.IResolvable): void;
        resetSingleHeaderConfig(): void;
        get singleHeaderConfigInput(): cdktn.IResolvable | SingleHeaderConfigProperty[] | undefined;
        private _singleWeightConfig;
        get singleWeightConfig(): SingleWeightConfigPropertyList;
        putSingleWeightConfig(value: SingleWeightConfigProperty[] | cdktn.IResolvable): void;
        resetSingleWeightConfig(): void;
        get singleWeightConfigInput(): cdktn.IResolvable | SingleWeightConfigProperty[] | undefined;
    }
    class TrafficConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrafficConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrafficConfigPropertyOutputReference;
    }
}
