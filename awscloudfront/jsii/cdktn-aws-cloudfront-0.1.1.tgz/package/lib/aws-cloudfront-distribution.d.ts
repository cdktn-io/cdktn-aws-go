import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCloudfrontDistributionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#aliases AwsCloudfrontDistribution#aliases}
    */
    readonly aliases?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#anycast_ip_list_id AwsCloudfrontDistribution#anycast_ip_list_id}
    */
    readonly anycastIpListId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#comment AwsCloudfrontDistribution#comment}
    */
    readonly comment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#continuous_deployment_policy_id AwsCloudfrontDistribution#continuous_deployment_policy_id}
    */
    readonly continuousDeploymentPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#default_root_object AwsCloudfrontDistribution#default_root_object}
    */
    readonly defaultRootObject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#enabled AwsCloudfrontDistribution#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#http_version AwsCloudfrontDistribution#http_version}
    */
    readonly httpVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#id AwsCloudfrontDistribution#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#is_ipv6_enabled AwsCloudfrontDistribution#is_ipv6_enabled}
    */
    readonly isIpv6Enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#price_class AwsCloudfrontDistribution#price_class}
    */
    readonly priceClass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#retain_on_delete AwsCloudfrontDistribution#retain_on_delete}
    */
    readonly retainOnDelete?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#staging AwsCloudfrontDistribution#staging}
    */
    readonly staging?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#tags AwsCloudfrontDistribution#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#tags_all AwsCloudfrontDistribution#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#wait_for_deployment AwsCloudfrontDistribution#wait_for_deployment}
    */
    readonly waitForDeployment?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#web_acl_id AwsCloudfrontDistribution#web_acl_id}
    */
    readonly webAclId?: string;
    /**
    * cache_tag_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cache_tag_config AwsCloudfrontDistribution#cache_tag_config}
    */
    readonly cacheTagConfig?: AwsCloudfrontDistribution.CacheTagConfigProperty;
    /**
    * connection_function_association block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#connection_function_association AwsCloudfrontDistribution#connection_function_association}
    */
    readonly connectionFunctionAssociation?: AwsCloudfrontDistribution.ConnectionFunctionAssociationProperty;
    /**
    * custom_error_response block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#custom_error_response AwsCloudfrontDistribution#custom_error_response}
    */
    readonly customErrorResponse?: AwsCloudfrontDistribution.CustomErrorResponseProperty[] | cdktn.IResolvable;
    /**
    * default_cache_behavior block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#default_cache_behavior AwsCloudfrontDistribution#default_cache_behavior}
    */
    readonly defaultCacheBehavior: AwsCloudfrontDistribution.DefaultCacheBehaviorProperty;
    /**
    * logging_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#logging_config AwsCloudfrontDistribution#logging_config}
    */
    readonly loggingConfig?: AwsCloudfrontDistribution.LoggingConfigProperty;
    /**
    * ordered_cache_behavior block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#ordered_cache_behavior AwsCloudfrontDistribution#ordered_cache_behavior}
    */
    readonly orderedCacheBehavior?: AwsCloudfrontDistribution.OrderedCacheBehaviorProperty[] | cdktn.IResolvable;
    /**
    * origin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin AwsCloudfrontDistribution#origin}
    */
    readonly origin: AwsCloudfrontDistribution.OriginProperty[] | cdktn.IResolvable;
    /**
    * origin_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_group AwsCloudfrontDistribution#origin_group}
    */
    readonly originGroup?: AwsCloudfrontDistribution.OriginGroupProperty[] | cdktn.IResolvable;
    /**
    * restrictions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#restrictions AwsCloudfrontDistribution#restrictions}
    */
    readonly restrictions: AwsCloudfrontDistribution.RestrictionsProperty;
    /**
    * viewer_certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#viewer_certificate AwsCloudfrontDistribution#viewer_certificate}
    */
    readonly viewerCertificate: AwsCloudfrontDistribution.ViewerCertificateProperty;
    /**
    * viewer_mtls_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#viewer_mtls_config AwsCloudfrontDistribution#viewer_mtls_config}
    */
    readonly viewerMtlsConfig?: AwsCloudfrontDistribution.ViewerMtlsConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution aws_cloudfront_distribution}
*/
export declare class AwsCloudfrontDistribution extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudfront_distribution";
    /**
    * Generates CDKTN code for importing a AwsCloudfrontDistribution resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCloudfrontDistribution to import
    * @param importFromId The id of the existing AwsCloudfrontDistribution that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCloudfrontDistribution to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution aws_cloudfront_distribution} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCloudfrontDistributionConfig
    */
    constructor(scope: Construct, id: string, config: AwsCloudfrontDistributionConfig);
    private _aliases?;
    get aliases(): string[];
    set aliases(value: string[]);
    resetAliases(): void;
    get aliasesInput(): string[] | undefined;
    private _anycastIpListId?;
    get anycastIpListId(): string;
    set anycastIpListId(value: string);
    resetAnycastIpListId(): void;
    get anycastIpListIdInput(): string | undefined;
    get arn(): string;
    get callerReference(): string;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    private _continuousDeploymentPolicyId?;
    get continuousDeploymentPolicyId(): string;
    set continuousDeploymentPolicyId(value: string);
    resetContinuousDeploymentPolicyId(): void;
    get continuousDeploymentPolicyIdInput(): string | undefined;
    private _defaultRootObject?;
    get defaultRootObject(): string;
    set defaultRootObject(value: string);
    resetDefaultRootObject(): void;
    get defaultRootObjectInput(): string | undefined;
    get domainName(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get etag(): string;
    get hostedZoneId(): string;
    private _httpVersion?;
    get httpVersion(): string;
    set httpVersion(value: string);
    resetHttpVersion(): void;
    get httpVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get inProgressValidationBatches(): number;
    private _isIpv6Enabled?;
    get isIpv6Enabled(): boolean | cdktn.IResolvable;
    set isIpv6Enabled(value: boolean | cdktn.IResolvable);
    resetIsIpv6Enabled(): void;
    get isIpv6EnabledInput(): boolean | cdktn.IResolvable | undefined;
    get lastModifiedTime(): string;
    get loggingV1Enabled(): cdktn.IResolvable;
    private _priceClass?;
    get priceClass(): string;
    set priceClass(value: string);
    resetPriceClass(): void;
    get priceClassInput(): string | undefined;
    private _retainOnDelete?;
    get retainOnDelete(): boolean | cdktn.IResolvable;
    set retainOnDelete(value: boolean | cdktn.IResolvable);
    resetRetainOnDelete(): void;
    get retainOnDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _staging?;
    get staging(): boolean | cdktn.IResolvable;
    set staging(value: boolean | cdktn.IResolvable);
    resetStaging(): void;
    get stagingInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _trustedKeyGroups;
    get trustedKeyGroups(): AwsCloudfrontDistribution.TrustedKeyGroupsPropertyList;
    private _trustedSigners;
    get trustedSigners(): AwsCloudfrontDistribution.TrustedSignersPropertyList;
    private _waitForDeployment?;
    get waitForDeployment(): boolean | cdktn.IResolvable;
    set waitForDeployment(value: boolean | cdktn.IResolvable);
    resetWaitForDeployment(): void;
    get waitForDeploymentInput(): boolean | cdktn.IResolvable | undefined;
    private _webAclId?;
    get webAclId(): string;
    set webAclId(value: string);
    resetWebAclId(): void;
    get webAclIdInput(): string | undefined;
    private _cacheTagConfig;
    get cacheTagConfig(): AwsCloudfrontDistribution.CacheTagConfigPropertyOutputReference;
    putCacheTagConfig(value: AwsCloudfrontDistribution.CacheTagConfigProperty): void;
    resetCacheTagConfig(): void;
    get cacheTagConfigInput(): AwsCloudfrontDistribution.CacheTagConfigProperty | undefined;
    private _connectionFunctionAssociation;
    get connectionFunctionAssociation(): AwsCloudfrontDistribution.ConnectionFunctionAssociationPropertyOutputReference;
    putConnectionFunctionAssociation(value: AwsCloudfrontDistribution.ConnectionFunctionAssociationProperty): void;
    resetConnectionFunctionAssociation(): void;
    get connectionFunctionAssociationInput(): AwsCloudfrontDistribution.ConnectionFunctionAssociationProperty | undefined;
    private _customErrorResponse;
    get customErrorResponse(): AwsCloudfrontDistribution.CustomErrorResponsePropertyList;
    putCustomErrorResponse(value: AwsCloudfrontDistribution.CustomErrorResponseProperty[] | cdktn.IResolvable): void;
    resetCustomErrorResponse(): void;
    get customErrorResponseInput(): cdktn.IResolvable | AwsCloudfrontDistribution.CustomErrorResponseProperty[] | undefined;
    private _defaultCacheBehavior;
    get defaultCacheBehavior(): AwsCloudfrontDistribution.DefaultCacheBehaviorPropertyOutputReference;
    putDefaultCacheBehavior(value: AwsCloudfrontDistribution.DefaultCacheBehaviorProperty): void;
    get defaultCacheBehaviorInput(): AwsCloudfrontDistribution.DefaultCacheBehaviorProperty | undefined;
    private _loggingConfig;
    get loggingConfig(): AwsCloudfrontDistribution.LoggingConfigPropertyOutputReference;
    putLoggingConfig(value: AwsCloudfrontDistribution.LoggingConfigProperty): void;
    resetLoggingConfig(): void;
    get loggingConfigInput(): AwsCloudfrontDistribution.LoggingConfigProperty | undefined;
    private _orderedCacheBehavior;
    get orderedCacheBehavior(): AwsCloudfrontDistribution.OrderedCacheBehaviorPropertyList;
    putOrderedCacheBehavior(value: AwsCloudfrontDistribution.OrderedCacheBehaviorProperty[] | cdktn.IResolvable): void;
    resetOrderedCacheBehavior(): void;
    get orderedCacheBehaviorInput(): cdktn.IResolvable | AwsCloudfrontDistribution.OrderedCacheBehaviorProperty[] | undefined;
    private _origin;
    get origin(): AwsCloudfrontDistribution.OriginPropertyList;
    putOrigin(value: AwsCloudfrontDistribution.OriginProperty[] | cdktn.IResolvable): void;
    get originInput(): cdktn.IResolvable | AwsCloudfrontDistribution.OriginProperty[] | undefined;
    private _originGroup;
    get originGroup(): AwsCloudfrontDistribution.OriginGroupPropertyList;
    putOriginGroup(value: AwsCloudfrontDistribution.OriginGroupProperty[] | cdktn.IResolvable): void;
    resetOriginGroup(): void;
    get originGroupInput(): cdktn.IResolvable | AwsCloudfrontDistribution.OriginGroupProperty[] | undefined;
    private _restrictions;
    get restrictions(): AwsCloudfrontDistribution.RestrictionsPropertyOutputReference;
    putRestrictions(value: AwsCloudfrontDistribution.RestrictionsProperty): void;
    get restrictionsInput(): AwsCloudfrontDistribution.RestrictionsProperty | undefined;
    private _viewerCertificate;
    get viewerCertificate(): AwsCloudfrontDistribution.ViewerCertificatePropertyOutputReference;
    putViewerCertificate(value: AwsCloudfrontDistribution.ViewerCertificateProperty): void;
    get viewerCertificateInput(): AwsCloudfrontDistribution.ViewerCertificateProperty | undefined;
    private _viewerMtlsConfig;
    get viewerMtlsConfig(): AwsCloudfrontDistribution.ViewerMtlsConfigPropertyOutputReference;
    putViewerMtlsConfig(value: AwsCloudfrontDistribution.ViewerMtlsConfigProperty): void;
    resetViewerMtlsConfig(): void;
    get viewerMtlsConfigInput(): AwsCloudfrontDistribution.ViewerMtlsConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCloudfrontDistributionTrustedKeyGroupsItemsPropertyToTerraform(struct?: AwsCloudfrontDistribution.TrustedKeyGroupsItemsProperty): any;
export declare function awsCloudfrontDistributionTrustedKeyGroupsItemsPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.TrustedKeyGroupsItemsProperty): any;
export declare function awsCloudfrontDistributionTrustedKeyGroupsPropertyToTerraform(struct?: AwsCloudfrontDistribution.TrustedKeyGroupsProperty): any;
export declare function awsCloudfrontDistributionTrustedKeyGroupsPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.TrustedKeyGroupsProperty): any;
export declare function awsCloudfrontDistributionTrustedSignersItemsPropertyToTerraform(struct?: AwsCloudfrontDistribution.TrustedSignersItemsProperty): any;
export declare function awsCloudfrontDistributionTrustedSignersItemsPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.TrustedSignersItemsProperty): any;
export declare function awsCloudfrontDistributionTrustedSignersPropertyToTerraform(struct?: AwsCloudfrontDistribution.TrustedSignersProperty): any;
export declare function awsCloudfrontDistributionTrustedSignersPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.TrustedSignersProperty): any;
export declare function awsCloudfrontDistributionCacheTagConfigPropertyToTerraform(struct?: AwsCloudfrontDistribution.CacheTagConfigPropertyOutputReference | AwsCloudfrontDistribution.CacheTagConfigProperty): any;
export declare function awsCloudfrontDistributionCacheTagConfigPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.CacheTagConfigPropertyOutputReference | AwsCloudfrontDistribution.CacheTagConfigProperty): any;
export declare function awsCloudfrontDistributionConnectionFunctionAssociationPropertyToTerraform(struct?: AwsCloudfrontDistribution.ConnectionFunctionAssociationPropertyOutputReference | AwsCloudfrontDistribution.ConnectionFunctionAssociationProperty): any;
export declare function awsCloudfrontDistributionConnectionFunctionAssociationPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.ConnectionFunctionAssociationPropertyOutputReference | AwsCloudfrontDistribution.ConnectionFunctionAssociationProperty): any;
export declare function awsCloudfrontDistributionCustomErrorResponsePropertyToTerraform(struct?: AwsCloudfrontDistribution.CustomErrorResponseProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionCustomErrorResponsePropertyToHclTerraform(struct?: AwsCloudfrontDistribution.CustomErrorResponseProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionDefaultCacheBehaviorForwardedValuesCookiesPropertyToTerraform(struct?: AwsCloudfrontDistribution.DefaultCacheBehaviorForwardedValuesCookiesPropertyOutputReference | AwsCloudfrontDistribution.DefaultCacheBehaviorForwardedValuesCookiesProperty): any;
export declare function awsCloudfrontDistributionDefaultCacheBehaviorForwardedValuesCookiesPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.DefaultCacheBehaviorForwardedValuesCookiesPropertyOutputReference | AwsCloudfrontDistribution.DefaultCacheBehaviorForwardedValuesCookiesProperty): any;
export declare function awsCloudfrontDistributionDefaultCacheBehaviorForwardedValuesPropertyToTerraform(struct?: AwsCloudfrontDistribution.DefaultCacheBehaviorForwardedValuesPropertyOutputReference | AwsCloudfrontDistribution.DefaultCacheBehaviorForwardedValuesProperty): any;
export declare function awsCloudfrontDistributionDefaultCacheBehaviorForwardedValuesPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.DefaultCacheBehaviorForwardedValuesPropertyOutputReference | AwsCloudfrontDistribution.DefaultCacheBehaviorForwardedValuesProperty): any;
export declare function awsCloudfrontDistributionDefaultCacheBehaviorFunctionAssociationPropertyToTerraform(struct?: AwsCloudfrontDistribution.DefaultCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionDefaultCacheBehaviorFunctionAssociationPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.DefaultCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionDefaultCacheBehaviorGrpcConfigPropertyToTerraform(struct?: AwsCloudfrontDistribution.DefaultCacheBehaviorGrpcConfigPropertyOutputReference | AwsCloudfrontDistribution.DefaultCacheBehaviorGrpcConfigProperty): any;
export declare function awsCloudfrontDistributionDefaultCacheBehaviorGrpcConfigPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.DefaultCacheBehaviorGrpcConfigPropertyOutputReference | AwsCloudfrontDistribution.DefaultCacheBehaviorGrpcConfigProperty): any;
export declare function awsCloudfrontDistributionDefaultCacheBehaviorLambdaFunctionAssociationPropertyToTerraform(struct?: AwsCloudfrontDistribution.DefaultCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionDefaultCacheBehaviorLambdaFunctionAssociationPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.DefaultCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionDefaultCacheBehaviorPropertyToTerraform(struct?: AwsCloudfrontDistribution.DefaultCacheBehaviorPropertyOutputReference | AwsCloudfrontDistribution.DefaultCacheBehaviorProperty): any;
export declare function awsCloudfrontDistributionDefaultCacheBehaviorPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.DefaultCacheBehaviorPropertyOutputReference | AwsCloudfrontDistribution.DefaultCacheBehaviorProperty): any;
export declare function awsCloudfrontDistributionLoggingConfigPropertyToTerraform(struct?: AwsCloudfrontDistribution.LoggingConfigPropertyOutputReference | AwsCloudfrontDistribution.LoggingConfigProperty): any;
export declare function awsCloudfrontDistributionLoggingConfigPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.LoggingConfigPropertyOutputReference | AwsCloudfrontDistribution.LoggingConfigProperty): any;
export declare function awsCloudfrontDistributionOrderedCacheBehaviorForwardedValuesCookiesPropertyToTerraform(struct?: AwsCloudfrontDistribution.OrderedCacheBehaviorForwardedValuesCookiesPropertyOutputReference | AwsCloudfrontDistribution.OrderedCacheBehaviorForwardedValuesCookiesProperty): any;
export declare function awsCloudfrontDistributionOrderedCacheBehaviorForwardedValuesCookiesPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.OrderedCacheBehaviorForwardedValuesCookiesPropertyOutputReference | AwsCloudfrontDistribution.OrderedCacheBehaviorForwardedValuesCookiesProperty): any;
export declare function awsCloudfrontDistributionOrderedCacheBehaviorForwardedValuesPropertyToTerraform(struct?: AwsCloudfrontDistribution.OrderedCacheBehaviorForwardedValuesPropertyOutputReference | AwsCloudfrontDistribution.OrderedCacheBehaviorForwardedValuesProperty): any;
export declare function awsCloudfrontDistributionOrderedCacheBehaviorForwardedValuesPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.OrderedCacheBehaviorForwardedValuesPropertyOutputReference | AwsCloudfrontDistribution.OrderedCacheBehaviorForwardedValuesProperty): any;
export declare function awsCloudfrontDistributionOrderedCacheBehaviorFunctionAssociationPropertyToTerraform(struct?: AwsCloudfrontDistribution.OrderedCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionOrderedCacheBehaviorFunctionAssociationPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.OrderedCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionOrderedCacheBehaviorGrpcConfigPropertyToTerraform(struct?: AwsCloudfrontDistribution.OrderedCacheBehaviorGrpcConfigPropertyOutputReference | AwsCloudfrontDistribution.OrderedCacheBehaviorGrpcConfigProperty): any;
export declare function awsCloudfrontDistributionOrderedCacheBehaviorGrpcConfigPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.OrderedCacheBehaviorGrpcConfigPropertyOutputReference | AwsCloudfrontDistribution.OrderedCacheBehaviorGrpcConfigProperty): any;
export declare function awsCloudfrontDistributionOrderedCacheBehaviorLambdaFunctionAssociationPropertyToTerraform(struct?: AwsCloudfrontDistribution.OrderedCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionOrderedCacheBehaviorLambdaFunctionAssociationPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.OrderedCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionOrderedCacheBehaviorPropertyToTerraform(struct?: AwsCloudfrontDistribution.OrderedCacheBehaviorProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionOrderedCacheBehaviorPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.OrderedCacheBehaviorProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionCustomHeaderPropertyToTerraform(struct?: AwsCloudfrontDistribution.CustomHeaderProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionCustomHeaderPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.CustomHeaderProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionOriginMtlsConfigPropertyToTerraform(struct?: AwsCloudfrontDistribution.OriginMtlsConfigPropertyOutputReference | AwsCloudfrontDistribution.OriginMtlsConfigProperty): any;
export declare function awsCloudfrontDistributionOriginMtlsConfigPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.OriginMtlsConfigPropertyOutputReference | AwsCloudfrontDistribution.OriginMtlsConfigProperty): any;
export declare function awsCloudfrontDistributionCustomOriginConfigPropertyToTerraform(struct?: AwsCloudfrontDistribution.CustomOriginConfigPropertyOutputReference | AwsCloudfrontDistribution.CustomOriginConfigProperty): any;
export declare function awsCloudfrontDistributionCustomOriginConfigPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.CustomOriginConfigPropertyOutputReference | AwsCloudfrontDistribution.CustomOriginConfigProperty): any;
export declare function awsCloudfrontDistributionOriginShieldPropertyToTerraform(struct?: AwsCloudfrontDistribution.OriginShieldPropertyOutputReference | AwsCloudfrontDistribution.OriginShieldProperty): any;
export declare function awsCloudfrontDistributionOriginShieldPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.OriginShieldPropertyOutputReference | AwsCloudfrontDistribution.OriginShieldProperty): any;
export declare function awsCloudfrontDistributionS3OriginConfigPropertyToTerraform(struct?: AwsCloudfrontDistribution.S3OriginConfigPropertyOutputReference | AwsCloudfrontDistribution.S3OriginConfigProperty): any;
export declare function awsCloudfrontDistributionS3OriginConfigPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.S3OriginConfigPropertyOutputReference | AwsCloudfrontDistribution.S3OriginConfigProperty): any;
export declare function awsCloudfrontDistributionVpcOriginConfigPropertyToTerraform(struct?: AwsCloudfrontDistribution.VpcOriginConfigPropertyOutputReference | AwsCloudfrontDistribution.VpcOriginConfigProperty): any;
export declare function awsCloudfrontDistributionVpcOriginConfigPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.VpcOriginConfigPropertyOutputReference | AwsCloudfrontDistribution.VpcOriginConfigProperty): any;
export declare function awsCloudfrontDistributionOriginPropertyToTerraform(struct?: AwsCloudfrontDistribution.OriginProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionOriginPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.OriginProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionFailoverCriteriaPropertyToTerraform(struct?: AwsCloudfrontDistribution.FailoverCriteriaPropertyOutputReference | AwsCloudfrontDistribution.FailoverCriteriaProperty): any;
export declare function awsCloudfrontDistributionFailoverCriteriaPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.FailoverCriteriaPropertyOutputReference | AwsCloudfrontDistribution.FailoverCriteriaProperty): any;
export declare function awsCloudfrontDistributionMemberPropertyToTerraform(struct?: AwsCloudfrontDistribution.MemberProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionMemberPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.MemberProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionOriginGroupPropertyToTerraform(struct?: AwsCloudfrontDistribution.OriginGroupProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionOriginGroupPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.OriginGroupProperty | cdktn.IResolvable): any;
export declare function awsCloudfrontDistributionGeoRestrictionPropertyToTerraform(struct?: AwsCloudfrontDistribution.GeoRestrictionPropertyOutputReference | AwsCloudfrontDistribution.GeoRestrictionProperty): any;
export declare function awsCloudfrontDistributionGeoRestrictionPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.GeoRestrictionPropertyOutputReference | AwsCloudfrontDistribution.GeoRestrictionProperty): any;
export declare function awsCloudfrontDistributionRestrictionsPropertyToTerraform(struct?: AwsCloudfrontDistribution.RestrictionsPropertyOutputReference | AwsCloudfrontDistribution.RestrictionsProperty): any;
export declare function awsCloudfrontDistributionRestrictionsPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.RestrictionsPropertyOutputReference | AwsCloudfrontDistribution.RestrictionsProperty): any;
export declare function awsCloudfrontDistributionViewerCertificatePropertyToTerraform(struct?: AwsCloudfrontDistribution.ViewerCertificatePropertyOutputReference | AwsCloudfrontDistribution.ViewerCertificateProperty): any;
export declare function awsCloudfrontDistributionViewerCertificatePropertyToHclTerraform(struct?: AwsCloudfrontDistribution.ViewerCertificatePropertyOutputReference | AwsCloudfrontDistribution.ViewerCertificateProperty): any;
export declare function awsCloudfrontDistributionTrustStoreConfigPropertyToTerraform(struct?: AwsCloudfrontDistribution.TrustStoreConfigPropertyOutputReference | AwsCloudfrontDistribution.TrustStoreConfigProperty): any;
export declare function awsCloudfrontDistributionTrustStoreConfigPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.TrustStoreConfigPropertyOutputReference | AwsCloudfrontDistribution.TrustStoreConfigProperty): any;
export declare function awsCloudfrontDistributionViewerMtlsConfigPropertyToTerraform(struct?: AwsCloudfrontDistribution.ViewerMtlsConfigPropertyOutputReference | AwsCloudfrontDistribution.ViewerMtlsConfigProperty): any;
export declare function awsCloudfrontDistributionViewerMtlsConfigPropertyToHclTerraform(struct?: AwsCloudfrontDistribution.ViewerMtlsConfigPropertyOutputReference | AwsCloudfrontDistribution.ViewerMtlsConfigProperty): any;
export declare namespace AwsCloudfrontDistribution {
    interface TrustedKeyGroupsItemsProperty {
    }
    class TrustedKeyGroupsItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrustedKeyGroupsItemsProperty | undefined;
        set internalValue(value: TrustedKeyGroupsItemsProperty | undefined);
        get keyGroupId(): string;
        get keyPairIds(): string[];
    }
    class TrustedKeyGroupsItemsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrustedKeyGroupsItemsPropertyOutputReference;
    }
    interface TrustedKeyGroupsProperty {
    }
    class TrustedKeyGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrustedKeyGroupsProperty | undefined;
        set internalValue(value: TrustedKeyGroupsProperty | undefined);
        get enabled(): cdktn.IResolvable;
        private _items;
        get items(): TrustedKeyGroupsItemsPropertyList;
    }
    class TrustedKeyGroupsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrustedKeyGroupsPropertyOutputReference;
    }
    interface TrustedSignersItemsProperty {
    }
    class TrustedSignersItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrustedSignersItemsProperty | undefined;
        set internalValue(value: TrustedSignersItemsProperty | undefined);
        get awsAccountNumber(): string;
        get keyPairIds(): string[];
    }
    class TrustedSignersItemsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrustedSignersItemsPropertyOutputReference;
    }
    interface TrustedSignersProperty {
    }
    class TrustedSignersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrustedSignersProperty | undefined;
        set internalValue(value: TrustedSignersProperty | undefined);
        get enabled(): cdktn.IResolvable;
        private _items;
        get items(): TrustedSignersItemsPropertyList;
    }
    class TrustedSignersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrustedSignersPropertyOutputReference;
    }
    interface CacheTagConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#header_name AwsCloudfrontDistribution#header_name}
        */
        readonly headerName: string;
    }
    class CacheTagConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CacheTagConfigProperty | undefined;
        set internalValue(value: CacheTagConfigProperty | undefined);
        private _headerName?;
        get headerName(): string;
        set headerName(value: string);
        get headerNameInput(): string | undefined;
    }
    interface ConnectionFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#id AwsCloudfrontDistribution#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
    }
    class ConnectionFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectionFunctionAssociationProperty | undefined;
        set internalValue(value: ConnectionFunctionAssociationProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
    }
    interface CustomErrorResponseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#error_caching_min_ttl AwsCloudfrontDistribution#error_caching_min_ttl}
        */
        readonly errorCachingMinTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#error_code AwsCloudfrontDistribution#error_code}
        */
        readonly errorCode: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#response_code AwsCloudfrontDistribution#response_code}
        */
        readonly responseCode?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#response_page_path AwsCloudfrontDistribution#response_page_path}
        */
        readonly responsePagePath?: string;
    }
    class CustomErrorResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomErrorResponseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomErrorResponseProperty | cdktn.IResolvable | undefined);
        private _errorCachingMinTtl?;
        get errorCachingMinTtl(): number;
        set errorCachingMinTtl(value: number);
        resetErrorCachingMinTtl(): void;
        get errorCachingMinTtlInput(): number | undefined;
        private _errorCode?;
        get errorCode(): number;
        set errorCode(value: number);
        get errorCodeInput(): number | undefined;
        private _responseCode?;
        get responseCode(): number;
        set responseCode(value: number);
        resetResponseCode(): void;
        get responseCodeInput(): number | undefined;
        private _responsePagePath?;
        get responsePagePath(): string;
        set responsePagePath(value: string);
        resetResponsePagePath(): void;
        get responsePagePathInput(): string | undefined;
    }
    class CustomErrorResponsePropertyList extends cdktn.ComplexList {
        internalValue?: CustomErrorResponseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomErrorResponsePropertyOutputReference;
    }
    interface DefaultCacheBehaviorForwardedValuesCookiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#forward AwsCloudfrontDistribution#forward}
        */
        readonly forward: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#whitelisted_names AwsCloudfrontDistribution#whitelisted_names}
        */
        readonly whitelistedNames?: string[];
    }
    class DefaultCacheBehaviorForwardedValuesCookiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultCacheBehaviorForwardedValuesCookiesProperty | undefined;
        set internalValue(value: DefaultCacheBehaviorForwardedValuesCookiesProperty | undefined);
        private _forward?;
        get forward(): string;
        set forward(value: string);
        get forwardInput(): string | undefined;
        private _whitelistedNames?;
        get whitelistedNames(): string[];
        set whitelistedNames(value: string[]);
        resetWhitelistedNames(): void;
        get whitelistedNamesInput(): string[] | undefined;
    }
    interface DefaultCacheBehaviorForwardedValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#headers AwsCloudfrontDistribution#headers}
        */
        readonly headers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#query_string AwsCloudfrontDistribution#query_string}
        */
        readonly queryString: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#query_string_cache_keys AwsCloudfrontDistribution#query_string_cache_keys}
        */
        readonly queryStringCacheKeys?: string[];
        /**
        * cookies block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cookies AwsCloudfrontDistribution#cookies}
        */
        readonly cookies: DefaultCacheBehaviorForwardedValuesCookiesProperty;
    }
    class DefaultCacheBehaviorForwardedValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultCacheBehaviorForwardedValuesProperty | undefined;
        set internalValue(value: DefaultCacheBehaviorForwardedValuesProperty | undefined);
        private _headers?;
        get headers(): string[];
        set headers(value: string[]);
        resetHeaders(): void;
        get headersInput(): string[] | undefined;
        private _queryString?;
        get queryString(): boolean | cdktn.IResolvable;
        set queryString(value: boolean | cdktn.IResolvable);
        get queryStringInput(): boolean | cdktn.IResolvable | undefined;
        private _queryStringCacheKeys?;
        get queryStringCacheKeys(): string[];
        set queryStringCacheKeys(value: string[]);
        resetQueryStringCacheKeys(): void;
        get queryStringCacheKeysInput(): string[] | undefined;
        private _cookies;
        get cookies(): DefaultCacheBehaviorForwardedValuesCookiesPropertyOutputReference;
        putCookies(value: DefaultCacheBehaviorForwardedValuesCookiesProperty): void;
        get cookiesInput(): DefaultCacheBehaviorForwardedValuesCookiesProperty | undefined;
    }
    interface DefaultCacheBehaviorFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#event_type AwsCloudfrontDistribution#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#function_arn AwsCloudfrontDistribution#function_arn}
        */
        readonly functionArn: string;
    }
    class DefaultCacheBehaviorFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable | undefined);
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
    }
    class DefaultCacheBehaviorFunctionAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultCacheBehaviorFunctionAssociationPropertyOutputReference;
    }
    interface DefaultCacheBehaviorGrpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#enabled AwsCloudfrontDistribution#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class DefaultCacheBehaviorGrpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultCacheBehaviorGrpcConfigProperty | undefined;
        set internalValue(value: DefaultCacheBehaviorGrpcConfigProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DefaultCacheBehaviorLambdaFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#event_type AwsCloudfrontDistribution#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#include_body AwsCloudfrontDistribution#include_body}
        */
        readonly includeBody?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#lambda_arn AwsCloudfrontDistribution#lambda_arn}
        */
        readonly lambdaArn: string;
    }
    class DefaultCacheBehaviorLambdaFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable | undefined);
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _includeBody?;
        get includeBody(): boolean | cdktn.IResolvable;
        set includeBody(value: boolean | cdktn.IResolvable);
        resetIncludeBody(): void;
        get includeBodyInput(): boolean | cdktn.IResolvable | undefined;
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
    }
    class DefaultCacheBehaviorLambdaFunctionAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultCacheBehaviorLambdaFunctionAssociationPropertyOutputReference;
    }
    interface DefaultCacheBehaviorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#allowed_methods AwsCloudfrontDistribution#allowed_methods}
        */
        readonly allowedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cache_policy_id AwsCloudfrontDistribution#cache_policy_id}
        */
        readonly cachePolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cached_methods AwsCloudfrontDistribution#cached_methods}
        */
        readonly cachedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#compress AwsCloudfrontDistribution#compress}
        */
        readonly compress?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#default_ttl AwsCloudfrontDistribution#default_ttl}
        */
        readonly defaultTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#field_level_encryption_id AwsCloudfrontDistribution#field_level_encryption_id}
        */
        readonly fieldLevelEncryptionId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#max_ttl AwsCloudfrontDistribution#max_ttl}
        */
        readonly maxTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#min_ttl AwsCloudfrontDistribution#min_ttl}
        */
        readonly minTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_request_policy_id AwsCloudfrontDistribution#origin_request_policy_id}
        */
        readonly originRequestPolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#realtime_log_config_arn AwsCloudfrontDistribution#realtime_log_config_arn}
        */
        readonly realtimeLogConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#response_headers_policy_id AwsCloudfrontDistribution#response_headers_policy_id}
        */
        readonly responseHeadersPolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#smooth_streaming AwsCloudfrontDistribution#smooth_streaming}
        */
        readonly smoothStreaming?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#target_origin_id AwsCloudfrontDistribution#target_origin_id}
        */
        readonly targetOriginId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trusted_key_groups AwsCloudfrontDistribution#trusted_key_groups}
        */
        readonly trustedKeyGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trusted_signers AwsCloudfrontDistribution#trusted_signers}
        */
        readonly trustedSigners?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#viewer_protocol_policy AwsCloudfrontDistribution#viewer_protocol_policy}
        */
        readonly viewerProtocolPolicy: string;
        /**
        * forwarded_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#forwarded_values AwsCloudfrontDistribution#forwarded_values}
        */
        readonly forwardedValues?: DefaultCacheBehaviorForwardedValuesProperty;
        /**
        * function_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#function_association AwsCloudfrontDistribution#function_association}
        */
        readonly functionAssociation?: DefaultCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * grpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#grpc_config AwsCloudfrontDistribution#grpc_config}
        */
        readonly grpcConfig?: DefaultCacheBehaviorGrpcConfigProperty;
        /**
        * lambda_function_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#lambda_function_association AwsCloudfrontDistribution#lambda_function_association}
        */
        readonly lambdaFunctionAssociation?: DefaultCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable;
    }
    class DefaultCacheBehaviorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultCacheBehaviorProperty | undefined;
        set internalValue(value: DefaultCacheBehaviorProperty | undefined);
        private _allowedMethods?;
        get allowedMethods(): string[];
        set allowedMethods(value: string[]);
        get allowedMethodsInput(): string[] | undefined;
        private _cachePolicyId?;
        get cachePolicyId(): string;
        set cachePolicyId(value: string);
        resetCachePolicyId(): void;
        get cachePolicyIdInput(): string | undefined;
        private _cachedMethods?;
        get cachedMethods(): string[];
        set cachedMethods(value: string[]);
        get cachedMethodsInput(): string[] | undefined;
        private _compress?;
        get compress(): boolean | cdktn.IResolvable;
        set compress(value: boolean | cdktn.IResolvable);
        resetCompress(): void;
        get compressInput(): boolean | cdktn.IResolvable | undefined;
        private _defaultTtl?;
        get defaultTtl(): number;
        set defaultTtl(value: number);
        resetDefaultTtl(): void;
        get defaultTtlInput(): number | undefined;
        private _fieldLevelEncryptionId?;
        get fieldLevelEncryptionId(): string;
        set fieldLevelEncryptionId(value: string);
        resetFieldLevelEncryptionId(): void;
        get fieldLevelEncryptionIdInput(): string | undefined;
        private _maxTtl?;
        get maxTtl(): number;
        set maxTtl(value: number);
        resetMaxTtl(): void;
        get maxTtlInput(): number | undefined;
        private _minTtl?;
        get minTtl(): number;
        set minTtl(value: number);
        resetMinTtl(): void;
        get minTtlInput(): number | undefined;
        private _originRequestPolicyId?;
        get originRequestPolicyId(): string;
        set originRequestPolicyId(value: string);
        resetOriginRequestPolicyId(): void;
        get originRequestPolicyIdInput(): string | undefined;
        private _realtimeLogConfigArn?;
        get realtimeLogConfigArn(): string;
        set realtimeLogConfigArn(value: string);
        resetRealtimeLogConfigArn(): void;
        get realtimeLogConfigArnInput(): string | undefined;
        private _responseHeadersPolicyId?;
        get responseHeadersPolicyId(): string;
        set responseHeadersPolicyId(value: string);
        resetResponseHeadersPolicyId(): void;
        get responseHeadersPolicyIdInput(): string | undefined;
        private _smoothStreaming?;
        get smoothStreaming(): boolean | cdktn.IResolvable;
        set smoothStreaming(value: boolean | cdktn.IResolvable);
        resetSmoothStreaming(): void;
        get smoothStreamingInput(): boolean | cdktn.IResolvable | undefined;
        private _targetOriginId?;
        get targetOriginId(): string;
        set targetOriginId(value: string);
        get targetOriginIdInput(): string | undefined;
        private _trustedKeyGroups?;
        get trustedKeyGroups(): string[];
        set trustedKeyGroups(value: string[]);
        resetTrustedKeyGroups(): void;
        get trustedKeyGroupsInput(): string[] | undefined;
        private _trustedSigners?;
        get trustedSigners(): string[];
        set trustedSigners(value: string[]);
        resetTrustedSigners(): void;
        get trustedSignersInput(): string[] | undefined;
        private _viewerProtocolPolicy?;
        get viewerProtocolPolicy(): string;
        set viewerProtocolPolicy(value: string);
        get viewerProtocolPolicyInput(): string | undefined;
        private _forwardedValues;
        get forwardedValues(): DefaultCacheBehaviorForwardedValuesPropertyOutputReference;
        putForwardedValues(value: DefaultCacheBehaviorForwardedValuesProperty): void;
        resetForwardedValues(): void;
        get forwardedValuesInput(): DefaultCacheBehaviorForwardedValuesProperty | undefined;
        private _functionAssociation;
        get functionAssociation(): DefaultCacheBehaviorFunctionAssociationPropertyList;
        putFunctionAssociation(value: DefaultCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable): void;
        resetFunctionAssociation(): void;
        get functionAssociationInput(): cdktn.IResolvable | DefaultCacheBehaviorFunctionAssociationProperty[] | undefined;
        private _grpcConfig;
        get grpcConfig(): DefaultCacheBehaviorGrpcConfigPropertyOutputReference;
        putGrpcConfig(value: DefaultCacheBehaviorGrpcConfigProperty): void;
        resetGrpcConfig(): void;
        get grpcConfigInput(): DefaultCacheBehaviorGrpcConfigProperty | undefined;
        private _lambdaFunctionAssociation;
        get lambdaFunctionAssociation(): DefaultCacheBehaviorLambdaFunctionAssociationPropertyList;
        putLambdaFunctionAssociation(value: DefaultCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable): void;
        resetLambdaFunctionAssociation(): void;
        get lambdaFunctionAssociationInput(): cdktn.IResolvable | DefaultCacheBehaviorLambdaFunctionAssociationProperty[] | undefined;
    }
    interface LoggingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#bucket AwsCloudfrontDistribution#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#include_cookies AwsCloudfrontDistribution#include_cookies}
        */
        readonly includeCookies?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#prefix AwsCloudfrontDistribution#prefix}
        */
        readonly prefix?: string;
    }
    class LoggingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingConfigProperty | undefined;
        set internalValue(value: LoggingConfigProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _includeCookies?;
        get includeCookies(): boolean | cdktn.IResolvable;
        set includeCookies(value: boolean | cdktn.IResolvable);
        resetIncludeCookies(): void;
        get includeCookiesInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface OrderedCacheBehaviorForwardedValuesCookiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#forward AwsCloudfrontDistribution#forward}
        */
        readonly forward: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#whitelisted_names AwsCloudfrontDistribution#whitelisted_names}
        */
        readonly whitelistedNames?: string[];
    }
    class OrderedCacheBehaviorForwardedValuesCookiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OrderedCacheBehaviorForwardedValuesCookiesProperty | undefined;
        set internalValue(value: OrderedCacheBehaviorForwardedValuesCookiesProperty | undefined);
        private _forward?;
        get forward(): string;
        set forward(value: string);
        get forwardInput(): string | undefined;
        private _whitelistedNames?;
        get whitelistedNames(): string[];
        set whitelistedNames(value: string[]);
        resetWhitelistedNames(): void;
        get whitelistedNamesInput(): string[] | undefined;
    }
    interface OrderedCacheBehaviorForwardedValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#headers AwsCloudfrontDistribution#headers}
        */
        readonly headers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#query_string AwsCloudfrontDistribution#query_string}
        */
        readonly queryString: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#query_string_cache_keys AwsCloudfrontDistribution#query_string_cache_keys}
        */
        readonly queryStringCacheKeys?: string[];
        /**
        * cookies block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cookies AwsCloudfrontDistribution#cookies}
        */
        readonly cookies: OrderedCacheBehaviorForwardedValuesCookiesProperty;
    }
    class OrderedCacheBehaviorForwardedValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OrderedCacheBehaviorForwardedValuesProperty | undefined;
        set internalValue(value: OrderedCacheBehaviorForwardedValuesProperty | undefined);
        private _headers?;
        get headers(): string[];
        set headers(value: string[]);
        resetHeaders(): void;
        get headersInput(): string[] | undefined;
        private _queryString?;
        get queryString(): boolean | cdktn.IResolvable;
        set queryString(value: boolean | cdktn.IResolvable);
        get queryStringInput(): boolean | cdktn.IResolvable | undefined;
        private _queryStringCacheKeys?;
        get queryStringCacheKeys(): string[];
        set queryStringCacheKeys(value: string[]);
        resetQueryStringCacheKeys(): void;
        get queryStringCacheKeysInput(): string[] | undefined;
        private _cookies;
        get cookies(): OrderedCacheBehaviorForwardedValuesCookiesPropertyOutputReference;
        putCookies(value: OrderedCacheBehaviorForwardedValuesCookiesProperty): void;
        get cookiesInput(): OrderedCacheBehaviorForwardedValuesCookiesProperty | undefined;
    }
    interface OrderedCacheBehaviorFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#event_type AwsCloudfrontDistribution#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#function_arn AwsCloudfrontDistribution#function_arn}
        */
        readonly functionArn: string;
    }
    class OrderedCacheBehaviorFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrderedCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrderedCacheBehaviorFunctionAssociationProperty | cdktn.IResolvable | undefined);
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
    }
    class OrderedCacheBehaviorFunctionAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: OrderedCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrderedCacheBehaviorFunctionAssociationPropertyOutputReference;
    }
    interface OrderedCacheBehaviorGrpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#enabled AwsCloudfrontDistribution#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class OrderedCacheBehaviorGrpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OrderedCacheBehaviorGrpcConfigProperty | undefined;
        set internalValue(value: OrderedCacheBehaviorGrpcConfigProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface OrderedCacheBehaviorLambdaFunctionAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#event_type AwsCloudfrontDistribution#event_type}
        */
        readonly eventType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#include_body AwsCloudfrontDistribution#include_body}
        */
        readonly includeBody?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#lambda_arn AwsCloudfrontDistribution#lambda_arn}
        */
        readonly lambdaArn: string;
    }
    class OrderedCacheBehaviorLambdaFunctionAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrderedCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrderedCacheBehaviorLambdaFunctionAssociationProperty | cdktn.IResolvable | undefined);
        private _eventType?;
        get eventType(): string;
        set eventType(value: string);
        get eventTypeInput(): string | undefined;
        private _includeBody?;
        get includeBody(): boolean | cdktn.IResolvable;
        set includeBody(value: boolean | cdktn.IResolvable);
        resetIncludeBody(): void;
        get includeBodyInput(): boolean | cdktn.IResolvable | undefined;
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
    }
    class OrderedCacheBehaviorLambdaFunctionAssociationPropertyList extends cdktn.ComplexList {
        internalValue?: OrderedCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrderedCacheBehaviorLambdaFunctionAssociationPropertyOutputReference;
    }
    interface OrderedCacheBehaviorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#allowed_methods AwsCloudfrontDistribution#allowed_methods}
        */
        readonly allowedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cache_policy_id AwsCloudfrontDistribution#cache_policy_id}
        */
        readonly cachePolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cached_methods AwsCloudfrontDistribution#cached_methods}
        */
        readonly cachedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#compress AwsCloudfrontDistribution#compress}
        */
        readonly compress?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#default_ttl AwsCloudfrontDistribution#default_ttl}
        */
        readonly defaultTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#field_level_encryption_id AwsCloudfrontDistribution#field_level_encryption_id}
        */
        readonly fieldLevelEncryptionId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#max_ttl AwsCloudfrontDistribution#max_ttl}
        */
        readonly maxTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#min_ttl AwsCloudfrontDistribution#min_ttl}
        */
        readonly minTtl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_request_policy_id AwsCloudfrontDistribution#origin_request_policy_id}
        */
        readonly originRequestPolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#path_pattern AwsCloudfrontDistribution#path_pattern}
        */
        readonly pathPattern: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#realtime_log_config_arn AwsCloudfrontDistribution#realtime_log_config_arn}
        */
        readonly realtimeLogConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#response_headers_policy_id AwsCloudfrontDistribution#response_headers_policy_id}
        */
        readonly responseHeadersPolicyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#smooth_streaming AwsCloudfrontDistribution#smooth_streaming}
        */
        readonly smoothStreaming?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#target_origin_id AwsCloudfrontDistribution#target_origin_id}
        */
        readonly targetOriginId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trusted_key_groups AwsCloudfrontDistribution#trusted_key_groups}
        */
        readonly trustedKeyGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trusted_signers AwsCloudfrontDistribution#trusted_signers}
        */
        readonly trustedSigners?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#viewer_protocol_policy AwsCloudfrontDistribution#viewer_protocol_policy}
        */
        readonly viewerProtocolPolicy: string;
        /**
        * forwarded_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#forwarded_values AwsCloudfrontDistribution#forwarded_values}
        */
        readonly forwardedValues?: OrderedCacheBehaviorForwardedValuesProperty;
        /**
        * function_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#function_association AwsCloudfrontDistribution#function_association}
        */
        readonly functionAssociation?: OrderedCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable;
        /**
        * grpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#grpc_config AwsCloudfrontDistribution#grpc_config}
        */
        readonly grpcConfig?: OrderedCacheBehaviorGrpcConfigProperty;
        /**
        * lambda_function_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#lambda_function_association AwsCloudfrontDistribution#lambda_function_association}
        */
        readonly lambdaFunctionAssociation?: OrderedCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable;
    }
    class OrderedCacheBehaviorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrderedCacheBehaviorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrderedCacheBehaviorProperty | cdktn.IResolvable | undefined);
        private _allowedMethods?;
        get allowedMethods(): string[];
        set allowedMethods(value: string[]);
        get allowedMethodsInput(): string[] | undefined;
        private _cachePolicyId?;
        get cachePolicyId(): string;
        set cachePolicyId(value: string);
        resetCachePolicyId(): void;
        get cachePolicyIdInput(): string | undefined;
        private _cachedMethods?;
        get cachedMethods(): string[];
        set cachedMethods(value: string[]);
        get cachedMethodsInput(): string[] | undefined;
        private _compress?;
        get compress(): boolean | cdktn.IResolvable;
        set compress(value: boolean | cdktn.IResolvable);
        resetCompress(): void;
        get compressInput(): boolean | cdktn.IResolvable | undefined;
        private _defaultTtl?;
        get defaultTtl(): number;
        set defaultTtl(value: number);
        resetDefaultTtl(): void;
        get defaultTtlInput(): number | undefined;
        private _fieldLevelEncryptionId?;
        get fieldLevelEncryptionId(): string;
        set fieldLevelEncryptionId(value: string);
        resetFieldLevelEncryptionId(): void;
        get fieldLevelEncryptionIdInput(): string | undefined;
        private _maxTtl?;
        get maxTtl(): number;
        set maxTtl(value: number);
        resetMaxTtl(): void;
        get maxTtlInput(): number | undefined;
        private _minTtl?;
        get minTtl(): number;
        set minTtl(value: number);
        resetMinTtl(): void;
        get minTtlInput(): number | undefined;
        private _originRequestPolicyId?;
        get originRequestPolicyId(): string;
        set originRequestPolicyId(value: string);
        resetOriginRequestPolicyId(): void;
        get originRequestPolicyIdInput(): string | undefined;
        private _pathPattern?;
        get pathPattern(): string;
        set pathPattern(value: string);
        get pathPatternInput(): string | undefined;
        private _realtimeLogConfigArn?;
        get realtimeLogConfigArn(): string;
        set realtimeLogConfigArn(value: string);
        resetRealtimeLogConfigArn(): void;
        get realtimeLogConfigArnInput(): string | undefined;
        private _responseHeadersPolicyId?;
        get responseHeadersPolicyId(): string;
        set responseHeadersPolicyId(value: string);
        resetResponseHeadersPolicyId(): void;
        get responseHeadersPolicyIdInput(): string | undefined;
        private _smoothStreaming?;
        get smoothStreaming(): boolean | cdktn.IResolvable;
        set smoothStreaming(value: boolean | cdktn.IResolvable);
        resetSmoothStreaming(): void;
        get smoothStreamingInput(): boolean | cdktn.IResolvable | undefined;
        private _targetOriginId?;
        get targetOriginId(): string;
        set targetOriginId(value: string);
        get targetOriginIdInput(): string | undefined;
        private _trustedKeyGroups?;
        get trustedKeyGroups(): string[];
        set trustedKeyGroups(value: string[]);
        resetTrustedKeyGroups(): void;
        get trustedKeyGroupsInput(): string[] | undefined;
        private _trustedSigners?;
        get trustedSigners(): string[];
        set trustedSigners(value: string[]);
        resetTrustedSigners(): void;
        get trustedSignersInput(): string[] | undefined;
        private _viewerProtocolPolicy?;
        get viewerProtocolPolicy(): string;
        set viewerProtocolPolicy(value: string);
        get viewerProtocolPolicyInput(): string | undefined;
        private _forwardedValues;
        get forwardedValues(): OrderedCacheBehaviorForwardedValuesPropertyOutputReference;
        putForwardedValues(value: OrderedCacheBehaviorForwardedValuesProperty): void;
        resetForwardedValues(): void;
        get forwardedValuesInput(): OrderedCacheBehaviorForwardedValuesProperty | undefined;
        private _functionAssociation;
        get functionAssociation(): OrderedCacheBehaviorFunctionAssociationPropertyList;
        putFunctionAssociation(value: OrderedCacheBehaviorFunctionAssociationProperty[] | cdktn.IResolvable): void;
        resetFunctionAssociation(): void;
        get functionAssociationInput(): cdktn.IResolvable | OrderedCacheBehaviorFunctionAssociationProperty[] | undefined;
        private _grpcConfig;
        get grpcConfig(): OrderedCacheBehaviorGrpcConfigPropertyOutputReference;
        putGrpcConfig(value: OrderedCacheBehaviorGrpcConfigProperty): void;
        resetGrpcConfig(): void;
        get grpcConfigInput(): OrderedCacheBehaviorGrpcConfigProperty | undefined;
        private _lambdaFunctionAssociation;
        get lambdaFunctionAssociation(): OrderedCacheBehaviorLambdaFunctionAssociationPropertyList;
        putLambdaFunctionAssociation(value: OrderedCacheBehaviorLambdaFunctionAssociationProperty[] | cdktn.IResolvable): void;
        resetLambdaFunctionAssociation(): void;
        get lambdaFunctionAssociationInput(): cdktn.IResolvable | OrderedCacheBehaviorLambdaFunctionAssociationProperty[] | undefined;
    }
    class OrderedCacheBehaviorPropertyList extends cdktn.ComplexList {
        internalValue?: OrderedCacheBehaviorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrderedCacheBehaviorPropertyOutputReference;
    }
    interface CustomHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#name AwsCloudfrontDistribution#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#value AwsCloudfrontDistribution#value}
        */
        readonly value: string;
    }
    class CustomHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomHeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class CustomHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: CustomHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomHeaderPropertyOutputReference;
    }
    interface OriginMtlsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#client_certificate_arn AwsCloudfrontDistribution#client_certificate_arn}
        */
        readonly clientCertificateArn: string;
    }
    class OriginMtlsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OriginMtlsConfigProperty | undefined;
        set internalValue(value: OriginMtlsConfigProperty | undefined);
        private _clientCertificateArn?;
        get clientCertificateArn(): string;
        set clientCertificateArn(value: string);
        get clientCertificateArnInput(): string | undefined;
    }
    interface CustomOriginConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#http_port AwsCloudfrontDistribution#http_port}
        */
        readonly httpPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#https_port AwsCloudfrontDistribution#https_port}
        */
        readonly httpsPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#ip_address_type AwsCloudfrontDistribution#ip_address_type}
        */
        readonly ipAddressType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_keepalive_timeout AwsCloudfrontDistribution#origin_keepalive_timeout}
        */
        readonly originKeepaliveTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_protocol_policy AwsCloudfrontDistribution#origin_protocol_policy}
        */
        readonly originProtocolPolicy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_read_timeout AwsCloudfrontDistribution#origin_read_timeout}
        */
        readonly originReadTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_ssl_protocols AwsCloudfrontDistribution#origin_ssl_protocols}
        */
        readonly originSslProtocols: string[];
        /**
        * origin_mtls_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_mtls_config AwsCloudfrontDistribution#origin_mtls_config}
        */
        readonly originMtlsConfig?: OriginMtlsConfigProperty;
    }
    class CustomOriginConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomOriginConfigProperty | undefined;
        set internalValue(value: CustomOriginConfigProperty | undefined);
        private _httpPort?;
        get httpPort(): number;
        set httpPort(value: number);
        get httpPortInput(): number | undefined;
        private _httpsPort?;
        get httpsPort(): number;
        set httpsPort(value: number);
        get httpsPortInput(): number | undefined;
        private _ipAddressType?;
        get ipAddressType(): string;
        set ipAddressType(value: string);
        resetIpAddressType(): void;
        get ipAddressTypeInput(): string | undefined;
        private _originKeepaliveTimeout?;
        get originKeepaliveTimeout(): number;
        set originKeepaliveTimeout(value: number);
        resetOriginKeepaliveTimeout(): void;
        get originKeepaliveTimeoutInput(): number | undefined;
        private _originProtocolPolicy?;
        get originProtocolPolicy(): string;
        set originProtocolPolicy(value: string);
        get originProtocolPolicyInput(): string | undefined;
        private _originReadTimeout?;
        get originReadTimeout(): number;
        set originReadTimeout(value: number);
        resetOriginReadTimeout(): void;
        get originReadTimeoutInput(): number | undefined;
        private _originSslProtocols?;
        get originSslProtocols(): string[];
        set originSslProtocols(value: string[]);
        get originSslProtocolsInput(): string[] | undefined;
        private _originMtlsConfig;
        get originMtlsConfig(): OriginMtlsConfigPropertyOutputReference;
        putOriginMtlsConfig(value: OriginMtlsConfigProperty): void;
        resetOriginMtlsConfig(): void;
        get originMtlsConfigInput(): OriginMtlsConfigProperty | undefined;
    }
    interface OriginShieldProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#enabled AwsCloudfrontDistribution#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_shield_region AwsCloudfrontDistribution#origin_shield_region}
        */
        readonly originShieldRegion?: string;
    }
    class OriginShieldPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OriginShieldProperty | undefined;
        set internalValue(value: OriginShieldProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _originShieldRegion?;
        get originShieldRegion(): string;
        set originShieldRegion(value: string);
        resetOriginShieldRegion(): void;
        get originShieldRegionInput(): string | undefined;
    }
    interface S3OriginConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_access_identity AwsCloudfrontDistribution#origin_access_identity}
        */
        readonly originAccessIdentity: string;
    }
    class S3OriginConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3OriginConfigProperty | undefined;
        set internalValue(value: S3OriginConfigProperty | undefined);
        private _originAccessIdentity?;
        get originAccessIdentity(): string;
        set originAccessIdentity(value: string);
        get originAccessIdentityInput(): string | undefined;
    }
    interface VpcOriginConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_keepalive_timeout AwsCloudfrontDistribution#origin_keepalive_timeout}
        */
        readonly originKeepaliveTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_read_timeout AwsCloudfrontDistribution#origin_read_timeout}
        */
        readonly originReadTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#owner_account_id AwsCloudfrontDistribution#owner_account_id}
        */
        readonly ownerAccountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#vpc_origin_id AwsCloudfrontDistribution#vpc_origin_id}
        */
        readonly vpcOriginId: string;
    }
    class VpcOriginConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcOriginConfigProperty | undefined;
        set internalValue(value: VpcOriginConfigProperty | undefined);
        private _originKeepaliveTimeout?;
        get originKeepaliveTimeout(): number;
        set originKeepaliveTimeout(value: number);
        resetOriginKeepaliveTimeout(): void;
        get originKeepaliveTimeoutInput(): number | undefined;
        private _originReadTimeout?;
        get originReadTimeout(): number;
        set originReadTimeout(value: number);
        resetOriginReadTimeout(): void;
        get originReadTimeoutInput(): number | undefined;
        private _ownerAccountId?;
        get ownerAccountId(): string;
        set ownerAccountId(value: string);
        resetOwnerAccountId(): void;
        get ownerAccountIdInput(): string | undefined;
        private _vpcOriginId?;
        get vpcOriginId(): string;
        set vpcOriginId(value: string);
        get vpcOriginIdInput(): string | undefined;
    }
    interface OriginProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#connection_attempts AwsCloudfrontDistribution#connection_attempts}
        */
        readonly connectionAttempts?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#connection_timeout AwsCloudfrontDistribution#connection_timeout}
        */
        readonly connectionTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#domain_name AwsCloudfrontDistribution#domain_name}
        */
        readonly domainName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_access_control_id AwsCloudfrontDistribution#origin_access_control_id}
        */
        readonly originAccessControlId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_id AwsCloudfrontDistribution#origin_id}
        */
        readonly originId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_path AwsCloudfrontDistribution#origin_path}
        */
        readonly originPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#response_completion_timeout AwsCloudfrontDistribution#response_completion_timeout}
        */
        readonly responseCompletionTimeout?: number;
        /**
        * custom_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#custom_header AwsCloudfrontDistribution#custom_header}
        */
        readonly customHeader?: CustomHeaderProperty[] | cdktn.IResolvable;
        /**
        * custom_origin_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#custom_origin_config AwsCloudfrontDistribution#custom_origin_config}
        */
        readonly customOriginConfig?: CustomOriginConfigProperty;
        /**
        * origin_shield block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_shield AwsCloudfrontDistribution#origin_shield}
        */
        readonly originShield?: OriginShieldProperty;
        /**
        * s3_origin_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#s3_origin_config AwsCloudfrontDistribution#s3_origin_config}
        */
        readonly s3OriginConfig?: S3OriginConfigProperty;
        /**
        * vpc_origin_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#vpc_origin_config AwsCloudfrontDistribution#vpc_origin_config}
        */
        readonly vpcOriginConfig?: VpcOriginConfigProperty;
    }
    class OriginPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OriginProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OriginProperty | cdktn.IResolvable | undefined);
        private _connectionAttempts?;
        get connectionAttempts(): number;
        set connectionAttempts(value: number);
        resetConnectionAttempts(): void;
        get connectionAttemptsInput(): number | undefined;
        private _connectionTimeout?;
        get connectionTimeout(): number;
        set connectionTimeout(value: number);
        resetConnectionTimeout(): void;
        get connectionTimeoutInput(): number | undefined;
        private _domainName?;
        get domainName(): string;
        set domainName(value: string);
        get domainNameInput(): string | undefined;
        private _originAccessControlId?;
        get originAccessControlId(): string;
        set originAccessControlId(value: string);
        resetOriginAccessControlId(): void;
        get originAccessControlIdInput(): string | undefined;
        private _originId?;
        get originId(): string;
        set originId(value: string);
        get originIdInput(): string | undefined;
        private _originPath?;
        get originPath(): string;
        set originPath(value: string);
        resetOriginPath(): void;
        get originPathInput(): string | undefined;
        private _responseCompletionTimeout?;
        get responseCompletionTimeout(): number;
        set responseCompletionTimeout(value: number);
        resetResponseCompletionTimeout(): void;
        get responseCompletionTimeoutInput(): number | undefined;
        private _customHeader;
        get customHeader(): CustomHeaderPropertyList;
        putCustomHeader(value: CustomHeaderProperty[] | cdktn.IResolvable): void;
        resetCustomHeader(): void;
        get customHeaderInput(): cdktn.IResolvable | CustomHeaderProperty[] | undefined;
        private _customOriginConfig;
        get customOriginConfig(): CustomOriginConfigPropertyOutputReference;
        putCustomOriginConfig(value: CustomOriginConfigProperty): void;
        resetCustomOriginConfig(): void;
        get customOriginConfigInput(): CustomOriginConfigProperty | undefined;
        private _originShield;
        get originShield(): OriginShieldPropertyOutputReference;
        putOriginShield(value: OriginShieldProperty): void;
        resetOriginShield(): void;
        get originShieldInput(): OriginShieldProperty | undefined;
        private _s3OriginConfig;
        get s3OriginConfig(): S3OriginConfigPropertyOutputReference;
        putS3OriginConfig(value: S3OriginConfigProperty): void;
        resetS3OriginConfig(): void;
        get s3OriginConfigInput(): S3OriginConfigProperty | undefined;
        private _vpcOriginConfig;
        get vpcOriginConfig(): VpcOriginConfigPropertyOutputReference;
        putVpcOriginConfig(value: VpcOriginConfigProperty): void;
        resetVpcOriginConfig(): void;
        get vpcOriginConfigInput(): VpcOriginConfigProperty | undefined;
    }
    class OriginPropertyList extends cdktn.ComplexList {
        internalValue?: OriginProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OriginPropertyOutputReference;
    }
    interface FailoverCriteriaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#status_codes AwsCloudfrontDistribution#status_codes}
        */
        readonly statusCodes: number[];
    }
    class FailoverCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FailoverCriteriaProperty | undefined;
        set internalValue(value: FailoverCriteriaProperty | undefined);
        private _statusCodes?;
        get statusCodes(): number[];
        set statusCodes(value: number[]);
        get statusCodesInput(): number[] | undefined;
    }
    interface MemberProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_id AwsCloudfrontDistribution#origin_id}
        */
        readonly originId: string;
    }
    class MemberPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemberProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MemberProperty | cdktn.IResolvable | undefined);
        private _originId?;
        get originId(): string;
        set originId(value: string);
        get originIdInput(): string | undefined;
    }
    class MemberPropertyList extends cdktn.ComplexList {
        internalValue?: MemberProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemberPropertyOutputReference;
    }
    interface OriginGroupProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#origin_id AwsCloudfrontDistribution#origin_id}
        */
        readonly originId: string;
        /**
        * failover_criteria block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#failover_criteria AwsCloudfrontDistribution#failover_criteria}
        */
        readonly failoverCriteria: FailoverCriteriaProperty;
        /**
        * member block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#member AwsCloudfrontDistribution#member}
        */
        readonly member: MemberProperty[] | cdktn.IResolvable;
    }
    class OriginGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OriginGroupProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OriginGroupProperty | cdktn.IResolvable | undefined);
        private _originId?;
        get originId(): string;
        set originId(value: string);
        get originIdInput(): string | undefined;
        private _failoverCriteria;
        get failoverCriteria(): FailoverCriteriaPropertyOutputReference;
        putFailoverCriteria(value: FailoverCriteriaProperty): void;
        get failoverCriteriaInput(): FailoverCriteriaProperty | undefined;
        private _member;
        get member(): MemberPropertyList;
        putMember(value: MemberProperty[] | cdktn.IResolvable): void;
        get memberInput(): cdktn.IResolvable | MemberProperty[] | undefined;
    }
    class OriginGroupPropertyList extends cdktn.ComplexList {
        internalValue?: OriginGroupProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OriginGroupPropertyOutputReference;
    }
    interface GeoRestrictionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#locations AwsCloudfrontDistribution#locations}
        */
        readonly locations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#restriction_type AwsCloudfrontDistribution#restriction_type}
        */
        readonly restrictionType: string;
    }
    class GeoRestrictionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GeoRestrictionProperty | undefined;
        set internalValue(value: GeoRestrictionProperty | undefined);
        private _locations?;
        get locations(): string[];
        set locations(value: string[]);
        resetLocations(): void;
        get locationsInput(): string[] | undefined;
        private _restrictionType?;
        get restrictionType(): string;
        set restrictionType(value: string);
        get restrictionTypeInput(): string | undefined;
    }
    interface RestrictionsProperty {
        /**
        * geo_restriction block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#geo_restriction AwsCloudfrontDistribution#geo_restriction}
        */
        readonly geoRestriction: GeoRestrictionProperty;
    }
    class RestrictionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RestrictionsProperty | undefined;
        set internalValue(value: RestrictionsProperty | undefined);
        private _geoRestriction;
        get geoRestriction(): GeoRestrictionPropertyOutputReference;
        putGeoRestriction(value: GeoRestrictionProperty): void;
        get geoRestrictionInput(): GeoRestrictionProperty | undefined;
    }
    interface ViewerCertificateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#acm_certificate_arn AwsCloudfrontDistribution#acm_certificate_arn}
        */
        readonly acmCertificateArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#cloudfront_default_certificate AwsCloudfrontDistribution#cloudfront_default_certificate}
        */
        readonly cloudfrontDefaultCertificate?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#iam_certificate_id AwsCloudfrontDistribution#iam_certificate_id}
        */
        readonly iamCertificateId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#minimum_protocol_version AwsCloudfrontDistribution#minimum_protocol_version}
        */
        readonly minimumProtocolVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#ssl_support_method AwsCloudfrontDistribution#ssl_support_method}
        */
        readonly sslSupportMethod?: string;
    }
    class ViewerCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ViewerCertificateProperty | undefined;
        set internalValue(value: ViewerCertificateProperty | undefined);
        private _acmCertificateArn?;
        get acmCertificateArn(): string;
        set acmCertificateArn(value: string);
        resetAcmCertificateArn(): void;
        get acmCertificateArnInput(): string | undefined;
        private _cloudfrontDefaultCertificate?;
        get cloudfrontDefaultCertificate(): boolean | cdktn.IResolvable;
        set cloudfrontDefaultCertificate(value: boolean | cdktn.IResolvable);
        resetCloudfrontDefaultCertificate(): void;
        get cloudfrontDefaultCertificateInput(): boolean | cdktn.IResolvable | undefined;
        private _iamCertificateId?;
        get iamCertificateId(): string;
        set iamCertificateId(value: string);
        resetIamCertificateId(): void;
        get iamCertificateIdInput(): string | undefined;
        private _minimumProtocolVersion?;
        get minimumProtocolVersion(): string;
        set minimumProtocolVersion(value: string);
        resetMinimumProtocolVersion(): void;
        get minimumProtocolVersionInput(): string | undefined;
        private _sslSupportMethod?;
        get sslSupportMethod(): string;
        set sslSupportMethod(value: string);
        resetSslSupportMethod(): void;
        get sslSupportMethodInput(): string | undefined;
    }
    interface TrustStoreConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#advertise_trust_store_ca_names AwsCloudfrontDistribution#advertise_trust_store_ca_names}
        */
        readonly advertiseTrustStoreCaNames?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#ignore_certificate_expiry AwsCloudfrontDistribution#ignore_certificate_expiry}
        */
        readonly ignoreCertificateExpiry?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trust_store_id AwsCloudfrontDistribution#trust_store_id}
        */
        readonly trustStoreId: string;
    }
    class TrustStoreConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TrustStoreConfigProperty | undefined;
        set internalValue(value: TrustStoreConfigProperty | undefined);
        private _advertiseTrustStoreCaNames?;
        get advertiseTrustStoreCaNames(): boolean | cdktn.IResolvable;
        set advertiseTrustStoreCaNames(value: boolean | cdktn.IResolvable);
        resetAdvertiseTrustStoreCaNames(): void;
        get advertiseTrustStoreCaNamesInput(): boolean | cdktn.IResolvable | undefined;
        private _ignoreCertificateExpiry?;
        get ignoreCertificateExpiry(): boolean | cdktn.IResolvable;
        set ignoreCertificateExpiry(value: boolean | cdktn.IResolvable);
        resetIgnoreCertificateExpiry(): void;
        get ignoreCertificateExpiryInput(): boolean | cdktn.IResolvable | undefined;
        private _trustStoreId?;
        get trustStoreId(): string;
        set trustStoreId(value: string);
        get trustStoreIdInput(): string | undefined;
    }
    interface ViewerMtlsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#mode AwsCloudfrontDistribution#mode}
        */
        readonly mode?: string;
        /**
        * trust_store_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudfront_distribution#trust_store_config AwsCloudfrontDistribution#trust_store_config}
        */
        readonly trustStoreConfig?: TrustStoreConfigProperty;
    }
    class ViewerMtlsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ViewerMtlsConfigProperty | undefined;
        set internalValue(value: ViewerMtlsConfigProperty | undefined);
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
        private _trustStoreConfig;
        get trustStoreConfig(): TrustStoreConfigPropertyOutputReference;
        putTrustStoreConfig(value: TrustStoreConfigProperty): void;
        resetTrustStoreConfig(): void;
        get trustStoreConfigInput(): TrustStoreConfigProperty | undefined;
    }
}
