import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCloudfrontResponseHeadersPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_response_headers_policy#id DataAwsCloudfrontResponseHeadersPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_response_headers_policy#name DataAwsCloudfrontResponseHeadersPolicy#name}
    */
    readonly name?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_response_headers_policy aws_cloudfront_response_headers_policy}
*/
export declare class DataAwsCloudfrontResponseHeadersPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cloudfront_response_headers_policy";
    /**
    * Generates CDKTN code for importing a DataAwsCloudfrontResponseHeadersPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCloudfrontResponseHeadersPolicy to import
    * @param importFromId The id of the existing DataAwsCloudfrontResponseHeadersPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_response_headers_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCloudfrontResponseHeadersPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudfront_response_headers_policy aws_cloudfront_response_headers_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCloudfrontResponseHeadersPolicyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsCloudfrontResponseHeadersPolicyConfig);
    get arn(): string;
    get comment(): string;
    private _corsConfig;
    get corsConfig(): DataAwsCloudfrontResponseHeadersPolicy.CorsConfigPropertyList;
    private _customHeadersConfig;
    get customHeadersConfig(): DataAwsCloudfrontResponseHeadersPolicy.CustomHeadersConfigPropertyList;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _removeHeadersConfig;
    get removeHeadersConfig(): DataAwsCloudfrontResponseHeadersPolicy.RemoveHeadersConfigPropertyList;
    private _securityHeadersConfig;
    get securityHeadersConfig(): DataAwsCloudfrontResponseHeadersPolicy.SecurityHeadersConfigPropertyList;
    private _serverTimingHeadersConfig;
    get serverTimingHeadersConfig(): DataAwsCloudfrontResponseHeadersPolicy.ServerTimingHeadersConfigPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsCloudfrontResponseHeadersPolicyAccessControlAllowHeadersPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.AccessControlAllowHeadersProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyAccessControlAllowHeadersPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.AccessControlAllowHeadersProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyAccessControlAllowMethodsPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.AccessControlAllowMethodsProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyAccessControlAllowMethodsPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.AccessControlAllowMethodsProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyAccessControlAllowOriginsPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.AccessControlAllowOriginsProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyAccessControlAllowOriginsPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.AccessControlAllowOriginsProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyAccessControlExposeHeadersPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.AccessControlExposeHeadersProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyAccessControlExposeHeadersPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.AccessControlExposeHeadersProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyCorsConfigPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.CorsConfigProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyCorsConfigPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.CorsConfigProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyCustomHeadersConfigItemsPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.CustomHeadersConfigItemsProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyCustomHeadersConfigItemsPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.CustomHeadersConfigItemsProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyCustomHeadersConfigPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.CustomHeadersConfigProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyCustomHeadersConfigPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.CustomHeadersConfigProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyRemoveHeadersConfigItemsPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.RemoveHeadersConfigItemsProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyRemoveHeadersConfigItemsPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.RemoveHeadersConfigItemsProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyRemoveHeadersConfigPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.RemoveHeadersConfigProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyRemoveHeadersConfigPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.RemoveHeadersConfigProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyContentSecurityPolicyPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.ContentSecurityPolicyProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyContentSecurityPolicyPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.ContentSecurityPolicyProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyContentTypeOptionsPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.ContentTypeOptionsProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyContentTypeOptionsPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.ContentTypeOptionsProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyFrameOptionsPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.FrameOptionsProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyFrameOptionsPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.FrameOptionsProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyReferrerPolicyPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.ReferrerPolicyProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyReferrerPolicyPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.ReferrerPolicyProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyStrictTransportSecurityPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.StrictTransportSecurityProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyStrictTransportSecurityPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.StrictTransportSecurityProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyXssProtectionPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.XssProtectionProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyXssProtectionPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.XssProtectionProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicySecurityHeadersConfigPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.SecurityHeadersConfigProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicySecurityHeadersConfigPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.SecurityHeadersConfigProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyServerTimingHeadersConfigPropertyToTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.ServerTimingHeadersConfigProperty): any;
export declare function dataAwsCloudfrontResponseHeadersPolicyServerTimingHeadersConfigPropertyToHclTerraform(struct?: DataAwsCloudfrontResponseHeadersPolicy.ServerTimingHeadersConfigProperty): any;
export declare namespace DataAwsCloudfrontResponseHeadersPolicy {
    interface AccessControlAllowHeadersProperty {
    }
    class AccessControlAllowHeadersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessControlAllowHeadersProperty | undefined;
        set internalValue(value: AccessControlAllowHeadersProperty | undefined);
        get items(): string[];
    }
    class AccessControlAllowHeadersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessControlAllowHeadersPropertyOutputReference;
    }
    interface AccessControlAllowMethodsProperty {
    }
    class AccessControlAllowMethodsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessControlAllowMethodsProperty | undefined;
        set internalValue(value: AccessControlAllowMethodsProperty | undefined);
        get items(): string[];
    }
    class AccessControlAllowMethodsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessControlAllowMethodsPropertyOutputReference;
    }
    interface AccessControlAllowOriginsProperty {
    }
    class AccessControlAllowOriginsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessControlAllowOriginsProperty | undefined;
        set internalValue(value: AccessControlAllowOriginsProperty | undefined);
        get items(): string[];
    }
    class AccessControlAllowOriginsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessControlAllowOriginsPropertyOutputReference;
    }
    interface AccessControlExposeHeadersProperty {
    }
    class AccessControlExposeHeadersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessControlExposeHeadersProperty | undefined;
        set internalValue(value: AccessControlExposeHeadersProperty | undefined);
        get items(): string[];
    }
    class AccessControlExposeHeadersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessControlExposeHeadersPropertyOutputReference;
    }
    interface CorsConfigProperty {
    }
    class CorsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CorsConfigProperty | undefined;
        set internalValue(value: CorsConfigProperty | undefined);
        get accessControlAllowCredentials(): cdktn.IResolvable;
        private _accessControlAllowHeaders;
        get accessControlAllowHeaders(): AccessControlAllowHeadersPropertyList;
        private _accessControlAllowMethods;
        get accessControlAllowMethods(): AccessControlAllowMethodsPropertyList;
        private _accessControlAllowOrigins;
        get accessControlAllowOrigins(): AccessControlAllowOriginsPropertyList;
        private _accessControlExposeHeaders;
        get accessControlExposeHeaders(): AccessControlExposeHeadersPropertyList;
        get accessControlMaxAgeSec(): number;
        get originOverride(): cdktn.IResolvable;
    }
    class CorsConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CorsConfigPropertyOutputReference;
    }
    interface CustomHeadersConfigItemsProperty {
    }
    class CustomHeadersConfigItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomHeadersConfigItemsProperty | undefined;
        set internalValue(value: CustomHeadersConfigItemsProperty | undefined);
        get header(): string;
        get override(): cdktn.IResolvable;
        get value(): string;
    }
    class CustomHeadersConfigItemsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomHeadersConfigItemsPropertyOutputReference;
    }
    interface CustomHeadersConfigProperty {
    }
    class CustomHeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomHeadersConfigProperty | undefined;
        set internalValue(value: CustomHeadersConfigProperty | undefined);
        private _items;
        get items(): CustomHeadersConfigItemsPropertyList;
    }
    class CustomHeadersConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomHeadersConfigPropertyOutputReference;
    }
    interface RemoveHeadersConfigItemsProperty {
    }
    class RemoveHeadersConfigItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RemoveHeadersConfigItemsProperty | undefined;
        set internalValue(value: RemoveHeadersConfigItemsProperty | undefined);
        get header(): string;
    }
    class RemoveHeadersConfigItemsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RemoveHeadersConfigItemsPropertyOutputReference;
    }
    interface RemoveHeadersConfigProperty {
    }
    class RemoveHeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RemoveHeadersConfigProperty | undefined;
        set internalValue(value: RemoveHeadersConfigProperty | undefined);
        private _items;
        get items(): RemoveHeadersConfigItemsPropertyList;
    }
    class RemoveHeadersConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RemoveHeadersConfigPropertyOutputReference;
    }
    interface ContentSecurityPolicyProperty {
    }
    class ContentSecurityPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContentSecurityPolicyProperty | undefined;
        set internalValue(value: ContentSecurityPolicyProperty | undefined);
        get contentSecurityPolicy(): string;
        get override(): cdktn.IResolvable;
    }
    class ContentSecurityPolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContentSecurityPolicyPropertyOutputReference;
    }
    interface ContentTypeOptionsProperty {
    }
    class ContentTypeOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContentTypeOptionsProperty | undefined;
        set internalValue(value: ContentTypeOptionsProperty | undefined);
        get override(): cdktn.IResolvable;
    }
    class ContentTypeOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContentTypeOptionsPropertyOutputReference;
    }
    interface FrameOptionsProperty {
    }
    class FrameOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FrameOptionsProperty | undefined;
        set internalValue(value: FrameOptionsProperty | undefined);
        get frameOption(): string;
        get override(): cdktn.IResolvable;
    }
    class FrameOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FrameOptionsPropertyOutputReference;
    }
    interface ReferrerPolicyProperty {
    }
    class ReferrerPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReferrerPolicyProperty | undefined;
        set internalValue(value: ReferrerPolicyProperty | undefined);
        get override(): cdktn.IResolvable;
        get referrerPolicy(): string;
    }
    class ReferrerPolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReferrerPolicyPropertyOutputReference;
    }
    interface StrictTransportSecurityProperty {
    }
    class StrictTransportSecurityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StrictTransportSecurityProperty | undefined;
        set internalValue(value: StrictTransportSecurityProperty | undefined);
        get accessControlMaxAgeSec(): number;
        get includeSubdomains(): cdktn.IResolvable;
        get override(): cdktn.IResolvable;
        get preload(): cdktn.IResolvable;
    }
    class StrictTransportSecurityPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StrictTransportSecurityPropertyOutputReference;
    }
    interface XssProtectionProperty {
    }
    class XssProtectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): XssProtectionProperty | undefined;
        set internalValue(value: XssProtectionProperty | undefined);
        get modeBlock(): cdktn.IResolvable;
        get override(): cdktn.IResolvable;
        get protection(): cdktn.IResolvable;
        get reportUri(): string;
    }
    class XssProtectionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): XssProtectionPropertyOutputReference;
    }
    interface SecurityHeadersConfigProperty {
    }
    class SecurityHeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecurityHeadersConfigProperty | undefined;
        set internalValue(value: SecurityHeadersConfigProperty | undefined);
        private _contentSecurityPolicy;
        get contentSecurityPolicy(): ContentSecurityPolicyPropertyList;
        private _contentTypeOptions;
        get contentTypeOptions(): ContentTypeOptionsPropertyList;
        private _frameOptions;
        get frameOptions(): FrameOptionsPropertyList;
        private _referrerPolicy;
        get referrerPolicy(): ReferrerPolicyPropertyList;
        private _strictTransportSecurity;
        get strictTransportSecurity(): StrictTransportSecurityPropertyList;
        private _xssProtection;
        get xssProtection(): XssProtectionPropertyList;
    }
    class SecurityHeadersConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecurityHeadersConfigPropertyOutputReference;
    }
    interface ServerTimingHeadersConfigProperty {
    }
    class ServerTimingHeadersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServerTimingHeadersConfigProperty | undefined;
        set internalValue(value: ServerTimingHeadersConfigProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get samplingRate(): number;
    }
    class ServerTimingHeadersConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServerTimingHeadersConfigPropertyOutputReference;
    }
}
