import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfPatchBaselineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline#default_baseline DataTfPatchBaseline#default_baseline}
    */
    readonly defaultBaseline?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline#id DataTfPatchBaseline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline#name_prefix DataTfPatchBaseline#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline#operating_system DataTfPatchBaseline#operating_system}
    */
    readonly operatingSystem?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline#owner DataTfPatchBaseline#owner}
    */
    readonly owner: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline#region DataTfPatchBaseline#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline aws_ssm_patch_baseline}
*/
export declare class DataTfPatchBaseline extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ssm_patch_baseline";
    /**
    * Generates CDKTN code for importing a DataTfPatchBaseline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfPatchBaseline to import
    * @param importFromId The id of the existing DataTfPatchBaseline that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfPatchBaseline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baseline aws_ssm_patch_baseline} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfPatchBaselineConfig
    */
    constructor(scope: Construct, id: string, config: DataTfPatchBaselineConfig);
    private _approvalRule;
    get approvalRule(): DataTfPatchBaseline.ApprovalRulePropertyList;
    get approvedPatches(): string[];
    get approvedPatchesComplianceLevel(): string;
    get approvedPatchesEnableNonSecurity(): cdktn.IResolvable;
    get availableSecurityUpdatesComplianceStatus(): string;
    private _defaultBaseline?;
    get defaultBaseline(): boolean | cdktn.IResolvable;
    set defaultBaseline(value: boolean | cdktn.IResolvable);
    resetDefaultBaseline(): void;
    get defaultBaselineInput(): boolean | cdktn.IResolvable | undefined;
    get description(): string;
    private _globalFilter;
    get globalFilter(): DataTfPatchBaseline.GlobalFilterPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get json(): string;
    get name(): string;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _operatingSystem?;
    get operatingSystem(): string;
    set operatingSystem(value: string);
    resetOperatingSystem(): void;
    get operatingSystemInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    get ownerInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get rejectedPatches(): string[];
    get rejectedPatchesAction(): string;
    private _source;
    get source(): DataTfPatchBaseline.SourcePropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfPatchBaselinePatchFilterPropertyToTerraform(struct?: DataTfPatchBaseline.PatchFilterProperty): any;
export declare function dataTfPatchBaselinePatchFilterPropertyToHclTerraform(struct?: DataTfPatchBaseline.PatchFilterProperty): any;
export declare function dataTfPatchBaselineApprovalRulePropertyToTerraform(struct?: DataTfPatchBaseline.ApprovalRuleProperty): any;
export declare function dataTfPatchBaselineApprovalRulePropertyToHclTerraform(struct?: DataTfPatchBaseline.ApprovalRuleProperty): any;
export declare function dataTfPatchBaselineGlobalFilterPropertyToTerraform(struct?: DataTfPatchBaseline.GlobalFilterProperty): any;
export declare function dataTfPatchBaselineGlobalFilterPropertyToHclTerraform(struct?: DataTfPatchBaseline.GlobalFilterProperty): any;
export declare function dataTfPatchBaselineSourcePropertyToTerraform(struct?: DataTfPatchBaseline.SourceProperty): any;
export declare function dataTfPatchBaselineSourcePropertyToHclTerraform(struct?: DataTfPatchBaseline.SourceProperty): any;
export declare namespace DataTfPatchBaseline {
    interface PatchFilterProperty {
    }
    class PatchFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PatchFilterProperty | undefined;
        set internalValue(value: PatchFilterProperty | undefined);
        get key(): string;
        get values(): string[];
    }
    class PatchFilterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PatchFilterPropertyOutputReference;
    }
    interface ApprovalRuleProperty {
    }
    class ApprovalRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApprovalRuleProperty | undefined;
        set internalValue(value: ApprovalRuleProperty | undefined);
        get approveAfterDays(): number;
        get approveUntilDate(): string;
        get complianceLevel(): string;
        get enableNonSecurity(): cdktn.IResolvable;
        private _patchFilter;
        get patchFilter(): PatchFilterPropertyList;
    }
    class ApprovalRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApprovalRulePropertyOutputReference;
    }
    interface GlobalFilterProperty {
    }
    class GlobalFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GlobalFilterProperty | undefined;
        set internalValue(value: GlobalFilterProperty | undefined);
        get key(): string;
        get values(): string[];
    }
    class GlobalFilterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GlobalFilterPropertyOutputReference;
    }
    interface SourceProperty {
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceProperty | undefined;
        set internalValue(value: SourceProperty | undefined);
        get configuration(): string;
        get name(): string;
        get products(): string[];
    }
    class SourcePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcePropertyOutputReference;
    }
}
