import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSsmServiceSettingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_service_setting#id AwsSsmServiceSetting#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_service_setting#region AwsSsmServiceSetting#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_service_setting#setting_id AwsSsmServiceSetting#setting_id}
    */
    readonly settingId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_service_setting#setting_value AwsSsmServiceSetting#setting_value}
    */
    readonly settingValue: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_service_setting aws_ssm_service_setting}
*/
export declare class AwsSsmServiceSetting extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssm_service_setting";
    /**
    * Generates CDKTN code for importing a AwsSsmServiceSetting resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSsmServiceSetting to import
    * @param importFromId The id of the existing AwsSsmServiceSetting that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_service_setting#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSsmServiceSetting to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssm_service_setting aws_ssm_service_setting} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSsmServiceSettingConfig
    */
    constructor(scope: Construct, id: string, config: AwsSsmServiceSettingConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _settingId?;
    get settingId(): string;
    set settingId(value: string);
    get settingIdInput(): string | undefined;
    private _settingValue?;
    get settingValue(): string;
    set settingValue(value: string);
    get settingValueInput(): string | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
