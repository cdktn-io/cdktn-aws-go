import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsSsmPatchBaselinesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baselines#default_baselines DataAwsSsmPatchBaselines#default_baselines}
    */
    readonly defaultBaselines?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baselines#region DataAwsSsmPatchBaselines#region}
    */
    readonly region?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baselines#filter DataAwsSsmPatchBaselines#filter}
    */
    readonly filter?: DataAwsSsmPatchBaselines.FilterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baselines aws_ssm_patch_baselines}
*/
export declare class DataAwsSsmPatchBaselines extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ssm_patch_baselines";
    /**
    * Generates CDKTN code for importing a DataAwsSsmPatchBaselines resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsSsmPatchBaselines to import
    * @param importFromId The id of the existing DataAwsSsmPatchBaselines that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baselines#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsSsmPatchBaselines to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baselines aws_ssm_patch_baselines} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsSsmPatchBaselinesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsSsmPatchBaselinesConfig);
    private _baselineIdentities;
    get baselineIdentities(): DataAwsSsmPatchBaselines.BaselineIdentitiesPropertyList;
    private _defaultBaselines?;
    get defaultBaselines(): boolean | cdktn.IResolvable;
    set defaultBaselines(value: boolean | cdktn.IResolvable);
    resetDefaultBaselines(): void;
    get defaultBaselinesInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _filter;
    get filter(): DataAwsSsmPatchBaselines.FilterPropertyList;
    putFilter(value: DataAwsSsmPatchBaselines.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataAwsSsmPatchBaselines.FilterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsSsmPatchBaselinesBaselineIdentitiesPropertyToTerraform(struct?: DataAwsSsmPatchBaselines.BaselineIdentitiesProperty): any;
export declare function dataAwsSsmPatchBaselinesBaselineIdentitiesPropertyToHclTerraform(struct?: DataAwsSsmPatchBaselines.BaselineIdentitiesProperty): any;
export declare function dataAwsSsmPatchBaselinesFilterPropertyToTerraform(struct?: DataAwsSsmPatchBaselines.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsSsmPatchBaselinesFilterPropertyToHclTerraform(struct?: DataAwsSsmPatchBaselines.FilterProperty | cdktn.IResolvable): any;
export declare namespace DataAwsSsmPatchBaselines {
    interface BaselineIdentitiesProperty {
    }
    class BaselineIdentitiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BaselineIdentitiesProperty | undefined;
        set internalValue(value: BaselineIdentitiesProperty | undefined);
        get baselineDescription(): string;
        get baselineId(): string;
        get baselineName(): string;
        get defaultBaseline(): cdktn.IResolvable;
        get operatingSystem(): string;
    }
    class BaselineIdentitiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BaselineIdentitiesPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baselines#key DataAwsSsmPatchBaselines#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssm_patch_baselines#values DataAwsSsmPatchBaselines#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
}
