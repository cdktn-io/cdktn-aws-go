import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsQuicksightThemeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#aws_account_id AwsQuicksightTheme#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#base_theme_id AwsQuicksightTheme#base_theme_id}
    */
    readonly baseThemeId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#id AwsQuicksightTheme#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#name AwsQuicksightTheme#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#region AwsQuicksightTheme#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#tags AwsQuicksightTheme#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#tags_all AwsQuicksightTheme#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#theme_id AwsQuicksightTheme#theme_id}
    */
    readonly themeId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#version_description AwsQuicksightTheme#version_description}
    */
    readonly versionDescription?: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#configuration AwsQuicksightTheme#configuration}
    */
    readonly configuration?: AwsQuicksightTheme.ConfigurationProperty;
    /**
    * permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#permissions AwsQuicksightTheme#permissions}
    */
    readonly permissions?: AwsQuicksightTheme.PermissionsProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#timeouts AwsQuicksightTheme#timeouts}
    */
    readonly timeouts?: AwsQuicksightTheme.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme aws_quicksight_theme}
*/
export declare class AwsQuicksightTheme extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_quicksight_theme";
    /**
    * Generates CDKTN code for importing a AwsQuicksightTheme resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsQuicksightTheme to import
    * @param importFromId The id of the existing AwsQuicksightTheme that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsQuicksightTheme to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme aws_quicksight_theme} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsQuicksightThemeConfig
    */
    constructor(scope: Construct, id: string, config: AwsQuicksightThemeConfig);
    get arn(): string;
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    private _baseThemeId?;
    get baseThemeId(): string;
    set baseThemeId(value: string);
    get baseThemeIdInput(): string | undefined;
    get createdTime(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _themeId?;
    get themeId(): string;
    set themeId(value: string);
    get themeIdInput(): string | undefined;
    private _versionDescription?;
    get versionDescription(): string;
    set versionDescription(value: string);
    resetVersionDescription(): void;
    get versionDescriptionInput(): string | undefined;
    get versionNumber(): number;
    private _configuration;
    get configuration(): AwsQuicksightTheme.ConfigurationPropertyOutputReference;
    putConfiguration(value: AwsQuicksightTheme.ConfigurationProperty): void;
    resetConfiguration(): void;
    get configurationInput(): AwsQuicksightTheme.ConfigurationProperty | undefined;
    private _permissions;
    get permissions(): AwsQuicksightTheme.PermissionsPropertyList;
    putPermissions(value: AwsQuicksightTheme.PermissionsProperty[] | cdktn.IResolvable): void;
    resetPermissions(): void;
    get permissionsInput(): cdktn.IResolvable | AwsQuicksightTheme.PermissionsProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsQuicksightTheme.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsQuicksightTheme.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsQuicksightTheme.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsQuicksightThemeDataColorPalettePropertyToTerraform(struct?: AwsQuicksightTheme.DataColorPalettePropertyOutputReference | AwsQuicksightTheme.DataColorPaletteProperty): any;
export declare function awsQuicksightThemeDataColorPalettePropertyToHclTerraform(struct?: AwsQuicksightTheme.DataColorPalettePropertyOutputReference | AwsQuicksightTheme.DataColorPaletteProperty): any;
export declare function awsQuicksightThemeBorderPropertyToTerraform(struct?: AwsQuicksightTheme.BorderPropertyOutputReference | AwsQuicksightTheme.BorderProperty): any;
export declare function awsQuicksightThemeBorderPropertyToHclTerraform(struct?: AwsQuicksightTheme.BorderPropertyOutputReference | AwsQuicksightTheme.BorderProperty): any;
export declare function awsQuicksightThemeTilePropertyToTerraform(struct?: AwsQuicksightTheme.TilePropertyOutputReference | AwsQuicksightTheme.TileProperty): any;
export declare function awsQuicksightThemeTilePropertyToHclTerraform(struct?: AwsQuicksightTheme.TilePropertyOutputReference | AwsQuicksightTheme.TileProperty): any;
export declare function awsQuicksightThemeGutterPropertyToTerraform(struct?: AwsQuicksightTheme.GutterPropertyOutputReference | AwsQuicksightTheme.GutterProperty): any;
export declare function awsQuicksightThemeGutterPropertyToHclTerraform(struct?: AwsQuicksightTheme.GutterPropertyOutputReference | AwsQuicksightTheme.GutterProperty): any;
export declare function awsQuicksightThemeMarginPropertyToTerraform(struct?: AwsQuicksightTheme.MarginPropertyOutputReference | AwsQuicksightTheme.MarginProperty): any;
export declare function awsQuicksightThemeMarginPropertyToHclTerraform(struct?: AwsQuicksightTheme.MarginPropertyOutputReference | AwsQuicksightTheme.MarginProperty): any;
export declare function awsQuicksightThemeTileLayoutPropertyToTerraform(struct?: AwsQuicksightTheme.TileLayoutPropertyOutputReference | AwsQuicksightTheme.TileLayoutProperty): any;
export declare function awsQuicksightThemeTileLayoutPropertyToHclTerraform(struct?: AwsQuicksightTheme.TileLayoutPropertyOutputReference | AwsQuicksightTheme.TileLayoutProperty): any;
export declare function awsQuicksightThemeSheetPropertyToTerraform(struct?: AwsQuicksightTheme.SheetPropertyOutputReference | AwsQuicksightTheme.SheetProperty): any;
export declare function awsQuicksightThemeSheetPropertyToHclTerraform(struct?: AwsQuicksightTheme.SheetPropertyOutputReference | AwsQuicksightTheme.SheetProperty): any;
export declare function awsQuicksightThemeFontFamiliesPropertyToTerraform(struct?: AwsQuicksightTheme.FontFamiliesProperty | cdktn.IResolvable): any;
export declare function awsQuicksightThemeFontFamiliesPropertyToHclTerraform(struct?: AwsQuicksightTheme.FontFamiliesProperty | cdktn.IResolvable): any;
export declare function awsQuicksightThemeTypographyPropertyToTerraform(struct?: AwsQuicksightTheme.TypographyPropertyOutputReference | AwsQuicksightTheme.TypographyProperty): any;
export declare function awsQuicksightThemeTypographyPropertyToHclTerraform(struct?: AwsQuicksightTheme.TypographyPropertyOutputReference | AwsQuicksightTheme.TypographyProperty): any;
export declare function awsQuicksightThemeUiColorPalettePropertyToTerraform(struct?: AwsQuicksightTheme.UiColorPalettePropertyOutputReference | AwsQuicksightTheme.UiColorPaletteProperty): any;
export declare function awsQuicksightThemeUiColorPalettePropertyToHclTerraform(struct?: AwsQuicksightTheme.UiColorPalettePropertyOutputReference | AwsQuicksightTheme.UiColorPaletteProperty): any;
export declare function awsQuicksightThemeConfigurationPropertyToTerraform(struct?: AwsQuicksightTheme.ConfigurationPropertyOutputReference | AwsQuicksightTheme.ConfigurationProperty): any;
export declare function awsQuicksightThemeConfigurationPropertyToHclTerraform(struct?: AwsQuicksightTheme.ConfigurationPropertyOutputReference | AwsQuicksightTheme.ConfigurationProperty): any;
export declare function awsQuicksightThemePermissionsPropertyToTerraform(struct?: AwsQuicksightTheme.PermissionsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightThemePermissionsPropertyToHclTerraform(struct?: AwsQuicksightTheme.PermissionsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightThemeTimeoutsPropertyToTerraform(struct?: AwsQuicksightTheme.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightThemeTimeoutsPropertyToHclTerraform(struct?: AwsQuicksightTheme.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsQuicksightTheme {
    interface DataColorPaletteProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#colors AwsQuicksightTheme#colors}
        */
        readonly colors?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#empty_fill_color AwsQuicksightTheme#empty_fill_color}
        */
        readonly emptyFillColor?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#min_max_gradient AwsQuicksightTheme#min_max_gradient}
        */
        readonly minMaxGradient?: string[];
    }
    class DataColorPalettePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataColorPaletteProperty | undefined;
        set internalValue(value: DataColorPaletteProperty | undefined);
        private _colors?;
        get colors(): string[];
        set colors(value: string[]);
        resetColors(): void;
        get colorsInput(): string[] | undefined;
        private _emptyFillColor?;
        get emptyFillColor(): string;
        set emptyFillColor(value: string);
        resetEmptyFillColor(): void;
        get emptyFillColorInput(): string | undefined;
        private _minMaxGradient?;
        get minMaxGradient(): string[];
        set minMaxGradient(value: string[]);
        resetMinMaxGradient(): void;
        get minMaxGradientInput(): string[] | undefined;
    }
    interface BorderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#show AwsQuicksightTheme#show}
        */
        readonly show?: boolean | cdktn.IResolvable;
    }
    class BorderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BorderProperty | undefined;
        set internalValue(value: BorderProperty | undefined);
        private _show?;
        get show(): boolean | cdktn.IResolvable;
        set show(value: boolean | cdktn.IResolvable);
        resetShow(): void;
        get showInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TileProperty {
        /**
        * border block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#border AwsQuicksightTheme#border}
        */
        readonly border?: BorderProperty;
    }
    class TilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TileProperty | undefined;
        set internalValue(value: TileProperty | undefined);
        private _border;
        get border(): BorderPropertyOutputReference;
        putBorder(value: BorderProperty): void;
        resetBorder(): void;
        get borderInput(): BorderProperty | undefined;
    }
    interface GutterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#show AwsQuicksightTheme#show}
        */
        readonly show?: boolean | cdktn.IResolvable;
    }
    class GutterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GutterProperty | undefined;
        set internalValue(value: GutterProperty | undefined);
        private _show?;
        get show(): boolean | cdktn.IResolvable;
        set show(value: boolean | cdktn.IResolvable);
        resetShow(): void;
        get showInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface MarginProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#show AwsQuicksightTheme#show}
        */
        readonly show?: boolean | cdktn.IResolvable;
    }
    class MarginPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MarginProperty | undefined;
        set internalValue(value: MarginProperty | undefined);
        private _show?;
        get show(): boolean | cdktn.IResolvable;
        set show(value: boolean | cdktn.IResolvable);
        resetShow(): void;
        get showInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TileLayoutProperty {
        /**
        * gutter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#gutter AwsQuicksightTheme#gutter}
        */
        readonly gutter?: GutterProperty;
        /**
        * margin block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#margin AwsQuicksightTheme#margin}
        */
        readonly margin?: MarginProperty;
    }
    class TileLayoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TileLayoutProperty | undefined;
        set internalValue(value: TileLayoutProperty | undefined);
        private _gutter;
        get gutter(): GutterPropertyOutputReference;
        putGutter(value: GutterProperty): void;
        resetGutter(): void;
        get gutterInput(): GutterProperty | undefined;
        private _margin;
        get margin(): MarginPropertyOutputReference;
        putMargin(value: MarginProperty): void;
        resetMargin(): void;
        get marginInput(): MarginProperty | undefined;
    }
    interface SheetProperty {
        /**
        * tile block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#tile AwsQuicksightTheme#tile}
        */
        readonly tile?: TileProperty;
        /**
        * tile_layout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#tile_layout AwsQuicksightTheme#tile_layout}
        */
        readonly tileLayout?: TileLayoutProperty;
    }
    class SheetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SheetProperty | undefined;
        set internalValue(value: SheetProperty | undefined);
        private _tile;
        get tile(): TilePropertyOutputReference;
        putTile(value: TileProperty): void;
        resetTile(): void;
        get tileInput(): TileProperty | undefined;
        private _tileLayout;
        get tileLayout(): TileLayoutPropertyOutputReference;
        putTileLayout(value: TileLayoutProperty): void;
        resetTileLayout(): void;
        get tileLayoutInput(): TileLayoutProperty | undefined;
    }
    interface FontFamiliesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#font_family AwsQuicksightTheme#font_family}
        */
        readonly fontFamily?: string;
    }
    class FontFamiliesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FontFamiliesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FontFamiliesProperty | cdktn.IResolvable | undefined);
        private _fontFamily?;
        get fontFamily(): string;
        set fontFamily(value: string);
        resetFontFamily(): void;
        get fontFamilyInput(): string | undefined;
    }
    class FontFamiliesPropertyList extends cdktn.ComplexList {
        internalValue?: FontFamiliesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FontFamiliesPropertyOutputReference;
    }
    interface TypographyProperty {
        /**
        * font_families block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#font_families AwsQuicksightTheme#font_families}
        */
        readonly fontFamilies?: FontFamiliesProperty[] | cdktn.IResolvable;
    }
    class TypographyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TypographyProperty | undefined;
        set internalValue(value: TypographyProperty | undefined);
        private _fontFamilies;
        get fontFamilies(): FontFamiliesPropertyList;
        putFontFamilies(value: FontFamiliesProperty[] | cdktn.IResolvable): void;
        resetFontFamilies(): void;
        get fontFamiliesInput(): cdktn.IResolvable | FontFamiliesProperty[] | undefined;
    }
    interface UiColorPaletteProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#accent AwsQuicksightTheme#accent}
        */
        readonly accent?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#accent_foreground AwsQuicksightTheme#accent_foreground}
        */
        readonly accentForeground?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#danger AwsQuicksightTheme#danger}
        */
        readonly danger?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#danger_foreground AwsQuicksightTheme#danger_foreground}
        */
        readonly dangerForeground?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#dimension AwsQuicksightTheme#dimension}
        */
        readonly dimension?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#dimension_foreground AwsQuicksightTheme#dimension_foreground}
        */
        readonly dimensionForeground?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#measure AwsQuicksightTheme#measure}
        */
        readonly measure?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#measure_foreground AwsQuicksightTheme#measure_foreground}
        */
        readonly measureForeground?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#primary_background AwsQuicksightTheme#primary_background}
        */
        readonly primaryBackground?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#primary_foreground AwsQuicksightTheme#primary_foreground}
        */
        readonly primaryForeground?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#secondary_background AwsQuicksightTheme#secondary_background}
        */
        readonly secondaryBackground?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#secondary_foreground AwsQuicksightTheme#secondary_foreground}
        */
        readonly secondaryForeground?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#success AwsQuicksightTheme#success}
        */
        readonly success?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#success_foreground AwsQuicksightTheme#success_foreground}
        */
        readonly successForeground?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#warning AwsQuicksightTheme#warning}
        */
        readonly warning?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#warning_foreground AwsQuicksightTheme#warning_foreground}
        */
        readonly warningForeground?: string;
    }
    class UiColorPalettePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UiColorPaletteProperty | undefined;
        set internalValue(value: UiColorPaletteProperty | undefined);
        private _accent?;
        get accent(): string;
        set accent(value: string);
        resetAccent(): void;
        get accentInput(): string | undefined;
        private _accentForeground?;
        get accentForeground(): string;
        set accentForeground(value: string);
        resetAccentForeground(): void;
        get accentForegroundInput(): string | undefined;
        private _danger?;
        get danger(): string;
        set danger(value: string);
        resetDanger(): void;
        get dangerInput(): string | undefined;
        private _dangerForeground?;
        get dangerForeground(): string;
        set dangerForeground(value: string);
        resetDangerForeground(): void;
        get dangerForegroundInput(): string | undefined;
        private _dimension?;
        get dimension(): string;
        set dimension(value: string);
        resetDimension(): void;
        get dimensionInput(): string | undefined;
        private _dimensionForeground?;
        get dimensionForeground(): string;
        set dimensionForeground(value: string);
        resetDimensionForeground(): void;
        get dimensionForegroundInput(): string | undefined;
        private _measure?;
        get measure(): string;
        set measure(value: string);
        resetMeasure(): void;
        get measureInput(): string | undefined;
        private _measureForeground?;
        get measureForeground(): string;
        set measureForeground(value: string);
        resetMeasureForeground(): void;
        get measureForegroundInput(): string | undefined;
        private _primaryBackground?;
        get primaryBackground(): string;
        set primaryBackground(value: string);
        resetPrimaryBackground(): void;
        get primaryBackgroundInput(): string | undefined;
        private _primaryForeground?;
        get primaryForeground(): string;
        set primaryForeground(value: string);
        resetPrimaryForeground(): void;
        get primaryForegroundInput(): string | undefined;
        private _secondaryBackground?;
        get secondaryBackground(): string;
        set secondaryBackground(value: string);
        resetSecondaryBackground(): void;
        get secondaryBackgroundInput(): string | undefined;
        private _secondaryForeground?;
        get secondaryForeground(): string;
        set secondaryForeground(value: string);
        resetSecondaryForeground(): void;
        get secondaryForegroundInput(): string | undefined;
        private _success?;
        get success(): string;
        set success(value: string);
        resetSuccess(): void;
        get successInput(): string | undefined;
        private _successForeground?;
        get successForeground(): string;
        set successForeground(value: string);
        resetSuccessForeground(): void;
        get successForegroundInput(): string | undefined;
        private _warning?;
        get warning(): string;
        set warning(value: string);
        resetWarning(): void;
        get warningInput(): string | undefined;
        private _warningForeground?;
        get warningForeground(): string;
        set warningForeground(value: string);
        resetWarningForeground(): void;
        get warningForegroundInput(): string | undefined;
    }
    interface ConfigurationProperty {
        /**
        * data_color_palette block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#data_color_palette AwsQuicksightTheme#data_color_palette}
        */
        readonly dataColorPalette?: DataColorPaletteProperty;
        /**
        * sheet block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#sheet AwsQuicksightTheme#sheet}
        */
        readonly sheet?: SheetProperty;
        /**
        * typography block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#typography AwsQuicksightTheme#typography}
        */
        readonly typography?: TypographyProperty;
        /**
        * ui_color_palette block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#ui_color_palette AwsQuicksightTheme#ui_color_palette}
        */
        readonly uiColorPalette?: UiColorPaletteProperty;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationProperty | undefined;
        set internalValue(value: ConfigurationProperty | undefined);
        private _dataColorPalette;
        get dataColorPalette(): DataColorPalettePropertyOutputReference;
        putDataColorPalette(value: DataColorPaletteProperty): void;
        resetDataColorPalette(): void;
        get dataColorPaletteInput(): DataColorPaletteProperty | undefined;
        private _sheet;
        get sheet(): SheetPropertyOutputReference;
        putSheet(value: SheetProperty): void;
        resetSheet(): void;
        get sheetInput(): SheetProperty | undefined;
        private _typography;
        get typography(): TypographyPropertyOutputReference;
        putTypography(value: TypographyProperty): void;
        resetTypography(): void;
        get typographyInput(): TypographyProperty | undefined;
        private _uiColorPalette;
        get uiColorPalette(): UiColorPalettePropertyOutputReference;
        putUiColorPalette(value: UiColorPaletteProperty): void;
        resetUiColorPalette(): void;
        get uiColorPaletteInput(): UiColorPaletteProperty | undefined;
    }
    interface PermissionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#actions AwsQuicksightTheme#actions}
        */
        readonly actions: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#principal AwsQuicksightTheme#principal}
        */
        readonly principal: string;
    }
    class PermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PermissionsProperty | cdktn.IResolvable | undefined);
        private _actions?;
        get actions(): string[];
        set actions(value: string[]);
        get actionsInput(): string[] | undefined;
        private _principal?;
        get principal(): string;
        set principal(value: string);
        get principalInput(): string | undefined;
    }
    class PermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: PermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PermissionsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#create AwsQuicksightTheme#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#delete AwsQuicksightTheme#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_theme#update AwsQuicksightTheme#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
