import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsQuicksightDataSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#aws_account_id AwsQuicksightDataSource#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#data_source_id AwsQuicksightDataSource#data_source_id}
    */
    readonly dataSourceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#id AwsQuicksightDataSource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#name AwsQuicksightDataSource#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#region AwsQuicksightDataSource#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#tags AwsQuicksightDataSource#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#tags_all AwsQuicksightDataSource#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#type AwsQuicksightDataSource#type}
    */
    readonly type: string;
    /**
    * credentials block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#credentials AwsQuicksightDataSource#credentials}
    */
    readonly credentials?: AwsQuicksightDataSource.CredentialsProperty;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#parameters AwsQuicksightDataSource#parameters}
    */
    readonly parameters: AwsQuicksightDataSource.ParametersProperty;
    /**
    * permission block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#permission AwsQuicksightDataSource#permission}
    */
    readonly permission?: AwsQuicksightDataSource.PermissionProperty[] | cdktn.IResolvable;
    /**
    * ssl_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#ssl_properties AwsQuicksightDataSource#ssl_properties}
    */
    readonly sslProperties?: AwsQuicksightDataSource.SslPropertiesProperty;
    /**
    * vpc_connection_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#vpc_connection_properties AwsQuicksightDataSource#vpc_connection_properties}
    */
    readonly vpcConnectionProperties?: AwsQuicksightDataSource.VpcConnectionPropertiesProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source aws_quicksight_data_source}
*/
export declare class AwsQuicksightDataSource extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_quicksight_data_source";
    /**
    * Generates CDKTN code for importing a AwsQuicksightDataSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsQuicksightDataSource to import
    * @param importFromId The id of the existing AwsQuicksightDataSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsQuicksightDataSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source aws_quicksight_data_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsQuicksightDataSourceConfig
    */
    constructor(scope: Construct, id: string, config: AwsQuicksightDataSourceConfig);
    get arn(): string;
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    private _dataSourceId?;
    get dataSourceId(): string;
    set dataSourceId(value: string);
    get dataSourceIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _credentials;
    get credentials(): AwsQuicksightDataSource.CredentialsPropertyOutputReference;
    putCredentials(value: AwsQuicksightDataSource.CredentialsProperty): void;
    resetCredentials(): void;
    get credentialsInput(): AwsQuicksightDataSource.CredentialsProperty | undefined;
    private _parameters;
    get parameters(): AwsQuicksightDataSource.ParametersPropertyOutputReference;
    putParameters(value: AwsQuicksightDataSource.ParametersProperty): void;
    get parametersInput(): AwsQuicksightDataSource.ParametersProperty | undefined;
    private _permission;
    get permission(): AwsQuicksightDataSource.PermissionPropertyList;
    putPermission(value: AwsQuicksightDataSource.PermissionProperty[] | cdktn.IResolvable): void;
    resetPermission(): void;
    get permissionInput(): cdktn.IResolvable | AwsQuicksightDataSource.PermissionProperty[] | undefined;
    private _sslProperties;
    get sslProperties(): AwsQuicksightDataSource.SslPropertiesPropertyOutputReference;
    putSslProperties(value: AwsQuicksightDataSource.SslPropertiesProperty): void;
    resetSslProperties(): void;
    get sslPropertiesInput(): AwsQuicksightDataSource.SslPropertiesProperty | undefined;
    private _vpcConnectionProperties;
    get vpcConnectionProperties(): AwsQuicksightDataSource.VpcConnectionPropertiesPropertyOutputReference;
    putVpcConnectionProperties(value: AwsQuicksightDataSource.VpcConnectionPropertiesProperty): void;
    resetVpcConnectionProperties(): void;
    get vpcConnectionPropertiesInput(): AwsQuicksightDataSource.VpcConnectionPropertiesProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsQuicksightDataSourceCredentialPairPropertyToTerraform(struct?: AwsQuicksightDataSource.CredentialPairPropertyOutputReference | AwsQuicksightDataSource.CredentialPairProperty): any;
export declare function awsQuicksightDataSourceCredentialPairPropertyToHclTerraform(struct?: AwsQuicksightDataSource.CredentialPairPropertyOutputReference | AwsQuicksightDataSource.CredentialPairProperty): any;
export declare function awsQuicksightDataSourceCredentialsPropertyToTerraform(struct?: AwsQuicksightDataSource.CredentialsPropertyOutputReference | AwsQuicksightDataSource.CredentialsProperty): any;
export declare function awsQuicksightDataSourceCredentialsPropertyToHclTerraform(struct?: AwsQuicksightDataSource.CredentialsPropertyOutputReference | AwsQuicksightDataSource.CredentialsProperty): any;
export declare function awsQuicksightDataSourceAmazonElasticsearchPropertyToTerraform(struct?: AwsQuicksightDataSource.AmazonElasticsearchPropertyOutputReference | AwsQuicksightDataSource.AmazonElasticsearchProperty): any;
export declare function awsQuicksightDataSourceAmazonElasticsearchPropertyToHclTerraform(struct?: AwsQuicksightDataSource.AmazonElasticsearchPropertyOutputReference | AwsQuicksightDataSource.AmazonElasticsearchProperty): any;
export declare function awsQuicksightDataSourceAthenaPropertyToTerraform(struct?: AwsQuicksightDataSource.AthenaPropertyOutputReference | AwsQuicksightDataSource.AthenaProperty): any;
export declare function awsQuicksightDataSourceAthenaPropertyToHclTerraform(struct?: AwsQuicksightDataSource.AthenaPropertyOutputReference | AwsQuicksightDataSource.AthenaProperty): any;
export declare function awsQuicksightDataSourceAuroraPropertyToTerraform(struct?: AwsQuicksightDataSource.AuroraPropertyOutputReference | AwsQuicksightDataSource.AuroraProperty): any;
export declare function awsQuicksightDataSourceAuroraPropertyToHclTerraform(struct?: AwsQuicksightDataSource.AuroraPropertyOutputReference | AwsQuicksightDataSource.AuroraProperty): any;
export declare function awsQuicksightDataSourceAuroraPostgresqlPropertyToTerraform(struct?: AwsQuicksightDataSource.AuroraPostgresqlPropertyOutputReference | AwsQuicksightDataSource.AuroraPostgresqlProperty): any;
export declare function awsQuicksightDataSourceAuroraPostgresqlPropertyToHclTerraform(struct?: AwsQuicksightDataSource.AuroraPostgresqlPropertyOutputReference | AwsQuicksightDataSource.AuroraPostgresqlProperty): any;
export declare function awsQuicksightDataSourceAwsIotAnalyticsPropertyToTerraform(struct?: AwsQuicksightDataSource.AwsIotAnalyticsPropertyOutputReference | AwsQuicksightDataSource.AwsIotAnalyticsProperty): any;
export declare function awsQuicksightDataSourceAwsIotAnalyticsPropertyToHclTerraform(struct?: AwsQuicksightDataSource.AwsIotAnalyticsPropertyOutputReference | AwsQuicksightDataSource.AwsIotAnalyticsProperty): any;
export declare function awsQuicksightDataSourceDatabricksPropertyToTerraform(struct?: AwsQuicksightDataSource.DatabricksPropertyOutputReference | AwsQuicksightDataSource.DatabricksProperty): any;
export declare function awsQuicksightDataSourceDatabricksPropertyToHclTerraform(struct?: AwsQuicksightDataSource.DatabricksPropertyOutputReference | AwsQuicksightDataSource.DatabricksProperty): any;
export declare function awsQuicksightDataSourceJiraPropertyToTerraform(struct?: AwsQuicksightDataSource.JiraPropertyOutputReference | AwsQuicksightDataSource.JiraProperty): any;
export declare function awsQuicksightDataSourceJiraPropertyToHclTerraform(struct?: AwsQuicksightDataSource.JiraPropertyOutputReference | AwsQuicksightDataSource.JiraProperty): any;
export declare function awsQuicksightDataSourceMariaDbPropertyToTerraform(struct?: AwsQuicksightDataSource.MariaDbPropertyOutputReference | AwsQuicksightDataSource.MariaDbProperty): any;
export declare function awsQuicksightDataSourceMariaDbPropertyToHclTerraform(struct?: AwsQuicksightDataSource.MariaDbPropertyOutputReference | AwsQuicksightDataSource.MariaDbProperty): any;
export declare function awsQuicksightDataSourceMysqlPropertyToTerraform(struct?: AwsQuicksightDataSource.MysqlPropertyOutputReference | AwsQuicksightDataSource.MysqlProperty): any;
export declare function awsQuicksightDataSourceMysqlPropertyToHclTerraform(struct?: AwsQuicksightDataSource.MysqlPropertyOutputReference | AwsQuicksightDataSource.MysqlProperty): any;
export declare function awsQuicksightDataSourceOraclePropertyToTerraform(struct?: AwsQuicksightDataSource.OraclePropertyOutputReference | AwsQuicksightDataSource.OracleProperty): any;
export declare function awsQuicksightDataSourceOraclePropertyToHclTerraform(struct?: AwsQuicksightDataSource.OraclePropertyOutputReference | AwsQuicksightDataSource.OracleProperty): any;
export declare function awsQuicksightDataSourcePostgresqlPropertyToTerraform(struct?: AwsQuicksightDataSource.PostgresqlPropertyOutputReference | AwsQuicksightDataSource.PostgresqlProperty): any;
export declare function awsQuicksightDataSourcePostgresqlPropertyToHclTerraform(struct?: AwsQuicksightDataSource.PostgresqlPropertyOutputReference | AwsQuicksightDataSource.PostgresqlProperty): any;
export declare function awsQuicksightDataSourcePrestoPropertyToTerraform(struct?: AwsQuicksightDataSource.PrestoPropertyOutputReference | AwsQuicksightDataSource.PrestoProperty): any;
export declare function awsQuicksightDataSourcePrestoPropertyToHclTerraform(struct?: AwsQuicksightDataSource.PrestoPropertyOutputReference | AwsQuicksightDataSource.PrestoProperty): any;
export declare function awsQuicksightDataSourceRdsPropertyToTerraform(struct?: AwsQuicksightDataSource.RdsPropertyOutputReference | AwsQuicksightDataSource.RdsProperty): any;
export declare function awsQuicksightDataSourceRdsPropertyToHclTerraform(struct?: AwsQuicksightDataSource.RdsPropertyOutputReference | AwsQuicksightDataSource.RdsProperty): any;
export declare function awsQuicksightDataSourceRedshiftPropertyToTerraform(struct?: AwsQuicksightDataSource.RedshiftPropertyOutputReference | AwsQuicksightDataSource.RedshiftProperty): any;
export declare function awsQuicksightDataSourceRedshiftPropertyToHclTerraform(struct?: AwsQuicksightDataSource.RedshiftPropertyOutputReference | AwsQuicksightDataSource.RedshiftProperty): any;
export declare function awsQuicksightDataSourceManifestFileLocationPropertyToTerraform(struct?: AwsQuicksightDataSource.ManifestFileLocationPropertyOutputReference | AwsQuicksightDataSource.ManifestFileLocationProperty): any;
export declare function awsQuicksightDataSourceManifestFileLocationPropertyToHclTerraform(struct?: AwsQuicksightDataSource.ManifestFileLocationPropertyOutputReference | AwsQuicksightDataSource.ManifestFileLocationProperty): any;
export declare function awsQuicksightDataSourceS3PropertyToTerraform(struct?: AwsQuicksightDataSource.S3PropertyOutputReference | AwsQuicksightDataSource.S3Property): any;
export declare function awsQuicksightDataSourceS3PropertyToHclTerraform(struct?: AwsQuicksightDataSource.S3PropertyOutputReference | AwsQuicksightDataSource.S3Property): any;
export declare function awsQuicksightDataSourceServiceNowPropertyToTerraform(struct?: AwsQuicksightDataSource.ServiceNowPropertyOutputReference | AwsQuicksightDataSource.ServiceNowProperty): any;
export declare function awsQuicksightDataSourceServiceNowPropertyToHclTerraform(struct?: AwsQuicksightDataSource.ServiceNowPropertyOutputReference | AwsQuicksightDataSource.ServiceNowProperty): any;
export declare function awsQuicksightDataSourceSnowflakePropertyToTerraform(struct?: AwsQuicksightDataSource.SnowflakePropertyOutputReference | AwsQuicksightDataSource.SnowflakeProperty): any;
export declare function awsQuicksightDataSourceSnowflakePropertyToHclTerraform(struct?: AwsQuicksightDataSource.SnowflakePropertyOutputReference | AwsQuicksightDataSource.SnowflakeProperty): any;
export declare function awsQuicksightDataSourceSparkPropertyToTerraform(struct?: AwsQuicksightDataSource.SparkPropertyOutputReference | AwsQuicksightDataSource.SparkProperty): any;
export declare function awsQuicksightDataSourceSparkPropertyToHclTerraform(struct?: AwsQuicksightDataSource.SparkPropertyOutputReference | AwsQuicksightDataSource.SparkProperty): any;
export declare function awsQuicksightDataSourceSqlServerPropertyToTerraform(struct?: AwsQuicksightDataSource.SqlServerPropertyOutputReference | AwsQuicksightDataSource.SqlServerProperty): any;
export declare function awsQuicksightDataSourceSqlServerPropertyToHclTerraform(struct?: AwsQuicksightDataSource.SqlServerPropertyOutputReference | AwsQuicksightDataSource.SqlServerProperty): any;
export declare function awsQuicksightDataSourceTeradataPropertyToTerraform(struct?: AwsQuicksightDataSource.TeradataPropertyOutputReference | AwsQuicksightDataSource.TeradataProperty): any;
export declare function awsQuicksightDataSourceTeradataPropertyToHclTerraform(struct?: AwsQuicksightDataSource.TeradataPropertyOutputReference | AwsQuicksightDataSource.TeradataProperty): any;
export declare function awsQuicksightDataSourceTwitterPropertyToTerraform(struct?: AwsQuicksightDataSource.TwitterPropertyOutputReference | AwsQuicksightDataSource.TwitterProperty): any;
export declare function awsQuicksightDataSourceTwitterPropertyToHclTerraform(struct?: AwsQuicksightDataSource.TwitterPropertyOutputReference | AwsQuicksightDataSource.TwitterProperty): any;
export declare function awsQuicksightDataSourceParametersPropertyToTerraform(struct?: AwsQuicksightDataSource.ParametersPropertyOutputReference | AwsQuicksightDataSource.ParametersProperty): any;
export declare function awsQuicksightDataSourceParametersPropertyToHclTerraform(struct?: AwsQuicksightDataSource.ParametersPropertyOutputReference | AwsQuicksightDataSource.ParametersProperty): any;
export declare function awsQuicksightDataSourcePermissionPropertyToTerraform(struct?: AwsQuicksightDataSource.PermissionProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSourcePermissionPropertyToHclTerraform(struct?: AwsQuicksightDataSource.PermissionProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSourceSslPropertiesPropertyToTerraform(struct?: AwsQuicksightDataSource.SslPropertiesPropertyOutputReference | AwsQuicksightDataSource.SslPropertiesProperty): any;
export declare function awsQuicksightDataSourceSslPropertiesPropertyToHclTerraform(struct?: AwsQuicksightDataSource.SslPropertiesPropertyOutputReference | AwsQuicksightDataSource.SslPropertiesProperty): any;
export declare function awsQuicksightDataSourceVpcConnectionPropertiesPropertyToTerraform(struct?: AwsQuicksightDataSource.VpcConnectionPropertiesPropertyOutputReference | AwsQuicksightDataSource.VpcConnectionPropertiesProperty): any;
export declare function awsQuicksightDataSourceVpcConnectionPropertiesPropertyToHclTerraform(struct?: AwsQuicksightDataSource.VpcConnectionPropertiesPropertyOutputReference | AwsQuicksightDataSource.VpcConnectionPropertiesProperty): any;
export declare namespace AwsQuicksightDataSource {
    interface CredentialPairProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#password AwsQuicksightDataSource#password}
        */
        readonly password: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#username AwsQuicksightDataSource#username}
        */
        readonly username: string;
    }
    class CredentialPairPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CredentialPairProperty | undefined;
        set internalValue(value: CredentialPairProperty | undefined);
        private _password?;
        get password(): string;
        set password(value: string);
        get passwordInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        get usernameInput(): string | undefined;
    }
    interface CredentialsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#copy_source_arn AwsQuicksightDataSource#copy_source_arn}
        */
        readonly copySourceArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#secret_arn AwsQuicksightDataSource#secret_arn}
        */
        readonly secretArn?: string;
        /**
        * credential_pair block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#credential_pair AwsQuicksightDataSource#credential_pair}
        */
        readonly credentialPair?: CredentialPairProperty;
    }
    class CredentialsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CredentialsProperty | undefined;
        set internalValue(value: CredentialsProperty | undefined);
        private _copySourceArn?;
        get copySourceArn(): string;
        set copySourceArn(value: string);
        resetCopySourceArn(): void;
        get copySourceArnInput(): string | undefined;
        private _secretArn?;
        get secretArn(): string;
        set secretArn(value: string);
        resetSecretArn(): void;
        get secretArnInput(): string | undefined;
        private _credentialPair;
        get credentialPair(): CredentialPairPropertyOutputReference;
        putCredentialPair(value: CredentialPairProperty): void;
        resetCredentialPair(): void;
        get credentialPairInput(): CredentialPairProperty | undefined;
    }
    interface AmazonElasticsearchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#domain AwsQuicksightDataSource#domain}
        */
        readonly domain: string;
    }
    class AmazonElasticsearchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AmazonElasticsearchProperty | undefined;
        set internalValue(value: AmazonElasticsearchProperty | undefined);
        private _domain?;
        get domain(): string;
        set domain(value: string);
        get domainInput(): string | undefined;
    }
    interface AthenaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#role_arn AwsQuicksightDataSource#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#work_group AwsQuicksightDataSource#work_group}
        */
        readonly workGroup?: string;
    }
    class AthenaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AthenaProperty | undefined;
        set internalValue(value: AthenaProperty | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _workGroup?;
        get workGroup(): string;
        set workGroup(value: string);
        resetWorkGroup(): void;
        get workGroupInput(): string | undefined;
    }
    interface AuroraProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#database AwsQuicksightDataSource#database}
        */
        readonly database: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#host AwsQuicksightDataSource#host}
        */
        readonly host: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#port AwsQuicksightDataSource#port}
        */
        readonly port: number;
    }
    class AuroraPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuroraProperty | undefined;
        set internalValue(value: AuroraProperty | undefined);
        private _database?;
        get database(): string;
        set database(value: string);
        get databaseInput(): string | undefined;
        private _host?;
        get host(): string;
        set host(value: string);
        get hostInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
    }
    interface AuroraPostgresqlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#database AwsQuicksightDataSource#database}
        */
        readonly database: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#host AwsQuicksightDataSource#host}
        */
        readonly host: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#port AwsQuicksightDataSource#port}
        */
        readonly port: number;
    }
    class AuroraPostgresqlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuroraPostgresqlProperty | undefined;
        set internalValue(value: AuroraPostgresqlProperty | undefined);
        private _database?;
        get database(): string;
        set database(value: string);
        get databaseInput(): string | undefined;
        private _host?;
        get host(): string;
        set host(value: string);
        get hostInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
    }
    interface AwsIotAnalyticsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#data_set_name AwsQuicksightDataSource#data_set_name}
        */
        readonly dataSetName: string;
    }
    class AwsIotAnalyticsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AwsIotAnalyticsProperty | undefined;
        set internalValue(value: AwsIotAnalyticsProperty | undefined);
        private _dataSetName?;
        get dataSetName(): string;
        set dataSetName(value: string);
        get dataSetNameInput(): string | undefined;
    }
    interface DatabricksProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#host AwsQuicksightDataSource#host}
        */
        readonly host: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#port AwsQuicksightDataSource#port}
        */
        readonly port: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#sql_endpoint_path AwsQuicksightDataSource#sql_endpoint_path}
        */
        readonly sqlEndpointPath: string;
    }
    class DatabricksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DatabricksProperty | undefined;
        set internalValue(value: DatabricksProperty | undefined);
        private _host?;
        get host(): string;
        set host(value: string);
        get hostInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
        private _sqlEndpointPath?;
        get sqlEndpointPath(): string;
        set sqlEndpointPath(value: string);
        get sqlEndpointPathInput(): string | undefined;
    }
    interface JiraProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#site_base_url AwsQuicksightDataSource#site_base_url}
        */
        readonly siteBaseUrl: string;
    }
    class JiraPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JiraProperty | undefined;
        set internalValue(value: JiraProperty | undefined);
        private _siteBaseUrl?;
        get siteBaseUrl(): string;
        set siteBaseUrl(value: string);
        get siteBaseUrlInput(): string | undefined;
    }
    interface MariaDbProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#database AwsQuicksightDataSource#database}
        */
        readonly database: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#host AwsQuicksightDataSource#host}
        */
        readonly host: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#port AwsQuicksightDataSource#port}
        */
        readonly port: number;
    }
    class MariaDbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MariaDbProperty | undefined;
        set internalValue(value: MariaDbProperty | undefined);
        private _database?;
        get database(): string;
        set database(value: string);
        get databaseInput(): string | undefined;
        private _host?;
        get host(): string;
        set host(value: string);
        get hostInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
    }
    interface MysqlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#database AwsQuicksightDataSource#database}
        */
        readonly database: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#host AwsQuicksightDataSource#host}
        */
        readonly host: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#port AwsQuicksightDataSource#port}
        */
        readonly port: number;
    }
    class MysqlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MysqlProperty | undefined;
        set internalValue(value: MysqlProperty | undefined);
        private _database?;
        get database(): string;
        set database(value: string);
        get databaseInput(): string | undefined;
        private _host?;
        get host(): string;
        set host(value: string);
        get hostInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
    }
    interface OracleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#database AwsQuicksightDataSource#database}
        */
        readonly database: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#host AwsQuicksightDataSource#host}
        */
        readonly host: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#port AwsQuicksightDataSource#port}
        */
        readonly port: number;
    }
    class OraclePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OracleProperty | undefined;
        set internalValue(value: OracleProperty | undefined);
        private _database?;
        get database(): string;
        set database(value: string);
        get databaseInput(): string | undefined;
        private _host?;
        get host(): string;
        set host(value: string);
        get hostInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
    }
    interface PostgresqlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#database AwsQuicksightDataSource#database}
        */
        readonly database: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#host AwsQuicksightDataSource#host}
        */
        readonly host: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#port AwsQuicksightDataSource#port}
        */
        readonly port: number;
    }
    class PostgresqlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PostgresqlProperty | undefined;
        set internalValue(value: PostgresqlProperty | undefined);
        private _database?;
        get database(): string;
        set database(value: string);
        get databaseInput(): string | undefined;
        private _host?;
        get host(): string;
        set host(value: string);
        get hostInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
    }
    interface PrestoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#catalog AwsQuicksightDataSource#catalog}
        */
        readonly catalog: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#host AwsQuicksightDataSource#host}
        */
        readonly host: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#port AwsQuicksightDataSource#port}
        */
        readonly port: number;
    }
    class PrestoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrestoProperty | undefined;
        set internalValue(value: PrestoProperty | undefined);
        private _catalog?;
        get catalog(): string;
        set catalog(value: string);
        get catalogInput(): string | undefined;
        private _host?;
        get host(): string;
        set host(value: string);
        get hostInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
    }
    interface RdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#database AwsQuicksightDataSource#database}
        */
        readonly database: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#instance_id AwsQuicksightDataSource#instance_id}
        */
        readonly instanceId: string;
    }
    class RdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RdsProperty | undefined;
        set internalValue(value: RdsProperty | undefined);
        private _database?;
        get database(): string;
        set database(value: string);
        get databaseInput(): string | undefined;
        private _instanceId?;
        get instanceId(): string;
        set instanceId(value: string);
        get instanceIdInput(): string | undefined;
    }
    interface RedshiftProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#cluster_id AwsQuicksightDataSource#cluster_id}
        */
        readonly clusterId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#database AwsQuicksightDataSource#database}
        */
        readonly database: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#host AwsQuicksightDataSource#host}
        */
        readonly host?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#port AwsQuicksightDataSource#port}
        */
        readonly port?: number;
    }
    class RedshiftPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedshiftProperty | undefined;
        set internalValue(value: RedshiftProperty | undefined);
        private _clusterId?;
        get clusterId(): string;
        set clusterId(value: string);
        resetClusterId(): void;
        get clusterIdInput(): string | undefined;
        private _database?;
        get database(): string;
        set database(value: string);
        get databaseInput(): string | undefined;
        private _host?;
        get host(): string;
        set host(value: string);
        resetHost(): void;
        get hostInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
    }
    interface ManifestFileLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#bucket AwsQuicksightDataSource#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#key AwsQuicksightDataSource#key}
        */
        readonly key: string;
    }
    class ManifestFileLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ManifestFileLocationProperty | undefined;
        set internalValue(value: ManifestFileLocationProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#role_arn AwsQuicksightDataSource#role_arn}
        */
        readonly roleArn?: string;
        /**
        * manifest_file_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#manifest_file_location AwsQuicksightDataSource#manifest_file_location}
        */
        readonly manifestFileLocation: ManifestFileLocationProperty;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3Property | undefined;
        set internalValue(value: S3Property | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _manifestFileLocation;
        get manifestFileLocation(): ManifestFileLocationPropertyOutputReference;
        putManifestFileLocation(value: ManifestFileLocationProperty): void;
        get manifestFileLocationInput(): ManifestFileLocationProperty | undefined;
    }
    interface ServiceNowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#site_base_url AwsQuicksightDataSource#site_base_url}
        */
        readonly siteBaseUrl: string;
    }
    class ServiceNowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceNowProperty | undefined;
        set internalValue(value: ServiceNowProperty | undefined);
        private _siteBaseUrl?;
        get siteBaseUrl(): string;
        set siteBaseUrl(value: string);
        get siteBaseUrlInput(): string | undefined;
    }
    interface SnowflakeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#database AwsQuicksightDataSource#database}
        */
        readonly database: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#host AwsQuicksightDataSource#host}
        */
        readonly host: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#warehouse AwsQuicksightDataSource#warehouse}
        */
        readonly warehouse: string;
    }
    class SnowflakePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnowflakeProperty | undefined;
        set internalValue(value: SnowflakeProperty | undefined);
        private _database?;
        get database(): string;
        set database(value: string);
        get databaseInput(): string | undefined;
        private _host?;
        get host(): string;
        set host(value: string);
        get hostInput(): string | undefined;
        private _warehouse?;
        get warehouse(): string;
        set warehouse(value: string);
        get warehouseInput(): string | undefined;
    }
    interface SparkProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#host AwsQuicksightDataSource#host}
        */
        readonly host: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#port AwsQuicksightDataSource#port}
        */
        readonly port: number;
    }
    class SparkPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SparkProperty | undefined;
        set internalValue(value: SparkProperty | undefined);
        private _host?;
        get host(): string;
        set host(value: string);
        get hostInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
    }
    interface SqlServerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#database AwsQuicksightDataSource#database}
        */
        readonly database: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#host AwsQuicksightDataSource#host}
        */
        readonly host: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#port AwsQuicksightDataSource#port}
        */
        readonly port: number;
    }
    class SqlServerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SqlServerProperty | undefined;
        set internalValue(value: SqlServerProperty | undefined);
        private _database?;
        get database(): string;
        set database(value: string);
        get databaseInput(): string | undefined;
        private _host?;
        get host(): string;
        set host(value: string);
        get hostInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
    }
    interface TeradataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#database AwsQuicksightDataSource#database}
        */
        readonly database: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#host AwsQuicksightDataSource#host}
        */
        readonly host: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#port AwsQuicksightDataSource#port}
        */
        readonly port: number;
    }
    class TeradataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TeradataProperty | undefined;
        set internalValue(value: TeradataProperty | undefined);
        private _database?;
        get database(): string;
        set database(value: string);
        get databaseInput(): string | undefined;
        private _host?;
        get host(): string;
        set host(value: string);
        get hostInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
    }
    interface TwitterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#max_rows AwsQuicksightDataSource#max_rows}
        */
        readonly maxRows: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#query AwsQuicksightDataSource#query}
        */
        readonly query: string;
    }
    class TwitterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TwitterProperty | undefined;
        set internalValue(value: TwitterProperty | undefined);
        private _maxRows?;
        get maxRows(): number;
        set maxRows(value: number);
        get maxRowsInput(): number | undefined;
        private _query?;
        get query(): string;
        set query(value: string);
        get queryInput(): string | undefined;
    }
    interface ParametersProperty {
        /**
        * amazon_elasticsearch block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#amazon_elasticsearch AwsQuicksightDataSource#amazon_elasticsearch}
        */
        readonly amazonElasticsearch?: AmazonElasticsearchProperty;
        /**
        * athena block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#athena AwsQuicksightDataSource#athena}
        */
        readonly athena?: AthenaProperty;
        /**
        * aurora block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#aurora AwsQuicksightDataSource#aurora}
        */
        readonly aurora?: AuroraProperty;
        /**
        * aurora_postgresql block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#aurora_postgresql AwsQuicksightDataSource#aurora_postgresql}
        */
        readonly auroraPostgresql?: AuroraPostgresqlProperty;
        /**
        * aws_iot_analytics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#aws_iot_analytics AwsQuicksightDataSource#aws_iot_analytics}
        */
        readonly awsIotAnalytics?: AwsIotAnalyticsProperty;
        /**
        * databricks block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#databricks AwsQuicksightDataSource#databricks}
        */
        readonly databricks?: DatabricksProperty;
        /**
        * jira block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#jira AwsQuicksightDataSource#jira}
        */
        readonly jira?: JiraProperty;
        /**
        * maria_db block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#maria_db AwsQuicksightDataSource#maria_db}
        */
        readonly mariaDb?: MariaDbProperty;
        /**
        * mysql block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#mysql AwsQuicksightDataSource#mysql}
        */
        readonly mysql?: MysqlProperty;
        /**
        * oracle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#oracle AwsQuicksightDataSource#oracle}
        */
        readonly oracle?: OracleProperty;
        /**
        * postgresql block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#postgresql AwsQuicksightDataSource#postgresql}
        */
        readonly postgresql?: PostgresqlProperty;
        /**
        * presto block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#presto AwsQuicksightDataSource#presto}
        */
        readonly presto?: PrestoProperty;
        /**
        * rds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#rds AwsQuicksightDataSource#rds}
        */
        readonly rds?: RdsProperty;
        /**
        * redshift block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#redshift AwsQuicksightDataSource#redshift}
        */
        readonly redshift?: RedshiftProperty;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#s3 AwsQuicksightDataSource#s3}
        */
        readonly s3?: S3Property;
        /**
        * service_now block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#service_now AwsQuicksightDataSource#service_now}
        */
        readonly serviceNow?: ServiceNowProperty;
        /**
        * snowflake block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#snowflake AwsQuicksightDataSource#snowflake}
        */
        readonly snowflake?: SnowflakeProperty;
        /**
        * spark block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#spark AwsQuicksightDataSource#spark}
        */
        readonly spark?: SparkProperty;
        /**
        * sql_server block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#sql_server AwsQuicksightDataSource#sql_server}
        */
        readonly sqlServer?: SqlServerProperty;
        /**
        * teradata block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#teradata AwsQuicksightDataSource#teradata}
        */
        readonly teradata?: TeradataProperty;
        /**
        * twitter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#twitter AwsQuicksightDataSource#twitter}
        */
        readonly twitter?: TwitterProperty;
    }
    class ParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ParametersProperty | undefined;
        set internalValue(value: ParametersProperty | undefined);
        private _amazonElasticsearch;
        get amazonElasticsearch(): AmazonElasticsearchPropertyOutputReference;
        putAmazonElasticsearch(value: AmazonElasticsearchProperty): void;
        resetAmazonElasticsearch(): void;
        get amazonElasticsearchInput(): AmazonElasticsearchProperty | undefined;
        private _athena;
        get athena(): AthenaPropertyOutputReference;
        putAthena(value: AthenaProperty): void;
        resetAthena(): void;
        get athenaInput(): AthenaProperty | undefined;
        private _aurora;
        get aurora(): AuroraPropertyOutputReference;
        putAurora(value: AuroraProperty): void;
        resetAurora(): void;
        get auroraInput(): AuroraProperty | undefined;
        private _auroraPostgresql;
        get auroraPostgresql(): AuroraPostgresqlPropertyOutputReference;
        putAuroraPostgresql(value: AuroraPostgresqlProperty): void;
        resetAuroraPostgresql(): void;
        get auroraPostgresqlInput(): AuroraPostgresqlProperty | undefined;
        private _awsIotAnalytics;
        get awsIotAnalytics(): AwsIotAnalyticsPropertyOutputReference;
        putAwsIotAnalytics(value: AwsIotAnalyticsProperty): void;
        resetAwsIotAnalytics(): void;
        get awsIotAnalyticsInput(): AwsIotAnalyticsProperty | undefined;
        private _databricks;
        get databricks(): DatabricksPropertyOutputReference;
        putDatabricks(value: DatabricksProperty): void;
        resetDatabricks(): void;
        get databricksInput(): DatabricksProperty | undefined;
        private _jira;
        get jira(): JiraPropertyOutputReference;
        putJira(value: JiraProperty): void;
        resetJira(): void;
        get jiraInput(): JiraProperty | undefined;
        private _mariaDb;
        get mariaDb(): MariaDbPropertyOutputReference;
        putMariaDb(value: MariaDbProperty): void;
        resetMariaDb(): void;
        get mariaDbInput(): MariaDbProperty | undefined;
        private _mysql;
        get mysql(): MysqlPropertyOutputReference;
        putMysql(value: MysqlProperty): void;
        resetMysql(): void;
        get mysqlInput(): MysqlProperty | undefined;
        private _oracle;
        get oracle(): OraclePropertyOutputReference;
        putOracle(value: OracleProperty): void;
        resetOracle(): void;
        get oracleInput(): OracleProperty | undefined;
        private _postgresql;
        get postgresql(): PostgresqlPropertyOutputReference;
        putPostgresql(value: PostgresqlProperty): void;
        resetPostgresql(): void;
        get postgresqlInput(): PostgresqlProperty | undefined;
        private _presto;
        get presto(): PrestoPropertyOutputReference;
        putPresto(value: PrestoProperty): void;
        resetPresto(): void;
        get prestoInput(): PrestoProperty | undefined;
        private _rds;
        get rds(): RdsPropertyOutputReference;
        putRds(value: RdsProperty): void;
        resetRds(): void;
        get rdsInput(): RdsProperty | undefined;
        private _redshift;
        get redshift(): RedshiftPropertyOutputReference;
        putRedshift(value: RedshiftProperty): void;
        resetRedshift(): void;
        get redshiftInput(): RedshiftProperty | undefined;
        private _s3;
        get s3(): S3PropertyOutputReference;
        putS3(value: S3Property): void;
        resetS3(): void;
        get s3Input(): S3Property | undefined;
        private _serviceNow;
        get serviceNow(): ServiceNowPropertyOutputReference;
        putServiceNow(value: ServiceNowProperty): void;
        resetServiceNow(): void;
        get serviceNowInput(): ServiceNowProperty | undefined;
        private _snowflake;
        get snowflake(): SnowflakePropertyOutputReference;
        putSnowflake(value: SnowflakeProperty): void;
        resetSnowflake(): void;
        get snowflakeInput(): SnowflakeProperty | undefined;
        private _spark;
        get spark(): SparkPropertyOutputReference;
        putSpark(value: SparkProperty): void;
        resetSpark(): void;
        get sparkInput(): SparkProperty | undefined;
        private _sqlServer;
        get sqlServer(): SqlServerPropertyOutputReference;
        putSqlServer(value: SqlServerProperty): void;
        resetSqlServer(): void;
        get sqlServerInput(): SqlServerProperty | undefined;
        private _teradata;
        get teradata(): TeradataPropertyOutputReference;
        putTeradata(value: TeradataProperty): void;
        resetTeradata(): void;
        get teradataInput(): TeradataProperty | undefined;
        private _twitter;
        get twitter(): TwitterPropertyOutputReference;
        putTwitter(value: TwitterProperty): void;
        resetTwitter(): void;
        get twitterInput(): TwitterProperty | undefined;
    }
    interface PermissionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#actions AwsQuicksightDataSource#actions}
        */
        readonly actions: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#principal AwsQuicksightDataSource#principal}
        */
        readonly principal: string;
    }
    class PermissionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PermissionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PermissionProperty | cdktn.IResolvable | undefined);
        private _actions?;
        get actions(): string[];
        set actions(value: string[]);
        get actionsInput(): string[] | undefined;
        private _principal?;
        get principal(): string;
        set principal(value: string);
        get principalInput(): string | undefined;
    }
    class PermissionPropertyList extends cdktn.ComplexList {
        internalValue?: PermissionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PermissionPropertyOutputReference;
    }
    interface SslPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#disable_ssl AwsQuicksightDataSource#disable_ssl}
        */
        readonly disableSsl: boolean | cdktn.IResolvable;
    }
    class SslPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SslPropertiesProperty | undefined;
        set internalValue(value: SslPropertiesProperty | undefined);
        private _disableSsl?;
        get disableSsl(): boolean | cdktn.IResolvable;
        set disableSsl(value: boolean | cdktn.IResolvable);
        get disableSslInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface VpcConnectionPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_source#vpc_connection_arn AwsQuicksightDataSource#vpc_connection_arn}
        */
        readonly vpcConnectionArn: string;
    }
    class VpcConnectionPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConnectionPropertiesProperty | undefined;
        set internalValue(value: VpcConnectionPropertiesProperty | undefined);
        private _vpcConnectionArn?;
        get vpcConnectionArn(): string;
        set vpcConnectionArn(value: string);
        get vpcConnectionArnInput(): string | undefined;
    }
}
