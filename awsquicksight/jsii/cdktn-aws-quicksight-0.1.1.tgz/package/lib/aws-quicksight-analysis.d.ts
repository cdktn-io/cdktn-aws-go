import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsQuicksightAnalysisConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#analysis_id AwsQuicksightAnalysis#analysis_id}
    */
    readonly analysisId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#aws_account_id AwsQuicksightAnalysis#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#id AwsQuicksightAnalysis#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#name AwsQuicksightAnalysis#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#recovery_window_in_days AwsQuicksightAnalysis#recovery_window_in_days}
    */
    readonly recoveryWindowInDays?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#region AwsQuicksightAnalysis#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#tags AwsQuicksightAnalysis#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#tags_all AwsQuicksightAnalysis#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#theme_arn AwsQuicksightAnalysis#theme_arn}
    */
    readonly themeArn?: string;
    /**
    * definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#definition AwsQuicksightAnalysis#definition}
    */
    readonly definition?: any;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#parameters AwsQuicksightAnalysis#parameters}
    */
    readonly parameters?: AwsQuicksightAnalysis.ParametersProperty;
    /**
    * permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#permissions AwsQuicksightAnalysis#permissions}
    */
    readonly permissions?: AwsQuicksightAnalysis.PermissionsProperty[] | cdktn.IResolvable;
    /**
    * source_entity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#source_entity AwsQuicksightAnalysis#source_entity}
    */
    readonly sourceEntity?: AwsQuicksightAnalysis.SourceEntityProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#timeouts AwsQuicksightAnalysis#timeouts}
    */
    readonly timeouts?: AwsQuicksightAnalysis.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis aws_quicksight_analysis}
*/
export declare class AwsQuicksightAnalysis extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_quicksight_analysis";
    /**
    * Generates CDKTN code for importing a AwsQuicksightAnalysis resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsQuicksightAnalysis to import
    * @param importFromId The id of the existing AwsQuicksightAnalysis that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsQuicksightAnalysis to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis aws_quicksight_analysis} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsQuicksightAnalysisConfig
    */
    constructor(scope: Construct, id: string, config: AwsQuicksightAnalysisConfig);
    private _analysisId?;
    get analysisId(): string;
    set analysisId(value: string);
    get analysisIdInput(): string | undefined;
    get arn(): string;
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    get createdTime(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastPublishedTime(): string;
    get lastUpdatedTime(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _recoveryWindowInDays?;
    get recoveryWindowInDays(): number;
    set recoveryWindowInDays(value: number);
    resetRecoveryWindowInDays(): void;
    get recoveryWindowInDaysInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _themeArn?;
    get themeArn(): string;
    set themeArn(value: string);
    resetThemeArn(): void;
    get themeArnInput(): string | undefined;
    private _definition?;
    get definition(): any;
    set definition(value: any);
    resetDefinition(): void;
    get definitionInput(): any;
    private _parameters;
    get parameters(): AwsQuicksightAnalysis.ParametersPropertyOutputReference;
    putParameters(value: AwsQuicksightAnalysis.ParametersProperty): void;
    resetParameters(): void;
    get parametersInput(): AwsQuicksightAnalysis.ParametersProperty | undefined;
    private _permissions;
    get permissions(): AwsQuicksightAnalysis.PermissionsPropertyList;
    putPermissions(value: AwsQuicksightAnalysis.PermissionsProperty[] | cdktn.IResolvable): void;
    resetPermissions(): void;
    get permissionsInput(): cdktn.IResolvable | AwsQuicksightAnalysis.PermissionsProperty[] | undefined;
    private _sourceEntity;
    get sourceEntity(): AwsQuicksightAnalysis.SourceEntityPropertyOutputReference;
    putSourceEntity(value: AwsQuicksightAnalysis.SourceEntityProperty): void;
    resetSourceEntity(): void;
    get sourceEntityInput(): AwsQuicksightAnalysis.SourceEntityProperty | undefined;
    private _timeouts;
    get timeouts(): AwsQuicksightAnalysis.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsQuicksightAnalysis.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsQuicksightAnalysis.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsQuicksightAnalysisDateTimeParametersPropertyToTerraform(struct?: AwsQuicksightAnalysis.DateTimeParametersProperty | cdktn.IResolvable): any;
export declare function awsQuicksightAnalysisDateTimeParametersPropertyToHclTerraform(struct?: AwsQuicksightAnalysis.DateTimeParametersProperty | cdktn.IResolvable): any;
export declare function awsQuicksightAnalysisDecimalParametersPropertyToTerraform(struct?: AwsQuicksightAnalysis.DecimalParametersProperty | cdktn.IResolvable): any;
export declare function awsQuicksightAnalysisDecimalParametersPropertyToHclTerraform(struct?: AwsQuicksightAnalysis.DecimalParametersProperty | cdktn.IResolvable): any;
export declare function awsQuicksightAnalysisIntegerParametersPropertyToTerraform(struct?: AwsQuicksightAnalysis.IntegerParametersProperty | cdktn.IResolvable): any;
export declare function awsQuicksightAnalysisIntegerParametersPropertyToHclTerraform(struct?: AwsQuicksightAnalysis.IntegerParametersProperty | cdktn.IResolvable): any;
export declare function awsQuicksightAnalysisStringParametersPropertyToTerraform(struct?: AwsQuicksightAnalysis.StringParametersProperty | cdktn.IResolvable): any;
export declare function awsQuicksightAnalysisStringParametersPropertyToHclTerraform(struct?: AwsQuicksightAnalysis.StringParametersProperty | cdktn.IResolvable): any;
export declare function awsQuicksightAnalysisParametersPropertyToTerraform(struct?: AwsQuicksightAnalysis.ParametersPropertyOutputReference | AwsQuicksightAnalysis.ParametersProperty): any;
export declare function awsQuicksightAnalysisParametersPropertyToHclTerraform(struct?: AwsQuicksightAnalysis.ParametersPropertyOutputReference | AwsQuicksightAnalysis.ParametersProperty): any;
export declare function awsQuicksightAnalysisPermissionsPropertyToTerraform(struct?: AwsQuicksightAnalysis.PermissionsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightAnalysisPermissionsPropertyToHclTerraform(struct?: AwsQuicksightAnalysis.PermissionsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightAnalysisDataSetReferencesPropertyToTerraform(struct?: AwsQuicksightAnalysis.DataSetReferencesProperty | cdktn.IResolvable): any;
export declare function awsQuicksightAnalysisDataSetReferencesPropertyToHclTerraform(struct?: AwsQuicksightAnalysis.DataSetReferencesProperty | cdktn.IResolvable): any;
export declare function awsQuicksightAnalysisSourceTemplatePropertyToTerraform(struct?: AwsQuicksightAnalysis.SourceTemplatePropertyOutputReference | AwsQuicksightAnalysis.SourceTemplateProperty): any;
export declare function awsQuicksightAnalysisSourceTemplatePropertyToHclTerraform(struct?: AwsQuicksightAnalysis.SourceTemplatePropertyOutputReference | AwsQuicksightAnalysis.SourceTemplateProperty): any;
export declare function awsQuicksightAnalysisSourceEntityPropertyToTerraform(struct?: AwsQuicksightAnalysis.SourceEntityPropertyOutputReference | AwsQuicksightAnalysis.SourceEntityProperty): any;
export declare function awsQuicksightAnalysisSourceEntityPropertyToHclTerraform(struct?: AwsQuicksightAnalysis.SourceEntityPropertyOutputReference | AwsQuicksightAnalysis.SourceEntityProperty): any;
export declare function awsQuicksightAnalysisTimeoutsPropertyToTerraform(struct?: AwsQuicksightAnalysis.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightAnalysisTimeoutsPropertyToHclTerraform(struct?: AwsQuicksightAnalysis.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsQuicksightAnalysis {
    interface DateTimeParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#name AwsQuicksightAnalysis#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#values AwsQuicksightAnalysis#values}
        */
        readonly values: string[];
    }
    class DateTimeParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DateTimeParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DateTimeParametersProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class DateTimeParametersPropertyList extends cdktn.ComplexList {
        internalValue?: DateTimeParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DateTimeParametersPropertyOutputReference;
    }
    interface DecimalParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#name AwsQuicksightAnalysis#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#values AwsQuicksightAnalysis#values}
        */
        readonly values: number[];
    }
    class DecimalParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DecimalParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DecimalParametersProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): number[];
        set values(value: number[]);
        get valuesInput(): number[] | undefined;
    }
    class DecimalParametersPropertyList extends cdktn.ComplexList {
        internalValue?: DecimalParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DecimalParametersPropertyOutputReference;
    }
    interface IntegerParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#name AwsQuicksightAnalysis#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#values AwsQuicksightAnalysis#values}
        */
        readonly values: number[];
    }
    class IntegerParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IntegerParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IntegerParametersProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): number[];
        set values(value: number[]);
        get valuesInput(): number[] | undefined;
    }
    class IntegerParametersPropertyList extends cdktn.ComplexList {
        internalValue?: IntegerParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IntegerParametersPropertyOutputReference;
    }
    interface StringParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#name AwsQuicksightAnalysis#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#values AwsQuicksightAnalysis#values}
        */
        readonly values: string[];
    }
    class StringParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StringParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StringParametersProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class StringParametersPropertyList extends cdktn.ComplexList {
        internalValue?: StringParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StringParametersPropertyOutputReference;
    }
    interface ParametersProperty {
        /**
        * date_time_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#date_time_parameters AwsQuicksightAnalysis#date_time_parameters}
        */
        readonly dateTimeParameters?: DateTimeParametersProperty[] | cdktn.IResolvable;
        /**
        * decimal_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#decimal_parameters AwsQuicksightAnalysis#decimal_parameters}
        */
        readonly decimalParameters?: DecimalParametersProperty[] | cdktn.IResolvable;
        /**
        * integer_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#integer_parameters AwsQuicksightAnalysis#integer_parameters}
        */
        readonly integerParameters?: IntegerParametersProperty[] | cdktn.IResolvable;
        /**
        * string_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#string_parameters AwsQuicksightAnalysis#string_parameters}
        */
        readonly stringParameters?: StringParametersProperty[] | cdktn.IResolvable;
    }
    class ParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ParametersProperty | undefined;
        set internalValue(value: ParametersProperty | undefined);
        private _dateTimeParameters;
        get dateTimeParameters(): DateTimeParametersPropertyList;
        putDateTimeParameters(value: DateTimeParametersProperty[] | cdktn.IResolvable): void;
        resetDateTimeParameters(): void;
        get dateTimeParametersInput(): cdktn.IResolvable | DateTimeParametersProperty[] | undefined;
        private _decimalParameters;
        get decimalParameters(): DecimalParametersPropertyList;
        putDecimalParameters(value: DecimalParametersProperty[] | cdktn.IResolvable): void;
        resetDecimalParameters(): void;
        get decimalParametersInput(): cdktn.IResolvable | DecimalParametersProperty[] | undefined;
        private _integerParameters;
        get integerParameters(): IntegerParametersPropertyList;
        putIntegerParameters(value: IntegerParametersProperty[] | cdktn.IResolvable): void;
        resetIntegerParameters(): void;
        get integerParametersInput(): cdktn.IResolvable | IntegerParametersProperty[] | undefined;
        private _stringParameters;
        get stringParameters(): StringParametersPropertyList;
        putStringParameters(value: StringParametersProperty[] | cdktn.IResolvable): void;
        resetStringParameters(): void;
        get stringParametersInput(): cdktn.IResolvable | StringParametersProperty[] | undefined;
    }
    interface PermissionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#actions AwsQuicksightAnalysis#actions}
        */
        readonly actions: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#principal AwsQuicksightAnalysis#principal}
        */
        readonly principal: string;
    }
    class PermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PermissionsProperty | cdktn.IResolvable | undefined);
        private _actions?;
        get actions(): string[];
        set actions(value: string[]);
        get actionsInput(): string[] | undefined;
        private _principal?;
        get principal(): string;
        set principal(value: string);
        get principalInput(): string | undefined;
    }
    class PermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: PermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PermissionsPropertyOutputReference;
    }
    interface DataSetReferencesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#data_set_arn AwsQuicksightAnalysis#data_set_arn}
        */
        readonly dataSetArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#data_set_placeholder AwsQuicksightAnalysis#data_set_placeholder}
        */
        readonly dataSetPlaceholder: string;
    }
    class DataSetReferencesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSetReferencesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataSetReferencesProperty | cdktn.IResolvable | undefined);
        private _dataSetArn?;
        get dataSetArn(): string;
        set dataSetArn(value: string);
        get dataSetArnInput(): string | undefined;
        private _dataSetPlaceholder?;
        get dataSetPlaceholder(): string;
        set dataSetPlaceholder(value: string);
        get dataSetPlaceholderInput(): string | undefined;
    }
    class DataSetReferencesPropertyList extends cdktn.ComplexList {
        internalValue?: DataSetReferencesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSetReferencesPropertyOutputReference;
    }
    interface SourceTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#arn AwsQuicksightAnalysis#arn}
        */
        readonly arn: string;
        /**
        * data_set_references block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#data_set_references AwsQuicksightAnalysis#data_set_references}
        */
        readonly dataSetReferences: DataSetReferencesProperty[] | cdktn.IResolvable;
    }
    class SourceTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceTemplateProperty | undefined;
        set internalValue(value: SourceTemplateProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _dataSetReferences;
        get dataSetReferences(): DataSetReferencesPropertyList;
        putDataSetReferences(value: DataSetReferencesProperty[] | cdktn.IResolvable): void;
        get dataSetReferencesInput(): cdktn.IResolvable | DataSetReferencesProperty[] | undefined;
    }
    interface SourceEntityProperty {
        /**
        * source_template block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#source_template AwsQuicksightAnalysis#source_template}
        */
        readonly sourceTemplate?: SourceTemplateProperty;
    }
    class SourceEntityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceEntityProperty | undefined;
        set internalValue(value: SourceEntityProperty | undefined);
        private _sourceTemplate;
        get sourceTemplate(): SourceTemplatePropertyOutputReference;
        putSourceTemplate(value: SourceTemplateProperty): void;
        resetSourceTemplate(): void;
        get sourceTemplateInput(): SourceTemplateProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#create AwsQuicksightAnalysis#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#delete AwsQuicksightAnalysis#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_analysis#update AwsQuicksightAnalysis#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
