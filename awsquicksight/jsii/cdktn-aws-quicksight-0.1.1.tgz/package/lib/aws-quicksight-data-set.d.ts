import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsQuicksightDataSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#aws_account_id AwsQuicksightDataSet#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#data_set_id AwsQuicksightDataSet#data_set_id}
    */
    readonly dataSetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#id AwsQuicksightDataSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#import_mode AwsQuicksightDataSet#import_mode}
    */
    readonly importMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#name AwsQuicksightDataSet#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#region AwsQuicksightDataSet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#tags AwsQuicksightDataSet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#tags_all AwsQuicksightDataSet#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#use_as AwsQuicksightDataSet#use_as}
    */
    readonly useAs?: string;
    /**
    * column_groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_groups AwsQuicksightDataSet#column_groups}
    */
    readonly columnGroups?: AwsQuicksightDataSet.ColumnGroupsProperty[] | cdktn.IResolvable;
    /**
    * column_level_permission_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_level_permission_rules AwsQuicksightDataSet#column_level_permission_rules}
    */
    readonly columnLevelPermissionRules?: AwsQuicksightDataSet.ColumnLevelPermissionRulesProperty[] | cdktn.IResolvable;
    /**
    * data_set_usage_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#data_set_usage_configuration AwsQuicksightDataSet#data_set_usage_configuration}
    */
    readonly dataSetUsageConfiguration?: AwsQuicksightDataSet.DataSetUsageConfigurationProperty;
    /**
    * field_folders block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#field_folders AwsQuicksightDataSet#field_folders}
    */
    readonly fieldFolders?: AwsQuicksightDataSet.FieldFoldersProperty[] | cdktn.IResolvable;
    /**
    * logical_table_map block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#logical_table_map AwsQuicksightDataSet#logical_table_map}
    */
    readonly logicalTableMap?: AwsQuicksightDataSet.LogicalTableMapProperty[] | cdktn.IResolvable;
    /**
    * permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#permissions AwsQuicksightDataSet#permissions}
    */
    readonly permissions?: AwsQuicksightDataSet.PermissionsProperty[] | cdktn.IResolvable;
    /**
    * physical_table_map block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#physical_table_map AwsQuicksightDataSet#physical_table_map}
    */
    readonly physicalTableMap?: AwsQuicksightDataSet.PhysicalTableMapProperty[] | cdktn.IResolvable;
    /**
    * refresh_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#refresh_properties AwsQuicksightDataSet#refresh_properties}
    */
    readonly refreshProperties?: AwsQuicksightDataSet.RefreshPropertiesProperty;
    /**
    * row_level_permission_data_set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#row_level_permission_data_set AwsQuicksightDataSet#row_level_permission_data_set}
    */
    readonly rowLevelPermissionDataSet?: AwsQuicksightDataSet.RowLevelPermissionDataSetProperty;
    /**
    * row_level_permission_tag_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#row_level_permission_tag_configuration AwsQuicksightDataSet#row_level_permission_tag_configuration}
    */
    readonly rowLevelPermissionTagConfiguration?: AwsQuicksightDataSet.RowLevelPermissionTagConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set aws_quicksight_data_set}
*/
export declare class AwsQuicksightDataSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_quicksight_data_set";
    /**
    * Generates CDKTN code for importing a AwsQuicksightDataSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsQuicksightDataSet to import
    * @param importFromId The id of the existing AwsQuicksightDataSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsQuicksightDataSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set aws_quicksight_data_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsQuicksightDataSetConfig
    */
    constructor(scope: Construct, id: string, config: AwsQuicksightDataSetConfig);
    get arn(): string;
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    private _dataSetId?;
    get dataSetId(): string;
    set dataSetId(value: string);
    get dataSetIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _importMode?;
    get importMode(): string;
    set importMode(value: string);
    get importModeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _outputColumns;
    get outputColumns(): AwsQuicksightDataSet.OutputColumnsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _useAs?;
    get useAs(): string;
    set useAs(value: string);
    resetUseAs(): void;
    get useAsInput(): string | undefined;
    private _columnGroups;
    get columnGroups(): AwsQuicksightDataSet.ColumnGroupsPropertyList;
    putColumnGroups(value: AwsQuicksightDataSet.ColumnGroupsProperty[] | cdktn.IResolvable): void;
    resetColumnGroups(): void;
    get columnGroupsInput(): cdktn.IResolvable | AwsQuicksightDataSet.ColumnGroupsProperty[] | undefined;
    private _columnLevelPermissionRules;
    get columnLevelPermissionRules(): AwsQuicksightDataSet.ColumnLevelPermissionRulesPropertyList;
    putColumnLevelPermissionRules(value: AwsQuicksightDataSet.ColumnLevelPermissionRulesProperty[] | cdktn.IResolvable): void;
    resetColumnLevelPermissionRules(): void;
    get columnLevelPermissionRulesInput(): cdktn.IResolvable | AwsQuicksightDataSet.ColumnLevelPermissionRulesProperty[] | undefined;
    private _dataSetUsageConfiguration;
    get dataSetUsageConfiguration(): AwsQuicksightDataSet.DataSetUsageConfigurationPropertyOutputReference;
    putDataSetUsageConfiguration(value: AwsQuicksightDataSet.DataSetUsageConfigurationProperty): void;
    resetDataSetUsageConfiguration(): void;
    get dataSetUsageConfigurationInput(): AwsQuicksightDataSet.DataSetUsageConfigurationProperty | undefined;
    private _fieldFolders;
    get fieldFolders(): AwsQuicksightDataSet.FieldFoldersPropertyList;
    putFieldFolders(value: AwsQuicksightDataSet.FieldFoldersProperty[] | cdktn.IResolvable): void;
    resetFieldFolders(): void;
    get fieldFoldersInput(): cdktn.IResolvable | AwsQuicksightDataSet.FieldFoldersProperty[] | undefined;
    private _logicalTableMap;
    get logicalTableMap(): AwsQuicksightDataSet.LogicalTableMapPropertyList;
    putLogicalTableMap(value: AwsQuicksightDataSet.LogicalTableMapProperty[] | cdktn.IResolvable): void;
    resetLogicalTableMap(): void;
    get logicalTableMapInput(): cdktn.IResolvable | AwsQuicksightDataSet.LogicalTableMapProperty[] | undefined;
    private _permissions;
    get permissions(): AwsQuicksightDataSet.PermissionsPropertyList;
    putPermissions(value: AwsQuicksightDataSet.PermissionsProperty[] | cdktn.IResolvable): void;
    resetPermissions(): void;
    get permissionsInput(): cdktn.IResolvable | AwsQuicksightDataSet.PermissionsProperty[] | undefined;
    private _physicalTableMap;
    get physicalTableMap(): AwsQuicksightDataSet.PhysicalTableMapPropertyList;
    putPhysicalTableMap(value: AwsQuicksightDataSet.PhysicalTableMapProperty[] | cdktn.IResolvable): void;
    resetPhysicalTableMap(): void;
    get physicalTableMapInput(): cdktn.IResolvable | AwsQuicksightDataSet.PhysicalTableMapProperty[] | undefined;
    private _refreshProperties;
    get refreshProperties(): AwsQuicksightDataSet.RefreshPropertiesPropertyOutputReference;
    putRefreshProperties(value: AwsQuicksightDataSet.RefreshPropertiesProperty): void;
    resetRefreshProperties(): void;
    get refreshPropertiesInput(): AwsQuicksightDataSet.RefreshPropertiesProperty | undefined;
    private _rowLevelPermissionDataSet;
    get rowLevelPermissionDataSet(): AwsQuicksightDataSet.RowLevelPermissionDataSetPropertyOutputReference;
    putRowLevelPermissionDataSet(value: AwsQuicksightDataSet.RowLevelPermissionDataSetProperty): void;
    resetRowLevelPermissionDataSet(): void;
    get rowLevelPermissionDataSetInput(): AwsQuicksightDataSet.RowLevelPermissionDataSetProperty | undefined;
    private _rowLevelPermissionTagConfiguration;
    get rowLevelPermissionTagConfiguration(): AwsQuicksightDataSet.RowLevelPermissionTagConfigurationPropertyOutputReference;
    putRowLevelPermissionTagConfiguration(value: AwsQuicksightDataSet.RowLevelPermissionTagConfigurationProperty): void;
    resetRowLevelPermissionTagConfiguration(): void;
    get rowLevelPermissionTagConfigurationInput(): AwsQuicksightDataSet.RowLevelPermissionTagConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsQuicksightDataSetOutputColumnsPropertyToTerraform(struct?: AwsQuicksightDataSet.OutputColumnsProperty): any;
export declare function awsQuicksightDataSetOutputColumnsPropertyToHclTerraform(struct?: AwsQuicksightDataSet.OutputColumnsProperty): any;
export declare function awsQuicksightDataSetGeoSpatialColumnGroupPropertyToTerraform(struct?: AwsQuicksightDataSet.GeoSpatialColumnGroupPropertyOutputReference | AwsQuicksightDataSet.GeoSpatialColumnGroupProperty): any;
export declare function awsQuicksightDataSetGeoSpatialColumnGroupPropertyToHclTerraform(struct?: AwsQuicksightDataSet.GeoSpatialColumnGroupPropertyOutputReference | AwsQuicksightDataSet.GeoSpatialColumnGroupProperty): any;
export declare function awsQuicksightDataSetColumnGroupsPropertyToTerraform(struct?: AwsQuicksightDataSet.ColumnGroupsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetColumnGroupsPropertyToHclTerraform(struct?: AwsQuicksightDataSet.ColumnGroupsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetColumnLevelPermissionRulesPropertyToTerraform(struct?: AwsQuicksightDataSet.ColumnLevelPermissionRulesProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetColumnLevelPermissionRulesPropertyToHclTerraform(struct?: AwsQuicksightDataSet.ColumnLevelPermissionRulesProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetDataSetUsageConfigurationPropertyToTerraform(struct?: AwsQuicksightDataSet.DataSetUsageConfigurationPropertyOutputReference | AwsQuicksightDataSet.DataSetUsageConfigurationProperty): any;
export declare function awsQuicksightDataSetDataSetUsageConfigurationPropertyToHclTerraform(struct?: AwsQuicksightDataSet.DataSetUsageConfigurationPropertyOutputReference | AwsQuicksightDataSet.DataSetUsageConfigurationProperty): any;
export declare function awsQuicksightDataSetFieldFoldersPropertyToTerraform(struct?: AwsQuicksightDataSet.FieldFoldersProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetFieldFoldersPropertyToHclTerraform(struct?: AwsQuicksightDataSet.FieldFoldersProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetCastColumnTypeOperationPropertyToTerraform(struct?: AwsQuicksightDataSet.CastColumnTypeOperationPropertyOutputReference | AwsQuicksightDataSet.CastColumnTypeOperationProperty): any;
export declare function awsQuicksightDataSetCastColumnTypeOperationPropertyToHclTerraform(struct?: AwsQuicksightDataSet.CastColumnTypeOperationPropertyOutputReference | AwsQuicksightDataSet.CastColumnTypeOperationProperty): any;
export declare function awsQuicksightDataSetLogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyToTerraform(struct?: AwsQuicksightDataSet.LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetLogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyToHclTerraform(struct?: AwsQuicksightDataSet.LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetCreateColumnsOperationPropertyToTerraform(struct?: AwsQuicksightDataSet.CreateColumnsOperationPropertyOutputReference | AwsQuicksightDataSet.CreateColumnsOperationProperty): any;
export declare function awsQuicksightDataSetCreateColumnsOperationPropertyToHclTerraform(struct?: AwsQuicksightDataSet.CreateColumnsOperationPropertyOutputReference | AwsQuicksightDataSet.CreateColumnsOperationProperty): any;
export declare function awsQuicksightDataSetFilterOperationPropertyToTerraform(struct?: AwsQuicksightDataSet.FilterOperationPropertyOutputReference | AwsQuicksightDataSet.FilterOperationProperty): any;
export declare function awsQuicksightDataSetFilterOperationPropertyToHclTerraform(struct?: AwsQuicksightDataSet.FilterOperationPropertyOutputReference | AwsQuicksightDataSet.FilterOperationProperty): any;
export declare function awsQuicksightDataSetProjectOperationPropertyToTerraform(struct?: AwsQuicksightDataSet.ProjectOperationPropertyOutputReference | AwsQuicksightDataSet.ProjectOperationProperty): any;
export declare function awsQuicksightDataSetProjectOperationPropertyToHclTerraform(struct?: AwsQuicksightDataSet.ProjectOperationPropertyOutputReference | AwsQuicksightDataSet.ProjectOperationProperty): any;
export declare function awsQuicksightDataSetRenameColumnOperationPropertyToTerraform(struct?: AwsQuicksightDataSet.RenameColumnOperationPropertyOutputReference | AwsQuicksightDataSet.RenameColumnOperationProperty): any;
export declare function awsQuicksightDataSetRenameColumnOperationPropertyToHclTerraform(struct?: AwsQuicksightDataSet.RenameColumnOperationPropertyOutputReference | AwsQuicksightDataSet.RenameColumnOperationProperty): any;
export declare function awsQuicksightDataSetColumnDescriptionPropertyToTerraform(struct?: AwsQuicksightDataSet.ColumnDescriptionPropertyOutputReference | AwsQuicksightDataSet.ColumnDescriptionProperty): any;
export declare function awsQuicksightDataSetColumnDescriptionPropertyToHclTerraform(struct?: AwsQuicksightDataSet.ColumnDescriptionPropertyOutputReference | AwsQuicksightDataSet.ColumnDescriptionProperty): any;
export declare function awsQuicksightDataSetTagsPropertyToTerraform(struct?: AwsQuicksightDataSet.TagsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetTagsPropertyToHclTerraform(struct?: AwsQuicksightDataSet.TagsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetTagColumnOperationPropertyToTerraform(struct?: AwsQuicksightDataSet.TagColumnOperationPropertyOutputReference | AwsQuicksightDataSet.TagColumnOperationProperty): any;
export declare function awsQuicksightDataSetTagColumnOperationPropertyToHclTerraform(struct?: AwsQuicksightDataSet.TagColumnOperationPropertyOutputReference | AwsQuicksightDataSet.TagColumnOperationProperty): any;
export declare function awsQuicksightDataSetUntagColumnOperationPropertyToTerraform(struct?: AwsQuicksightDataSet.UntagColumnOperationPropertyOutputReference | AwsQuicksightDataSet.UntagColumnOperationProperty): any;
export declare function awsQuicksightDataSetUntagColumnOperationPropertyToHclTerraform(struct?: AwsQuicksightDataSet.UntagColumnOperationPropertyOutputReference | AwsQuicksightDataSet.UntagColumnOperationProperty): any;
export declare function awsQuicksightDataSetDataTransformsPropertyToTerraform(struct?: AwsQuicksightDataSet.DataTransformsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetDataTransformsPropertyToHclTerraform(struct?: AwsQuicksightDataSet.DataTransformsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetLeftJoinKeyPropertiesPropertyToTerraform(struct?: AwsQuicksightDataSet.LeftJoinKeyPropertiesPropertyOutputReference | AwsQuicksightDataSet.LeftJoinKeyPropertiesProperty): any;
export declare function awsQuicksightDataSetLeftJoinKeyPropertiesPropertyToHclTerraform(struct?: AwsQuicksightDataSet.LeftJoinKeyPropertiesPropertyOutputReference | AwsQuicksightDataSet.LeftJoinKeyPropertiesProperty): any;
export declare function awsQuicksightDataSetRightJoinKeyPropertiesPropertyToTerraform(struct?: AwsQuicksightDataSet.RightJoinKeyPropertiesPropertyOutputReference | AwsQuicksightDataSet.RightJoinKeyPropertiesProperty): any;
export declare function awsQuicksightDataSetRightJoinKeyPropertiesPropertyToHclTerraform(struct?: AwsQuicksightDataSet.RightJoinKeyPropertiesPropertyOutputReference | AwsQuicksightDataSet.RightJoinKeyPropertiesProperty): any;
export declare function awsQuicksightDataSetJoinInstructionPropertyToTerraform(struct?: AwsQuicksightDataSet.JoinInstructionPropertyOutputReference | AwsQuicksightDataSet.JoinInstructionProperty): any;
export declare function awsQuicksightDataSetJoinInstructionPropertyToHclTerraform(struct?: AwsQuicksightDataSet.JoinInstructionPropertyOutputReference | AwsQuicksightDataSet.JoinInstructionProperty): any;
export declare function awsQuicksightDataSetSourcePropertyToTerraform(struct?: AwsQuicksightDataSet.SourcePropertyOutputReference | AwsQuicksightDataSet.SourceProperty): any;
export declare function awsQuicksightDataSetSourcePropertyToHclTerraform(struct?: AwsQuicksightDataSet.SourcePropertyOutputReference | AwsQuicksightDataSet.SourceProperty): any;
export declare function awsQuicksightDataSetLogicalTableMapPropertyToTerraform(struct?: AwsQuicksightDataSet.LogicalTableMapProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetLogicalTableMapPropertyToHclTerraform(struct?: AwsQuicksightDataSet.LogicalTableMapProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetPermissionsPropertyToTerraform(struct?: AwsQuicksightDataSet.PermissionsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetPermissionsPropertyToHclTerraform(struct?: AwsQuicksightDataSet.PermissionsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetPhysicalTableMapCustomSqlColumnsPropertyToTerraform(struct?: AwsQuicksightDataSet.PhysicalTableMapCustomSqlColumnsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetPhysicalTableMapCustomSqlColumnsPropertyToHclTerraform(struct?: AwsQuicksightDataSet.PhysicalTableMapCustomSqlColumnsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetCustomSqlPropertyToTerraform(struct?: AwsQuicksightDataSet.CustomSqlPropertyOutputReference | AwsQuicksightDataSet.CustomSqlProperty): any;
export declare function awsQuicksightDataSetCustomSqlPropertyToHclTerraform(struct?: AwsQuicksightDataSet.CustomSqlPropertyOutputReference | AwsQuicksightDataSet.CustomSqlProperty): any;
export declare function awsQuicksightDataSetPhysicalTableMapRelationalTableInputColumnsPropertyToTerraform(struct?: AwsQuicksightDataSet.PhysicalTableMapRelationalTableInputColumnsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetPhysicalTableMapRelationalTableInputColumnsPropertyToHclTerraform(struct?: AwsQuicksightDataSet.PhysicalTableMapRelationalTableInputColumnsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetRelationalTablePropertyToTerraform(struct?: AwsQuicksightDataSet.RelationalTablePropertyOutputReference | AwsQuicksightDataSet.RelationalTableProperty): any;
export declare function awsQuicksightDataSetRelationalTablePropertyToHclTerraform(struct?: AwsQuicksightDataSet.RelationalTablePropertyOutputReference | AwsQuicksightDataSet.RelationalTableProperty): any;
export declare function awsQuicksightDataSetPhysicalTableMapS3SourceInputColumnsPropertyToTerraform(struct?: AwsQuicksightDataSet.PhysicalTableMapS3SourceInputColumnsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetPhysicalTableMapS3SourceInputColumnsPropertyToHclTerraform(struct?: AwsQuicksightDataSet.PhysicalTableMapS3SourceInputColumnsProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetUploadSettingsPropertyToTerraform(struct?: AwsQuicksightDataSet.UploadSettingsPropertyOutputReference | AwsQuicksightDataSet.UploadSettingsProperty): any;
export declare function awsQuicksightDataSetUploadSettingsPropertyToHclTerraform(struct?: AwsQuicksightDataSet.UploadSettingsPropertyOutputReference | AwsQuicksightDataSet.UploadSettingsProperty): any;
export declare function awsQuicksightDataSetS3SourcePropertyToTerraform(struct?: AwsQuicksightDataSet.S3SourcePropertyOutputReference | AwsQuicksightDataSet.S3SourceProperty): any;
export declare function awsQuicksightDataSetS3SourcePropertyToHclTerraform(struct?: AwsQuicksightDataSet.S3SourcePropertyOutputReference | AwsQuicksightDataSet.S3SourceProperty): any;
export declare function awsQuicksightDataSetPhysicalTableMapPropertyToTerraform(struct?: AwsQuicksightDataSet.PhysicalTableMapProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetPhysicalTableMapPropertyToHclTerraform(struct?: AwsQuicksightDataSet.PhysicalTableMapProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetLookbackWindowPropertyToTerraform(struct?: AwsQuicksightDataSet.LookbackWindowPropertyOutputReference | AwsQuicksightDataSet.LookbackWindowProperty): any;
export declare function awsQuicksightDataSetLookbackWindowPropertyToHclTerraform(struct?: AwsQuicksightDataSet.LookbackWindowPropertyOutputReference | AwsQuicksightDataSet.LookbackWindowProperty): any;
export declare function awsQuicksightDataSetIncrementalRefreshPropertyToTerraform(struct?: AwsQuicksightDataSet.IncrementalRefreshPropertyOutputReference | AwsQuicksightDataSet.IncrementalRefreshProperty): any;
export declare function awsQuicksightDataSetIncrementalRefreshPropertyToHclTerraform(struct?: AwsQuicksightDataSet.IncrementalRefreshPropertyOutputReference | AwsQuicksightDataSet.IncrementalRefreshProperty): any;
export declare function awsQuicksightDataSetRefreshConfigurationPropertyToTerraform(struct?: AwsQuicksightDataSet.RefreshConfigurationPropertyOutputReference | AwsQuicksightDataSet.RefreshConfigurationProperty): any;
export declare function awsQuicksightDataSetRefreshConfigurationPropertyToHclTerraform(struct?: AwsQuicksightDataSet.RefreshConfigurationPropertyOutputReference | AwsQuicksightDataSet.RefreshConfigurationProperty): any;
export declare function awsQuicksightDataSetRefreshPropertiesPropertyToTerraform(struct?: AwsQuicksightDataSet.RefreshPropertiesPropertyOutputReference | AwsQuicksightDataSet.RefreshPropertiesProperty): any;
export declare function awsQuicksightDataSetRefreshPropertiesPropertyToHclTerraform(struct?: AwsQuicksightDataSet.RefreshPropertiesPropertyOutputReference | AwsQuicksightDataSet.RefreshPropertiesProperty): any;
export declare function awsQuicksightDataSetRowLevelPermissionDataSetPropertyToTerraform(struct?: AwsQuicksightDataSet.RowLevelPermissionDataSetPropertyOutputReference | AwsQuicksightDataSet.RowLevelPermissionDataSetProperty): any;
export declare function awsQuicksightDataSetRowLevelPermissionDataSetPropertyToHclTerraform(struct?: AwsQuicksightDataSet.RowLevelPermissionDataSetPropertyOutputReference | AwsQuicksightDataSet.RowLevelPermissionDataSetProperty): any;
export declare function awsQuicksightDataSetTagRulesPropertyToTerraform(struct?: AwsQuicksightDataSet.TagRulesProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetTagRulesPropertyToHclTerraform(struct?: AwsQuicksightDataSet.TagRulesProperty | cdktn.IResolvable): any;
export declare function awsQuicksightDataSetRowLevelPermissionTagConfigurationPropertyToTerraform(struct?: AwsQuicksightDataSet.RowLevelPermissionTagConfigurationPropertyOutputReference | AwsQuicksightDataSet.RowLevelPermissionTagConfigurationProperty): any;
export declare function awsQuicksightDataSetRowLevelPermissionTagConfigurationPropertyToHclTerraform(struct?: AwsQuicksightDataSet.RowLevelPermissionTagConfigurationPropertyOutputReference | AwsQuicksightDataSet.RowLevelPermissionTagConfigurationProperty): any;
export declare namespace AwsQuicksightDataSet {
    interface OutputColumnsProperty {
    }
    class OutputColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputColumnsProperty | undefined;
        set internalValue(value: OutputColumnsProperty | undefined);
        get description(): string;
        get name(): string;
        get type(): string;
    }
    class OutputColumnsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputColumnsPropertyOutputReference;
    }
    interface GeoSpatialColumnGroupProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#columns AwsQuicksightDataSet#columns}
        */
        readonly columns: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#country_code AwsQuicksightDataSet#country_code}
        */
        readonly countryCode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#name AwsQuicksightDataSet#name}
        */
        readonly name: string;
    }
    class GeoSpatialColumnGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GeoSpatialColumnGroupProperty | undefined;
        set internalValue(value: GeoSpatialColumnGroupProperty | undefined);
        private _columns?;
        get columns(): string[];
        set columns(value: string[]);
        get columnsInput(): string[] | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        get countryCodeInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    interface ColumnGroupsProperty {
        /**
        * geo_spatial_column_group block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#geo_spatial_column_group AwsQuicksightDataSet#geo_spatial_column_group}
        */
        readonly geoSpatialColumnGroup?: GeoSpatialColumnGroupProperty;
    }
    class ColumnGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnGroupsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ColumnGroupsProperty | cdktn.IResolvable | undefined);
        private _geoSpatialColumnGroup;
        get geoSpatialColumnGroup(): GeoSpatialColumnGroupPropertyOutputReference;
        putGeoSpatialColumnGroup(value: GeoSpatialColumnGroupProperty): void;
        resetGeoSpatialColumnGroup(): void;
        get geoSpatialColumnGroupInput(): GeoSpatialColumnGroupProperty | undefined;
    }
    class ColumnGroupsPropertyList extends cdktn.ComplexList {
        internalValue?: ColumnGroupsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnGroupsPropertyOutputReference;
    }
    interface ColumnLevelPermissionRulesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_names AwsQuicksightDataSet#column_names}
        */
        readonly columnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#principals AwsQuicksightDataSet#principals}
        */
        readonly principals?: string[];
    }
    class ColumnLevelPermissionRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnLevelPermissionRulesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ColumnLevelPermissionRulesProperty | cdktn.IResolvable | undefined);
        private _columnNames?;
        get columnNames(): string[];
        set columnNames(value: string[]);
        resetColumnNames(): void;
        get columnNamesInput(): string[] | undefined;
        private _principals?;
        get principals(): string[];
        set principals(value: string[]);
        resetPrincipals(): void;
        get principalsInput(): string[] | undefined;
    }
    class ColumnLevelPermissionRulesPropertyList extends cdktn.ComplexList {
        internalValue?: ColumnLevelPermissionRulesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnLevelPermissionRulesPropertyOutputReference;
    }
    interface DataSetUsageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#disable_use_as_direct_query_source AwsQuicksightDataSet#disable_use_as_direct_query_source}
        */
        readonly disableUseAsDirectQuerySource?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#disable_use_as_imported_source AwsQuicksightDataSet#disable_use_as_imported_source}
        */
        readonly disableUseAsImportedSource?: boolean | cdktn.IResolvable;
    }
    class DataSetUsageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataSetUsageConfigurationProperty | undefined;
        set internalValue(value: DataSetUsageConfigurationProperty | undefined);
        private _disableUseAsDirectQuerySource?;
        get disableUseAsDirectQuerySource(): boolean | cdktn.IResolvable;
        set disableUseAsDirectQuerySource(value: boolean | cdktn.IResolvable);
        resetDisableUseAsDirectQuerySource(): void;
        get disableUseAsDirectQuerySourceInput(): boolean | cdktn.IResolvable | undefined;
        private _disableUseAsImportedSource?;
        get disableUseAsImportedSource(): boolean | cdktn.IResolvable;
        set disableUseAsImportedSource(value: boolean | cdktn.IResolvable);
        resetDisableUseAsImportedSource(): void;
        get disableUseAsImportedSourceInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface FieldFoldersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#columns AwsQuicksightDataSet#columns}
        */
        readonly columns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#description AwsQuicksightDataSet#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#field_folders_id AwsQuicksightDataSet#field_folders_id}
        */
        readonly fieldFoldersId: string;
    }
    class FieldFoldersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FieldFoldersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FieldFoldersProperty | cdktn.IResolvable | undefined);
        private _columns?;
        get columns(): string[];
        set columns(value: string[]);
        resetColumns(): void;
        get columnsInput(): string[] | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _fieldFoldersId?;
        get fieldFoldersId(): string;
        set fieldFoldersId(value: string);
        get fieldFoldersIdInput(): string | undefined;
    }
    class FieldFoldersPropertyList extends cdktn.ComplexList {
        internalValue?: FieldFoldersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FieldFoldersPropertyOutputReference;
    }
    interface CastColumnTypeOperationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_name AwsQuicksightDataSet#column_name}
        */
        readonly columnName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#format AwsQuicksightDataSet#format}
        */
        readonly format?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#new_column_type AwsQuicksightDataSet#new_column_type}
        */
        readonly newColumnType: string;
    }
    class CastColumnTypeOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CastColumnTypeOperationProperty | undefined;
        set internalValue(value: CastColumnTypeOperationProperty | undefined);
        private _columnName?;
        get columnName(): string;
        set columnName(value: string);
        get columnNameInput(): string | undefined;
        private _format?;
        get format(): string;
        set format(value: string);
        resetFormat(): void;
        get formatInput(): string | undefined;
        private _newColumnType?;
        get newColumnType(): string;
        set newColumnType(value: string);
        get newColumnTypeInput(): string | undefined;
    }
    interface LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_id AwsQuicksightDataSet#column_id}
        */
        readonly columnId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_name AwsQuicksightDataSet#column_name}
        */
        readonly columnName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#expression AwsQuicksightDataSet#expression}
        */
        readonly expression: string;
    }
    class LogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty | cdktn.IResolvable | undefined);
        private _columnId?;
        get columnId(): string;
        set columnId(value: string);
        get columnIdInput(): string | undefined;
        private _columnName?;
        get columnName(): string;
        set columnName(value: string);
        get columnNameInput(): string | undefined;
        private _expression?;
        get expression(): string;
        set expression(value: string);
        get expressionInput(): string | undefined;
    }
    class LogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyOutputReference;
    }
    interface CreateColumnsOperationProperty {
        /**
        * columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#columns AwsQuicksightDataSet#columns}
        */
        readonly columns: LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty[] | cdktn.IResolvable;
    }
    class CreateColumnsOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CreateColumnsOperationProperty | undefined;
        set internalValue(value: CreateColumnsOperationProperty | undefined);
        private _columns;
        get columns(): LogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyList;
        putColumns(value: LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty[] | cdktn.IResolvable): void;
        get columnsInput(): cdktn.IResolvable | LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty[] | undefined;
    }
    interface FilterOperationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#condition_expression AwsQuicksightDataSet#condition_expression}
        */
        readonly conditionExpression: string;
    }
    class FilterOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterOperationProperty | undefined;
        set internalValue(value: FilterOperationProperty | undefined);
        private _conditionExpression?;
        get conditionExpression(): string;
        set conditionExpression(value: string);
        get conditionExpressionInput(): string | undefined;
    }
    interface ProjectOperationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#projected_columns AwsQuicksightDataSet#projected_columns}
        */
        readonly projectedColumns: string[];
    }
    class ProjectOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProjectOperationProperty | undefined;
        set internalValue(value: ProjectOperationProperty | undefined);
        private _projectedColumns?;
        get projectedColumns(): string[];
        set projectedColumns(value: string[]);
        get projectedColumnsInput(): string[] | undefined;
    }
    interface RenameColumnOperationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_name AwsQuicksightDataSet#column_name}
        */
        readonly columnName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#new_column_name AwsQuicksightDataSet#new_column_name}
        */
        readonly newColumnName: string;
    }
    class RenameColumnOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RenameColumnOperationProperty | undefined;
        set internalValue(value: RenameColumnOperationProperty | undefined);
        private _columnName?;
        get columnName(): string;
        set columnName(value: string);
        get columnNameInput(): string | undefined;
        private _newColumnName?;
        get newColumnName(): string;
        set newColumnName(value: string);
        get newColumnNameInput(): string | undefined;
    }
    interface ColumnDescriptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#text AwsQuicksightDataSet#text}
        */
        readonly text?: string;
    }
    class ColumnDescriptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ColumnDescriptionProperty | undefined;
        set internalValue(value: ColumnDescriptionProperty | undefined);
        private _text?;
        get text(): string;
        set text(value: string);
        resetText(): void;
        get textInput(): string | undefined;
    }
    interface TagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_geographic_role AwsQuicksightDataSet#column_geographic_role}
        */
        readonly columnGeographicRole?: string;
        /**
        * column_description block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_description AwsQuicksightDataSet#column_description}
        */
        readonly columnDescription?: ColumnDescriptionProperty;
    }
    class TagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagsProperty | cdktn.IResolvable | undefined);
        private _columnGeographicRole?;
        get columnGeographicRole(): string;
        set columnGeographicRole(value: string);
        resetColumnGeographicRole(): void;
        get columnGeographicRoleInput(): string | undefined;
        private _columnDescription;
        get columnDescription(): ColumnDescriptionPropertyOutputReference;
        putColumnDescription(value: ColumnDescriptionProperty): void;
        resetColumnDescription(): void;
        get columnDescriptionInput(): ColumnDescriptionProperty | undefined;
    }
    class TagsPropertyList extends cdktn.ComplexList {
        internalValue?: TagsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagsPropertyOutputReference;
    }
    interface TagColumnOperationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_name AwsQuicksightDataSet#column_name}
        */
        readonly columnName: string;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#tags AwsQuicksightDataSet#tags}
        */
        readonly tags: TagsProperty[] | cdktn.IResolvable;
    }
    class TagColumnOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TagColumnOperationProperty | undefined;
        set internalValue(value: TagColumnOperationProperty | undefined);
        private _columnName?;
        get columnName(): string;
        set columnName(value: string);
        get columnNameInput(): string | undefined;
        private _tags;
        get tags(): TagsPropertyList;
        putTags(value: TagsProperty[] | cdktn.IResolvable): void;
        get tagsInput(): cdktn.IResolvable | TagsProperty[] | undefined;
    }
    interface UntagColumnOperationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_name AwsQuicksightDataSet#column_name}
        */
        readonly columnName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#tag_names AwsQuicksightDataSet#tag_names}
        */
        readonly tagNames: string[];
    }
    class UntagColumnOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UntagColumnOperationProperty | undefined;
        set internalValue(value: UntagColumnOperationProperty | undefined);
        private _columnName?;
        get columnName(): string;
        set columnName(value: string);
        get columnNameInput(): string | undefined;
        private _tagNames?;
        get tagNames(): string[];
        set tagNames(value: string[]);
        get tagNamesInput(): string[] | undefined;
    }
    interface DataTransformsProperty {
        /**
        * cast_column_type_operation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#cast_column_type_operation AwsQuicksightDataSet#cast_column_type_operation}
        */
        readonly castColumnTypeOperation?: CastColumnTypeOperationProperty;
        /**
        * create_columns_operation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#create_columns_operation AwsQuicksightDataSet#create_columns_operation}
        */
        readonly createColumnsOperation?: CreateColumnsOperationProperty;
        /**
        * filter_operation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#filter_operation AwsQuicksightDataSet#filter_operation}
        */
        readonly filterOperation?: FilterOperationProperty;
        /**
        * project_operation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#project_operation AwsQuicksightDataSet#project_operation}
        */
        readonly projectOperation?: ProjectOperationProperty;
        /**
        * rename_column_operation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#rename_column_operation AwsQuicksightDataSet#rename_column_operation}
        */
        readonly renameColumnOperation?: RenameColumnOperationProperty;
        /**
        * tag_column_operation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#tag_column_operation AwsQuicksightDataSet#tag_column_operation}
        */
        readonly tagColumnOperation?: TagColumnOperationProperty;
        /**
        * untag_column_operation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#untag_column_operation AwsQuicksightDataSet#untag_column_operation}
        */
        readonly untagColumnOperation?: UntagColumnOperationProperty;
    }
    class DataTransformsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataTransformsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataTransformsProperty | cdktn.IResolvable | undefined);
        private _castColumnTypeOperation;
        get castColumnTypeOperation(): CastColumnTypeOperationPropertyOutputReference;
        putCastColumnTypeOperation(value: CastColumnTypeOperationProperty): void;
        resetCastColumnTypeOperation(): void;
        get castColumnTypeOperationInput(): CastColumnTypeOperationProperty | undefined;
        private _createColumnsOperation;
        get createColumnsOperation(): CreateColumnsOperationPropertyOutputReference;
        putCreateColumnsOperation(value: CreateColumnsOperationProperty): void;
        resetCreateColumnsOperation(): void;
        get createColumnsOperationInput(): CreateColumnsOperationProperty | undefined;
        private _filterOperation;
        get filterOperation(): FilterOperationPropertyOutputReference;
        putFilterOperation(value: FilterOperationProperty): void;
        resetFilterOperation(): void;
        get filterOperationInput(): FilterOperationProperty | undefined;
        private _projectOperation;
        get projectOperation(): ProjectOperationPropertyOutputReference;
        putProjectOperation(value: ProjectOperationProperty): void;
        resetProjectOperation(): void;
        get projectOperationInput(): ProjectOperationProperty | undefined;
        private _renameColumnOperation;
        get renameColumnOperation(): RenameColumnOperationPropertyOutputReference;
        putRenameColumnOperation(value: RenameColumnOperationProperty): void;
        resetRenameColumnOperation(): void;
        get renameColumnOperationInput(): RenameColumnOperationProperty | undefined;
        private _tagColumnOperation;
        get tagColumnOperation(): TagColumnOperationPropertyOutputReference;
        putTagColumnOperation(value: TagColumnOperationProperty): void;
        resetTagColumnOperation(): void;
        get tagColumnOperationInput(): TagColumnOperationProperty | undefined;
        private _untagColumnOperation;
        get untagColumnOperation(): UntagColumnOperationPropertyOutputReference;
        putUntagColumnOperation(value: UntagColumnOperationProperty): void;
        resetUntagColumnOperation(): void;
        get untagColumnOperationInput(): UntagColumnOperationProperty | undefined;
    }
    class DataTransformsPropertyList extends cdktn.ComplexList {
        internalValue?: DataTransformsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataTransformsPropertyOutputReference;
    }
    interface LeftJoinKeyPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#unique_key AwsQuicksightDataSet#unique_key}
        */
        readonly uniqueKey?: boolean | cdktn.IResolvable;
    }
    class LeftJoinKeyPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LeftJoinKeyPropertiesProperty | undefined;
        set internalValue(value: LeftJoinKeyPropertiesProperty | undefined);
        private _uniqueKey?;
        get uniqueKey(): boolean | cdktn.IResolvable;
        set uniqueKey(value: boolean | cdktn.IResolvable);
        resetUniqueKey(): void;
        get uniqueKeyInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface RightJoinKeyPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#unique_key AwsQuicksightDataSet#unique_key}
        */
        readonly uniqueKey?: boolean | cdktn.IResolvable;
    }
    class RightJoinKeyPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RightJoinKeyPropertiesProperty | undefined;
        set internalValue(value: RightJoinKeyPropertiesProperty | undefined);
        private _uniqueKey?;
        get uniqueKey(): boolean | cdktn.IResolvable;
        set uniqueKey(value: boolean | cdktn.IResolvable);
        resetUniqueKey(): void;
        get uniqueKeyInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface JoinInstructionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#left_operand AwsQuicksightDataSet#left_operand}
        */
        readonly leftOperand: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#on_clause AwsQuicksightDataSet#on_clause}
        */
        readonly onClause: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#right_operand AwsQuicksightDataSet#right_operand}
        */
        readonly rightOperand: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#type AwsQuicksightDataSet#type}
        */
        readonly type: string;
        /**
        * left_join_key_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#left_join_key_properties AwsQuicksightDataSet#left_join_key_properties}
        */
        readonly leftJoinKeyProperties?: LeftJoinKeyPropertiesProperty;
        /**
        * right_join_key_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#right_join_key_properties AwsQuicksightDataSet#right_join_key_properties}
        */
        readonly rightJoinKeyProperties?: RightJoinKeyPropertiesProperty;
    }
    class JoinInstructionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JoinInstructionProperty | undefined;
        set internalValue(value: JoinInstructionProperty | undefined);
        private _leftOperand?;
        get leftOperand(): string;
        set leftOperand(value: string);
        get leftOperandInput(): string | undefined;
        private _onClause?;
        get onClause(): string;
        set onClause(value: string);
        get onClauseInput(): string | undefined;
        private _rightOperand?;
        get rightOperand(): string;
        set rightOperand(value: string);
        get rightOperandInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _leftJoinKeyProperties;
        get leftJoinKeyProperties(): LeftJoinKeyPropertiesPropertyOutputReference;
        putLeftJoinKeyProperties(value: LeftJoinKeyPropertiesProperty): void;
        resetLeftJoinKeyProperties(): void;
        get leftJoinKeyPropertiesInput(): LeftJoinKeyPropertiesProperty | undefined;
        private _rightJoinKeyProperties;
        get rightJoinKeyProperties(): RightJoinKeyPropertiesPropertyOutputReference;
        putRightJoinKeyProperties(value: RightJoinKeyPropertiesProperty): void;
        resetRightJoinKeyProperties(): void;
        get rightJoinKeyPropertiesInput(): RightJoinKeyPropertiesProperty | undefined;
    }
    interface SourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#data_set_arn AwsQuicksightDataSet#data_set_arn}
        */
        readonly dataSetArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#physical_table_id AwsQuicksightDataSet#physical_table_id}
        */
        readonly physicalTableId?: string;
        /**
        * join_instruction block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#join_instruction AwsQuicksightDataSet#join_instruction}
        */
        readonly joinInstruction?: JoinInstructionProperty;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceProperty | undefined;
        set internalValue(value: SourceProperty | undefined);
        private _dataSetArn?;
        get dataSetArn(): string;
        set dataSetArn(value: string);
        resetDataSetArn(): void;
        get dataSetArnInput(): string | undefined;
        private _physicalTableId?;
        get physicalTableId(): string;
        set physicalTableId(value: string);
        resetPhysicalTableId(): void;
        get physicalTableIdInput(): string | undefined;
        private _joinInstruction;
        get joinInstruction(): JoinInstructionPropertyOutputReference;
        putJoinInstruction(value: JoinInstructionProperty): void;
        resetJoinInstruction(): void;
        get joinInstructionInput(): JoinInstructionProperty | undefined;
    }
    interface LogicalTableMapProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#alias AwsQuicksightDataSet#alias}
        */
        readonly alias: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#logical_table_map_id AwsQuicksightDataSet#logical_table_map_id}
        */
        readonly logicalTableMapId: string;
        /**
        * data_transforms block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#data_transforms AwsQuicksightDataSet#data_transforms}
        */
        readonly dataTransforms?: DataTransformsProperty[] | cdktn.IResolvable;
        /**
        * source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#source AwsQuicksightDataSet#source}
        */
        readonly source: SourceProperty;
    }
    class LogicalTableMapPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogicalTableMapProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogicalTableMapProperty | cdktn.IResolvable | undefined);
        private _alias?;
        get alias(): string;
        set alias(value: string);
        get aliasInput(): string | undefined;
        private _logicalTableMapId?;
        get logicalTableMapId(): string;
        set logicalTableMapId(value: string);
        get logicalTableMapIdInput(): string | undefined;
        private _dataTransforms;
        get dataTransforms(): DataTransformsPropertyList;
        putDataTransforms(value: DataTransformsProperty[] | cdktn.IResolvable): void;
        resetDataTransforms(): void;
        get dataTransformsInput(): cdktn.IResolvable | DataTransformsProperty[] | undefined;
        private _source;
        get source(): SourcePropertyOutputReference;
        putSource(value: SourceProperty): void;
        get sourceInput(): SourceProperty | undefined;
    }
    class LogicalTableMapPropertyList extends cdktn.ComplexList {
        internalValue?: LogicalTableMapProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogicalTableMapPropertyOutputReference;
    }
    interface PermissionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#actions AwsQuicksightDataSet#actions}
        */
        readonly actions: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#principal AwsQuicksightDataSet#principal}
        */
        readonly principal: string;
    }
    class PermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PermissionsProperty | cdktn.IResolvable | undefined);
        private _actions?;
        get actions(): string[];
        set actions(value: string[]);
        get actionsInput(): string[] | undefined;
        private _principal?;
        get principal(): string;
        set principal(value: string);
        get principalInput(): string | undefined;
    }
    class PermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: PermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PermissionsPropertyOutputReference;
    }
    interface PhysicalTableMapCustomSqlColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#name AwsQuicksightDataSet#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#type AwsQuicksightDataSet#type}
        */
        readonly type: string;
    }
    class PhysicalTableMapCustomSqlColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhysicalTableMapCustomSqlColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PhysicalTableMapCustomSqlColumnsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class PhysicalTableMapCustomSqlColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: PhysicalTableMapCustomSqlColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhysicalTableMapCustomSqlColumnsPropertyOutputReference;
    }
    interface CustomSqlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#data_source_arn AwsQuicksightDataSet#data_source_arn}
        */
        readonly dataSourceArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#name AwsQuicksightDataSet#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#sql_query AwsQuicksightDataSet#sql_query}
        */
        readonly sqlQuery: string;
        /**
        * columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#columns AwsQuicksightDataSet#columns}
        */
        readonly columns?: PhysicalTableMapCustomSqlColumnsProperty[] | cdktn.IResolvable;
    }
    class CustomSqlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomSqlProperty | undefined;
        set internalValue(value: CustomSqlProperty | undefined);
        private _dataSourceArn?;
        get dataSourceArn(): string;
        set dataSourceArn(value: string);
        get dataSourceArnInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _sqlQuery?;
        get sqlQuery(): string;
        set sqlQuery(value: string);
        get sqlQueryInput(): string | undefined;
        private _columns;
        get columns(): PhysicalTableMapCustomSqlColumnsPropertyList;
        putColumns(value: PhysicalTableMapCustomSqlColumnsProperty[] | cdktn.IResolvable): void;
        resetColumns(): void;
        get columnsInput(): cdktn.IResolvable | PhysicalTableMapCustomSqlColumnsProperty[] | undefined;
    }
    interface PhysicalTableMapRelationalTableInputColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#name AwsQuicksightDataSet#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#type AwsQuicksightDataSet#type}
        */
        readonly type: string;
    }
    class PhysicalTableMapRelationalTableInputColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhysicalTableMapRelationalTableInputColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PhysicalTableMapRelationalTableInputColumnsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class PhysicalTableMapRelationalTableInputColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: PhysicalTableMapRelationalTableInputColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhysicalTableMapRelationalTableInputColumnsPropertyOutputReference;
    }
    interface RelationalTableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#catalog AwsQuicksightDataSet#catalog}
        */
        readonly catalog?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#data_source_arn AwsQuicksightDataSet#data_source_arn}
        */
        readonly dataSourceArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#name AwsQuicksightDataSet#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#schema AwsQuicksightDataSet#schema}
        */
        readonly schema?: string;
        /**
        * input_columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#input_columns AwsQuicksightDataSet#input_columns}
        */
        readonly inputColumns: PhysicalTableMapRelationalTableInputColumnsProperty[] | cdktn.IResolvable;
    }
    class RelationalTablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RelationalTableProperty | undefined;
        set internalValue(value: RelationalTableProperty | undefined);
        private _catalog?;
        get catalog(): string;
        set catalog(value: string);
        resetCatalog(): void;
        get catalogInput(): string | undefined;
        private _dataSourceArn?;
        get dataSourceArn(): string;
        set dataSourceArn(value: string);
        get dataSourceArnInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _schema?;
        get schema(): string;
        set schema(value: string);
        resetSchema(): void;
        get schemaInput(): string | undefined;
        private _inputColumns;
        get inputColumns(): PhysicalTableMapRelationalTableInputColumnsPropertyList;
        putInputColumns(value: PhysicalTableMapRelationalTableInputColumnsProperty[] | cdktn.IResolvable): void;
        get inputColumnsInput(): cdktn.IResolvable | PhysicalTableMapRelationalTableInputColumnsProperty[] | undefined;
    }
    interface PhysicalTableMapS3SourceInputColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#name AwsQuicksightDataSet#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#type AwsQuicksightDataSet#type}
        */
        readonly type: string;
    }
    class PhysicalTableMapS3SourceInputColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhysicalTableMapS3SourceInputColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PhysicalTableMapS3SourceInputColumnsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class PhysicalTableMapS3SourceInputColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: PhysicalTableMapS3SourceInputColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhysicalTableMapS3SourceInputColumnsPropertyOutputReference;
    }
    interface UploadSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#contains_header AwsQuicksightDataSet#contains_header}
        */
        readonly containsHeader?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#delimiter AwsQuicksightDataSet#delimiter}
        */
        readonly delimiter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#format AwsQuicksightDataSet#format}
        */
        readonly format?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#start_from_row AwsQuicksightDataSet#start_from_row}
        */
        readonly startFromRow?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#text_qualifier AwsQuicksightDataSet#text_qualifier}
        */
        readonly textQualifier?: string;
    }
    class UploadSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UploadSettingsProperty | undefined;
        set internalValue(value: UploadSettingsProperty | undefined);
        private _containsHeader?;
        get containsHeader(): boolean | cdktn.IResolvable;
        set containsHeader(value: boolean | cdktn.IResolvable);
        resetContainsHeader(): void;
        get containsHeaderInput(): boolean | cdktn.IResolvable | undefined;
        private _delimiter?;
        get delimiter(): string;
        set delimiter(value: string);
        resetDelimiter(): void;
        get delimiterInput(): string | undefined;
        private _format?;
        get format(): string;
        set format(value: string);
        resetFormat(): void;
        get formatInput(): string | undefined;
        private _startFromRow?;
        get startFromRow(): number;
        set startFromRow(value: number);
        resetStartFromRow(): void;
        get startFromRowInput(): number | undefined;
        private _textQualifier?;
        get textQualifier(): string;
        set textQualifier(value: string);
        resetTextQualifier(): void;
        get textQualifierInput(): string | undefined;
    }
    interface S3SourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#data_source_arn AwsQuicksightDataSet#data_source_arn}
        */
        readonly dataSourceArn: string;
        /**
        * input_columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#input_columns AwsQuicksightDataSet#input_columns}
        */
        readonly inputColumns: PhysicalTableMapS3SourceInputColumnsProperty[] | cdktn.IResolvable;
        /**
        * upload_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#upload_settings AwsQuicksightDataSet#upload_settings}
        */
        readonly uploadSettings: UploadSettingsProperty;
    }
    class S3SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3SourceProperty | undefined;
        set internalValue(value: S3SourceProperty | undefined);
        private _dataSourceArn?;
        get dataSourceArn(): string;
        set dataSourceArn(value: string);
        get dataSourceArnInput(): string | undefined;
        private _inputColumns;
        get inputColumns(): PhysicalTableMapS3SourceInputColumnsPropertyList;
        putInputColumns(value: PhysicalTableMapS3SourceInputColumnsProperty[] | cdktn.IResolvable): void;
        get inputColumnsInput(): cdktn.IResolvable | PhysicalTableMapS3SourceInputColumnsProperty[] | undefined;
        private _uploadSettings;
        get uploadSettings(): UploadSettingsPropertyOutputReference;
        putUploadSettings(value: UploadSettingsProperty): void;
        get uploadSettingsInput(): UploadSettingsProperty | undefined;
    }
    interface PhysicalTableMapProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#physical_table_map_id AwsQuicksightDataSet#physical_table_map_id}
        */
        readonly physicalTableMapId: string;
        /**
        * custom_sql block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#custom_sql AwsQuicksightDataSet#custom_sql}
        */
        readonly customSql?: CustomSqlProperty;
        /**
        * relational_table block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#relational_table AwsQuicksightDataSet#relational_table}
        */
        readonly relationalTable?: RelationalTableProperty;
        /**
        * s3_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#s3_source AwsQuicksightDataSet#s3_source}
        */
        readonly s3Source?: S3SourceProperty;
    }
    class PhysicalTableMapPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhysicalTableMapProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PhysicalTableMapProperty | cdktn.IResolvable | undefined);
        private _physicalTableMapId?;
        get physicalTableMapId(): string;
        set physicalTableMapId(value: string);
        get physicalTableMapIdInput(): string | undefined;
        private _customSql;
        get customSql(): CustomSqlPropertyOutputReference;
        putCustomSql(value: CustomSqlProperty): void;
        resetCustomSql(): void;
        get customSqlInput(): CustomSqlProperty | undefined;
        private _relationalTable;
        get relationalTable(): RelationalTablePropertyOutputReference;
        putRelationalTable(value: RelationalTableProperty): void;
        resetRelationalTable(): void;
        get relationalTableInput(): RelationalTableProperty | undefined;
        private _s3Source;
        get s3Source(): S3SourcePropertyOutputReference;
        putS3Source(value: S3SourceProperty): void;
        resetS3Source(): void;
        get s3SourceInput(): S3SourceProperty | undefined;
    }
    class PhysicalTableMapPropertyList extends cdktn.ComplexList {
        internalValue?: PhysicalTableMapProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhysicalTableMapPropertyOutputReference;
    }
    interface LookbackWindowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_name AwsQuicksightDataSet#column_name}
        */
        readonly columnName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#size AwsQuicksightDataSet#size}
        */
        readonly size: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#size_unit AwsQuicksightDataSet#size_unit}
        */
        readonly sizeUnit: string;
    }
    class LookbackWindowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LookbackWindowProperty | undefined;
        set internalValue(value: LookbackWindowProperty | undefined);
        private _columnName?;
        get columnName(): string;
        set columnName(value: string);
        get columnNameInput(): string | undefined;
        private _size?;
        get size(): number;
        set size(value: number);
        get sizeInput(): number | undefined;
        private _sizeUnit?;
        get sizeUnit(): string;
        set sizeUnit(value: string);
        get sizeUnitInput(): string | undefined;
    }
    interface IncrementalRefreshProperty {
        /**
        * lookback_window block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#lookback_window AwsQuicksightDataSet#lookback_window}
        */
        readonly lookbackWindow: LookbackWindowProperty;
    }
    class IncrementalRefreshPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IncrementalRefreshProperty | undefined;
        set internalValue(value: IncrementalRefreshProperty | undefined);
        private _lookbackWindow;
        get lookbackWindow(): LookbackWindowPropertyOutputReference;
        putLookbackWindow(value: LookbackWindowProperty): void;
        get lookbackWindowInput(): LookbackWindowProperty | undefined;
    }
    interface RefreshConfigurationProperty {
        /**
        * incremental_refresh block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#incremental_refresh AwsQuicksightDataSet#incremental_refresh}
        */
        readonly incrementalRefresh: IncrementalRefreshProperty;
    }
    class RefreshConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RefreshConfigurationProperty | undefined;
        set internalValue(value: RefreshConfigurationProperty | undefined);
        private _incrementalRefresh;
        get incrementalRefresh(): IncrementalRefreshPropertyOutputReference;
        putIncrementalRefresh(value: IncrementalRefreshProperty): void;
        get incrementalRefreshInput(): IncrementalRefreshProperty | undefined;
    }
    interface RefreshPropertiesProperty {
        /**
        * refresh_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#refresh_configuration AwsQuicksightDataSet#refresh_configuration}
        */
        readonly refreshConfiguration: RefreshConfigurationProperty;
    }
    class RefreshPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RefreshPropertiesProperty | undefined;
        set internalValue(value: RefreshPropertiesProperty | undefined);
        private _refreshConfiguration;
        get refreshConfiguration(): RefreshConfigurationPropertyOutputReference;
        putRefreshConfiguration(value: RefreshConfigurationProperty): void;
        get refreshConfigurationInput(): RefreshConfigurationProperty | undefined;
    }
    interface RowLevelPermissionDataSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#arn AwsQuicksightDataSet#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#format_version AwsQuicksightDataSet#format_version}
        */
        readonly formatVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#namespace AwsQuicksightDataSet#namespace}
        */
        readonly namespace?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#permission_policy AwsQuicksightDataSet#permission_policy}
        */
        readonly permissionPolicy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#status AwsQuicksightDataSet#status}
        */
        readonly status?: string;
    }
    class RowLevelPermissionDataSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RowLevelPermissionDataSetProperty | undefined;
        set internalValue(value: RowLevelPermissionDataSetProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _formatVersion?;
        get formatVersion(): string;
        set formatVersion(value: string);
        resetFormatVersion(): void;
        get formatVersionInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        resetNamespace(): void;
        get namespaceInput(): string | undefined;
        private _permissionPolicy?;
        get permissionPolicy(): string;
        set permissionPolicy(value: string);
        get permissionPolicyInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface TagRulesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_name AwsQuicksightDataSet#column_name}
        */
        readonly columnName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#match_all_value AwsQuicksightDataSet#match_all_value}
        */
        readonly matchAllValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#tag_key AwsQuicksightDataSet#tag_key}
        */
        readonly tagKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#tag_multi_value_delimiter AwsQuicksightDataSet#tag_multi_value_delimiter}
        */
        readonly tagMultiValueDelimiter?: string;
    }
    class TagRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagRulesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagRulesProperty | cdktn.IResolvable | undefined);
        private _columnName?;
        get columnName(): string;
        set columnName(value: string);
        get columnNameInput(): string | undefined;
        private _matchAllValue?;
        get matchAllValue(): string;
        set matchAllValue(value: string);
        resetMatchAllValue(): void;
        get matchAllValueInput(): string | undefined;
        private _tagKey?;
        get tagKey(): string;
        set tagKey(value: string);
        get tagKeyInput(): string | undefined;
        private _tagMultiValueDelimiter?;
        get tagMultiValueDelimiter(): string;
        set tagMultiValueDelimiter(value: string);
        resetTagMultiValueDelimiter(): void;
        get tagMultiValueDelimiterInput(): string | undefined;
    }
    class TagRulesPropertyList extends cdktn.ComplexList {
        internalValue?: TagRulesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagRulesPropertyOutputReference;
    }
    interface RowLevelPermissionTagConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#status AwsQuicksightDataSet#status}
        */
        readonly status?: string;
        /**
        * tag_rules block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#tag_rules AwsQuicksightDataSet#tag_rules}
        */
        readonly tagRules: TagRulesProperty[] | cdktn.IResolvable;
    }
    class RowLevelPermissionTagConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RowLevelPermissionTagConfigurationProperty | undefined;
        set internalValue(value: RowLevelPermissionTagConfigurationProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
        private _tagRules;
        get tagRules(): TagRulesPropertyList;
        putTagRules(value: TagRulesProperty[] | cdktn.IResolvable): void;
        get tagRulesInput(): cdktn.IResolvable | TagRulesProperty[] | undefined;
    }
}
