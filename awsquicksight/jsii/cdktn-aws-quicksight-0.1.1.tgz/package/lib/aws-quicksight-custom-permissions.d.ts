import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsQuicksightCustomPermissionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#aws_account_id AwsQuicksightCustomPermissions#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#custom_permissions_name AwsQuicksightCustomPermissions#custom_permissions_name}
    */
    readonly customPermissionsName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#region AwsQuicksightCustomPermissions#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#tags AwsQuicksightCustomPermissions#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * capabilities block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#capabilities AwsQuicksightCustomPermissions#capabilities}
    */
    readonly capabilities?: AwsQuicksightCustomPermissions.CapabilitiesProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions aws_quicksight_custom_permissions}
*/
export declare class AwsQuicksightCustomPermissions extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_quicksight_custom_permissions";
    /**
    * Generates CDKTN code for importing a AwsQuicksightCustomPermissions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsQuicksightCustomPermissions to import
    * @param importFromId The id of the existing AwsQuicksightCustomPermissions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsQuicksightCustomPermissions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions aws_quicksight_custom_permissions} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsQuicksightCustomPermissionsConfig
    */
    constructor(scope: Construct, id: string, config: AwsQuicksightCustomPermissionsConfig);
    get arn(): string;
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    private _customPermissionsName?;
    get customPermissionsName(): string;
    set customPermissionsName(value: string);
    get customPermissionsNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _capabilities;
    get capabilities(): AwsQuicksightCustomPermissions.CapabilitiesPropertyList;
    putCapabilities(value: AwsQuicksightCustomPermissions.CapabilitiesProperty[] | cdktn.IResolvable): void;
    resetCapabilities(): void;
    get capabilitiesInput(): cdktn.IResolvable | AwsQuicksightCustomPermissions.CapabilitiesProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsQuicksightCustomPermissionsCapabilitiesPropertyToTerraform(struct?: AwsQuicksightCustomPermissions.CapabilitiesProperty | cdktn.IResolvable): any;
export declare function awsQuicksightCustomPermissionsCapabilitiesPropertyToHclTerraform(struct?: AwsQuicksightCustomPermissions.CapabilitiesProperty | cdktn.IResolvable): any;
export declare namespace AwsQuicksightCustomPermissions {
    interface CapabilitiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#add_or_run_anomaly_detection_for_analyses AwsQuicksightCustomPermissions#add_or_run_anomaly_detection_for_analyses}
        */
        readonly addOrRunAnomalyDetectionForAnalyses?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#create_and_update_dashboard_email_reports AwsQuicksightCustomPermissions#create_and_update_dashboard_email_reports}
        */
        readonly createAndUpdateDashboardEmailReports?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#create_and_update_data_sources AwsQuicksightCustomPermissions#create_and_update_data_sources}
        */
        readonly createAndUpdateDataSources?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#create_and_update_datasets AwsQuicksightCustomPermissions#create_and_update_datasets}
        */
        readonly createAndUpdateDatasets?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#create_and_update_themes AwsQuicksightCustomPermissions#create_and_update_themes}
        */
        readonly createAndUpdateThemes?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#create_and_update_threshold_alerts AwsQuicksightCustomPermissions#create_and_update_threshold_alerts}
        */
        readonly createAndUpdateThresholdAlerts?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#create_shared_folders AwsQuicksightCustomPermissions#create_shared_folders}
        */
        readonly createSharedFolders?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#create_spice_dataset AwsQuicksightCustomPermissions#create_spice_dataset}
        */
        readonly createSpiceDataset?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#export_to_csv AwsQuicksightCustomPermissions#export_to_csv}
        */
        readonly exportToCsv?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#export_to_csv_in_scheduled_reports AwsQuicksightCustomPermissions#export_to_csv_in_scheduled_reports}
        */
        readonly exportToCsvInScheduledReports?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#export_to_excel AwsQuicksightCustomPermissions#export_to_excel}
        */
        readonly exportToExcel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#export_to_excel_in_scheduled_reports AwsQuicksightCustomPermissions#export_to_excel_in_scheduled_reports}
        */
        readonly exportToExcelInScheduledReports?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#export_to_pdf AwsQuicksightCustomPermissions#export_to_pdf}
        */
        readonly exportToPdf?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#export_to_pdf_in_scheduled_reports AwsQuicksightCustomPermissions#export_to_pdf_in_scheduled_reports}
        */
        readonly exportToPdfInScheduledReports?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#include_content_in_scheduled_reports_email AwsQuicksightCustomPermissions#include_content_in_scheduled_reports_email}
        */
        readonly includeContentInScheduledReportsEmail?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#print_reports AwsQuicksightCustomPermissions#print_reports}
        */
        readonly printReports?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#rename_shared_folders AwsQuicksightCustomPermissions#rename_shared_folders}
        */
        readonly renameSharedFolders?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#share_analyses AwsQuicksightCustomPermissions#share_analyses}
        */
        readonly shareAnalyses?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#share_dashboards AwsQuicksightCustomPermissions#share_dashboards}
        */
        readonly shareDashboards?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#share_data_sources AwsQuicksightCustomPermissions#share_data_sources}
        */
        readonly shareDataSources?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#share_datasets AwsQuicksightCustomPermissions#share_datasets}
        */
        readonly shareDatasets?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#subscribe_dashboard_email_reports AwsQuicksightCustomPermissions#subscribe_dashboard_email_reports}
        */
        readonly subscribeDashboardEmailReports?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_custom_permissions#view_account_spice_capacity AwsQuicksightCustomPermissions#view_account_spice_capacity}
        */
        readonly viewAccountSpiceCapacity?: string;
    }
    class CapabilitiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapabilitiesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CapabilitiesProperty | cdktn.IResolvable | undefined);
        private _addOrRunAnomalyDetectionForAnalyses?;
        get addOrRunAnomalyDetectionForAnalyses(): string;
        set addOrRunAnomalyDetectionForAnalyses(value: string);
        resetAddOrRunAnomalyDetectionForAnalyses(): void;
        get addOrRunAnomalyDetectionForAnalysesInput(): string | undefined;
        private _createAndUpdateDashboardEmailReports?;
        get createAndUpdateDashboardEmailReports(): string;
        set createAndUpdateDashboardEmailReports(value: string);
        resetCreateAndUpdateDashboardEmailReports(): void;
        get createAndUpdateDashboardEmailReportsInput(): string | undefined;
        private _createAndUpdateDataSources?;
        get createAndUpdateDataSources(): string;
        set createAndUpdateDataSources(value: string);
        resetCreateAndUpdateDataSources(): void;
        get createAndUpdateDataSourcesInput(): string | undefined;
        private _createAndUpdateDatasets?;
        get createAndUpdateDatasets(): string;
        set createAndUpdateDatasets(value: string);
        resetCreateAndUpdateDatasets(): void;
        get createAndUpdateDatasetsInput(): string | undefined;
        private _createAndUpdateThemes?;
        get createAndUpdateThemes(): string;
        set createAndUpdateThemes(value: string);
        resetCreateAndUpdateThemes(): void;
        get createAndUpdateThemesInput(): string | undefined;
        private _createAndUpdateThresholdAlerts?;
        get createAndUpdateThresholdAlerts(): string;
        set createAndUpdateThresholdAlerts(value: string);
        resetCreateAndUpdateThresholdAlerts(): void;
        get createAndUpdateThresholdAlertsInput(): string | undefined;
        private _createSharedFolders?;
        get createSharedFolders(): string;
        set createSharedFolders(value: string);
        resetCreateSharedFolders(): void;
        get createSharedFoldersInput(): string | undefined;
        private _createSpiceDataset?;
        get createSpiceDataset(): string;
        set createSpiceDataset(value: string);
        resetCreateSpiceDataset(): void;
        get createSpiceDatasetInput(): string | undefined;
        private _exportToCsv?;
        get exportToCsv(): string;
        set exportToCsv(value: string);
        resetExportToCsv(): void;
        get exportToCsvInput(): string | undefined;
        private _exportToCsvInScheduledReports?;
        get exportToCsvInScheduledReports(): string;
        set exportToCsvInScheduledReports(value: string);
        resetExportToCsvInScheduledReports(): void;
        get exportToCsvInScheduledReportsInput(): string | undefined;
        private _exportToExcel?;
        get exportToExcel(): string;
        set exportToExcel(value: string);
        resetExportToExcel(): void;
        get exportToExcelInput(): string | undefined;
        private _exportToExcelInScheduledReports?;
        get exportToExcelInScheduledReports(): string;
        set exportToExcelInScheduledReports(value: string);
        resetExportToExcelInScheduledReports(): void;
        get exportToExcelInScheduledReportsInput(): string | undefined;
        private _exportToPdf?;
        get exportToPdf(): string;
        set exportToPdf(value: string);
        resetExportToPdf(): void;
        get exportToPdfInput(): string | undefined;
        private _exportToPdfInScheduledReports?;
        get exportToPdfInScheduledReports(): string;
        set exportToPdfInScheduledReports(value: string);
        resetExportToPdfInScheduledReports(): void;
        get exportToPdfInScheduledReportsInput(): string | undefined;
        private _includeContentInScheduledReportsEmail?;
        get includeContentInScheduledReportsEmail(): string;
        set includeContentInScheduledReportsEmail(value: string);
        resetIncludeContentInScheduledReportsEmail(): void;
        get includeContentInScheduledReportsEmailInput(): string | undefined;
        private _printReports?;
        get printReports(): string;
        set printReports(value: string);
        resetPrintReports(): void;
        get printReportsInput(): string | undefined;
        private _renameSharedFolders?;
        get renameSharedFolders(): string;
        set renameSharedFolders(value: string);
        resetRenameSharedFolders(): void;
        get renameSharedFoldersInput(): string | undefined;
        private _shareAnalyses?;
        get shareAnalyses(): string;
        set shareAnalyses(value: string);
        resetShareAnalyses(): void;
        get shareAnalysesInput(): string | undefined;
        private _shareDashboards?;
        get shareDashboards(): string;
        set shareDashboards(value: string);
        resetShareDashboards(): void;
        get shareDashboardsInput(): string | undefined;
        private _shareDataSources?;
        get shareDataSources(): string;
        set shareDataSources(value: string);
        resetShareDataSources(): void;
        get shareDataSourcesInput(): string | undefined;
        private _shareDatasets?;
        get shareDatasets(): string;
        set shareDatasets(value: string);
        resetShareDatasets(): void;
        get shareDatasetsInput(): string | undefined;
        private _subscribeDashboardEmailReports?;
        get subscribeDashboardEmailReports(): string;
        set subscribeDashboardEmailReports(value: string);
        resetSubscribeDashboardEmailReports(): void;
        get subscribeDashboardEmailReportsInput(): string | undefined;
        private _viewAccountSpiceCapacity?;
        get viewAccountSpiceCapacity(): string;
        set viewAccountSpiceCapacity(value: string);
        resetViewAccountSpiceCapacity(): void;
        get viewAccountSpiceCapacityInput(): string | undefined;
    }
    class CapabilitiesPropertyList extends cdktn.ComplexList {
        internalValue?: CapabilitiesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapabilitiesPropertyOutputReference;
    }
}
