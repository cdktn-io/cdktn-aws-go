import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfDataSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#aws_account_id TfDataSet#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#data_set_id TfDataSet#data_set_id}
    */
    readonly dataSetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#id TfDataSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#import_mode TfDataSet#import_mode}
    */
    readonly importMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#name TfDataSet#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#region TfDataSet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#tags TfDataSet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#tags_all TfDataSet#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#use_as TfDataSet#use_as}
    */
    readonly useAs?: string;
    /**
    * column_groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_groups TfDataSet#column_groups}
    */
    readonly columnGroups?: TfDataSet.ColumnGroupsProperty[] | cdktn.IResolvable;
    /**
    * column_level_permission_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_level_permission_rules TfDataSet#column_level_permission_rules}
    */
    readonly columnLevelPermissionRules?: TfDataSet.ColumnLevelPermissionRulesProperty[] | cdktn.IResolvable;
    /**
    * data_set_usage_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#data_set_usage_configuration TfDataSet#data_set_usage_configuration}
    */
    readonly dataSetUsageConfiguration?: TfDataSet.DataSetUsageConfigurationProperty;
    /**
    * field_folders block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#field_folders TfDataSet#field_folders}
    */
    readonly fieldFolders?: TfDataSet.FieldFoldersProperty[] | cdktn.IResolvable;
    /**
    * logical_table_map block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#logical_table_map TfDataSet#logical_table_map}
    */
    readonly logicalTableMap?: TfDataSet.LogicalTableMapProperty[] | cdktn.IResolvable;
    /**
    * permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#permissions TfDataSet#permissions}
    */
    readonly permissions?: TfDataSet.PermissionsProperty[] | cdktn.IResolvable;
    /**
    * physical_table_map block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#physical_table_map TfDataSet#physical_table_map}
    */
    readonly physicalTableMap?: TfDataSet.PhysicalTableMapProperty[] | cdktn.IResolvable;
    /**
    * refresh_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#refresh_properties TfDataSet#refresh_properties}
    */
    readonly refreshProperties?: TfDataSet.RefreshPropertiesProperty;
    /**
    * row_level_permission_data_set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#row_level_permission_data_set TfDataSet#row_level_permission_data_set}
    */
    readonly rowLevelPermissionDataSet?: TfDataSet.RowLevelPermissionDataSetProperty;
    /**
    * row_level_permission_tag_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#row_level_permission_tag_configuration TfDataSet#row_level_permission_tag_configuration}
    */
    readonly rowLevelPermissionTagConfiguration?: TfDataSet.RowLevelPermissionTagConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set aws_quicksight_data_set}
*/
export declare class TfDataSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_quicksight_data_set";
    /**
    * Generates CDKTN code for importing a TfDataSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfDataSet to import
    * @param importFromId The id of the existing TfDataSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfDataSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set aws_quicksight_data_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfDataSetConfig
    */
    constructor(scope: Construct, id: string, config: TfDataSetConfig);
    get arn(): string;
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    private _dataSetId?;
    get dataSetId(): string;
    set dataSetId(value: string);
    get dataSetIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _importMode?;
    get importMode(): string;
    set importMode(value: string);
    get importModeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _outputColumns;
    get outputColumns(): TfDataSet.OutputColumnsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _useAs?;
    get useAs(): string;
    set useAs(value: string);
    resetUseAs(): void;
    get useAsInput(): string | undefined;
    private _columnGroups;
    get columnGroups(): TfDataSet.ColumnGroupsPropertyList;
    putColumnGroups(value: TfDataSet.ColumnGroupsProperty[] | cdktn.IResolvable): void;
    resetColumnGroups(): void;
    get columnGroupsInput(): cdktn.IResolvable | TfDataSet.ColumnGroupsProperty[] | undefined;
    private _columnLevelPermissionRules;
    get columnLevelPermissionRules(): TfDataSet.ColumnLevelPermissionRulesPropertyList;
    putColumnLevelPermissionRules(value: TfDataSet.ColumnLevelPermissionRulesProperty[] | cdktn.IResolvable): void;
    resetColumnLevelPermissionRules(): void;
    get columnLevelPermissionRulesInput(): cdktn.IResolvable | TfDataSet.ColumnLevelPermissionRulesProperty[] | undefined;
    private _dataSetUsageConfiguration;
    get dataSetUsageConfiguration(): TfDataSet.DataSetUsageConfigurationPropertyOutputReference;
    putDataSetUsageConfiguration(value: TfDataSet.DataSetUsageConfigurationProperty): void;
    resetDataSetUsageConfiguration(): void;
    get dataSetUsageConfigurationInput(): TfDataSet.DataSetUsageConfigurationProperty | undefined;
    private _fieldFolders;
    get fieldFolders(): TfDataSet.FieldFoldersPropertyList;
    putFieldFolders(value: TfDataSet.FieldFoldersProperty[] | cdktn.IResolvable): void;
    resetFieldFolders(): void;
    get fieldFoldersInput(): cdktn.IResolvable | TfDataSet.FieldFoldersProperty[] | undefined;
    private _logicalTableMap;
    get logicalTableMap(): TfDataSet.LogicalTableMapPropertyList;
    putLogicalTableMap(value: TfDataSet.LogicalTableMapProperty[] | cdktn.IResolvable): void;
    resetLogicalTableMap(): void;
    get logicalTableMapInput(): cdktn.IResolvable | TfDataSet.LogicalTableMapProperty[] | undefined;
    private _permissions;
    get permissions(): TfDataSet.PermissionsPropertyList;
    putPermissions(value: TfDataSet.PermissionsProperty[] | cdktn.IResolvable): void;
    resetPermissions(): void;
    get permissionsInput(): cdktn.IResolvable | TfDataSet.PermissionsProperty[] | undefined;
    private _physicalTableMap;
    get physicalTableMap(): TfDataSet.PhysicalTableMapPropertyList;
    putPhysicalTableMap(value: TfDataSet.PhysicalTableMapProperty[] | cdktn.IResolvable): void;
    resetPhysicalTableMap(): void;
    get physicalTableMapInput(): cdktn.IResolvable | TfDataSet.PhysicalTableMapProperty[] | undefined;
    private _refreshProperties;
    get refreshProperties(): TfDataSet.RefreshPropertiesPropertyOutputReference;
    putRefreshProperties(value: TfDataSet.RefreshPropertiesProperty): void;
    resetRefreshProperties(): void;
    get refreshPropertiesInput(): TfDataSet.RefreshPropertiesProperty | undefined;
    private _rowLevelPermissionDataSet;
    get rowLevelPermissionDataSet(): TfDataSet.RowLevelPermissionDataSetPropertyOutputReference;
    putRowLevelPermissionDataSet(value: TfDataSet.RowLevelPermissionDataSetProperty): void;
    resetRowLevelPermissionDataSet(): void;
    get rowLevelPermissionDataSetInput(): TfDataSet.RowLevelPermissionDataSetProperty | undefined;
    private _rowLevelPermissionTagConfiguration;
    get rowLevelPermissionTagConfiguration(): TfDataSet.RowLevelPermissionTagConfigurationPropertyOutputReference;
    putRowLevelPermissionTagConfiguration(value: TfDataSet.RowLevelPermissionTagConfigurationProperty): void;
    resetRowLevelPermissionTagConfiguration(): void;
    get rowLevelPermissionTagConfigurationInput(): TfDataSet.RowLevelPermissionTagConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfDataSetOutputColumnsPropertyToTerraform(struct?: TfDataSet.OutputColumnsProperty): any;
export declare function tfDataSetOutputColumnsPropertyToHclTerraform(struct?: TfDataSet.OutputColumnsProperty): any;
export declare function tfDataSetGeoSpatialColumnGroupPropertyToTerraform(struct?: TfDataSet.GeoSpatialColumnGroupPropertyOutputReference | TfDataSet.GeoSpatialColumnGroupProperty): any;
export declare function tfDataSetGeoSpatialColumnGroupPropertyToHclTerraform(struct?: TfDataSet.GeoSpatialColumnGroupPropertyOutputReference | TfDataSet.GeoSpatialColumnGroupProperty): any;
export declare function tfDataSetColumnGroupsPropertyToTerraform(struct?: TfDataSet.ColumnGroupsProperty | cdktn.IResolvable): any;
export declare function tfDataSetColumnGroupsPropertyToHclTerraform(struct?: TfDataSet.ColumnGroupsProperty | cdktn.IResolvable): any;
export declare function tfDataSetColumnLevelPermissionRulesPropertyToTerraform(struct?: TfDataSet.ColumnLevelPermissionRulesProperty | cdktn.IResolvable): any;
export declare function tfDataSetColumnLevelPermissionRulesPropertyToHclTerraform(struct?: TfDataSet.ColumnLevelPermissionRulesProperty | cdktn.IResolvable): any;
export declare function tfDataSetDataSetUsageConfigurationPropertyToTerraform(struct?: TfDataSet.DataSetUsageConfigurationPropertyOutputReference | TfDataSet.DataSetUsageConfigurationProperty): any;
export declare function tfDataSetDataSetUsageConfigurationPropertyToHclTerraform(struct?: TfDataSet.DataSetUsageConfigurationPropertyOutputReference | TfDataSet.DataSetUsageConfigurationProperty): any;
export declare function tfDataSetFieldFoldersPropertyToTerraform(struct?: TfDataSet.FieldFoldersProperty | cdktn.IResolvable): any;
export declare function tfDataSetFieldFoldersPropertyToHclTerraform(struct?: TfDataSet.FieldFoldersProperty | cdktn.IResolvable): any;
export declare function tfDataSetCastColumnTypeOperationPropertyToTerraform(struct?: TfDataSet.CastColumnTypeOperationPropertyOutputReference | TfDataSet.CastColumnTypeOperationProperty): any;
export declare function tfDataSetCastColumnTypeOperationPropertyToHclTerraform(struct?: TfDataSet.CastColumnTypeOperationPropertyOutputReference | TfDataSet.CastColumnTypeOperationProperty): any;
export declare function tfDataSetLogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyToTerraform(struct?: TfDataSet.LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty | cdktn.IResolvable): any;
export declare function tfDataSetLogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyToHclTerraform(struct?: TfDataSet.LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty | cdktn.IResolvable): any;
export declare function tfDataSetCreateColumnsOperationPropertyToTerraform(struct?: TfDataSet.CreateColumnsOperationPropertyOutputReference | TfDataSet.CreateColumnsOperationProperty): any;
export declare function tfDataSetCreateColumnsOperationPropertyToHclTerraform(struct?: TfDataSet.CreateColumnsOperationPropertyOutputReference | TfDataSet.CreateColumnsOperationProperty): any;
export declare function tfDataSetFilterOperationPropertyToTerraform(struct?: TfDataSet.FilterOperationPropertyOutputReference | TfDataSet.FilterOperationProperty): any;
export declare function tfDataSetFilterOperationPropertyToHclTerraform(struct?: TfDataSet.FilterOperationPropertyOutputReference | TfDataSet.FilterOperationProperty): any;
export declare function tfDataSetProjectOperationPropertyToTerraform(struct?: TfDataSet.ProjectOperationPropertyOutputReference | TfDataSet.ProjectOperationProperty): any;
export declare function tfDataSetProjectOperationPropertyToHclTerraform(struct?: TfDataSet.ProjectOperationPropertyOutputReference | TfDataSet.ProjectOperationProperty): any;
export declare function tfDataSetRenameColumnOperationPropertyToTerraform(struct?: TfDataSet.RenameColumnOperationPropertyOutputReference | TfDataSet.RenameColumnOperationProperty): any;
export declare function tfDataSetRenameColumnOperationPropertyToHclTerraform(struct?: TfDataSet.RenameColumnOperationPropertyOutputReference | TfDataSet.RenameColumnOperationProperty): any;
export declare function tfDataSetColumnDescriptionPropertyToTerraform(struct?: TfDataSet.ColumnDescriptionPropertyOutputReference | TfDataSet.ColumnDescriptionProperty): any;
export declare function tfDataSetColumnDescriptionPropertyToHclTerraform(struct?: TfDataSet.ColumnDescriptionPropertyOutputReference | TfDataSet.ColumnDescriptionProperty): any;
export declare function tfDataSetTagsPropertyToTerraform(struct?: TfDataSet.TagsProperty | cdktn.IResolvable): any;
export declare function tfDataSetTagsPropertyToHclTerraform(struct?: TfDataSet.TagsProperty | cdktn.IResolvable): any;
export declare function tfDataSetTagColumnOperationPropertyToTerraform(struct?: TfDataSet.TagColumnOperationPropertyOutputReference | TfDataSet.TagColumnOperationProperty): any;
export declare function tfDataSetTagColumnOperationPropertyToHclTerraform(struct?: TfDataSet.TagColumnOperationPropertyOutputReference | TfDataSet.TagColumnOperationProperty): any;
export declare function tfDataSetUntagColumnOperationPropertyToTerraform(struct?: TfDataSet.UntagColumnOperationPropertyOutputReference | TfDataSet.UntagColumnOperationProperty): any;
export declare function tfDataSetUntagColumnOperationPropertyToHclTerraform(struct?: TfDataSet.UntagColumnOperationPropertyOutputReference | TfDataSet.UntagColumnOperationProperty): any;
export declare function tfDataSetDataTransformsPropertyToTerraform(struct?: TfDataSet.DataTransformsProperty | cdktn.IResolvable): any;
export declare function tfDataSetDataTransformsPropertyToHclTerraform(struct?: TfDataSet.DataTransformsProperty | cdktn.IResolvable): any;
export declare function tfDataSetLeftJoinKeyPropertiesPropertyToTerraform(struct?: TfDataSet.LeftJoinKeyPropertiesPropertyOutputReference | TfDataSet.LeftJoinKeyPropertiesProperty): any;
export declare function tfDataSetLeftJoinKeyPropertiesPropertyToHclTerraform(struct?: TfDataSet.LeftJoinKeyPropertiesPropertyOutputReference | TfDataSet.LeftJoinKeyPropertiesProperty): any;
export declare function tfDataSetRightJoinKeyPropertiesPropertyToTerraform(struct?: TfDataSet.RightJoinKeyPropertiesPropertyOutputReference | TfDataSet.RightJoinKeyPropertiesProperty): any;
export declare function tfDataSetRightJoinKeyPropertiesPropertyToHclTerraform(struct?: TfDataSet.RightJoinKeyPropertiesPropertyOutputReference | TfDataSet.RightJoinKeyPropertiesProperty): any;
export declare function tfDataSetJoinInstructionPropertyToTerraform(struct?: TfDataSet.JoinInstructionPropertyOutputReference | TfDataSet.JoinInstructionProperty): any;
export declare function tfDataSetJoinInstructionPropertyToHclTerraform(struct?: TfDataSet.JoinInstructionPropertyOutputReference | TfDataSet.JoinInstructionProperty): any;
export declare function tfDataSetSourcePropertyToTerraform(struct?: TfDataSet.SourcePropertyOutputReference | TfDataSet.SourceProperty): any;
export declare function tfDataSetSourcePropertyToHclTerraform(struct?: TfDataSet.SourcePropertyOutputReference | TfDataSet.SourceProperty): any;
export declare function tfDataSetLogicalTableMapPropertyToTerraform(struct?: TfDataSet.LogicalTableMapProperty | cdktn.IResolvable): any;
export declare function tfDataSetLogicalTableMapPropertyToHclTerraform(struct?: TfDataSet.LogicalTableMapProperty | cdktn.IResolvable): any;
export declare function tfDataSetPermissionsPropertyToTerraform(struct?: TfDataSet.PermissionsProperty | cdktn.IResolvable): any;
export declare function tfDataSetPermissionsPropertyToHclTerraform(struct?: TfDataSet.PermissionsProperty | cdktn.IResolvable): any;
export declare function tfDataSetPhysicalTableMapCustomSqlColumnsPropertyToTerraform(struct?: TfDataSet.PhysicalTableMapCustomSqlColumnsProperty | cdktn.IResolvable): any;
export declare function tfDataSetPhysicalTableMapCustomSqlColumnsPropertyToHclTerraform(struct?: TfDataSet.PhysicalTableMapCustomSqlColumnsProperty | cdktn.IResolvable): any;
export declare function tfDataSetCustomSqlPropertyToTerraform(struct?: TfDataSet.CustomSqlPropertyOutputReference | TfDataSet.CustomSqlProperty): any;
export declare function tfDataSetCustomSqlPropertyToHclTerraform(struct?: TfDataSet.CustomSqlPropertyOutputReference | TfDataSet.CustomSqlProperty): any;
export declare function tfDataSetPhysicalTableMapRelationalTableInputColumnsPropertyToTerraform(struct?: TfDataSet.PhysicalTableMapRelationalTableInputColumnsProperty | cdktn.IResolvable): any;
export declare function tfDataSetPhysicalTableMapRelationalTableInputColumnsPropertyToHclTerraform(struct?: TfDataSet.PhysicalTableMapRelationalTableInputColumnsProperty | cdktn.IResolvable): any;
export declare function tfDataSetRelationalTablePropertyToTerraform(struct?: TfDataSet.RelationalTablePropertyOutputReference | TfDataSet.RelationalTableProperty): any;
export declare function tfDataSetRelationalTablePropertyToHclTerraform(struct?: TfDataSet.RelationalTablePropertyOutputReference | TfDataSet.RelationalTableProperty): any;
export declare function tfDataSetPhysicalTableMapS3SourceInputColumnsPropertyToTerraform(struct?: TfDataSet.PhysicalTableMapS3SourceInputColumnsProperty | cdktn.IResolvable): any;
export declare function tfDataSetPhysicalTableMapS3SourceInputColumnsPropertyToHclTerraform(struct?: TfDataSet.PhysicalTableMapS3SourceInputColumnsProperty | cdktn.IResolvable): any;
export declare function tfDataSetUploadSettingsPropertyToTerraform(struct?: TfDataSet.UploadSettingsPropertyOutputReference | TfDataSet.UploadSettingsProperty): any;
export declare function tfDataSetUploadSettingsPropertyToHclTerraform(struct?: TfDataSet.UploadSettingsPropertyOutputReference | TfDataSet.UploadSettingsProperty): any;
export declare function tfDataSetS3SourcePropertyToTerraform(struct?: TfDataSet.S3SourcePropertyOutputReference | TfDataSet.S3SourceProperty): any;
export declare function tfDataSetS3SourcePropertyToHclTerraform(struct?: TfDataSet.S3SourcePropertyOutputReference | TfDataSet.S3SourceProperty): any;
export declare function tfDataSetPhysicalTableMapPropertyToTerraform(struct?: TfDataSet.PhysicalTableMapProperty | cdktn.IResolvable): any;
export declare function tfDataSetPhysicalTableMapPropertyToHclTerraform(struct?: TfDataSet.PhysicalTableMapProperty | cdktn.IResolvable): any;
export declare function tfDataSetLookbackWindowPropertyToTerraform(struct?: TfDataSet.LookbackWindowPropertyOutputReference | TfDataSet.LookbackWindowProperty): any;
export declare function tfDataSetLookbackWindowPropertyToHclTerraform(struct?: TfDataSet.LookbackWindowPropertyOutputReference | TfDataSet.LookbackWindowProperty): any;
export declare function tfDataSetIncrementalRefreshPropertyToTerraform(struct?: TfDataSet.IncrementalRefreshPropertyOutputReference | TfDataSet.IncrementalRefreshProperty): any;
export declare function tfDataSetIncrementalRefreshPropertyToHclTerraform(struct?: TfDataSet.IncrementalRefreshPropertyOutputReference | TfDataSet.IncrementalRefreshProperty): any;
export declare function tfDataSetRefreshConfigurationPropertyToTerraform(struct?: TfDataSet.RefreshConfigurationPropertyOutputReference | TfDataSet.RefreshConfigurationProperty): any;
export declare function tfDataSetRefreshConfigurationPropertyToHclTerraform(struct?: TfDataSet.RefreshConfigurationPropertyOutputReference | TfDataSet.RefreshConfigurationProperty): any;
export declare function tfDataSetRefreshPropertiesPropertyToTerraform(struct?: TfDataSet.RefreshPropertiesPropertyOutputReference | TfDataSet.RefreshPropertiesProperty): any;
export declare function tfDataSetRefreshPropertiesPropertyToHclTerraform(struct?: TfDataSet.RefreshPropertiesPropertyOutputReference | TfDataSet.RefreshPropertiesProperty): any;
export declare function tfDataSetRowLevelPermissionDataSetPropertyToTerraform(struct?: TfDataSet.RowLevelPermissionDataSetPropertyOutputReference | TfDataSet.RowLevelPermissionDataSetProperty): any;
export declare function tfDataSetRowLevelPermissionDataSetPropertyToHclTerraform(struct?: TfDataSet.RowLevelPermissionDataSetPropertyOutputReference | TfDataSet.RowLevelPermissionDataSetProperty): any;
export declare function tfDataSetTagRulesPropertyToTerraform(struct?: TfDataSet.TagRulesProperty | cdktn.IResolvable): any;
export declare function tfDataSetTagRulesPropertyToHclTerraform(struct?: TfDataSet.TagRulesProperty | cdktn.IResolvable): any;
export declare function tfDataSetRowLevelPermissionTagConfigurationPropertyToTerraform(struct?: TfDataSet.RowLevelPermissionTagConfigurationPropertyOutputReference | TfDataSet.RowLevelPermissionTagConfigurationProperty): any;
export declare function tfDataSetRowLevelPermissionTagConfigurationPropertyToHclTerraform(struct?: TfDataSet.RowLevelPermissionTagConfigurationPropertyOutputReference | TfDataSet.RowLevelPermissionTagConfigurationProperty): any;
export declare namespace TfDataSet {
    interface OutputColumnsProperty {
    }
    class OutputColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputColumnsProperty | undefined;
        set internalValue(value: OutputColumnsProperty | undefined);
        get description(): string;
        get name(): string;
        get type(): string;
    }
    class OutputColumnsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputColumnsPropertyOutputReference;
    }
    interface GeoSpatialColumnGroupProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#columns TfDataSet#columns}
        */
        readonly columns: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#country_code TfDataSet#country_code}
        */
        readonly countryCode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#name TfDataSet#name}
        */
        readonly name: string;
    }
    class GeoSpatialColumnGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GeoSpatialColumnGroupProperty | undefined;
        set internalValue(value: GeoSpatialColumnGroupProperty | undefined);
        private _columns?;
        get columns(): string[];
        set columns(value: string[]);
        get columnsInput(): string[] | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        get countryCodeInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    interface ColumnGroupsProperty {
        /**
        * geo_spatial_column_group block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#geo_spatial_column_group TfDataSet#geo_spatial_column_group}
        */
        readonly geoSpatialColumnGroup?: GeoSpatialColumnGroupProperty;
    }
    class ColumnGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnGroupsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ColumnGroupsProperty | cdktn.IResolvable | undefined);
        private _geoSpatialColumnGroup;
        get geoSpatialColumnGroup(): GeoSpatialColumnGroupPropertyOutputReference;
        putGeoSpatialColumnGroup(value: GeoSpatialColumnGroupProperty): void;
        resetGeoSpatialColumnGroup(): void;
        get geoSpatialColumnGroupInput(): GeoSpatialColumnGroupProperty | undefined;
    }
    class ColumnGroupsPropertyList extends cdktn.ComplexList {
        internalValue?: ColumnGroupsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnGroupsPropertyOutputReference;
    }
    interface ColumnLevelPermissionRulesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_names TfDataSet#column_names}
        */
        readonly columnNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#principals TfDataSet#principals}
        */
        readonly principals?: string[];
    }
    class ColumnLevelPermissionRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnLevelPermissionRulesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ColumnLevelPermissionRulesProperty | cdktn.IResolvable | undefined);
        private _columnNames?;
        get columnNames(): string[];
        set columnNames(value: string[]);
        resetColumnNames(): void;
        get columnNamesInput(): string[] | undefined;
        private _principals?;
        get principals(): string[];
        set principals(value: string[]);
        resetPrincipals(): void;
        get principalsInput(): string[] | undefined;
    }
    class ColumnLevelPermissionRulesPropertyList extends cdktn.ComplexList {
        internalValue?: ColumnLevelPermissionRulesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnLevelPermissionRulesPropertyOutputReference;
    }
    interface DataSetUsageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#disable_use_as_direct_query_source TfDataSet#disable_use_as_direct_query_source}
        */
        readonly disableUseAsDirectQuerySource?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#disable_use_as_imported_source TfDataSet#disable_use_as_imported_source}
        */
        readonly disableUseAsImportedSource?: boolean | cdktn.IResolvable;
    }
    class DataSetUsageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataSetUsageConfigurationProperty | undefined;
        set internalValue(value: DataSetUsageConfigurationProperty | undefined);
        private _disableUseAsDirectQuerySource?;
        get disableUseAsDirectQuerySource(): boolean | cdktn.IResolvable;
        set disableUseAsDirectQuerySource(value: boolean | cdktn.IResolvable);
        resetDisableUseAsDirectQuerySource(): void;
        get disableUseAsDirectQuerySourceInput(): boolean | cdktn.IResolvable | undefined;
        private _disableUseAsImportedSource?;
        get disableUseAsImportedSource(): boolean | cdktn.IResolvable;
        set disableUseAsImportedSource(value: boolean | cdktn.IResolvable);
        resetDisableUseAsImportedSource(): void;
        get disableUseAsImportedSourceInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface FieldFoldersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#columns TfDataSet#columns}
        */
        readonly columns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#description TfDataSet#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#field_folders_id TfDataSet#field_folders_id}
        */
        readonly fieldFoldersId: string;
    }
    class FieldFoldersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FieldFoldersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FieldFoldersProperty | cdktn.IResolvable | undefined);
        private _columns?;
        get columns(): string[];
        set columns(value: string[]);
        resetColumns(): void;
        get columnsInput(): string[] | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _fieldFoldersId?;
        get fieldFoldersId(): string;
        set fieldFoldersId(value: string);
        get fieldFoldersIdInput(): string | undefined;
    }
    class FieldFoldersPropertyList extends cdktn.ComplexList {
        internalValue?: FieldFoldersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FieldFoldersPropertyOutputReference;
    }
    interface CastColumnTypeOperationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_name TfDataSet#column_name}
        */
        readonly columnName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#format TfDataSet#format}
        */
        readonly format?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#new_column_type TfDataSet#new_column_type}
        */
        readonly newColumnType: string;
    }
    class CastColumnTypeOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CastColumnTypeOperationProperty | undefined;
        set internalValue(value: CastColumnTypeOperationProperty | undefined);
        private _columnName?;
        get columnName(): string;
        set columnName(value: string);
        get columnNameInput(): string | undefined;
        private _format?;
        get format(): string;
        set format(value: string);
        resetFormat(): void;
        get formatInput(): string | undefined;
        private _newColumnType?;
        get newColumnType(): string;
        set newColumnType(value: string);
        get newColumnTypeInput(): string | undefined;
    }
    interface LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_id TfDataSet#column_id}
        */
        readonly columnId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_name TfDataSet#column_name}
        */
        readonly columnName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#expression TfDataSet#expression}
        */
        readonly expression: string;
    }
    class LogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty | cdktn.IResolvable | undefined);
        private _columnId?;
        get columnId(): string;
        set columnId(value: string);
        get columnIdInput(): string | undefined;
        private _columnName?;
        get columnName(): string;
        set columnName(value: string);
        get columnNameInput(): string | undefined;
        private _expression?;
        get expression(): string;
        set expression(value: string);
        get expressionInput(): string | undefined;
    }
    class LogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyOutputReference;
    }
    interface CreateColumnsOperationProperty {
        /**
        * columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#columns TfDataSet#columns}
        */
        readonly columns: LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty[] | cdktn.IResolvable;
    }
    class CreateColumnsOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CreateColumnsOperationProperty | undefined;
        set internalValue(value: CreateColumnsOperationProperty | undefined);
        private _columns;
        get columns(): LogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyList;
        putColumns(value: LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty[] | cdktn.IResolvable): void;
        get columnsInput(): cdktn.IResolvable | LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty[] | undefined;
    }
    interface FilterOperationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#condition_expression TfDataSet#condition_expression}
        */
        readonly conditionExpression: string;
    }
    class FilterOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterOperationProperty | undefined;
        set internalValue(value: FilterOperationProperty | undefined);
        private _conditionExpression?;
        get conditionExpression(): string;
        set conditionExpression(value: string);
        get conditionExpressionInput(): string | undefined;
    }
    interface ProjectOperationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#projected_columns TfDataSet#projected_columns}
        */
        readonly projectedColumns: string[];
    }
    class ProjectOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProjectOperationProperty | undefined;
        set internalValue(value: ProjectOperationProperty | undefined);
        private _projectedColumns?;
        get projectedColumns(): string[];
        set projectedColumns(value: string[]);
        get projectedColumnsInput(): string[] | undefined;
    }
    interface RenameColumnOperationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_name TfDataSet#column_name}
        */
        readonly columnName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#new_column_name TfDataSet#new_column_name}
        */
        readonly newColumnName: string;
    }
    class RenameColumnOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RenameColumnOperationProperty | undefined;
        set internalValue(value: RenameColumnOperationProperty | undefined);
        private _columnName?;
        get columnName(): string;
        set columnName(value: string);
        get columnNameInput(): string | undefined;
        private _newColumnName?;
        get newColumnName(): string;
        set newColumnName(value: string);
        get newColumnNameInput(): string | undefined;
    }
    interface ColumnDescriptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#text TfDataSet#text}
        */
        readonly text?: string;
    }
    class ColumnDescriptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ColumnDescriptionProperty | undefined;
        set internalValue(value: ColumnDescriptionProperty | undefined);
        private _text?;
        get text(): string;
        set text(value: string);
        resetText(): void;
        get textInput(): string | undefined;
    }
    interface TagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_geographic_role TfDataSet#column_geographic_role}
        */
        readonly columnGeographicRole?: string;
        /**
        * column_description block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_description TfDataSet#column_description}
        */
        readonly columnDescription?: ColumnDescriptionProperty;
    }
    class TagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagsProperty | cdktn.IResolvable | undefined);
        private _columnGeographicRole?;
        get columnGeographicRole(): string;
        set columnGeographicRole(value: string);
        resetColumnGeographicRole(): void;
        get columnGeographicRoleInput(): string | undefined;
        private _columnDescription;
        get columnDescription(): ColumnDescriptionPropertyOutputReference;
        putColumnDescription(value: ColumnDescriptionProperty): void;
        resetColumnDescription(): void;
        get columnDescriptionInput(): ColumnDescriptionProperty | undefined;
    }
    class TagsPropertyList extends cdktn.ComplexList {
        internalValue?: TagsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagsPropertyOutputReference;
    }
    interface TagColumnOperationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_name TfDataSet#column_name}
        */
        readonly columnName: string;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#tags TfDataSet#tags}
        */
        readonly tags: TagsProperty[] | cdktn.IResolvable;
    }
    class TagColumnOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TagColumnOperationProperty | undefined;
        set internalValue(value: TagColumnOperationProperty | undefined);
        private _columnName?;
        get columnName(): string;
        set columnName(value: string);
        get columnNameInput(): string | undefined;
        private _tags;
        get tags(): TagsPropertyList;
        putTags(value: TagsProperty[] | cdktn.IResolvable): void;
        get tagsInput(): cdktn.IResolvable | TagsProperty[] | undefined;
    }
    interface UntagColumnOperationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_name TfDataSet#column_name}
        */
        readonly columnName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#tag_names TfDataSet#tag_names}
        */
        readonly tagNames: string[];
    }
    class UntagColumnOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UntagColumnOperationProperty | undefined;
        set internalValue(value: UntagColumnOperationProperty | undefined);
        private _columnName?;
        get columnName(): string;
        set columnName(value: string);
        get columnNameInput(): string | undefined;
        private _tagNames?;
        get tagNames(): string[];
        set tagNames(value: string[]);
        get tagNamesInput(): string[] | undefined;
    }
    interface DataTransformsProperty {
        /**
        * cast_column_type_operation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#cast_column_type_operation TfDataSet#cast_column_type_operation}
        */
        readonly castColumnTypeOperation?: CastColumnTypeOperationProperty;
        /**
        * create_columns_operation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#create_columns_operation TfDataSet#create_columns_operation}
        */
        readonly createColumnsOperation?: CreateColumnsOperationProperty;
        /**
        * filter_operation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#filter_operation TfDataSet#filter_operation}
        */
        readonly filterOperation?: FilterOperationProperty;
        /**
        * project_operation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#project_operation TfDataSet#project_operation}
        */
        readonly projectOperation?: ProjectOperationProperty;
        /**
        * rename_column_operation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#rename_column_operation TfDataSet#rename_column_operation}
        */
        readonly renameColumnOperation?: RenameColumnOperationProperty;
        /**
        * tag_column_operation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#tag_column_operation TfDataSet#tag_column_operation}
        */
        readonly tagColumnOperation?: TagColumnOperationProperty;
        /**
        * untag_column_operation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#untag_column_operation TfDataSet#untag_column_operation}
        */
        readonly untagColumnOperation?: UntagColumnOperationProperty;
    }
    class DataTransformsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataTransformsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataTransformsProperty | cdktn.IResolvable | undefined);
        private _castColumnTypeOperation;
        get castColumnTypeOperation(): CastColumnTypeOperationPropertyOutputReference;
        putCastColumnTypeOperation(value: CastColumnTypeOperationProperty): void;
        resetCastColumnTypeOperation(): void;
        get castColumnTypeOperationInput(): CastColumnTypeOperationProperty | undefined;
        private _createColumnsOperation;
        get createColumnsOperation(): CreateColumnsOperationPropertyOutputReference;
        putCreateColumnsOperation(value: CreateColumnsOperationProperty): void;
        resetCreateColumnsOperation(): void;
        get createColumnsOperationInput(): CreateColumnsOperationProperty | undefined;
        private _filterOperation;
        get filterOperation(): FilterOperationPropertyOutputReference;
        putFilterOperation(value: FilterOperationProperty): void;
        resetFilterOperation(): void;
        get filterOperationInput(): FilterOperationProperty | undefined;
        private _projectOperation;
        get projectOperation(): ProjectOperationPropertyOutputReference;
        putProjectOperation(value: ProjectOperationProperty): void;
        resetProjectOperation(): void;
        get projectOperationInput(): ProjectOperationProperty | undefined;
        private _renameColumnOperation;
        get renameColumnOperation(): RenameColumnOperationPropertyOutputReference;
        putRenameColumnOperation(value: RenameColumnOperationProperty): void;
        resetRenameColumnOperation(): void;
        get renameColumnOperationInput(): RenameColumnOperationProperty | undefined;
        private _tagColumnOperation;
        get tagColumnOperation(): TagColumnOperationPropertyOutputReference;
        putTagColumnOperation(value: TagColumnOperationProperty): void;
        resetTagColumnOperation(): void;
        get tagColumnOperationInput(): TagColumnOperationProperty | undefined;
        private _untagColumnOperation;
        get untagColumnOperation(): UntagColumnOperationPropertyOutputReference;
        putUntagColumnOperation(value: UntagColumnOperationProperty): void;
        resetUntagColumnOperation(): void;
        get untagColumnOperationInput(): UntagColumnOperationProperty | undefined;
    }
    class DataTransformsPropertyList extends cdktn.ComplexList {
        internalValue?: DataTransformsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataTransformsPropertyOutputReference;
    }
    interface LeftJoinKeyPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#unique_key TfDataSet#unique_key}
        */
        readonly uniqueKey?: boolean | cdktn.IResolvable;
    }
    class LeftJoinKeyPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LeftJoinKeyPropertiesProperty | undefined;
        set internalValue(value: LeftJoinKeyPropertiesProperty | undefined);
        private _uniqueKey?;
        get uniqueKey(): boolean | cdktn.IResolvable;
        set uniqueKey(value: boolean | cdktn.IResolvable);
        resetUniqueKey(): void;
        get uniqueKeyInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface RightJoinKeyPropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#unique_key TfDataSet#unique_key}
        */
        readonly uniqueKey?: boolean | cdktn.IResolvable;
    }
    class RightJoinKeyPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RightJoinKeyPropertiesProperty | undefined;
        set internalValue(value: RightJoinKeyPropertiesProperty | undefined);
        private _uniqueKey?;
        get uniqueKey(): boolean | cdktn.IResolvable;
        set uniqueKey(value: boolean | cdktn.IResolvable);
        resetUniqueKey(): void;
        get uniqueKeyInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface JoinInstructionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#left_operand TfDataSet#left_operand}
        */
        readonly leftOperand: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#on_clause TfDataSet#on_clause}
        */
        readonly onClause: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#right_operand TfDataSet#right_operand}
        */
        readonly rightOperand: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#type TfDataSet#type}
        */
        readonly type: string;
        /**
        * left_join_key_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#left_join_key_properties TfDataSet#left_join_key_properties}
        */
        readonly leftJoinKeyProperties?: LeftJoinKeyPropertiesProperty;
        /**
        * right_join_key_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#right_join_key_properties TfDataSet#right_join_key_properties}
        */
        readonly rightJoinKeyProperties?: RightJoinKeyPropertiesProperty;
    }
    class JoinInstructionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JoinInstructionProperty | undefined;
        set internalValue(value: JoinInstructionProperty | undefined);
        private _leftOperand?;
        get leftOperand(): string;
        set leftOperand(value: string);
        get leftOperandInput(): string | undefined;
        private _onClause?;
        get onClause(): string;
        set onClause(value: string);
        get onClauseInput(): string | undefined;
        private _rightOperand?;
        get rightOperand(): string;
        set rightOperand(value: string);
        get rightOperandInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _leftJoinKeyProperties;
        get leftJoinKeyProperties(): LeftJoinKeyPropertiesPropertyOutputReference;
        putLeftJoinKeyProperties(value: LeftJoinKeyPropertiesProperty): void;
        resetLeftJoinKeyProperties(): void;
        get leftJoinKeyPropertiesInput(): LeftJoinKeyPropertiesProperty | undefined;
        private _rightJoinKeyProperties;
        get rightJoinKeyProperties(): RightJoinKeyPropertiesPropertyOutputReference;
        putRightJoinKeyProperties(value: RightJoinKeyPropertiesProperty): void;
        resetRightJoinKeyProperties(): void;
        get rightJoinKeyPropertiesInput(): RightJoinKeyPropertiesProperty | undefined;
    }
    interface SourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#data_set_arn TfDataSet#data_set_arn}
        */
        readonly dataSetArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#physical_table_id TfDataSet#physical_table_id}
        */
        readonly physicalTableId?: string;
        /**
        * join_instruction block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#join_instruction TfDataSet#join_instruction}
        */
        readonly joinInstruction?: JoinInstructionProperty;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceProperty | undefined;
        set internalValue(value: SourceProperty | undefined);
        private _dataSetArn?;
        get dataSetArn(): string;
        set dataSetArn(value: string);
        resetDataSetArn(): void;
        get dataSetArnInput(): string | undefined;
        private _physicalTableId?;
        get physicalTableId(): string;
        set physicalTableId(value: string);
        resetPhysicalTableId(): void;
        get physicalTableIdInput(): string | undefined;
        private _joinInstruction;
        get joinInstruction(): JoinInstructionPropertyOutputReference;
        putJoinInstruction(value: JoinInstructionProperty): void;
        resetJoinInstruction(): void;
        get joinInstructionInput(): JoinInstructionProperty | undefined;
    }
    interface LogicalTableMapProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#alias TfDataSet#alias}
        */
        readonly alias: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#logical_table_map_id TfDataSet#logical_table_map_id}
        */
        readonly logicalTableMapId: string;
        /**
        * data_transforms block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#data_transforms TfDataSet#data_transforms}
        */
        readonly dataTransforms?: DataTransformsProperty[] | cdktn.IResolvable;
        /**
        * source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#source TfDataSet#source}
        */
        readonly source: SourceProperty;
    }
    class LogicalTableMapPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogicalTableMapProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogicalTableMapProperty | cdktn.IResolvable | undefined);
        private _alias?;
        get alias(): string;
        set alias(value: string);
        get aliasInput(): string | undefined;
        private _logicalTableMapId?;
        get logicalTableMapId(): string;
        set logicalTableMapId(value: string);
        get logicalTableMapIdInput(): string | undefined;
        private _dataTransforms;
        get dataTransforms(): DataTransformsPropertyList;
        putDataTransforms(value: DataTransformsProperty[] | cdktn.IResolvable): void;
        resetDataTransforms(): void;
        get dataTransformsInput(): cdktn.IResolvable | DataTransformsProperty[] | undefined;
        private _source;
        get source(): SourcePropertyOutputReference;
        putSource(value: SourceProperty): void;
        get sourceInput(): SourceProperty | undefined;
    }
    class LogicalTableMapPropertyList extends cdktn.ComplexList {
        internalValue?: LogicalTableMapProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogicalTableMapPropertyOutputReference;
    }
    interface PermissionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#actions TfDataSet#actions}
        */
        readonly actions: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#principal TfDataSet#principal}
        */
        readonly principal: string;
    }
    class PermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PermissionsProperty | cdktn.IResolvable | undefined);
        private _actions?;
        get actions(): string[];
        set actions(value: string[]);
        get actionsInput(): string[] | undefined;
        private _principal?;
        get principal(): string;
        set principal(value: string);
        get principalInput(): string | undefined;
    }
    class PermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: PermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PermissionsPropertyOutputReference;
    }
    interface PhysicalTableMapCustomSqlColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#name TfDataSet#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#type TfDataSet#type}
        */
        readonly type: string;
    }
    class PhysicalTableMapCustomSqlColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhysicalTableMapCustomSqlColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PhysicalTableMapCustomSqlColumnsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class PhysicalTableMapCustomSqlColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: PhysicalTableMapCustomSqlColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhysicalTableMapCustomSqlColumnsPropertyOutputReference;
    }
    interface CustomSqlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#data_source_arn TfDataSet#data_source_arn}
        */
        readonly dataSourceArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#name TfDataSet#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#sql_query TfDataSet#sql_query}
        */
        readonly sqlQuery: string;
        /**
        * columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#columns TfDataSet#columns}
        */
        readonly columns?: PhysicalTableMapCustomSqlColumnsProperty[] | cdktn.IResolvable;
    }
    class CustomSqlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomSqlProperty | undefined;
        set internalValue(value: CustomSqlProperty | undefined);
        private _dataSourceArn?;
        get dataSourceArn(): string;
        set dataSourceArn(value: string);
        get dataSourceArnInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _sqlQuery?;
        get sqlQuery(): string;
        set sqlQuery(value: string);
        get sqlQueryInput(): string | undefined;
        private _columns;
        get columns(): PhysicalTableMapCustomSqlColumnsPropertyList;
        putColumns(value: PhysicalTableMapCustomSqlColumnsProperty[] | cdktn.IResolvable): void;
        resetColumns(): void;
        get columnsInput(): cdktn.IResolvable | PhysicalTableMapCustomSqlColumnsProperty[] | undefined;
    }
    interface PhysicalTableMapRelationalTableInputColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#name TfDataSet#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#type TfDataSet#type}
        */
        readonly type: string;
    }
    class PhysicalTableMapRelationalTableInputColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhysicalTableMapRelationalTableInputColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PhysicalTableMapRelationalTableInputColumnsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class PhysicalTableMapRelationalTableInputColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: PhysicalTableMapRelationalTableInputColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhysicalTableMapRelationalTableInputColumnsPropertyOutputReference;
    }
    interface RelationalTableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#catalog TfDataSet#catalog}
        */
        readonly catalog?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#data_source_arn TfDataSet#data_source_arn}
        */
        readonly dataSourceArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#name TfDataSet#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#schema TfDataSet#schema}
        */
        readonly schema?: string;
        /**
        * input_columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#input_columns TfDataSet#input_columns}
        */
        readonly inputColumns: PhysicalTableMapRelationalTableInputColumnsProperty[] | cdktn.IResolvable;
    }
    class RelationalTablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RelationalTableProperty | undefined;
        set internalValue(value: RelationalTableProperty | undefined);
        private _catalog?;
        get catalog(): string;
        set catalog(value: string);
        resetCatalog(): void;
        get catalogInput(): string | undefined;
        private _dataSourceArn?;
        get dataSourceArn(): string;
        set dataSourceArn(value: string);
        get dataSourceArnInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _schema?;
        get schema(): string;
        set schema(value: string);
        resetSchema(): void;
        get schemaInput(): string | undefined;
        private _inputColumns;
        get inputColumns(): PhysicalTableMapRelationalTableInputColumnsPropertyList;
        putInputColumns(value: PhysicalTableMapRelationalTableInputColumnsProperty[] | cdktn.IResolvable): void;
        get inputColumnsInput(): cdktn.IResolvable | PhysicalTableMapRelationalTableInputColumnsProperty[] | undefined;
    }
    interface PhysicalTableMapS3SourceInputColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#name TfDataSet#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#type TfDataSet#type}
        */
        readonly type: string;
    }
    class PhysicalTableMapS3SourceInputColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhysicalTableMapS3SourceInputColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PhysicalTableMapS3SourceInputColumnsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class PhysicalTableMapS3SourceInputColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: PhysicalTableMapS3SourceInputColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhysicalTableMapS3SourceInputColumnsPropertyOutputReference;
    }
    interface UploadSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#contains_header TfDataSet#contains_header}
        */
        readonly containsHeader?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#delimiter TfDataSet#delimiter}
        */
        readonly delimiter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#format TfDataSet#format}
        */
        readonly format?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#start_from_row TfDataSet#start_from_row}
        */
        readonly startFromRow?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#text_qualifier TfDataSet#text_qualifier}
        */
        readonly textQualifier?: string;
    }
    class UploadSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UploadSettingsProperty | undefined;
        set internalValue(value: UploadSettingsProperty | undefined);
        private _containsHeader?;
        get containsHeader(): boolean | cdktn.IResolvable;
        set containsHeader(value: boolean | cdktn.IResolvable);
        resetContainsHeader(): void;
        get containsHeaderInput(): boolean | cdktn.IResolvable | undefined;
        private _delimiter?;
        get delimiter(): string;
        set delimiter(value: string);
        resetDelimiter(): void;
        get delimiterInput(): string | undefined;
        private _format?;
        get format(): string;
        set format(value: string);
        resetFormat(): void;
        get formatInput(): string | undefined;
        private _startFromRow?;
        get startFromRow(): number;
        set startFromRow(value: number);
        resetStartFromRow(): void;
        get startFromRowInput(): number | undefined;
        private _textQualifier?;
        get textQualifier(): string;
        set textQualifier(value: string);
        resetTextQualifier(): void;
        get textQualifierInput(): string | undefined;
    }
    interface S3SourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#data_source_arn TfDataSet#data_source_arn}
        */
        readonly dataSourceArn: string;
        /**
        * input_columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#input_columns TfDataSet#input_columns}
        */
        readonly inputColumns: PhysicalTableMapS3SourceInputColumnsProperty[] | cdktn.IResolvable;
        /**
        * upload_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#upload_settings TfDataSet#upload_settings}
        */
        readonly uploadSettings: UploadSettingsProperty;
    }
    class S3SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3SourceProperty | undefined;
        set internalValue(value: S3SourceProperty | undefined);
        private _dataSourceArn?;
        get dataSourceArn(): string;
        set dataSourceArn(value: string);
        get dataSourceArnInput(): string | undefined;
        private _inputColumns;
        get inputColumns(): PhysicalTableMapS3SourceInputColumnsPropertyList;
        putInputColumns(value: PhysicalTableMapS3SourceInputColumnsProperty[] | cdktn.IResolvable): void;
        get inputColumnsInput(): cdktn.IResolvable | PhysicalTableMapS3SourceInputColumnsProperty[] | undefined;
        private _uploadSettings;
        get uploadSettings(): UploadSettingsPropertyOutputReference;
        putUploadSettings(value: UploadSettingsProperty): void;
        get uploadSettingsInput(): UploadSettingsProperty | undefined;
    }
    interface PhysicalTableMapProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#physical_table_map_id TfDataSet#physical_table_map_id}
        */
        readonly physicalTableMapId: string;
        /**
        * custom_sql block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#custom_sql TfDataSet#custom_sql}
        */
        readonly customSql?: CustomSqlProperty;
        /**
        * relational_table block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#relational_table TfDataSet#relational_table}
        */
        readonly relationalTable?: RelationalTableProperty;
        /**
        * s3_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#s3_source TfDataSet#s3_source}
        */
        readonly s3Source?: S3SourceProperty;
    }
    class PhysicalTableMapPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhysicalTableMapProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PhysicalTableMapProperty | cdktn.IResolvable | undefined);
        private _physicalTableMapId?;
        get physicalTableMapId(): string;
        set physicalTableMapId(value: string);
        get physicalTableMapIdInput(): string | undefined;
        private _customSql;
        get customSql(): CustomSqlPropertyOutputReference;
        putCustomSql(value: CustomSqlProperty): void;
        resetCustomSql(): void;
        get customSqlInput(): CustomSqlProperty | undefined;
        private _relationalTable;
        get relationalTable(): RelationalTablePropertyOutputReference;
        putRelationalTable(value: RelationalTableProperty): void;
        resetRelationalTable(): void;
        get relationalTableInput(): RelationalTableProperty | undefined;
        private _s3Source;
        get s3Source(): S3SourcePropertyOutputReference;
        putS3Source(value: S3SourceProperty): void;
        resetS3Source(): void;
        get s3SourceInput(): S3SourceProperty | undefined;
    }
    class PhysicalTableMapPropertyList extends cdktn.ComplexList {
        internalValue?: PhysicalTableMapProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhysicalTableMapPropertyOutputReference;
    }
    interface LookbackWindowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_name TfDataSet#column_name}
        */
        readonly columnName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#size TfDataSet#size}
        */
        readonly size: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#size_unit TfDataSet#size_unit}
        */
        readonly sizeUnit: string;
    }
    class LookbackWindowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LookbackWindowProperty | undefined;
        set internalValue(value: LookbackWindowProperty | undefined);
        private _columnName?;
        get columnName(): string;
        set columnName(value: string);
        get columnNameInput(): string | undefined;
        private _size?;
        get size(): number;
        set size(value: number);
        get sizeInput(): number | undefined;
        private _sizeUnit?;
        get sizeUnit(): string;
        set sizeUnit(value: string);
        get sizeUnitInput(): string | undefined;
    }
    interface IncrementalRefreshProperty {
        /**
        * lookback_window block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#lookback_window TfDataSet#lookback_window}
        */
        readonly lookbackWindow: LookbackWindowProperty;
    }
    class IncrementalRefreshPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IncrementalRefreshProperty | undefined;
        set internalValue(value: IncrementalRefreshProperty | undefined);
        private _lookbackWindow;
        get lookbackWindow(): LookbackWindowPropertyOutputReference;
        putLookbackWindow(value: LookbackWindowProperty): void;
        get lookbackWindowInput(): LookbackWindowProperty | undefined;
    }
    interface RefreshConfigurationProperty {
        /**
        * incremental_refresh block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#incremental_refresh TfDataSet#incremental_refresh}
        */
        readonly incrementalRefresh: IncrementalRefreshProperty;
    }
    class RefreshConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RefreshConfigurationProperty | undefined;
        set internalValue(value: RefreshConfigurationProperty | undefined);
        private _incrementalRefresh;
        get incrementalRefresh(): IncrementalRefreshPropertyOutputReference;
        putIncrementalRefresh(value: IncrementalRefreshProperty): void;
        get incrementalRefreshInput(): IncrementalRefreshProperty | undefined;
    }
    interface RefreshPropertiesProperty {
        /**
        * refresh_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#refresh_configuration TfDataSet#refresh_configuration}
        */
        readonly refreshConfiguration: RefreshConfigurationProperty;
    }
    class RefreshPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RefreshPropertiesProperty | undefined;
        set internalValue(value: RefreshPropertiesProperty | undefined);
        private _refreshConfiguration;
        get refreshConfiguration(): RefreshConfigurationPropertyOutputReference;
        putRefreshConfiguration(value: RefreshConfigurationProperty): void;
        get refreshConfigurationInput(): RefreshConfigurationProperty | undefined;
    }
    interface RowLevelPermissionDataSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#arn TfDataSet#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#format_version TfDataSet#format_version}
        */
        readonly formatVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#namespace TfDataSet#namespace}
        */
        readonly namespace?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#permission_policy TfDataSet#permission_policy}
        */
        readonly permissionPolicy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#status TfDataSet#status}
        */
        readonly status?: string;
    }
    class RowLevelPermissionDataSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RowLevelPermissionDataSetProperty | undefined;
        set internalValue(value: RowLevelPermissionDataSetProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _formatVersion?;
        get formatVersion(): string;
        set formatVersion(value: string);
        resetFormatVersion(): void;
        get formatVersionInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        resetNamespace(): void;
        get namespaceInput(): string | undefined;
        private _permissionPolicy?;
        get permissionPolicy(): string;
        set permissionPolicy(value: string);
        get permissionPolicyInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface TagRulesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#column_name TfDataSet#column_name}
        */
        readonly columnName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#match_all_value TfDataSet#match_all_value}
        */
        readonly matchAllValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#tag_key TfDataSet#tag_key}
        */
        readonly tagKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#tag_multi_value_delimiter TfDataSet#tag_multi_value_delimiter}
        */
        readonly tagMultiValueDelimiter?: string;
    }
    class TagRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagRulesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagRulesProperty | cdktn.IResolvable | undefined);
        private _columnName?;
        get columnName(): string;
        set columnName(value: string);
        get columnNameInput(): string | undefined;
        private _matchAllValue?;
        get matchAllValue(): string;
        set matchAllValue(value: string);
        resetMatchAllValue(): void;
        get matchAllValueInput(): string | undefined;
        private _tagKey?;
        get tagKey(): string;
        set tagKey(value: string);
        get tagKeyInput(): string | undefined;
        private _tagMultiValueDelimiter?;
        get tagMultiValueDelimiter(): string;
        set tagMultiValueDelimiter(value: string);
        resetTagMultiValueDelimiter(): void;
        get tagMultiValueDelimiterInput(): string | undefined;
    }
    class TagRulesPropertyList extends cdktn.ComplexList {
        internalValue?: TagRulesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagRulesPropertyOutputReference;
    }
    interface RowLevelPermissionTagConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#status TfDataSet#status}
        */
        readonly status?: string;
        /**
        * tag_rules block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_data_set#tag_rules TfDataSet#tag_rules}
        */
        readonly tagRules: TagRulesProperty[] | cdktn.IResolvable;
    }
    class RowLevelPermissionTagConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RowLevelPermissionTagConfigurationProperty | undefined;
        set internalValue(value: RowLevelPermissionTagConfigurationProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
        private _tagRules;
        get tagRules(): TagRulesPropertyList;
        putTagRules(value: TagRulesProperty[] | cdktn.IResolvable): void;
        get tagRulesInput(): cdktn.IResolvable | TagRulesProperty[] | undefined;
    }
}
