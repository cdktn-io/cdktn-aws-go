import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfIpRestrictionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_ip_restriction#aws_account_id TfIpRestriction#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_ip_restriction#enabled TfIpRestriction#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_ip_restriction#ip_restriction_rule_map TfIpRestriction#ip_restriction_rule_map}
    */
    readonly ipRestrictionRuleMap?: {
        [key: string]: string;
    };
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_ip_restriction#region TfIpRestriction#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_ip_restriction#vpc_endpoint_id_restriction_rule_map TfIpRestriction#vpc_endpoint_id_restriction_rule_map}
    */
    readonly vpcEndpointIdRestrictionRuleMap?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_ip_restriction#vpc_id_restriction_rule_map TfIpRestriction#vpc_id_restriction_rule_map}
    */
    readonly vpcIdRestrictionRuleMap?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_ip_restriction aws_quicksight_ip_restriction}
*/
export declare class TfIpRestriction extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_quicksight_ip_restriction";
    /**
    * Generates CDKTN code for importing a TfIpRestriction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfIpRestriction to import
    * @param importFromId The id of the existing TfIpRestriction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_ip_restriction#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfIpRestriction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_ip_restriction aws_quicksight_ip_restriction} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfIpRestrictionConfig
    */
    constructor(scope: Construct, id: string, config: TfIpRestrictionConfig);
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _ipRestrictionRuleMap?;
    get ipRestrictionRuleMap(): {
        [key: string]: string;
    };
    set ipRestrictionRuleMap(value: {
        [key: string]: string;
    });
    resetIpRestrictionRuleMap(): void;
    get ipRestrictionRuleMapInput(): {
        [key: string]: string;
    } | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _vpcEndpointIdRestrictionRuleMap?;
    get vpcEndpointIdRestrictionRuleMap(): {
        [key: string]: string;
    };
    set vpcEndpointIdRestrictionRuleMap(value: {
        [key: string]: string;
    });
    resetVpcEndpointIdRestrictionRuleMap(): void;
    get vpcEndpointIdRestrictionRuleMapInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcIdRestrictionRuleMap?;
    get vpcIdRestrictionRuleMap(): {
        [key: string]: string;
    };
    set vpcIdRestrictionRuleMap(value: {
        [key: string]: string;
    });
    resetVpcIdRestrictionRuleMap(): void;
    get vpcIdRestrictionRuleMapInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
