import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfTemplateAliasConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template_alias#alias_name TfTemplateAlias#alias_name}
    */
    readonly aliasName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template_alias#aws_account_id TfTemplateAlias#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template_alias#region TfTemplateAlias#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template_alias#template_id TfTemplateAlias#template_id}
    */
    readonly templateId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template_alias#template_version_number TfTemplateAlias#template_version_number}
    */
    readonly templateVersionNumber: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template_alias aws_quicksight_template_alias}
*/
export declare class TfTemplateAlias extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_quicksight_template_alias";
    /**
    * Generates CDKTN code for importing a TfTemplateAlias resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfTemplateAlias to import
    * @param importFromId The id of the existing TfTemplateAlias that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template_alias#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfTemplateAlias to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/quicksight_template_alias aws_quicksight_template_alias} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfTemplateAliasConfig
    */
    constructor(scope: Construct, id: string, config: TfTemplateAliasConfig);
    private _aliasName?;
    get aliasName(): string;
    set aliasName(value: string);
    get aliasNameInput(): string | undefined;
    get arn(): string;
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _templateId?;
    get templateId(): string;
    set templateId(value: string);
    get templateIdInput(): string | undefined;
    private _templateVersionNumber?;
    get templateVersionNumber(): number;
    set templateVersionNumber(value: number);
    get templateVersionNumberInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
