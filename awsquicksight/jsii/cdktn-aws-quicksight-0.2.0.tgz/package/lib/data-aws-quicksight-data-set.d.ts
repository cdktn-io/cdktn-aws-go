import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfDataSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/quicksight_data_set#aws_account_id DataTfDataSet#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/quicksight_data_set#data_set_id DataTfDataSet#data_set_id}
    */
    readonly dataSetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/quicksight_data_set#id DataTfDataSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/quicksight_data_set#region DataTfDataSet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/quicksight_data_set#tags DataTfDataSet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/quicksight_data_set aws_quicksight_data_set}
*/
export declare class DataTfDataSet extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_quicksight_data_set";
    /**
    * Generates CDKTN code for importing a DataTfDataSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfDataSet to import
    * @param importFromId The id of the existing DataTfDataSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/quicksight_data_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfDataSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/quicksight_data_set aws_quicksight_data_set} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfDataSetConfig
    */
    constructor(scope: Construct, id: string, config: DataTfDataSetConfig);
    get arn(): string;
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    private _columnGroups;
    get columnGroups(): DataTfDataSet.ColumnGroupsPropertyList;
    private _columnLevelPermissionRules;
    get columnLevelPermissionRules(): DataTfDataSet.ColumnLevelPermissionRulesPropertyList;
    private _dataSetId?;
    get dataSetId(): string;
    set dataSetId(value: string);
    get dataSetIdInput(): string | undefined;
    private _dataSetUsageConfiguration;
    get dataSetUsageConfiguration(): DataTfDataSet.DataSetUsageConfigurationPropertyList;
    private _fieldFolders;
    get fieldFolders(): DataTfDataSet.FieldFoldersPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get importMode(): string;
    private _logicalTableMap;
    get logicalTableMap(): DataTfDataSet.LogicalTableMapPropertyList;
    get name(): string;
    private _permissions;
    get permissions(): DataTfDataSet.PermissionsPropertyList;
    private _physicalTableMap;
    get physicalTableMap(): DataTfDataSet.PhysicalTableMapPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rowLevelPermissionDataSet;
    get rowLevelPermissionDataSet(): DataTfDataSet.RowLevelPermissionDataSetPropertyList;
    private _rowLevelPermissionTagConfiguration;
    get rowLevelPermissionTagConfiguration(): DataTfDataSet.RowLevelPermissionTagConfigurationPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfDataSetGeoSpatialColumnGroupPropertyToTerraform(struct?: DataTfDataSet.GeoSpatialColumnGroupProperty): any;
export declare function dataTfDataSetGeoSpatialColumnGroupPropertyToHclTerraform(struct?: DataTfDataSet.GeoSpatialColumnGroupProperty): any;
export declare function dataTfDataSetColumnGroupsPropertyToTerraform(struct?: DataTfDataSet.ColumnGroupsProperty): any;
export declare function dataTfDataSetColumnGroupsPropertyToHclTerraform(struct?: DataTfDataSet.ColumnGroupsProperty): any;
export declare function dataTfDataSetColumnLevelPermissionRulesPropertyToTerraform(struct?: DataTfDataSet.ColumnLevelPermissionRulesProperty): any;
export declare function dataTfDataSetColumnLevelPermissionRulesPropertyToHclTerraform(struct?: DataTfDataSet.ColumnLevelPermissionRulesProperty): any;
export declare function dataTfDataSetDataSetUsageConfigurationPropertyToTerraform(struct?: DataTfDataSet.DataSetUsageConfigurationProperty): any;
export declare function dataTfDataSetDataSetUsageConfigurationPropertyToHclTerraform(struct?: DataTfDataSet.DataSetUsageConfigurationProperty): any;
export declare function dataTfDataSetFieldFoldersPropertyToTerraform(struct?: DataTfDataSet.FieldFoldersProperty): any;
export declare function dataTfDataSetFieldFoldersPropertyToHclTerraform(struct?: DataTfDataSet.FieldFoldersProperty): any;
export declare function dataTfDataSetCastColumnTypeOperationPropertyToTerraform(struct?: DataTfDataSet.CastColumnTypeOperationProperty): any;
export declare function dataTfDataSetCastColumnTypeOperationPropertyToHclTerraform(struct?: DataTfDataSet.CastColumnTypeOperationProperty): any;
export declare function dataTfDataSetLogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyToTerraform(struct?: DataTfDataSet.LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty): any;
export declare function dataTfDataSetLogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyToHclTerraform(struct?: DataTfDataSet.LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty): any;
export declare function dataTfDataSetCreateColumnsOperationPropertyToTerraform(struct?: DataTfDataSet.CreateColumnsOperationProperty): any;
export declare function dataTfDataSetCreateColumnsOperationPropertyToHclTerraform(struct?: DataTfDataSet.CreateColumnsOperationProperty): any;
export declare function dataTfDataSetFilterOperationPropertyToTerraform(struct?: DataTfDataSet.FilterOperationProperty): any;
export declare function dataTfDataSetFilterOperationPropertyToHclTerraform(struct?: DataTfDataSet.FilterOperationProperty): any;
export declare function dataTfDataSetProjectOperationPropertyToTerraform(struct?: DataTfDataSet.ProjectOperationProperty): any;
export declare function dataTfDataSetProjectOperationPropertyToHclTerraform(struct?: DataTfDataSet.ProjectOperationProperty): any;
export declare function dataTfDataSetRenameColumnOperationPropertyToTerraform(struct?: DataTfDataSet.RenameColumnOperationProperty): any;
export declare function dataTfDataSetRenameColumnOperationPropertyToHclTerraform(struct?: DataTfDataSet.RenameColumnOperationProperty): any;
export declare function dataTfDataSetColumnDescriptionPropertyToTerraform(struct?: DataTfDataSet.ColumnDescriptionProperty): any;
export declare function dataTfDataSetColumnDescriptionPropertyToHclTerraform(struct?: DataTfDataSet.ColumnDescriptionProperty): any;
export declare function dataTfDataSetTagsPropertyToTerraform(struct?: DataTfDataSet.TagsProperty): any;
export declare function dataTfDataSetTagsPropertyToHclTerraform(struct?: DataTfDataSet.TagsProperty): any;
export declare function dataTfDataSetTagColumnOperationPropertyToTerraform(struct?: DataTfDataSet.TagColumnOperationProperty): any;
export declare function dataTfDataSetTagColumnOperationPropertyToHclTerraform(struct?: DataTfDataSet.TagColumnOperationProperty): any;
export declare function dataTfDataSetUntagColumnOperationPropertyToTerraform(struct?: DataTfDataSet.UntagColumnOperationProperty): any;
export declare function dataTfDataSetUntagColumnOperationPropertyToHclTerraform(struct?: DataTfDataSet.UntagColumnOperationProperty): any;
export declare function dataTfDataSetDataTransformsPropertyToTerraform(struct?: DataTfDataSet.DataTransformsProperty): any;
export declare function dataTfDataSetDataTransformsPropertyToHclTerraform(struct?: DataTfDataSet.DataTransformsProperty): any;
export declare function dataTfDataSetLeftJoinKeyPropertiesPropertyToTerraform(struct?: DataTfDataSet.LeftJoinKeyPropertiesProperty): any;
export declare function dataTfDataSetLeftJoinKeyPropertiesPropertyToHclTerraform(struct?: DataTfDataSet.LeftJoinKeyPropertiesProperty): any;
export declare function dataTfDataSetRightJoinKeyPropertiesPropertyToTerraform(struct?: DataTfDataSet.RightJoinKeyPropertiesProperty): any;
export declare function dataTfDataSetRightJoinKeyPropertiesPropertyToHclTerraform(struct?: DataTfDataSet.RightJoinKeyPropertiesProperty): any;
export declare function dataTfDataSetJoinInstructionPropertyToTerraform(struct?: DataTfDataSet.JoinInstructionProperty): any;
export declare function dataTfDataSetJoinInstructionPropertyToHclTerraform(struct?: DataTfDataSet.JoinInstructionProperty): any;
export declare function dataTfDataSetSourcePropertyToTerraform(struct?: DataTfDataSet.SourceProperty): any;
export declare function dataTfDataSetSourcePropertyToHclTerraform(struct?: DataTfDataSet.SourceProperty): any;
export declare function dataTfDataSetLogicalTableMapPropertyToTerraform(struct?: DataTfDataSet.LogicalTableMapProperty): any;
export declare function dataTfDataSetLogicalTableMapPropertyToHclTerraform(struct?: DataTfDataSet.LogicalTableMapProperty): any;
export declare function dataTfDataSetPermissionsPropertyToTerraform(struct?: DataTfDataSet.PermissionsProperty): any;
export declare function dataTfDataSetPermissionsPropertyToHclTerraform(struct?: DataTfDataSet.PermissionsProperty): any;
export declare function dataTfDataSetPhysicalTableMapCustomSqlColumnsPropertyToTerraform(struct?: DataTfDataSet.PhysicalTableMapCustomSqlColumnsProperty): any;
export declare function dataTfDataSetPhysicalTableMapCustomSqlColumnsPropertyToHclTerraform(struct?: DataTfDataSet.PhysicalTableMapCustomSqlColumnsProperty): any;
export declare function dataTfDataSetCustomSqlPropertyToTerraform(struct?: DataTfDataSet.CustomSqlProperty): any;
export declare function dataTfDataSetCustomSqlPropertyToHclTerraform(struct?: DataTfDataSet.CustomSqlProperty): any;
export declare function dataTfDataSetPhysicalTableMapRelationalTableInputColumnsPropertyToTerraform(struct?: DataTfDataSet.PhysicalTableMapRelationalTableInputColumnsProperty): any;
export declare function dataTfDataSetPhysicalTableMapRelationalTableInputColumnsPropertyToHclTerraform(struct?: DataTfDataSet.PhysicalTableMapRelationalTableInputColumnsProperty): any;
export declare function dataTfDataSetRelationalTablePropertyToTerraform(struct?: DataTfDataSet.RelationalTableProperty): any;
export declare function dataTfDataSetRelationalTablePropertyToHclTerraform(struct?: DataTfDataSet.RelationalTableProperty): any;
export declare function dataTfDataSetPhysicalTableMapS3SourceInputColumnsPropertyToTerraform(struct?: DataTfDataSet.PhysicalTableMapS3SourceInputColumnsProperty): any;
export declare function dataTfDataSetPhysicalTableMapS3SourceInputColumnsPropertyToHclTerraform(struct?: DataTfDataSet.PhysicalTableMapS3SourceInputColumnsProperty): any;
export declare function dataTfDataSetUploadSettingsPropertyToTerraform(struct?: DataTfDataSet.UploadSettingsProperty): any;
export declare function dataTfDataSetUploadSettingsPropertyToHclTerraform(struct?: DataTfDataSet.UploadSettingsProperty): any;
export declare function dataTfDataSetS3SourcePropertyToTerraform(struct?: DataTfDataSet.S3SourceProperty): any;
export declare function dataTfDataSetS3SourcePropertyToHclTerraform(struct?: DataTfDataSet.S3SourceProperty): any;
export declare function dataTfDataSetPhysicalTableMapPropertyToTerraform(struct?: DataTfDataSet.PhysicalTableMapProperty): any;
export declare function dataTfDataSetPhysicalTableMapPropertyToHclTerraform(struct?: DataTfDataSet.PhysicalTableMapProperty): any;
export declare function dataTfDataSetRowLevelPermissionDataSetPropertyToTerraform(struct?: DataTfDataSet.RowLevelPermissionDataSetProperty): any;
export declare function dataTfDataSetRowLevelPermissionDataSetPropertyToHclTerraform(struct?: DataTfDataSet.RowLevelPermissionDataSetProperty): any;
export declare function dataTfDataSetTagRulesPropertyToTerraform(struct?: DataTfDataSet.TagRulesProperty): any;
export declare function dataTfDataSetTagRulesPropertyToHclTerraform(struct?: DataTfDataSet.TagRulesProperty): any;
export declare function dataTfDataSetRowLevelPermissionTagConfigurationPropertyToTerraform(struct?: DataTfDataSet.RowLevelPermissionTagConfigurationProperty): any;
export declare function dataTfDataSetRowLevelPermissionTagConfigurationPropertyToHclTerraform(struct?: DataTfDataSet.RowLevelPermissionTagConfigurationProperty): any;
export declare namespace DataTfDataSet {
    interface GeoSpatialColumnGroupProperty {
    }
    class GeoSpatialColumnGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GeoSpatialColumnGroupProperty | undefined;
        set internalValue(value: GeoSpatialColumnGroupProperty | undefined);
        get columns(): string[];
        get countryCode(): string;
        get name(): string;
    }
    class GeoSpatialColumnGroupPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GeoSpatialColumnGroupPropertyOutputReference;
    }
    interface ColumnGroupsProperty {
    }
    class ColumnGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnGroupsProperty | undefined;
        set internalValue(value: ColumnGroupsProperty | undefined);
        private _geoSpatialColumnGroup;
        get geoSpatialColumnGroup(): GeoSpatialColumnGroupPropertyList;
    }
    class ColumnGroupsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnGroupsPropertyOutputReference;
    }
    interface ColumnLevelPermissionRulesProperty {
    }
    class ColumnLevelPermissionRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnLevelPermissionRulesProperty | undefined;
        set internalValue(value: ColumnLevelPermissionRulesProperty | undefined);
        get columnNames(): string[];
        get principals(): string[];
    }
    class ColumnLevelPermissionRulesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnLevelPermissionRulesPropertyOutputReference;
    }
    interface DataSetUsageConfigurationProperty {
    }
    class DataSetUsageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataSetUsageConfigurationProperty | undefined;
        set internalValue(value: DataSetUsageConfigurationProperty | undefined);
        get disableUseAsDirectQuerySource(): cdktn.IResolvable;
        get disableUseAsImportedSource(): cdktn.IResolvable;
    }
    class DataSetUsageConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataSetUsageConfigurationPropertyOutputReference;
    }
    interface FieldFoldersProperty {
    }
    class FieldFoldersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FieldFoldersProperty | undefined;
        set internalValue(value: FieldFoldersProperty | undefined);
        get columns(): string[];
        get description(): string;
        get fieldFoldersId(): string;
    }
    class FieldFoldersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FieldFoldersPropertyOutputReference;
    }
    interface CastColumnTypeOperationProperty {
    }
    class CastColumnTypeOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CastColumnTypeOperationProperty | undefined;
        set internalValue(value: CastColumnTypeOperationProperty | undefined);
        get columnName(): string;
        get format(): string;
        get newColumnType(): string;
    }
    class CastColumnTypeOperationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CastColumnTypeOperationPropertyOutputReference;
    }
    interface LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty {
    }
    class LogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty | undefined;
        set internalValue(value: LogicalTableMapDataTransformsCreateColumnsOperationColumnsProperty | undefined);
        get columnId(): string;
        get columnName(): string;
        get expression(): string;
    }
    class LogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyOutputReference;
    }
    interface CreateColumnsOperationProperty {
    }
    class CreateColumnsOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreateColumnsOperationProperty | undefined;
        set internalValue(value: CreateColumnsOperationProperty | undefined);
        private _columns;
        get columns(): LogicalTableMapDataTransformsCreateColumnsOperationColumnsPropertyList;
    }
    class CreateColumnsOperationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreateColumnsOperationPropertyOutputReference;
    }
    interface FilterOperationProperty {
    }
    class FilterOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterOperationProperty | undefined;
        set internalValue(value: FilterOperationProperty | undefined);
        get conditionExpression(): string;
    }
    class FilterOperationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterOperationPropertyOutputReference;
    }
    interface ProjectOperationProperty {
    }
    class ProjectOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProjectOperationProperty | undefined;
        set internalValue(value: ProjectOperationProperty | undefined);
        get projectedColumns(): string[];
    }
    class ProjectOperationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProjectOperationPropertyOutputReference;
    }
    interface RenameColumnOperationProperty {
    }
    class RenameColumnOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RenameColumnOperationProperty | undefined;
        set internalValue(value: RenameColumnOperationProperty | undefined);
        get columnName(): string;
        get newColumnName(): string;
    }
    class RenameColumnOperationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RenameColumnOperationPropertyOutputReference;
    }
    interface ColumnDescriptionProperty {
    }
    class ColumnDescriptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColumnDescriptionProperty | undefined;
        set internalValue(value: ColumnDescriptionProperty | undefined);
        get text(): string;
    }
    class ColumnDescriptionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColumnDescriptionPropertyOutputReference;
    }
    interface TagsProperty {
    }
    class TagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagsProperty | undefined;
        set internalValue(value: TagsProperty | undefined);
        private _columnDescription;
        get columnDescription(): ColumnDescriptionPropertyList;
        get columnGeographicRole(): string;
    }
    class TagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagsPropertyOutputReference;
    }
    interface TagColumnOperationProperty {
    }
    class TagColumnOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagColumnOperationProperty | undefined;
        set internalValue(value: TagColumnOperationProperty | undefined);
        get columnName(): string;
        private _tags;
        get tags(): TagsPropertyList;
    }
    class TagColumnOperationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagColumnOperationPropertyOutputReference;
    }
    interface UntagColumnOperationProperty {
    }
    class UntagColumnOperationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UntagColumnOperationProperty | undefined;
        set internalValue(value: UntagColumnOperationProperty | undefined);
        get columnName(): string;
        get tagNames(): string[];
    }
    class UntagColumnOperationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UntagColumnOperationPropertyOutputReference;
    }
    interface DataTransformsProperty {
    }
    class DataTransformsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataTransformsProperty | undefined;
        set internalValue(value: DataTransformsProperty | undefined);
        private _castColumnTypeOperation;
        get castColumnTypeOperation(): CastColumnTypeOperationPropertyList;
        private _createColumnsOperation;
        get createColumnsOperation(): CreateColumnsOperationPropertyList;
        private _filterOperation;
        get filterOperation(): FilterOperationPropertyList;
        private _projectOperation;
        get projectOperation(): ProjectOperationPropertyList;
        private _renameColumnOperation;
        get renameColumnOperation(): RenameColumnOperationPropertyList;
        private _tagColumnOperation;
        get tagColumnOperation(): TagColumnOperationPropertyList;
        private _untagColumnOperation;
        get untagColumnOperation(): UntagColumnOperationPropertyList;
    }
    class DataTransformsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataTransformsPropertyOutputReference;
    }
    interface LeftJoinKeyPropertiesProperty {
    }
    class LeftJoinKeyPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LeftJoinKeyPropertiesProperty | undefined;
        set internalValue(value: LeftJoinKeyPropertiesProperty | undefined);
        get uniqueKey(): cdktn.IResolvable;
    }
    class LeftJoinKeyPropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LeftJoinKeyPropertiesPropertyOutputReference;
    }
    interface RightJoinKeyPropertiesProperty {
    }
    class RightJoinKeyPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RightJoinKeyPropertiesProperty | undefined;
        set internalValue(value: RightJoinKeyPropertiesProperty | undefined);
        get uniqueKey(): cdktn.IResolvable;
    }
    class RightJoinKeyPropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RightJoinKeyPropertiesPropertyOutputReference;
    }
    interface JoinInstructionProperty {
    }
    class JoinInstructionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JoinInstructionProperty | undefined;
        set internalValue(value: JoinInstructionProperty | undefined);
        private _leftJoinKeyProperties;
        get leftJoinKeyProperties(): LeftJoinKeyPropertiesPropertyList;
        get leftOperand(): string;
        get onClause(): string;
        private _rightJoinKeyProperties;
        get rightJoinKeyProperties(): RightJoinKeyPropertiesPropertyList;
        get rightOperand(): string;
        get type(): string;
    }
    class JoinInstructionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JoinInstructionPropertyOutputReference;
    }
    interface SourceProperty {
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceProperty | undefined;
        set internalValue(value: SourceProperty | undefined);
        get dataSetArn(): string;
        private _joinInstruction;
        get joinInstruction(): JoinInstructionPropertyList;
        get physicalTableId(): string;
    }
    class SourcePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcePropertyOutputReference;
    }
    interface LogicalTableMapProperty {
    }
    class LogicalTableMapPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogicalTableMapProperty | undefined;
        set internalValue(value: LogicalTableMapProperty | undefined);
        get alias(): string;
        private _dataTransforms;
        get dataTransforms(): DataTransformsPropertyList;
        get logicalTableMapId(): string;
        private _source;
        get source(): SourcePropertyList;
    }
    class LogicalTableMapPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogicalTableMapPropertyOutputReference;
    }
    interface PermissionsProperty {
    }
    class PermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PermissionsProperty | undefined;
        set internalValue(value: PermissionsProperty | undefined);
        get actions(): string[];
        get principal(): string;
    }
    class PermissionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PermissionsPropertyOutputReference;
    }
    interface PhysicalTableMapCustomSqlColumnsProperty {
    }
    class PhysicalTableMapCustomSqlColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhysicalTableMapCustomSqlColumnsProperty | undefined;
        set internalValue(value: PhysicalTableMapCustomSqlColumnsProperty | undefined);
        get name(): string;
        get type(): string;
    }
    class PhysicalTableMapCustomSqlColumnsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhysicalTableMapCustomSqlColumnsPropertyOutputReference;
    }
    interface CustomSqlProperty {
    }
    class CustomSqlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomSqlProperty | undefined;
        set internalValue(value: CustomSqlProperty | undefined);
        private _columns;
        get columns(): PhysicalTableMapCustomSqlColumnsPropertyList;
        get dataSourceArn(): string;
        get name(): string;
        get sqlQuery(): string;
    }
    class CustomSqlPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomSqlPropertyOutputReference;
    }
    interface PhysicalTableMapRelationalTableInputColumnsProperty {
    }
    class PhysicalTableMapRelationalTableInputColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhysicalTableMapRelationalTableInputColumnsProperty | undefined;
        set internalValue(value: PhysicalTableMapRelationalTableInputColumnsProperty | undefined);
        get name(): string;
        get type(): string;
    }
    class PhysicalTableMapRelationalTableInputColumnsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhysicalTableMapRelationalTableInputColumnsPropertyOutputReference;
    }
    interface RelationalTableProperty {
    }
    class RelationalTablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RelationalTableProperty | undefined;
        set internalValue(value: RelationalTableProperty | undefined);
        get catalog(): string;
        get dataSourceArn(): string;
        private _inputColumns;
        get inputColumns(): PhysicalTableMapRelationalTableInputColumnsPropertyList;
        get name(): string;
        get schema(): string;
    }
    class RelationalTablePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RelationalTablePropertyOutputReference;
    }
    interface PhysicalTableMapS3SourceInputColumnsProperty {
    }
    class PhysicalTableMapS3SourceInputColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhysicalTableMapS3SourceInputColumnsProperty | undefined;
        set internalValue(value: PhysicalTableMapS3SourceInputColumnsProperty | undefined);
        get name(): string;
        get type(): string;
    }
    class PhysicalTableMapS3SourceInputColumnsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhysicalTableMapS3SourceInputColumnsPropertyOutputReference;
    }
    interface UploadSettingsProperty {
    }
    class UploadSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UploadSettingsProperty | undefined;
        set internalValue(value: UploadSettingsProperty | undefined);
        get containsHeader(): cdktn.IResolvable;
        get delimiter(): string;
        get format(): string;
        get startFromRow(): number;
        get textQualifier(): string;
    }
    class UploadSettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UploadSettingsPropertyOutputReference;
    }
    interface S3SourceProperty {
    }
    class S3SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3SourceProperty | undefined;
        set internalValue(value: S3SourceProperty | undefined);
        get dataSourceArn(): string;
        private _inputColumns;
        get inputColumns(): PhysicalTableMapS3SourceInputColumnsPropertyList;
        private _uploadSettings;
        get uploadSettings(): UploadSettingsPropertyList;
    }
    class S3SourcePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3SourcePropertyOutputReference;
    }
    interface PhysicalTableMapProperty {
    }
    class PhysicalTableMapPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PhysicalTableMapProperty | undefined;
        set internalValue(value: PhysicalTableMapProperty | undefined);
        private _customSql;
        get customSql(): CustomSqlPropertyList;
        get physicalTableMapId(): string;
        private _relationalTable;
        get relationalTable(): RelationalTablePropertyList;
        private _s3Source;
        get s3Source(): S3SourcePropertyList;
    }
    class PhysicalTableMapPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PhysicalTableMapPropertyOutputReference;
    }
    interface RowLevelPermissionDataSetProperty {
    }
    class RowLevelPermissionDataSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RowLevelPermissionDataSetProperty | undefined;
        set internalValue(value: RowLevelPermissionDataSetProperty | undefined);
        get arn(): string;
        get formatVersion(): string;
        get namespace(): string;
        get permissionPolicy(): string;
        get status(): string;
    }
    class RowLevelPermissionDataSetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RowLevelPermissionDataSetPropertyOutputReference;
    }
    interface TagRulesProperty {
    }
    class TagRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagRulesProperty | undefined;
        set internalValue(value: TagRulesProperty | undefined);
        get columnName(): string;
        get matchAllValue(): string;
        get tagKey(): string;
        get tagMultiValueDelimiter(): string;
    }
    class TagRulesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagRulesPropertyOutputReference;
    }
    interface RowLevelPermissionTagConfigurationProperty {
    }
    class RowLevelPermissionTagConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RowLevelPermissionTagConfigurationProperty | undefined;
        set internalValue(value: RowLevelPermissionTagConfigurationProperty | undefined);
        get status(): string;
        private _tagRules;
        get tagRules(): TagRulesPropertyList;
    }
    class RowLevelPermissionTagConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RowLevelPermissionTagConfigurationPropertyOutputReference;
    }
}
