import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPipelineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#max_units AwsPipeline#max_units}
    */
    readonly maxUnits: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#min_units AwsPipeline#min_units}
    */
    readonly minUnits: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#pipeline_configuration_body AwsPipeline#pipeline_configuration_body}
    */
    readonly pipelineConfigurationBody: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#pipeline_name AwsPipeline#pipeline_name}
    */
    readonly pipelineName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#pipeline_role_arn AwsPipeline#pipeline_role_arn}
    */
    readonly pipelineRoleArn?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#region AwsPipeline#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#tags AwsPipeline#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * buffer_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#buffer_options AwsPipeline#buffer_options}
    */
    readonly bufferOptions?: AwsPipeline.BufferOptionsProperty[] | cdktn.IResolvable;
    /**
    * encryption_at_rest_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#encryption_at_rest_options AwsPipeline#encryption_at_rest_options}
    */
    readonly encryptionAtRestOptions?: AwsPipeline.EncryptionAtRestOptionsProperty[] | cdktn.IResolvable;
    /**
    * log_publishing_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#log_publishing_options AwsPipeline#log_publishing_options}
    */
    readonly logPublishingOptions?: AwsPipeline.LogPublishingOptionsProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#timeouts AwsPipeline#timeouts}
    */
    readonly timeouts?: AwsPipeline.TimeoutsProperty;
    /**
    * vpc_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#vpc_options AwsPipeline#vpc_options}
    */
    readonly vpcOptions?: AwsPipeline.VpcOptionsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline aws_osis_pipeline}
*/
export declare class AwsPipeline extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_osis_pipeline";
    /**
    * Generates CDKTN code for importing a AwsPipeline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPipeline to import
    * @param importFromId The id of the existing AwsPipeline that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPipeline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline aws_osis_pipeline} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPipelineConfig
    */
    constructor(scope: Construct, id: string, config: AwsPipelineConfig);
    get id(): string;
    get ingestEndpointUrls(): string[];
    private _maxUnits?;
    get maxUnits(): number;
    set maxUnits(value: number);
    get maxUnitsInput(): number | undefined;
    private _minUnits?;
    get minUnits(): number;
    set minUnits(value: number);
    get minUnitsInput(): number | undefined;
    get pipelineArn(): string;
    private _pipelineConfigurationBody?;
    get pipelineConfigurationBody(): string;
    set pipelineConfigurationBody(value: string);
    get pipelineConfigurationBodyInput(): string | undefined;
    private _pipelineName?;
    get pipelineName(): string;
    set pipelineName(value: string);
    get pipelineNameInput(): string | undefined;
    private _pipelineRoleArn?;
    get pipelineRoleArn(): string;
    set pipelineRoleArn(value: string);
    resetPipelineRoleArn(): void;
    get pipelineRoleArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _bufferOptions;
    get bufferOptions(): AwsPipeline.BufferOptionsPropertyList;
    putBufferOptions(value: AwsPipeline.BufferOptionsProperty[] | cdktn.IResolvable): void;
    resetBufferOptions(): void;
    get bufferOptionsInput(): cdktn.IResolvable | AwsPipeline.BufferOptionsProperty[] | undefined;
    private _encryptionAtRestOptions;
    get encryptionAtRestOptions(): AwsPipeline.EncryptionAtRestOptionsPropertyList;
    putEncryptionAtRestOptions(value: AwsPipeline.EncryptionAtRestOptionsProperty[] | cdktn.IResolvable): void;
    resetEncryptionAtRestOptions(): void;
    get encryptionAtRestOptionsInput(): cdktn.IResolvable | AwsPipeline.EncryptionAtRestOptionsProperty[] | undefined;
    private _logPublishingOptions;
    get logPublishingOptions(): AwsPipeline.LogPublishingOptionsPropertyList;
    putLogPublishingOptions(value: AwsPipeline.LogPublishingOptionsProperty[] | cdktn.IResolvable): void;
    resetLogPublishingOptions(): void;
    get logPublishingOptionsInput(): cdktn.IResolvable | AwsPipeline.LogPublishingOptionsProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsPipeline.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsPipeline.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsPipeline.TimeoutsProperty | undefined;
    private _vpcOptions;
    get vpcOptions(): AwsPipeline.VpcOptionsPropertyList;
    putVpcOptions(value: AwsPipeline.VpcOptionsProperty[] | cdktn.IResolvable): void;
    resetVpcOptions(): void;
    get vpcOptionsInput(): cdktn.IResolvable | AwsPipeline.VpcOptionsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPipelineBufferOptionsPropertyToTerraform(struct?: AwsPipeline.BufferOptionsProperty | cdktn.IResolvable): any;
export declare function awsPipelineBufferOptionsPropertyToHclTerraform(struct?: AwsPipeline.BufferOptionsProperty | cdktn.IResolvable): any;
export declare function awsPipelineEncryptionAtRestOptionsPropertyToTerraform(struct?: AwsPipeline.EncryptionAtRestOptionsProperty | cdktn.IResolvable): any;
export declare function awsPipelineEncryptionAtRestOptionsPropertyToHclTerraform(struct?: AwsPipeline.EncryptionAtRestOptionsProperty | cdktn.IResolvable): any;
export declare function awsPipelineCloudwatchLogDestinationPropertyToTerraform(struct?: AwsPipeline.CloudwatchLogDestinationProperty | cdktn.IResolvable): any;
export declare function awsPipelineCloudwatchLogDestinationPropertyToHclTerraform(struct?: AwsPipeline.CloudwatchLogDestinationProperty | cdktn.IResolvable): any;
export declare function awsPipelineLogPublishingOptionsPropertyToTerraform(struct?: AwsPipeline.LogPublishingOptionsProperty | cdktn.IResolvable): any;
export declare function awsPipelineLogPublishingOptionsPropertyToHclTerraform(struct?: AwsPipeline.LogPublishingOptionsProperty | cdktn.IResolvable): any;
export declare function awsPipelineTimeoutsPropertyToTerraform(struct?: AwsPipeline.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsPipelineTimeoutsPropertyToHclTerraform(struct?: AwsPipeline.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsPipelineVpcOptionsPropertyToTerraform(struct?: AwsPipeline.VpcOptionsProperty | cdktn.IResolvable): any;
export declare function awsPipelineVpcOptionsPropertyToHclTerraform(struct?: AwsPipeline.VpcOptionsProperty | cdktn.IResolvable): any;
export declare namespace AwsPipeline {
    interface BufferOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#persistent_buffer_enabled AwsPipeline#persistent_buffer_enabled}
        */
        readonly persistentBufferEnabled: boolean | cdktn.IResolvable;
    }
    class BufferOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BufferOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BufferOptionsProperty | cdktn.IResolvable | undefined);
        private _persistentBufferEnabled?;
        get persistentBufferEnabled(): boolean | cdktn.IResolvable;
        set persistentBufferEnabled(value: boolean | cdktn.IResolvable);
        get persistentBufferEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    class BufferOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: BufferOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BufferOptionsPropertyOutputReference;
    }
    interface EncryptionAtRestOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#kms_key_arn AwsPipeline#kms_key_arn}
        */
        readonly kmsKeyArn: string;
    }
    class EncryptionAtRestOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionAtRestOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EncryptionAtRestOptionsProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        get kmsKeyArnInput(): string | undefined;
    }
    class EncryptionAtRestOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: EncryptionAtRestOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionAtRestOptionsPropertyOutputReference;
    }
    interface CloudwatchLogDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#log_group AwsPipeline#log_group}
        */
        readonly logGroup: string;
    }
    class CloudwatchLogDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchLogDestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchLogDestinationProperty | cdktn.IResolvable | undefined);
        private _logGroup?;
        get logGroup(): string;
        set logGroup(value: string);
        get logGroupInput(): string | undefined;
    }
    class CloudwatchLogDestinationPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchLogDestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchLogDestinationPropertyOutputReference;
    }
    interface LogPublishingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#is_logging_enabled AwsPipeline#is_logging_enabled}
        */
        readonly isLoggingEnabled?: boolean | cdktn.IResolvable;
        /**
        * cloudwatch_log_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#cloudwatch_log_destination AwsPipeline#cloudwatch_log_destination}
        */
        readonly cloudwatchLogDestination?: CloudwatchLogDestinationProperty[] | cdktn.IResolvable;
    }
    class LogPublishingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogPublishingOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogPublishingOptionsProperty | cdktn.IResolvable | undefined);
        private _isLoggingEnabled?;
        get isLoggingEnabled(): boolean | cdktn.IResolvable;
        set isLoggingEnabled(value: boolean | cdktn.IResolvable);
        resetIsLoggingEnabled(): void;
        get isLoggingEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _cloudwatchLogDestination;
        get cloudwatchLogDestination(): CloudwatchLogDestinationPropertyList;
        putCloudwatchLogDestination(value: CloudwatchLogDestinationProperty[] | cdktn.IResolvable): void;
        resetCloudwatchLogDestination(): void;
        get cloudwatchLogDestinationInput(): cdktn.IResolvable | CloudwatchLogDestinationProperty[] | undefined;
    }
    class LogPublishingOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: LogPublishingOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogPublishingOptionsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#create AwsPipeline#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#delete AwsPipeline#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#update AwsPipeline#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#security_group_ids AwsPipeline#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#subnet_ids AwsPipeline#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/osis_pipeline#vpc_endpoint_management AwsPipeline#vpc_endpoint_management}
        */
        readonly vpcEndpointManagement?: string;
    }
    class VpcOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcOptionsProperty | cdktn.IResolvable | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _vpcEndpointManagement?;
        get vpcEndpointManagement(): string;
        set vpcEndpointManagement(value: string);
        resetVpcEndpointManagement(): void;
        get vpcEndpointManagementInput(): string | undefined;
    }
    class VpcOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: VpcOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcOptionsPropertyOutputReference;
    }
}
