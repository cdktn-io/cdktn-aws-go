import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#airflow_configuration_options TfEnvironment#airflow_configuration_options}
    */
    readonly airflowConfigurationOptions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#airflow_version TfEnvironment#airflow_version}
    */
    readonly airflowVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#dag_s3_path TfEnvironment#dag_s3_path}
    */
    readonly dagS3Path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#endpoint_management TfEnvironment#endpoint_management}
    */
    readonly endpointManagement?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#environment_class TfEnvironment#environment_class}
    */
    readonly environmentClass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#execution_role_arn TfEnvironment#execution_role_arn}
    */
    readonly executionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#id TfEnvironment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#kms_key TfEnvironment#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#max_webservers TfEnvironment#max_webservers}
    */
    readonly maxWebservers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#max_workers TfEnvironment#max_workers}
    */
    readonly maxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#min_webservers TfEnvironment#min_webservers}
    */
    readonly minWebservers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#min_workers TfEnvironment#min_workers}
    */
    readonly minWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#name TfEnvironment#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#plugins_s3_object_version TfEnvironment#plugins_s3_object_version}
    */
    readonly pluginsS3ObjectVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#plugins_s3_path TfEnvironment#plugins_s3_path}
    */
    readonly pluginsS3Path?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#region TfEnvironment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#requirements_s3_object_version TfEnvironment#requirements_s3_object_version}
    */
    readonly requirementsS3ObjectVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#requirements_s3_path TfEnvironment#requirements_s3_path}
    */
    readonly requirementsS3Path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#schedulers TfEnvironment#schedulers}
    */
    readonly schedulers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#source_bucket_arn TfEnvironment#source_bucket_arn}
    */
    readonly sourceBucketArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#startup_script_s3_object_version TfEnvironment#startup_script_s3_object_version}
    */
    readonly startupScriptS3ObjectVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#startup_script_s3_path TfEnvironment#startup_script_s3_path}
    */
    readonly startupScriptS3Path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#tags TfEnvironment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#tags_all TfEnvironment#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#webserver_access_mode TfEnvironment#webserver_access_mode}
    */
    readonly webserverAccessMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#weekly_maintenance_window_start TfEnvironment#weekly_maintenance_window_start}
    */
    readonly weeklyMaintenanceWindowStart?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#worker_replacement_strategy TfEnvironment#worker_replacement_strategy}
    */
    readonly workerReplacementStrategy?: string;
    /**
    * logging_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#logging_configuration TfEnvironment#logging_configuration}
    */
    readonly loggingConfiguration?: TfEnvironment.LoggingConfigurationProperty;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#network_configuration TfEnvironment#network_configuration}
    */
    readonly networkConfiguration: TfEnvironment.NetworkConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#timeouts TfEnvironment#timeouts}
    */
    readonly timeouts?: TfEnvironment.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment aws_mwaa_environment}
*/
export declare class TfEnvironment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_mwaa_environment";
    /**
    * Generates CDKTN code for importing a TfEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfEnvironment to import
    * @param importFromId The id of the existing TfEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment aws_mwaa_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: TfEnvironmentConfig);
    private _airflowConfigurationOptions?;
    get airflowConfigurationOptions(): {
        [key: string]: string;
    };
    set airflowConfigurationOptions(value: {
        [key: string]: string;
    });
    resetAirflowConfigurationOptions(): void;
    get airflowConfigurationOptionsInput(): {
        [key: string]: string;
    } | undefined;
    private _airflowVersion?;
    get airflowVersion(): string;
    set airflowVersion(value: string);
    resetAirflowVersion(): void;
    get airflowVersionInput(): string | undefined;
    get arn(): string;
    get createdAt(): string;
    private _dagS3Path?;
    get dagS3Path(): string;
    set dagS3Path(value: string);
    get dagS3PathInput(): string | undefined;
    get databaseVpcEndpointService(): string;
    private _endpointManagement?;
    get endpointManagement(): string;
    set endpointManagement(value: string);
    resetEndpointManagement(): void;
    get endpointManagementInput(): string | undefined;
    private _environmentClass?;
    get environmentClass(): string;
    set environmentClass(value: string);
    resetEnvironmentClass(): void;
    get environmentClassInput(): string | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    get executionRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _lastUpdated;
    get lastUpdated(): TfEnvironment.LastUpdatedPropertyList;
    private _maxWebservers?;
    get maxWebservers(): number;
    set maxWebservers(value: number);
    resetMaxWebservers(): void;
    get maxWebserversInput(): number | undefined;
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    resetMaxWorkers(): void;
    get maxWorkersInput(): number | undefined;
    private _minWebservers?;
    get minWebservers(): number;
    set minWebservers(value: number);
    resetMinWebservers(): void;
    get minWebserversInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    resetMinWorkers(): void;
    get minWorkersInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _pluginsS3ObjectVersion?;
    get pluginsS3ObjectVersion(): string;
    set pluginsS3ObjectVersion(value: string);
    resetPluginsS3ObjectVersion(): void;
    get pluginsS3ObjectVersionInput(): string | undefined;
    private _pluginsS3Path?;
    get pluginsS3Path(): string;
    set pluginsS3Path(value: string);
    resetPluginsS3Path(): void;
    get pluginsS3PathInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requirementsS3ObjectVersion?;
    get requirementsS3ObjectVersion(): string;
    set requirementsS3ObjectVersion(value: string);
    resetRequirementsS3ObjectVersion(): void;
    get requirementsS3ObjectVersionInput(): string | undefined;
    private _requirementsS3Path?;
    get requirementsS3Path(): string;
    set requirementsS3Path(value: string);
    resetRequirementsS3Path(): void;
    get requirementsS3PathInput(): string | undefined;
    private _schedulers?;
    get schedulers(): number;
    set schedulers(value: number);
    resetSchedulers(): void;
    get schedulersInput(): number | undefined;
    get serviceRoleArn(): string;
    private _sourceBucketArn?;
    get sourceBucketArn(): string;
    set sourceBucketArn(value: string);
    get sourceBucketArnInput(): string | undefined;
    private _startupScriptS3ObjectVersion?;
    get startupScriptS3ObjectVersion(): string;
    set startupScriptS3ObjectVersion(value: string);
    resetStartupScriptS3ObjectVersion(): void;
    get startupScriptS3ObjectVersionInput(): string | undefined;
    private _startupScriptS3Path?;
    get startupScriptS3Path(): string;
    set startupScriptS3Path(value: string);
    resetStartupScriptS3Path(): void;
    get startupScriptS3PathInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _webserverAccessMode?;
    get webserverAccessMode(): string;
    set webserverAccessMode(value: string);
    resetWebserverAccessMode(): void;
    get webserverAccessModeInput(): string | undefined;
    get webserverUrl(): string;
    get webserverVpcEndpointService(): string;
    private _weeklyMaintenanceWindowStart?;
    get weeklyMaintenanceWindowStart(): string;
    set weeklyMaintenanceWindowStart(value: string);
    resetWeeklyMaintenanceWindowStart(): void;
    get weeklyMaintenanceWindowStartInput(): string | undefined;
    private _workerReplacementStrategy?;
    get workerReplacementStrategy(): string;
    set workerReplacementStrategy(value: string);
    resetWorkerReplacementStrategy(): void;
    get workerReplacementStrategyInput(): string | undefined;
    private _loggingConfiguration;
    get loggingConfiguration(): TfEnvironment.LoggingConfigurationPropertyOutputReference;
    putLoggingConfiguration(value: TfEnvironment.LoggingConfigurationProperty): void;
    resetLoggingConfiguration(): void;
    get loggingConfigurationInput(): TfEnvironment.LoggingConfigurationProperty | undefined;
    private _networkConfiguration;
    get networkConfiguration(): TfEnvironment.NetworkConfigurationPropertyOutputReference;
    putNetworkConfiguration(value: TfEnvironment.NetworkConfigurationProperty): void;
    get networkConfigurationInput(): TfEnvironment.NetworkConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): TfEnvironment.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfEnvironment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): TfEnvironment.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfEnvironmentErrorPropertyToTerraform(struct?: TfEnvironment.ErrorProperty): any;
export declare function tfEnvironmentErrorPropertyToHclTerraform(struct?: TfEnvironment.ErrorProperty): any;
export declare function tfEnvironmentLastUpdatedPropertyToTerraform(struct?: TfEnvironment.LastUpdatedProperty): any;
export declare function tfEnvironmentLastUpdatedPropertyToHclTerraform(struct?: TfEnvironment.LastUpdatedProperty): any;
export declare function tfEnvironmentDagProcessingLogsPropertyToTerraform(struct?: TfEnvironment.DagProcessingLogsPropertyOutputReference | TfEnvironment.DagProcessingLogsProperty): any;
export declare function tfEnvironmentDagProcessingLogsPropertyToHclTerraform(struct?: TfEnvironment.DagProcessingLogsPropertyOutputReference | TfEnvironment.DagProcessingLogsProperty): any;
export declare function tfEnvironmentSchedulerLogsPropertyToTerraform(struct?: TfEnvironment.SchedulerLogsPropertyOutputReference | TfEnvironment.SchedulerLogsProperty): any;
export declare function tfEnvironmentSchedulerLogsPropertyToHclTerraform(struct?: TfEnvironment.SchedulerLogsPropertyOutputReference | TfEnvironment.SchedulerLogsProperty): any;
export declare function tfEnvironmentTaskLogsPropertyToTerraform(struct?: TfEnvironment.TaskLogsPropertyOutputReference | TfEnvironment.TaskLogsProperty): any;
export declare function tfEnvironmentTaskLogsPropertyToHclTerraform(struct?: TfEnvironment.TaskLogsPropertyOutputReference | TfEnvironment.TaskLogsProperty): any;
export declare function tfEnvironmentWebserverLogsPropertyToTerraform(struct?: TfEnvironment.WebserverLogsPropertyOutputReference | TfEnvironment.WebserverLogsProperty): any;
export declare function tfEnvironmentWebserverLogsPropertyToHclTerraform(struct?: TfEnvironment.WebserverLogsPropertyOutputReference | TfEnvironment.WebserverLogsProperty): any;
export declare function tfEnvironmentWorkerLogsPropertyToTerraform(struct?: TfEnvironment.WorkerLogsPropertyOutputReference | TfEnvironment.WorkerLogsProperty): any;
export declare function tfEnvironmentWorkerLogsPropertyToHclTerraform(struct?: TfEnvironment.WorkerLogsPropertyOutputReference | TfEnvironment.WorkerLogsProperty): any;
export declare function tfEnvironmentLoggingConfigurationPropertyToTerraform(struct?: TfEnvironment.LoggingConfigurationPropertyOutputReference | TfEnvironment.LoggingConfigurationProperty): any;
export declare function tfEnvironmentLoggingConfigurationPropertyToHclTerraform(struct?: TfEnvironment.LoggingConfigurationPropertyOutputReference | TfEnvironment.LoggingConfigurationProperty): any;
export declare function tfEnvironmentNetworkConfigurationPropertyToTerraform(struct?: TfEnvironment.NetworkConfigurationPropertyOutputReference | TfEnvironment.NetworkConfigurationProperty): any;
export declare function tfEnvironmentNetworkConfigurationPropertyToHclTerraform(struct?: TfEnvironment.NetworkConfigurationPropertyOutputReference | TfEnvironment.NetworkConfigurationProperty): any;
export declare function tfEnvironmentTimeoutsPropertyToTerraform(struct?: TfEnvironment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfEnvironmentTimeoutsPropertyToHclTerraform(struct?: TfEnvironment.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfEnvironment {
    interface ErrorProperty {
    }
    class ErrorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ErrorProperty | undefined;
        set internalValue(value: ErrorProperty | undefined);
        get errorCode(): string;
        get errorMessage(): string;
    }
    class ErrorPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ErrorPropertyOutputReference;
    }
    interface LastUpdatedProperty {
    }
    class LastUpdatedPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastUpdatedProperty | undefined;
        set internalValue(value: LastUpdatedProperty | undefined);
        get createdAt(): string;
        private _error;
        get error(): ErrorPropertyList;
        get status(): string;
    }
    class LastUpdatedPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastUpdatedPropertyOutputReference;
    }
    interface DagProcessingLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#enabled TfEnvironment#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#log_level TfEnvironment#log_level}
        */
        readonly logLevel?: string;
    }
    class DagProcessingLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DagProcessingLogsProperty | undefined;
        set internalValue(value: DagProcessingLogsProperty | undefined);
        get cloudWatchLogGroupArn(): string;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logLevel?;
        get logLevel(): string;
        set logLevel(value: string);
        resetLogLevel(): void;
        get logLevelInput(): string | undefined;
    }
    interface SchedulerLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#enabled TfEnvironment#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#log_level TfEnvironment#log_level}
        */
        readonly logLevel?: string;
    }
    class SchedulerLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchedulerLogsProperty | undefined;
        set internalValue(value: SchedulerLogsProperty | undefined);
        get cloudWatchLogGroupArn(): string;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logLevel?;
        get logLevel(): string;
        set logLevel(value: string);
        resetLogLevel(): void;
        get logLevelInput(): string | undefined;
    }
    interface TaskLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#enabled TfEnvironment#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#log_level TfEnvironment#log_level}
        */
        readonly logLevel?: string;
    }
    class TaskLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TaskLogsProperty | undefined;
        set internalValue(value: TaskLogsProperty | undefined);
        get cloudWatchLogGroupArn(): string;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logLevel?;
        get logLevel(): string;
        set logLevel(value: string);
        resetLogLevel(): void;
        get logLevelInput(): string | undefined;
    }
    interface WebserverLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#enabled TfEnvironment#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#log_level TfEnvironment#log_level}
        */
        readonly logLevel?: string;
    }
    class WebserverLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WebserverLogsProperty | undefined;
        set internalValue(value: WebserverLogsProperty | undefined);
        get cloudWatchLogGroupArn(): string;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logLevel?;
        get logLevel(): string;
        set logLevel(value: string);
        resetLogLevel(): void;
        get logLevelInput(): string | undefined;
    }
    interface WorkerLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#enabled TfEnvironment#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#log_level TfEnvironment#log_level}
        */
        readonly logLevel?: string;
    }
    class WorkerLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkerLogsProperty | undefined;
        set internalValue(value: WorkerLogsProperty | undefined);
        get cloudWatchLogGroupArn(): string;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logLevel?;
        get logLevel(): string;
        set logLevel(value: string);
        resetLogLevel(): void;
        get logLevelInput(): string | undefined;
    }
    interface LoggingConfigurationProperty {
        /**
        * dag_processing_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#dag_processing_logs TfEnvironment#dag_processing_logs}
        */
        readonly dagProcessingLogs?: DagProcessingLogsProperty;
        /**
        * scheduler_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#scheduler_logs TfEnvironment#scheduler_logs}
        */
        readonly schedulerLogs?: SchedulerLogsProperty;
        /**
        * task_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#task_logs TfEnvironment#task_logs}
        */
        readonly taskLogs?: TaskLogsProperty;
        /**
        * webserver_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#webserver_logs TfEnvironment#webserver_logs}
        */
        readonly webserverLogs?: WebserverLogsProperty;
        /**
        * worker_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#worker_logs TfEnvironment#worker_logs}
        */
        readonly workerLogs?: WorkerLogsProperty;
    }
    class LoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingConfigurationProperty | undefined;
        set internalValue(value: LoggingConfigurationProperty | undefined);
        private _dagProcessingLogs;
        get dagProcessingLogs(): DagProcessingLogsPropertyOutputReference;
        putDagProcessingLogs(value: DagProcessingLogsProperty): void;
        resetDagProcessingLogs(): void;
        get dagProcessingLogsInput(): DagProcessingLogsProperty | undefined;
        private _schedulerLogs;
        get schedulerLogs(): SchedulerLogsPropertyOutputReference;
        putSchedulerLogs(value: SchedulerLogsProperty): void;
        resetSchedulerLogs(): void;
        get schedulerLogsInput(): SchedulerLogsProperty | undefined;
        private _taskLogs;
        get taskLogs(): TaskLogsPropertyOutputReference;
        putTaskLogs(value: TaskLogsProperty): void;
        resetTaskLogs(): void;
        get taskLogsInput(): TaskLogsProperty | undefined;
        private _webserverLogs;
        get webserverLogs(): WebserverLogsPropertyOutputReference;
        putWebserverLogs(value: WebserverLogsProperty): void;
        resetWebserverLogs(): void;
        get webserverLogsInput(): WebserverLogsProperty | undefined;
        private _workerLogs;
        get workerLogs(): WorkerLogsPropertyOutputReference;
        putWorkerLogs(value: WorkerLogsProperty): void;
        resetWorkerLogs(): void;
        get workerLogsInput(): WorkerLogsProperty | undefined;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#security_group_ids TfEnvironment#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#subnet_ids TfEnvironment#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#create TfEnvironment#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#delete TfEnvironment#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#update TfEnvironment#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
