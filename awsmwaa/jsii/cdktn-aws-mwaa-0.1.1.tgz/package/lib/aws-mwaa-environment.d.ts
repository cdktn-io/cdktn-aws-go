import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMwaaEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#airflow_configuration_options AwsMwaaEnvironment#airflow_configuration_options}
    */
    readonly airflowConfigurationOptions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#airflow_version AwsMwaaEnvironment#airflow_version}
    */
    readonly airflowVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#dag_s3_path AwsMwaaEnvironment#dag_s3_path}
    */
    readonly dagS3Path: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#endpoint_management AwsMwaaEnvironment#endpoint_management}
    */
    readonly endpointManagement?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#environment_class AwsMwaaEnvironment#environment_class}
    */
    readonly environmentClass?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#execution_role_arn AwsMwaaEnvironment#execution_role_arn}
    */
    readonly executionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#id AwsMwaaEnvironment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#kms_key AwsMwaaEnvironment#kms_key}
    */
    readonly kmsKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#max_webservers AwsMwaaEnvironment#max_webservers}
    */
    readonly maxWebservers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#max_workers AwsMwaaEnvironment#max_workers}
    */
    readonly maxWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#min_webservers AwsMwaaEnvironment#min_webservers}
    */
    readonly minWebservers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#min_workers AwsMwaaEnvironment#min_workers}
    */
    readonly minWorkers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#name AwsMwaaEnvironment#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#plugins_s3_object_version AwsMwaaEnvironment#plugins_s3_object_version}
    */
    readonly pluginsS3ObjectVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#plugins_s3_path AwsMwaaEnvironment#plugins_s3_path}
    */
    readonly pluginsS3Path?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#region AwsMwaaEnvironment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#requirements_s3_object_version AwsMwaaEnvironment#requirements_s3_object_version}
    */
    readonly requirementsS3ObjectVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#requirements_s3_path AwsMwaaEnvironment#requirements_s3_path}
    */
    readonly requirementsS3Path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#schedulers AwsMwaaEnvironment#schedulers}
    */
    readonly schedulers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#source_bucket_arn AwsMwaaEnvironment#source_bucket_arn}
    */
    readonly sourceBucketArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#startup_script_s3_object_version AwsMwaaEnvironment#startup_script_s3_object_version}
    */
    readonly startupScriptS3ObjectVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#startup_script_s3_path AwsMwaaEnvironment#startup_script_s3_path}
    */
    readonly startupScriptS3Path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#tags AwsMwaaEnvironment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#tags_all AwsMwaaEnvironment#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#webserver_access_mode AwsMwaaEnvironment#webserver_access_mode}
    */
    readonly webserverAccessMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#weekly_maintenance_window_start AwsMwaaEnvironment#weekly_maintenance_window_start}
    */
    readonly weeklyMaintenanceWindowStart?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#worker_replacement_strategy AwsMwaaEnvironment#worker_replacement_strategy}
    */
    readonly workerReplacementStrategy?: string;
    /**
    * logging_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#logging_configuration AwsMwaaEnvironment#logging_configuration}
    */
    readonly loggingConfiguration?: AwsMwaaEnvironment.LoggingConfigurationProperty;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#network_configuration AwsMwaaEnvironment#network_configuration}
    */
    readonly networkConfiguration: AwsMwaaEnvironment.NetworkConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#timeouts AwsMwaaEnvironment#timeouts}
    */
    readonly timeouts?: AwsMwaaEnvironment.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment aws_mwaa_environment}
*/
export declare class AwsMwaaEnvironment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_mwaa_environment";
    /**
    * Generates CDKTN code for importing a AwsMwaaEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMwaaEnvironment to import
    * @param importFromId The id of the existing AwsMwaaEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMwaaEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment aws_mwaa_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMwaaEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsMwaaEnvironmentConfig);
    private _airflowConfigurationOptions?;
    get airflowConfigurationOptions(): {
        [key: string]: string;
    };
    set airflowConfigurationOptions(value: {
        [key: string]: string;
    });
    resetAirflowConfigurationOptions(): void;
    get airflowConfigurationOptionsInput(): {
        [key: string]: string;
    } | undefined;
    private _airflowVersion?;
    get airflowVersion(): string;
    set airflowVersion(value: string);
    resetAirflowVersion(): void;
    get airflowVersionInput(): string | undefined;
    get arn(): string;
    get createdAt(): string;
    private _dagS3Path?;
    get dagS3Path(): string;
    set dagS3Path(value: string);
    get dagS3PathInput(): string | undefined;
    get databaseVpcEndpointService(): string;
    private _endpointManagement?;
    get endpointManagement(): string;
    set endpointManagement(value: string);
    resetEndpointManagement(): void;
    get endpointManagementInput(): string | undefined;
    private _environmentClass?;
    get environmentClass(): string;
    set environmentClass(value: string);
    resetEnvironmentClass(): void;
    get environmentClassInput(): string | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    get executionRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKey?;
    get kmsKey(): string;
    set kmsKey(value: string);
    resetKmsKey(): void;
    get kmsKeyInput(): string | undefined;
    private _lastUpdated;
    get lastUpdated(): AwsMwaaEnvironment.LastUpdatedPropertyList;
    private _maxWebservers?;
    get maxWebservers(): number;
    set maxWebservers(value: number);
    resetMaxWebservers(): void;
    get maxWebserversInput(): number | undefined;
    private _maxWorkers?;
    get maxWorkers(): number;
    set maxWorkers(value: number);
    resetMaxWorkers(): void;
    get maxWorkersInput(): number | undefined;
    private _minWebservers?;
    get minWebservers(): number;
    set minWebservers(value: number);
    resetMinWebservers(): void;
    get minWebserversInput(): number | undefined;
    private _minWorkers?;
    get minWorkers(): number;
    set minWorkers(value: number);
    resetMinWorkers(): void;
    get minWorkersInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _pluginsS3ObjectVersion?;
    get pluginsS3ObjectVersion(): string;
    set pluginsS3ObjectVersion(value: string);
    resetPluginsS3ObjectVersion(): void;
    get pluginsS3ObjectVersionInput(): string | undefined;
    private _pluginsS3Path?;
    get pluginsS3Path(): string;
    set pluginsS3Path(value: string);
    resetPluginsS3Path(): void;
    get pluginsS3PathInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requirementsS3ObjectVersion?;
    get requirementsS3ObjectVersion(): string;
    set requirementsS3ObjectVersion(value: string);
    resetRequirementsS3ObjectVersion(): void;
    get requirementsS3ObjectVersionInput(): string | undefined;
    private _requirementsS3Path?;
    get requirementsS3Path(): string;
    set requirementsS3Path(value: string);
    resetRequirementsS3Path(): void;
    get requirementsS3PathInput(): string | undefined;
    private _schedulers?;
    get schedulers(): number;
    set schedulers(value: number);
    resetSchedulers(): void;
    get schedulersInput(): number | undefined;
    get serviceRoleArn(): string;
    private _sourceBucketArn?;
    get sourceBucketArn(): string;
    set sourceBucketArn(value: string);
    get sourceBucketArnInput(): string | undefined;
    private _startupScriptS3ObjectVersion?;
    get startupScriptS3ObjectVersion(): string;
    set startupScriptS3ObjectVersion(value: string);
    resetStartupScriptS3ObjectVersion(): void;
    get startupScriptS3ObjectVersionInput(): string | undefined;
    private _startupScriptS3Path?;
    get startupScriptS3Path(): string;
    set startupScriptS3Path(value: string);
    resetStartupScriptS3Path(): void;
    get startupScriptS3PathInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _webserverAccessMode?;
    get webserverAccessMode(): string;
    set webserverAccessMode(value: string);
    resetWebserverAccessMode(): void;
    get webserverAccessModeInput(): string | undefined;
    get webserverUrl(): string;
    get webserverVpcEndpointService(): string;
    private _weeklyMaintenanceWindowStart?;
    get weeklyMaintenanceWindowStart(): string;
    set weeklyMaintenanceWindowStart(value: string);
    resetWeeklyMaintenanceWindowStart(): void;
    get weeklyMaintenanceWindowStartInput(): string | undefined;
    private _workerReplacementStrategy?;
    get workerReplacementStrategy(): string;
    set workerReplacementStrategy(value: string);
    resetWorkerReplacementStrategy(): void;
    get workerReplacementStrategyInput(): string | undefined;
    private _loggingConfiguration;
    get loggingConfiguration(): AwsMwaaEnvironment.LoggingConfigurationPropertyOutputReference;
    putLoggingConfiguration(value: AwsMwaaEnvironment.LoggingConfigurationProperty): void;
    resetLoggingConfiguration(): void;
    get loggingConfigurationInput(): AwsMwaaEnvironment.LoggingConfigurationProperty | undefined;
    private _networkConfiguration;
    get networkConfiguration(): AwsMwaaEnvironment.NetworkConfigurationPropertyOutputReference;
    putNetworkConfiguration(value: AwsMwaaEnvironment.NetworkConfigurationProperty): void;
    get networkConfigurationInput(): AwsMwaaEnvironment.NetworkConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsMwaaEnvironment.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsMwaaEnvironment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsMwaaEnvironment.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMwaaEnvironmentErrorPropertyToTerraform(struct?: AwsMwaaEnvironment.ErrorProperty): any;
export declare function awsMwaaEnvironmentErrorPropertyToHclTerraform(struct?: AwsMwaaEnvironment.ErrorProperty): any;
export declare function awsMwaaEnvironmentLastUpdatedPropertyToTerraform(struct?: AwsMwaaEnvironment.LastUpdatedProperty): any;
export declare function awsMwaaEnvironmentLastUpdatedPropertyToHclTerraform(struct?: AwsMwaaEnvironment.LastUpdatedProperty): any;
export declare function awsMwaaEnvironmentDagProcessingLogsPropertyToTerraform(struct?: AwsMwaaEnvironment.DagProcessingLogsPropertyOutputReference | AwsMwaaEnvironment.DagProcessingLogsProperty): any;
export declare function awsMwaaEnvironmentDagProcessingLogsPropertyToHclTerraform(struct?: AwsMwaaEnvironment.DagProcessingLogsPropertyOutputReference | AwsMwaaEnvironment.DagProcessingLogsProperty): any;
export declare function awsMwaaEnvironmentSchedulerLogsPropertyToTerraform(struct?: AwsMwaaEnvironment.SchedulerLogsPropertyOutputReference | AwsMwaaEnvironment.SchedulerLogsProperty): any;
export declare function awsMwaaEnvironmentSchedulerLogsPropertyToHclTerraform(struct?: AwsMwaaEnvironment.SchedulerLogsPropertyOutputReference | AwsMwaaEnvironment.SchedulerLogsProperty): any;
export declare function awsMwaaEnvironmentTaskLogsPropertyToTerraform(struct?: AwsMwaaEnvironment.TaskLogsPropertyOutputReference | AwsMwaaEnvironment.TaskLogsProperty): any;
export declare function awsMwaaEnvironmentTaskLogsPropertyToHclTerraform(struct?: AwsMwaaEnvironment.TaskLogsPropertyOutputReference | AwsMwaaEnvironment.TaskLogsProperty): any;
export declare function awsMwaaEnvironmentWebserverLogsPropertyToTerraform(struct?: AwsMwaaEnvironment.WebserverLogsPropertyOutputReference | AwsMwaaEnvironment.WebserverLogsProperty): any;
export declare function awsMwaaEnvironmentWebserverLogsPropertyToHclTerraform(struct?: AwsMwaaEnvironment.WebserverLogsPropertyOutputReference | AwsMwaaEnvironment.WebserverLogsProperty): any;
export declare function awsMwaaEnvironmentWorkerLogsPropertyToTerraform(struct?: AwsMwaaEnvironment.WorkerLogsPropertyOutputReference | AwsMwaaEnvironment.WorkerLogsProperty): any;
export declare function awsMwaaEnvironmentWorkerLogsPropertyToHclTerraform(struct?: AwsMwaaEnvironment.WorkerLogsPropertyOutputReference | AwsMwaaEnvironment.WorkerLogsProperty): any;
export declare function awsMwaaEnvironmentLoggingConfigurationPropertyToTerraform(struct?: AwsMwaaEnvironment.LoggingConfigurationPropertyOutputReference | AwsMwaaEnvironment.LoggingConfigurationProperty): any;
export declare function awsMwaaEnvironmentLoggingConfigurationPropertyToHclTerraform(struct?: AwsMwaaEnvironment.LoggingConfigurationPropertyOutputReference | AwsMwaaEnvironment.LoggingConfigurationProperty): any;
export declare function awsMwaaEnvironmentNetworkConfigurationPropertyToTerraform(struct?: AwsMwaaEnvironment.NetworkConfigurationPropertyOutputReference | AwsMwaaEnvironment.NetworkConfigurationProperty): any;
export declare function awsMwaaEnvironmentNetworkConfigurationPropertyToHclTerraform(struct?: AwsMwaaEnvironment.NetworkConfigurationPropertyOutputReference | AwsMwaaEnvironment.NetworkConfigurationProperty): any;
export declare function awsMwaaEnvironmentTimeoutsPropertyToTerraform(struct?: AwsMwaaEnvironment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsMwaaEnvironmentTimeoutsPropertyToHclTerraform(struct?: AwsMwaaEnvironment.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsMwaaEnvironment {
    interface ErrorProperty {
    }
    class ErrorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ErrorProperty | undefined;
        set internalValue(value: ErrorProperty | undefined);
        get errorCode(): string;
        get errorMessage(): string;
    }
    class ErrorPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ErrorPropertyOutputReference;
    }
    interface LastUpdatedProperty {
    }
    class LastUpdatedPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastUpdatedProperty | undefined;
        set internalValue(value: LastUpdatedProperty | undefined);
        get createdAt(): string;
        private _error;
        get error(): ErrorPropertyList;
        get status(): string;
    }
    class LastUpdatedPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastUpdatedPropertyOutputReference;
    }
    interface DagProcessingLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#enabled AwsMwaaEnvironment#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#log_level AwsMwaaEnvironment#log_level}
        */
        readonly logLevel?: string;
    }
    class DagProcessingLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DagProcessingLogsProperty | undefined;
        set internalValue(value: DagProcessingLogsProperty | undefined);
        get cloudWatchLogGroupArn(): string;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logLevel?;
        get logLevel(): string;
        set logLevel(value: string);
        resetLogLevel(): void;
        get logLevelInput(): string | undefined;
    }
    interface SchedulerLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#enabled AwsMwaaEnvironment#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#log_level AwsMwaaEnvironment#log_level}
        */
        readonly logLevel?: string;
    }
    class SchedulerLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchedulerLogsProperty | undefined;
        set internalValue(value: SchedulerLogsProperty | undefined);
        get cloudWatchLogGroupArn(): string;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logLevel?;
        get logLevel(): string;
        set logLevel(value: string);
        resetLogLevel(): void;
        get logLevelInput(): string | undefined;
    }
    interface TaskLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#enabled AwsMwaaEnvironment#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#log_level AwsMwaaEnvironment#log_level}
        */
        readonly logLevel?: string;
    }
    class TaskLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TaskLogsProperty | undefined;
        set internalValue(value: TaskLogsProperty | undefined);
        get cloudWatchLogGroupArn(): string;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logLevel?;
        get logLevel(): string;
        set logLevel(value: string);
        resetLogLevel(): void;
        get logLevelInput(): string | undefined;
    }
    interface WebserverLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#enabled AwsMwaaEnvironment#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#log_level AwsMwaaEnvironment#log_level}
        */
        readonly logLevel?: string;
    }
    class WebserverLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WebserverLogsProperty | undefined;
        set internalValue(value: WebserverLogsProperty | undefined);
        get cloudWatchLogGroupArn(): string;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logLevel?;
        get logLevel(): string;
        set logLevel(value: string);
        resetLogLevel(): void;
        get logLevelInput(): string | undefined;
    }
    interface WorkerLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#enabled AwsMwaaEnvironment#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#log_level AwsMwaaEnvironment#log_level}
        */
        readonly logLevel?: string;
    }
    class WorkerLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkerLogsProperty | undefined;
        set internalValue(value: WorkerLogsProperty | undefined);
        get cloudWatchLogGroupArn(): string;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logLevel?;
        get logLevel(): string;
        set logLevel(value: string);
        resetLogLevel(): void;
        get logLevelInput(): string | undefined;
    }
    interface LoggingConfigurationProperty {
        /**
        * dag_processing_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#dag_processing_logs AwsMwaaEnvironment#dag_processing_logs}
        */
        readonly dagProcessingLogs?: DagProcessingLogsProperty;
        /**
        * scheduler_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#scheduler_logs AwsMwaaEnvironment#scheduler_logs}
        */
        readonly schedulerLogs?: SchedulerLogsProperty;
        /**
        * task_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#task_logs AwsMwaaEnvironment#task_logs}
        */
        readonly taskLogs?: TaskLogsProperty;
        /**
        * webserver_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#webserver_logs AwsMwaaEnvironment#webserver_logs}
        */
        readonly webserverLogs?: WebserverLogsProperty;
        /**
        * worker_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#worker_logs AwsMwaaEnvironment#worker_logs}
        */
        readonly workerLogs?: WorkerLogsProperty;
    }
    class LoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingConfigurationProperty | undefined;
        set internalValue(value: LoggingConfigurationProperty | undefined);
        private _dagProcessingLogs;
        get dagProcessingLogs(): DagProcessingLogsPropertyOutputReference;
        putDagProcessingLogs(value: DagProcessingLogsProperty): void;
        resetDagProcessingLogs(): void;
        get dagProcessingLogsInput(): DagProcessingLogsProperty | undefined;
        private _schedulerLogs;
        get schedulerLogs(): SchedulerLogsPropertyOutputReference;
        putSchedulerLogs(value: SchedulerLogsProperty): void;
        resetSchedulerLogs(): void;
        get schedulerLogsInput(): SchedulerLogsProperty | undefined;
        private _taskLogs;
        get taskLogs(): TaskLogsPropertyOutputReference;
        putTaskLogs(value: TaskLogsProperty): void;
        resetTaskLogs(): void;
        get taskLogsInput(): TaskLogsProperty | undefined;
        private _webserverLogs;
        get webserverLogs(): WebserverLogsPropertyOutputReference;
        putWebserverLogs(value: WebserverLogsProperty): void;
        resetWebserverLogs(): void;
        get webserverLogsInput(): WebserverLogsProperty | undefined;
        private _workerLogs;
        get workerLogs(): WorkerLogsPropertyOutputReference;
        putWorkerLogs(value: WorkerLogsProperty): void;
        resetWorkerLogs(): void;
        get workerLogsInput(): WorkerLogsProperty | undefined;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#security_group_ids AwsMwaaEnvironment#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#subnet_ids AwsMwaaEnvironment#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#create AwsMwaaEnvironment#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#delete AwsMwaaEnvironment#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mwaa_environment#update AwsMwaaEnvironment#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
