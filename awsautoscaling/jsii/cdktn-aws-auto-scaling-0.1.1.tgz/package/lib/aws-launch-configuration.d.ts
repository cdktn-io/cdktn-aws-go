import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLaunchConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#associate_public_ip_address AwsLaunchConfiguration#associate_public_ip_address}
    */
    readonly associatePublicIpAddress?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#ebs_optimized AwsLaunchConfiguration#ebs_optimized}
    */
    readonly ebsOptimized?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#enable_monitoring AwsLaunchConfiguration#enable_monitoring}
    */
    readonly enableMonitoring?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#iam_instance_profile AwsLaunchConfiguration#iam_instance_profile}
    */
    readonly iamInstanceProfile?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#id AwsLaunchConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#image_id AwsLaunchConfiguration#image_id}
    */
    readonly imageId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#instance_type AwsLaunchConfiguration#instance_type}
    */
    readonly instanceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#key_name AwsLaunchConfiguration#key_name}
    */
    readonly keyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#name AwsLaunchConfiguration#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#name_prefix AwsLaunchConfiguration#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#placement_tenancy AwsLaunchConfiguration#placement_tenancy}
    */
    readonly placementTenancy?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#region AwsLaunchConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#security_groups AwsLaunchConfiguration#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#spot_price AwsLaunchConfiguration#spot_price}
    */
    readonly spotPrice?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#user_data AwsLaunchConfiguration#user_data}
    */
    readonly userData?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#user_data_base64 AwsLaunchConfiguration#user_data_base64}
    */
    readonly userDataBase64?: string;
    /**
    * ebs_block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#ebs_block_device AwsLaunchConfiguration#ebs_block_device}
    */
    readonly ebsBlockDevice?: AwsLaunchConfiguration.EbsBlockDeviceProperty[] | cdktn.IResolvable;
    /**
    * ephemeral_block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#ephemeral_block_device AwsLaunchConfiguration#ephemeral_block_device}
    */
    readonly ephemeralBlockDevice?: AwsLaunchConfiguration.EphemeralBlockDeviceProperty[] | cdktn.IResolvable;
    /**
    * metadata_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#metadata_options AwsLaunchConfiguration#metadata_options}
    */
    readonly metadataOptions?: AwsLaunchConfiguration.MetadataOptionsProperty;
    /**
    * root_block_device block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#root_block_device AwsLaunchConfiguration#root_block_device}
    */
    readonly rootBlockDevice?: AwsLaunchConfiguration.RootBlockDeviceProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration aws_launch_configuration}
*/
export declare class AwsLaunchConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_launch_configuration";
    /**
    * Generates CDKTN code for importing a AwsLaunchConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLaunchConfiguration to import
    * @param importFromId The id of the existing AwsLaunchConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLaunchConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration aws_launch_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLaunchConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsLaunchConfigurationConfig);
    get arn(): string;
    private _associatePublicIpAddress?;
    get associatePublicIpAddress(): boolean | cdktn.IResolvable;
    set associatePublicIpAddress(value: boolean | cdktn.IResolvable);
    resetAssociatePublicIpAddress(): void;
    get associatePublicIpAddressInput(): boolean | cdktn.IResolvable | undefined;
    private _ebsOptimized?;
    get ebsOptimized(): boolean | cdktn.IResolvable;
    set ebsOptimized(value: boolean | cdktn.IResolvable);
    resetEbsOptimized(): void;
    get ebsOptimizedInput(): boolean | cdktn.IResolvable | undefined;
    private _enableMonitoring?;
    get enableMonitoring(): boolean | cdktn.IResolvable;
    set enableMonitoring(value: boolean | cdktn.IResolvable);
    resetEnableMonitoring(): void;
    get enableMonitoringInput(): boolean | cdktn.IResolvable | undefined;
    private _iamInstanceProfile?;
    get iamInstanceProfile(): string;
    set iamInstanceProfile(value: string);
    resetIamInstanceProfile(): void;
    get iamInstanceProfileInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageId?;
    get imageId(): string;
    set imageId(value: string);
    get imageIdInput(): string | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    get instanceTypeInput(): string | undefined;
    private _keyName?;
    get keyName(): string;
    set keyName(value: string);
    resetKeyName(): void;
    get keyNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _placementTenancy?;
    get placementTenancy(): string;
    set placementTenancy(value: string);
    resetPlacementTenancy(): void;
    get placementTenancyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _spotPrice?;
    get spotPrice(): string;
    set spotPrice(value: string);
    resetSpotPrice(): void;
    get spotPriceInput(): string | undefined;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
    private _userDataBase64?;
    get userDataBase64(): string;
    set userDataBase64(value: string);
    resetUserDataBase64(): void;
    get userDataBase64Input(): string | undefined;
    private _ebsBlockDevice;
    get ebsBlockDevice(): AwsLaunchConfiguration.EbsBlockDevicePropertyList;
    putEbsBlockDevice(value: AwsLaunchConfiguration.EbsBlockDeviceProperty[] | cdktn.IResolvable): void;
    resetEbsBlockDevice(): void;
    get ebsBlockDeviceInput(): cdktn.IResolvable | AwsLaunchConfiguration.EbsBlockDeviceProperty[] | undefined;
    private _ephemeralBlockDevice;
    get ephemeralBlockDevice(): AwsLaunchConfiguration.EphemeralBlockDevicePropertyList;
    putEphemeralBlockDevice(value: AwsLaunchConfiguration.EphemeralBlockDeviceProperty[] | cdktn.IResolvable): void;
    resetEphemeralBlockDevice(): void;
    get ephemeralBlockDeviceInput(): cdktn.IResolvable | AwsLaunchConfiguration.EphemeralBlockDeviceProperty[] | undefined;
    private _metadataOptions;
    get metadataOptions(): AwsLaunchConfiguration.MetadataOptionsPropertyOutputReference;
    putMetadataOptions(value: AwsLaunchConfiguration.MetadataOptionsProperty): void;
    resetMetadataOptions(): void;
    get metadataOptionsInput(): AwsLaunchConfiguration.MetadataOptionsProperty | undefined;
    private _rootBlockDevice;
    get rootBlockDevice(): AwsLaunchConfiguration.RootBlockDevicePropertyOutputReference;
    putRootBlockDevice(value: AwsLaunchConfiguration.RootBlockDeviceProperty): void;
    resetRootBlockDevice(): void;
    get rootBlockDeviceInput(): AwsLaunchConfiguration.RootBlockDeviceProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLaunchConfigurationEbsBlockDevicePropertyToTerraform(struct?: AwsLaunchConfiguration.EbsBlockDeviceProperty | cdktn.IResolvable): any;
export declare function awsLaunchConfigurationEbsBlockDevicePropertyToHclTerraform(struct?: AwsLaunchConfiguration.EbsBlockDeviceProperty | cdktn.IResolvable): any;
export declare function awsLaunchConfigurationEphemeralBlockDevicePropertyToTerraform(struct?: AwsLaunchConfiguration.EphemeralBlockDeviceProperty | cdktn.IResolvable): any;
export declare function awsLaunchConfigurationEphemeralBlockDevicePropertyToHclTerraform(struct?: AwsLaunchConfiguration.EphemeralBlockDeviceProperty | cdktn.IResolvable): any;
export declare function awsLaunchConfigurationMetadataOptionsPropertyToTerraform(struct?: AwsLaunchConfiguration.MetadataOptionsPropertyOutputReference | AwsLaunchConfiguration.MetadataOptionsProperty): any;
export declare function awsLaunchConfigurationMetadataOptionsPropertyToHclTerraform(struct?: AwsLaunchConfiguration.MetadataOptionsPropertyOutputReference | AwsLaunchConfiguration.MetadataOptionsProperty): any;
export declare function awsLaunchConfigurationRootBlockDevicePropertyToTerraform(struct?: AwsLaunchConfiguration.RootBlockDevicePropertyOutputReference | AwsLaunchConfiguration.RootBlockDeviceProperty): any;
export declare function awsLaunchConfigurationRootBlockDevicePropertyToHclTerraform(struct?: AwsLaunchConfiguration.RootBlockDevicePropertyOutputReference | AwsLaunchConfiguration.RootBlockDeviceProperty): any;
export declare namespace AwsLaunchConfiguration {
    interface EbsBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#delete_on_termination AwsLaunchConfiguration#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#device_name AwsLaunchConfiguration#device_name}
        */
        readonly deviceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#encrypted AwsLaunchConfiguration#encrypted}
        */
        readonly encrypted?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#iops AwsLaunchConfiguration#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#no_device AwsLaunchConfiguration#no_device}
        */
        readonly noDevice?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#snapshot_id AwsLaunchConfiguration#snapshot_id}
        */
        readonly snapshotId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#throughput AwsLaunchConfiguration#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#volume_size AwsLaunchConfiguration#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#volume_type AwsLaunchConfiguration#volume_type}
        */
        readonly volumeType?: string;
    }
    class EbsBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsBlockDeviceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EbsBlockDeviceProperty | cdktn.IResolvable | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _deviceName?;
        get deviceName(): string;
        set deviceName(value: string);
        get deviceNameInput(): string | undefined;
        private _encrypted?;
        get encrypted(): boolean | cdktn.IResolvable;
        set encrypted(value: boolean | cdktn.IResolvable);
        resetEncrypted(): void;
        get encryptedInput(): boolean | cdktn.IResolvable | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _noDevice?;
        get noDevice(): boolean | cdktn.IResolvable;
        set noDevice(value: boolean | cdktn.IResolvable);
        resetNoDevice(): void;
        get noDeviceInput(): boolean | cdktn.IResolvable | undefined;
        private _snapshotId?;
        get snapshotId(): string;
        set snapshotId(value: string);
        resetSnapshotId(): void;
        get snapshotIdInput(): string | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    class EbsBlockDevicePropertyList extends cdktn.ComplexList {
        internalValue?: EbsBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsBlockDevicePropertyOutputReference;
    }
    interface EphemeralBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#device_name AwsLaunchConfiguration#device_name}
        */
        readonly deviceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#no_device AwsLaunchConfiguration#no_device}
        */
        readonly noDevice?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#virtual_name AwsLaunchConfiguration#virtual_name}
        */
        readonly virtualName?: string;
    }
    class EphemeralBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EphemeralBlockDeviceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EphemeralBlockDeviceProperty | cdktn.IResolvable | undefined);
        private _deviceName?;
        get deviceName(): string;
        set deviceName(value: string);
        get deviceNameInput(): string | undefined;
        private _noDevice?;
        get noDevice(): boolean | cdktn.IResolvable;
        set noDevice(value: boolean | cdktn.IResolvable);
        resetNoDevice(): void;
        get noDeviceInput(): boolean | cdktn.IResolvable | undefined;
        private _virtualName?;
        get virtualName(): string;
        set virtualName(value: string);
        resetVirtualName(): void;
        get virtualNameInput(): string | undefined;
    }
    class EphemeralBlockDevicePropertyList extends cdktn.ComplexList {
        internalValue?: EphemeralBlockDeviceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EphemeralBlockDevicePropertyOutputReference;
    }
    interface MetadataOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#http_endpoint AwsLaunchConfiguration#http_endpoint}
        */
        readonly httpEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#http_put_response_hop_limit AwsLaunchConfiguration#http_put_response_hop_limit}
        */
        readonly httpPutResponseHopLimit?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#http_tokens AwsLaunchConfiguration#http_tokens}
        */
        readonly httpTokens?: string;
    }
    class MetadataOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetadataOptionsProperty | undefined;
        set internalValue(value: MetadataOptionsProperty | undefined);
        private _httpEndpoint?;
        get httpEndpoint(): string;
        set httpEndpoint(value: string);
        resetHttpEndpoint(): void;
        get httpEndpointInput(): string | undefined;
        private _httpPutResponseHopLimit?;
        get httpPutResponseHopLimit(): number;
        set httpPutResponseHopLimit(value: number);
        resetHttpPutResponseHopLimit(): void;
        get httpPutResponseHopLimitInput(): number | undefined;
        private _httpTokens?;
        get httpTokens(): string;
        set httpTokens(value: string);
        resetHttpTokens(): void;
        get httpTokensInput(): string | undefined;
    }
    interface RootBlockDeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#delete_on_termination AwsLaunchConfiguration#delete_on_termination}
        */
        readonly deleteOnTermination?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#encrypted AwsLaunchConfiguration#encrypted}
        */
        readonly encrypted?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#iops AwsLaunchConfiguration#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#throughput AwsLaunchConfiguration#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#volume_size AwsLaunchConfiguration#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/launch_configuration#volume_type AwsLaunchConfiguration#volume_type}
        */
        readonly volumeType?: string;
    }
    class RootBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RootBlockDeviceProperty | undefined;
        set internalValue(value: RootBlockDeviceProperty | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): boolean | cdktn.IResolvable;
        set deleteOnTermination(value: boolean | cdktn.IResolvable);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): boolean | cdktn.IResolvable | undefined;
        private _encrypted?;
        get encrypted(): boolean | cdktn.IResolvable;
        set encrypted(value: boolean | cdktn.IResolvable);
        resetEncrypted(): void;
        get encryptedInput(): boolean | cdktn.IResolvable | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
}
