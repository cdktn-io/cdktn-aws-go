import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAutoscalingPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#adjustment_type AwsAutoscalingPolicy#adjustment_type}
    */
    readonly adjustmentType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#autoscaling_group_name AwsAutoscalingPolicy#autoscaling_group_name}
    */
    readonly autoscalingGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#cooldown AwsAutoscalingPolicy#cooldown}
    */
    readonly cooldown?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#enabled AwsAutoscalingPolicy#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#estimated_instance_warmup AwsAutoscalingPolicy#estimated_instance_warmup}
    */
    readonly estimatedInstanceWarmup?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#id AwsAutoscalingPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_aggregation_type AwsAutoscalingPolicy#metric_aggregation_type}
    */
    readonly metricAggregationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#min_adjustment_magnitude AwsAutoscalingPolicy#min_adjustment_magnitude}
    */
    readonly minAdjustmentMagnitude?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#name AwsAutoscalingPolicy#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#policy_type AwsAutoscalingPolicy#policy_type}
    */
    readonly policyType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#region AwsAutoscalingPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#scaling_adjustment AwsAutoscalingPolicy#scaling_adjustment}
    */
    readonly scalingAdjustment?: number;
    /**
    * predictive_scaling_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predictive_scaling_configuration AwsAutoscalingPolicy#predictive_scaling_configuration}
    */
    readonly predictiveScalingConfiguration?: AwsAutoscalingPolicy.PredictiveScalingConfigurationProperty;
    /**
    * step_adjustment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#step_adjustment AwsAutoscalingPolicy#step_adjustment}
    */
    readonly stepAdjustment?: AwsAutoscalingPolicy.StepAdjustmentProperty[] | cdktn.IResolvable;
    /**
    * target_tracking_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#target_tracking_configuration AwsAutoscalingPolicy#target_tracking_configuration}
    */
    readonly targetTrackingConfiguration?: AwsAutoscalingPolicy.TargetTrackingConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy aws_autoscaling_policy}
*/
export declare class AwsAutoscalingPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_autoscaling_policy";
    /**
    * Generates CDKTN code for importing a AwsAutoscalingPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAutoscalingPolicy to import
    * @param importFromId The id of the existing AwsAutoscalingPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAutoscalingPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy aws_autoscaling_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAutoscalingPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsAutoscalingPolicyConfig);
    private _adjustmentType?;
    get adjustmentType(): string;
    set adjustmentType(value: string);
    resetAdjustmentType(): void;
    get adjustmentTypeInput(): string | undefined;
    get arn(): string;
    private _autoscalingGroupName?;
    get autoscalingGroupName(): string;
    set autoscalingGroupName(value: string);
    get autoscalingGroupNameInput(): string | undefined;
    private _cooldown?;
    get cooldown(): number;
    set cooldown(value: number);
    resetCooldown(): void;
    get cooldownInput(): number | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _estimatedInstanceWarmup?;
    get estimatedInstanceWarmup(): number;
    set estimatedInstanceWarmup(value: number);
    resetEstimatedInstanceWarmup(): void;
    get estimatedInstanceWarmupInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metricAggregationType?;
    get metricAggregationType(): string;
    set metricAggregationType(value: string);
    resetMetricAggregationType(): void;
    get metricAggregationTypeInput(): string | undefined;
    private _minAdjustmentMagnitude?;
    get minAdjustmentMagnitude(): number;
    set minAdjustmentMagnitude(value: number);
    resetMinAdjustmentMagnitude(): void;
    get minAdjustmentMagnitudeInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _policyType?;
    get policyType(): string;
    set policyType(value: string);
    resetPolicyType(): void;
    get policyTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scalingAdjustment?;
    get scalingAdjustment(): number;
    set scalingAdjustment(value: number);
    resetScalingAdjustment(): void;
    get scalingAdjustmentInput(): number | undefined;
    private _predictiveScalingConfiguration;
    get predictiveScalingConfiguration(): AwsAutoscalingPolicy.PredictiveScalingConfigurationPropertyOutputReference;
    putPredictiveScalingConfiguration(value: AwsAutoscalingPolicy.PredictiveScalingConfigurationProperty): void;
    resetPredictiveScalingConfiguration(): void;
    get predictiveScalingConfigurationInput(): AwsAutoscalingPolicy.PredictiveScalingConfigurationProperty | undefined;
    private _stepAdjustment;
    get stepAdjustment(): AwsAutoscalingPolicy.StepAdjustmentPropertyList;
    putStepAdjustment(value: AwsAutoscalingPolicy.StepAdjustmentProperty[] | cdktn.IResolvable): void;
    resetStepAdjustment(): void;
    get stepAdjustmentInput(): cdktn.IResolvable | AwsAutoscalingPolicy.StepAdjustmentProperty[] | undefined;
    private _targetTrackingConfiguration;
    get targetTrackingConfiguration(): AwsAutoscalingPolicy.TargetTrackingConfigurationPropertyOutputReference;
    putTargetTrackingConfiguration(value: AwsAutoscalingPolicy.TargetTrackingConfigurationProperty): void;
    resetTargetTrackingConfiguration(): void;
    get targetTrackingConfigurationInput(): AwsAutoscalingPolicy.TargetTrackingConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference | AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricProperty): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference | AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricProperty): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference | AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatProperty): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference | AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatProperty): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyCustomizedCapacityMetricSpecificationPropertyToTerraform(struct?: AwsAutoscalingPolicy.CustomizedCapacityMetricSpecificationPropertyOutputReference | AwsAutoscalingPolicy.CustomizedCapacityMetricSpecificationProperty): any;
export declare function awsAutoscalingPolicyCustomizedCapacityMetricSpecificationPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.CustomizedCapacityMetricSpecificationPropertyOutputReference | AwsAutoscalingPolicy.CustomizedCapacityMetricSpecificationProperty): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference | AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricProperty): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference | AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricProperty): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference | AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatProperty): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference | AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatProperty): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyCustomizedLoadMetricSpecificationPropertyToTerraform(struct?: AwsAutoscalingPolicy.CustomizedLoadMetricSpecificationPropertyOutputReference | AwsAutoscalingPolicy.CustomizedLoadMetricSpecificationProperty): any;
export declare function awsAutoscalingPolicyCustomizedLoadMetricSpecificationPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.CustomizedLoadMetricSpecificationPropertyOutputReference | AwsAutoscalingPolicy.CustomizedLoadMetricSpecificationProperty): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference | AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricProperty): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference | AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricProperty): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference | AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatProperty): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference | AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatProperty): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyCustomizedScalingMetricSpecificationPropertyToTerraform(struct?: AwsAutoscalingPolicy.CustomizedScalingMetricSpecificationPropertyOutputReference | AwsAutoscalingPolicy.CustomizedScalingMetricSpecificationProperty): any;
export declare function awsAutoscalingPolicyCustomizedScalingMetricSpecificationPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.CustomizedScalingMetricSpecificationPropertyOutputReference | AwsAutoscalingPolicy.CustomizedScalingMetricSpecificationProperty): any;
export declare function awsAutoscalingPolicyPredefinedLoadMetricSpecificationPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredefinedLoadMetricSpecificationPropertyOutputReference | AwsAutoscalingPolicy.PredefinedLoadMetricSpecificationProperty): any;
export declare function awsAutoscalingPolicyPredefinedLoadMetricSpecificationPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredefinedLoadMetricSpecificationPropertyOutputReference | AwsAutoscalingPolicy.PredefinedLoadMetricSpecificationProperty): any;
export declare function awsAutoscalingPolicyPredefinedMetricPairSpecificationPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredefinedMetricPairSpecificationPropertyOutputReference | AwsAutoscalingPolicy.PredefinedMetricPairSpecificationProperty): any;
export declare function awsAutoscalingPolicyPredefinedMetricPairSpecificationPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredefinedMetricPairSpecificationPropertyOutputReference | AwsAutoscalingPolicy.PredefinedMetricPairSpecificationProperty): any;
export declare function awsAutoscalingPolicyPredefinedScalingMetricSpecificationPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredefinedScalingMetricSpecificationPropertyOutputReference | AwsAutoscalingPolicy.PredefinedScalingMetricSpecificationProperty): any;
export declare function awsAutoscalingPolicyPredefinedScalingMetricSpecificationPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredefinedScalingMetricSpecificationPropertyOutputReference | AwsAutoscalingPolicy.PredefinedScalingMetricSpecificationProperty): any;
export declare function awsAutoscalingPolicyMetricSpecificationPropertyToTerraform(struct?: AwsAutoscalingPolicy.MetricSpecificationPropertyOutputReference | AwsAutoscalingPolicy.MetricSpecificationProperty): any;
export declare function awsAutoscalingPolicyMetricSpecificationPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.MetricSpecificationPropertyOutputReference | AwsAutoscalingPolicy.MetricSpecificationProperty): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationPropertyOutputReference | AwsAutoscalingPolicy.PredictiveScalingConfigurationProperty): any;
export declare function awsAutoscalingPolicyPredictiveScalingConfigurationPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredictiveScalingConfigurationPropertyOutputReference | AwsAutoscalingPolicy.PredictiveScalingConfigurationProperty): any;
export declare function awsAutoscalingPolicyStepAdjustmentPropertyToTerraform(struct?: AwsAutoscalingPolicy.StepAdjustmentProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyStepAdjustmentPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.StepAdjustmentProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyMetricDimensionPropertyToTerraform(struct?: AwsAutoscalingPolicy.MetricDimensionProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyMetricDimensionPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.MetricDimensionProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyTargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsPropertyToTerraform(struct?: AwsAutoscalingPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyTargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyTargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricPropertyToTerraform(struct?: AwsAutoscalingPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricPropertyOutputReference | AwsAutoscalingPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricProperty): any;
export declare function awsAutoscalingPolicyTargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricPropertyOutputReference | AwsAutoscalingPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricProperty): any;
export declare function awsAutoscalingPolicyTargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatPropertyToTerraform(struct?: AwsAutoscalingPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatPropertyOutputReference | AwsAutoscalingPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatProperty): any;
export declare function awsAutoscalingPolicyTargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatPropertyOutputReference | AwsAutoscalingPolicy.TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatProperty): any;
export declare function awsAutoscalingPolicyMetricsPropertyToTerraform(struct?: AwsAutoscalingPolicy.MetricsProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyMetricsPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.MetricsProperty | cdktn.IResolvable): any;
export declare function awsAutoscalingPolicyCustomizedMetricSpecificationPropertyToTerraform(struct?: AwsAutoscalingPolicy.CustomizedMetricSpecificationPropertyOutputReference | AwsAutoscalingPolicy.CustomizedMetricSpecificationProperty): any;
export declare function awsAutoscalingPolicyCustomizedMetricSpecificationPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.CustomizedMetricSpecificationPropertyOutputReference | AwsAutoscalingPolicy.CustomizedMetricSpecificationProperty): any;
export declare function awsAutoscalingPolicyPredefinedMetricSpecificationPropertyToTerraform(struct?: AwsAutoscalingPolicy.PredefinedMetricSpecificationPropertyOutputReference | AwsAutoscalingPolicy.PredefinedMetricSpecificationProperty): any;
export declare function awsAutoscalingPolicyPredefinedMetricSpecificationPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.PredefinedMetricSpecificationPropertyOutputReference | AwsAutoscalingPolicy.PredefinedMetricSpecificationProperty): any;
export declare function awsAutoscalingPolicyTargetTrackingConfigurationPropertyToTerraform(struct?: AwsAutoscalingPolicy.TargetTrackingConfigurationPropertyOutputReference | AwsAutoscalingPolicy.TargetTrackingConfigurationProperty): any;
export declare function awsAutoscalingPolicyTargetTrackingConfigurationPropertyToHclTerraform(struct?: AwsAutoscalingPolicy.TargetTrackingConfigurationPropertyOutputReference | AwsAutoscalingPolicy.TargetTrackingConfigurationProperty): any;
export declare namespace AwsAutoscalingPolicy {
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#name AwsAutoscalingPolicy#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#value AwsAutoscalingPolicy#value}
        */
        readonly value: string;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyList extends cdktn.ComplexList {
        internalValue?: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyOutputReference;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_name AwsAutoscalingPolicy#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#namespace AwsAutoscalingPolicy#namespace}
        */
        readonly namespace: string;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#dimensions AwsAutoscalingPolicy#dimensions}
        */
        readonly dimensions?: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _dimensions;
        get dimensions(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyList;
        putDimensions(value: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable): void;
        resetDimensions(): void;
        get dimensionsInput(): cdktn.IResolvable | PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | undefined;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#stat AwsAutoscalingPolicy#stat}
        */
        readonly stat: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#unit AwsAutoscalingPolicy#unit}
        */
        readonly unit?: string;
        /**
        * metric block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric AwsAutoscalingPolicy#metric}
        */
        readonly metric: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricProperty;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatProperty | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatProperty | undefined);
        private _stat?;
        get stat(): string;
        set stat(value: string);
        get statInput(): string | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
        private _metric;
        get metric(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference;
        putMetric(value: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricProperty): void;
        get metricInput(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#expression AwsAutoscalingPolicy#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#id AwsAutoscalingPolicy#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#label AwsAutoscalingPolicy#label}
        */
        readonly label?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#return_data AwsAutoscalingPolicy#return_data}
        */
        readonly returnData?: boolean | cdktn.IResolvable;
        /**
        * metric_stat block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_stat AwsAutoscalingPolicy#metric_stat}
        */
        readonly metricStat?: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatProperty;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable | undefined);
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _label?;
        get label(): string;
        set label(value: string);
        resetLabel(): void;
        get labelInput(): string | undefined;
        private _returnData?;
        get returnData(): boolean | cdktn.IResolvable;
        set returnData(value: boolean | cdktn.IResolvable);
        resetReturnData(): void;
        get returnDataInput(): boolean | cdktn.IResolvable | undefined;
        private _metricStat;
        get metricStat(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference;
        putMetricStat(value: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatProperty): void;
        resetMetricStat(): void;
        get metricStatInput(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesMetricStatProperty | undefined;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesPropertyList extends cdktn.ComplexList {
        internalValue?: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesPropertyOutputReference;
    }
    interface CustomizedCapacityMetricSpecificationProperty {
        /**
        * metric_data_queries block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_data_queries AwsAutoscalingPolicy#metric_data_queries}
        */
        readonly metricDataQueries: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable;
    }
    class CustomizedCapacityMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomizedCapacityMetricSpecificationProperty | undefined;
        set internalValue(value: CustomizedCapacityMetricSpecificationProperty | undefined);
        private _metricDataQueries;
        get metricDataQueries(): PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesPropertyList;
        putMetricDataQueries(value: PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable): void;
        get metricDataQueriesInput(): cdktn.IResolvable | PredictiveScalingConfigurationMetricSpecificationCustomizedCapacityMetricSpecificationMetricDataQueriesProperty[] | undefined;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#name AwsAutoscalingPolicy#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#value AwsAutoscalingPolicy#value}
        */
        readonly value: string;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyList extends cdktn.ComplexList {
        internalValue?: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyOutputReference;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_name AwsAutoscalingPolicy#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#namespace AwsAutoscalingPolicy#namespace}
        */
        readonly namespace: string;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#dimensions AwsAutoscalingPolicy#dimensions}
        */
        readonly dimensions?: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _dimensions;
        get dimensions(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyList;
        putDimensions(value: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable): void;
        resetDimensions(): void;
        get dimensionsInput(): cdktn.IResolvable | PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | undefined;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#stat AwsAutoscalingPolicy#stat}
        */
        readonly stat: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#unit AwsAutoscalingPolicy#unit}
        */
        readonly unit?: string;
        /**
        * metric block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric AwsAutoscalingPolicy#metric}
        */
        readonly metric: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricProperty;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatProperty | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatProperty | undefined);
        private _stat?;
        get stat(): string;
        set stat(value: string);
        get statInput(): string | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
        private _metric;
        get metric(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference;
        putMetric(value: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricProperty): void;
        get metricInput(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#expression AwsAutoscalingPolicy#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#id AwsAutoscalingPolicy#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#label AwsAutoscalingPolicy#label}
        */
        readonly label?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#return_data AwsAutoscalingPolicy#return_data}
        */
        readonly returnData?: boolean | cdktn.IResolvable;
        /**
        * metric_stat block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_stat AwsAutoscalingPolicy#metric_stat}
        */
        readonly metricStat?: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatProperty;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable | undefined);
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _label?;
        get label(): string;
        set label(value: string);
        resetLabel(): void;
        get labelInput(): string | undefined;
        private _returnData?;
        get returnData(): boolean | cdktn.IResolvable;
        set returnData(value: boolean | cdktn.IResolvable);
        resetReturnData(): void;
        get returnDataInput(): boolean | cdktn.IResolvable | undefined;
        private _metricStat;
        get metricStat(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference;
        putMetricStat(value: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatProperty): void;
        resetMetricStat(): void;
        get metricStatInput(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesMetricStatProperty | undefined;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesPropertyList extends cdktn.ComplexList {
        internalValue?: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesPropertyOutputReference;
    }
    interface CustomizedLoadMetricSpecificationProperty {
        /**
        * metric_data_queries block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_data_queries AwsAutoscalingPolicy#metric_data_queries}
        */
        readonly metricDataQueries: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable;
    }
    class CustomizedLoadMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomizedLoadMetricSpecificationProperty | undefined;
        set internalValue(value: CustomizedLoadMetricSpecificationProperty | undefined);
        private _metricDataQueries;
        get metricDataQueries(): PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesPropertyList;
        putMetricDataQueries(value: PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable): void;
        get metricDataQueriesInput(): cdktn.IResolvable | PredictiveScalingConfigurationMetricSpecificationCustomizedLoadMetricSpecificationMetricDataQueriesProperty[] | undefined;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#name AwsAutoscalingPolicy#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#value AwsAutoscalingPolicy#value}
        */
        readonly value: string;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyList extends cdktn.ComplexList {
        internalValue?: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyOutputReference;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_name AwsAutoscalingPolicy#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#namespace AwsAutoscalingPolicy#namespace}
        */
        readonly namespace: string;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#dimensions AwsAutoscalingPolicy#dimensions}
        */
        readonly dimensions?: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _dimensions;
        get dimensions(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsPropertyList;
        putDimensions(value: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | cdktn.IResolvable): void;
        resetDimensions(): void;
        get dimensionsInput(): cdktn.IResolvable | PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricDimensionsProperty[] | undefined;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#stat AwsAutoscalingPolicy#stat}
        */
        readonly stat: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#unit AwsAutoscalingPolicy#unit}
        */
        readonly unit?: string;
        /**
        * metric block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric AwsAutoscalingPolicy#metric}
        */
        readonly metric: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricProperty;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatProperty | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatProperty | undefined);
        private _stat?;
        get stat(): string;
        set stat(value: string);
        get statInput(): string | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
        private _metric;
        get metric(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricPropertyOutputReference;
        putMetric(value: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricProperty): void;
        get metricInput(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatMetricProperty | undefined;
    }
    interface PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#expression AwsAutoscalingPolicy#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#id AwsAutoscalingPolicy#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#label AwsAutoscalingPolicy#label}
        */
        readonly label?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#return_data AwsAutoscalingPolicy#return_data}
        */
        readonly returnData?: boolean | cdktn.IResolvable;
        /**
        * metric_stat block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_stat AwsAutoscalingPolicy#metric_stat}
        */
        readonly metricStat?: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatProperty;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty | cdktn.IResolvable | undefined);
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _label?;
        get label(): string;
        set label(value: string);
        resetLabel(): void;
        get labelInput(): string | undefined;
        private _returnData?;
        get returnData(): boolean | cdktn.IResolvable;
        set returnData(value: boolean | cdktn.IResolvable);
        resetReturnData(): void;
        get returnDataInput(): boolean | cdktn.IResolvable | undefined;
        private _metricStat;
        get metricStat(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatPropertyOutputReference;
        putMetricStat(value: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatProperty): void;
        resetMetricStat(): void;
        get metricStatInput(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesMetricStatProperty | undefined;
    }
    class PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesPropertyList extends cdktn.ComplexList {
        internalValue?: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesPropertyOutputReference;
    }
    interface CustomizedScalingMetricSpecificationProperty {
        /**
        * metric_data_queries block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_data_queries AwsAutoscalingPolicy#metric_data_queries}
        */
        readonly metricDataQueries: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable;
    }
    class CustomizedScalingMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomizedScalingMetricSpecificationProperty | undefined;
        set internalValue(value: CustomizedScalingMetricSpecificationProperty | undefined);
        private _metricDataQueries;
        get metricDataQueries(): PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesPropertyList;
        putMetricDataQueries(value: PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty[] | cdktn.IResolvable): void;
        get metricDataQueriesInput(): cdktn.IResolvable | PredictiveScalingConfigurationMetricSpecificationCustomizedScalingMetricSpecificationMetricDataQueriesProperty[] | undefined;
    }
    interface PredefinedLoadMetricSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predefined_metric_type AwsAutoscalingPolicy#predefined_metric_type}
        */
        readonly predefinedMetricType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#resource_label AwsAutoscalingPolicy#resource_label}
        */
        readonly resourceLabel?: string;
    }
    class PredefinedLoadMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredefinedLoadMetricSpecificationProperty | undefined;
        set internalValue(value: PredefinedLoadMetricSpecificationProperty | undefined);
        private _predefinedMetricType?;
        get predefinedMetricType(): string;
        set predefinedMetricType(value: string);
        get predefinedMetricTypeInput(): string | undefined;
        private _resourceLabel?;
        get resourceLabel(): string;
        set resourceLabel(value: string);
        resetResourceLabel(): void;
        get resourceLabelInput(): string | undefined;
    }
    interface PredefinedMetricPairSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predefined_metric_type AwsAutoscalingPolicy#predefined_metric_type}
        */
        readonly predefinedMetricType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#resource_label AwsAutoscalingPolicy#resource_label}
        */
        readonly resourceLabel?: string;
    }
    class PredefinedMetricPairSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredefinedMetricPairSpecificationProperty | undefined;
        set internalValue(value: PredefinedMetricPairSpecificationProperty | undefined);
        private _predefinedMetricType?;
        get predefinedMetricType(): string;
        set predefinedMetricType(value: string);
        get predefinedMetricTypeInput(): string | undefined;
        private _resourceLabel?;
        get resourceLabel(): string;
        set resourceLabel(value: string);
        resetResourceLabel(): void;
        get resourceLabelInput(): string | undefined;
    }
    interface PredefinedScalingMetricSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predefined_metric_type AwsAutoscalingPolicy#predefined_metric_type}
        */
        readonly predefinedMetricType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#resource_label AwsAutoscalingPolicy#resource_label}
        */
        readonly resourceLabel?: string;
    }
    class PredefinedScalingMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredefinedScalingMetricSpecificationProperty | undefined;
        set internalValue(value: PredefinedScalingMetricSpecificationProperty | undefined);
        private _predefinedMetricType?;
        get predefinedMetricType(): string;
        set predefinedMetricType(value: string);
        get predefinedMetricTypeInput(): string | undefined;
        private _resourceLabel?;
        get resourceLabel(): string;
        set resourceLabel(value: string);
        resetResourceLabel(): void;
        get resourceLabelInput(): string | undefined;
    }
    interface MetricSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#target_value AwsAutoscalingPolicy#target_value}
        */
        readonly targetValue: number;
        /**
        * customized_capacity_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#customized_capacity_metric_specification AwsAutoscalingPolicy#customized_capacity_metric_specification}
        */
        readonly customizedCapacityMetricSpecification?: CustomizedCapacityMetricSpecificationProperty;
        /**
        * customized_load_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#customized_load_metric_specification AwsAutoscalingPolicy#customized_load_metric_specification}
        */
        readonly customizedLoadMetricSpecification?: CustomizedLoadMetricSpecificationProperty;
        /**
        * customized_scaling_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#customized_scaling_metric_specification AwsAutoscalingPolicy#customized_scaling_metric_specification}
        */
        readonly customizedScalingMetricSpecification?: CustomizedScalingMetricSpecificationProperty;
        /**
        * predefined_load_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predefined_load_metric_specification AwsAutoscalingPolicy#predefined_load_metric_specification}
        */
        readonly predefinedLoadMetricSpecification?: PredefinedLoadMetricSpecificationProperty;
        /**
        * predefined_metric_pair_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predefined_metric_pair_specification AwsAutoscalingPolicy#predefined_metric_pair_specification}
        */
        readonly predefinedMetricPairSpecification?: PredefinedMetricPairSpecificationProperty;
        /**
        * predefined_scaling_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predefined_scaling_metric_specification AwsAutoscalingPolicy#predefined_scaling_metric_specification}
        */
        readonly predefinedScalingMetricSpecification?: PredefinedScalingMetricSpecificationProperty;
    }
    class MetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetricSpecificationProperty | undefined;
        set internalValue(value: MetricSpecificationProperty | undefined);
        private _targetValue?;
        get targetValue(): number;
        set targetValue(value: number);
        get targetValueInput(): number | undefined;
        private _customizedCapacityMetricSpecification;
        get customizedCapacityMetricSpecification(): CustomizedCapacityMetricSpecificationPropertyOutputReference;
        putCustomizedCapacityMetricSpecification(value: CustomizedCapacityMetricSpecificationProperty): void;
        resetCustomizedCapacityMetricSpecification(): void;
        get customizedCapacityMetricSpecificationInput(): CustomizedCapacityMetricSpecificationProperty | undefined;
        private _customizedLoadMetricSpecification;
        get customizedLoadMetricSpecification(): CustomizedLoadMetricSpecificationPropertyOutputReference;
        putCustomizedLoadMetricSpecification(value: CustomizedLoadMetricSpecificationProperty): void;
        resetCustomizedLoadMetricSpecification(): void;
        get customizedLoadMetricSpecificationInput(): CustomizedLoadMetricSpecificationProperty | undefined;
        private _customizedScalingMetricSpecification;
        get customizedScalingMetricSpecification(): CustomizedScalingMetricSpecificationPropertyOutputReference;
        putCustomizedScalingMetricSpecification(value: CustomizedScalingMetricSpecificationProperty): void;
        resetCustomizedScalingMetricSpecification(): void;
        get customizedScalingMetricSpecificationInput(): CustomizedScalingMetricSpecificationProperty | undefined;
        private _predefinedLoadMetricSpecification;
        get predefinedLoadMetricSpecification(): PredefinedLoadMetricSpecificationPropertyOutputReference;
        putPredefinedLoadMetricSpecification(value: PredefinedLoadMetricSpecificationProperty): void;
        resetPredefinedLoadMetricSpecification(): void;
        get predefinedLoadMetricSpecificationInput(): PredefinedLoadMetricSpecificationProperty | undefined;
        private _predefinedMetricPairSpecification;
        get predefinedMetricPairSpecification(): PredefinedMetricPairSpecificationPropertyOutputReference;
        putPredefinedMetricPairSpecification(value: PredefinedMetricPairSpecificationProperty): void;
        resetPredefinedMetricPairSpecification(): void;
        get predefinedMetricPairSpecificationInput(): PredefinedMetricPairSpecificationProperty | undefined;
        private _predefinedScalingMetricSpecification;
        get predefinedScalingMetricSpecification(): PredefinedScalingMetricSpecificationPropertyOutputReference;
        putPredefinedScalingMetricSpecification(value: PredefinedScalingMetricSpecificationProperty): void;
        resetPredefinedScalingMetricSpecification(): void;
        get predefinedScalingMetricSpecificationInput(): PredefinedScalingMetricSpecificationProperty | undefined;
    }
    interface PredictiveScalingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#max_capacity_breach_behavior AwsAutoscalingPolicy#max_capacity_breach_behavior}
        */
        readonly maxCapacityBreachBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#max_capacity_buffer AwsAutoscalingPolicy#max_capacity_buffer}
        */
        readonly maxCapacityBuffer?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#mode AwsAutoscalingPolicy#mode}
        */
        readonly mode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#scheduling_buffer_time AwsAutoscalingPolicy#scheduling_buffer_time}
        */
        readonly schedulingBufferTime?: string;
        /**
        * metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_specification AwsAutoscalingPolicy#metric_specification}
        */
        readonly metricSpecification: MetricSpecificationProperty;
    }
    class PredictiveScalingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredictiveScalingConfigurationProperty | undefined;
        set internalValue(value: PredictiveScalingConfigurationProperty | undefined);
        private _maxCapacityBreachBehavior?;
        get maxCapacityBreachBehavior(): string;
        set maxCapacityBreachBehavior(value: string);
        resetMaxCapacityBreachBehavior(): void;
        get maxCapacityBreachBehaviorInput(): string | undefined;
        private _maxCapacityBuffer?;
        get maxCapacityBuffer(): string;
        set maxCapacityBuffer(value: string);
        resetMaxCapacityBuffer(): void;
        get maxCapacityBufferInput(): string | undefined;
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
        private _schedulingBufferTime?;
        get schedulingBufferTime(): string;
        set schedulingBufferTime(value: string);
        resetSchedulingBufferTime(): void;
        get schedulingBufferTimeInput(): string | undefined;
        private _metricSpecification;
        get metricSpecification(): MetricSpecificationPropertyOutputReference;
        putMetricSpecification(value: MetricSpecificationProperty): void;
        get metricSpecificationInput(): MetricSpecificationProperty | undefined;
    }
    interface StepAdjustmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_interval_lower_bound AwsAutoscalingPolicy#metric_interval_lower_bound}
        */
        readonly metricIntervalLowerBound?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_interval_upper_bound AwsAutoscalingPolicy#metric_interval_upper_bound}
        */
        readonly metricIntervalUpperBound?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#scaling_adjustment AwsAutoscalingPolicy#scaling_adjustment}
        */
        readonly scalingAdjustment: number;
    }
    class StepAdjustmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StepAdjustmentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StepAdjustmentProperty | cdktn.IResolvable | undefined);
        private _metricIntervalLowerBound?;
        get metricIntervalLowerBound(): string;
        set metricIntervalLowerBound(value: string);
        resetMetricIntervalLowerBound(): void;
        get metricIntervalLowerBoundInput(): string | undefined;
        private _metricIntervalUpperBound?;
        get metricIntervalUpperBound(): string;
        set metricIntervalUpperBound(value: string);
        resetMetricIntervalUpperBound(): void;
        get metricIntervalUpperBoundInput(): string | undefined;
        private _scalingAdjustment?;
        get scalingAdjustment(): number;
        set scalingAdjustment(value: number);
        get scalingAdjustmentInput(): number | undefined;
    }
    class StepAdjustmentPropertyList extends cdktn.ComplexList {
        internalValue?: StepAdjustmentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StepAdjustmentPropertyOutputReference;
    }
    interface MetricDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#name AwsAutoscalingPolicy#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#value AwsAutoscalingPolicy#value}
        */
        readonly value: string;
    }
    class MetricDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetricDimensionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetricDimensionProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class MetricDimensionPropertyList extends cdktn.ComplexList {
        internalValue?: MetricDimensionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetricDimensionPropertyOutputReference;
    }
    interface TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#name AwsAutoscalingPolicy#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#value AwsAutoscalingPolicy#value}
        */
        readonly value: string;
    }
    class TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsPropertyList extends cdktn.ComplexList {
        internalValue?: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsPropertyOutputReference;
    }
    interface TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_name AwsAutoscalingPolicy#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#namespace AwsAutoscalingPolicy#namespace}
        */
        readonly namespace: string;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#dimensions AwsAutoscalingPolicy#dimensions}
        */
        readonly dimensions?: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty[] | cdktn.IResolvable;
    }
    class TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricProperty | undefined;
        set internalValue(value: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricProperty | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        get namespaceInput(): string | undefined;
        private _dimensions;
        get dimensions(): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsPropertyList;
        putDimensions(value: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty[] | cdktn.IResolvable): void;
        resetDimensions(): void;
        get dimensionsInput(): cdktn.IResolvable | TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricDimensionsProperty[] | undefined;
    }
    interface TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#period AwsAutoscalingPolicy#period}
        */
        readonly period?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#stat AwsAutoscalingPolicy#stat}
        */
        readonly stat: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#unit AwsAutoscalingPolicy#unit}
        */
        readonly unit?: string;
        /**
        * metric block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric AwsAutoscalingPolicy#metric}
        */
        readonly metric: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricProperty;
    }
    class TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatProperty | undefined;
        set internalValue(value: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatProperty | undefined);
        private _period?;
        get period(): number;
        set period(value: number);
        resetPeriod(): void;
        get periodInput(): number | undefined;
        private _stat?;
        get stat(): string;
        set stat(value: string);
        get statInput(): string | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
        private _metric;
        get metric(): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricPropertyOutputReference;
        putMetric(value: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricProperty): void;
        get metricInput(): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatMetricProperty | undefined;
    }
    interface MetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#expression AwsAutoscalingPolicy#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#id AwsAutoscalingPolicy#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#label AwsAutoscalingPolicy#label}
        */
        readonly label?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#return_data AwsAutoscalingPolicy#return_data}
        */
        readonly returnData?: boolean | cdktn.IResolvable;
        /**
        * metric_stat block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_stat AwsAutoscalingPolicy#metric_stat}
        */
        readonly metricStat?: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatProperty;
    }
    class MetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetricsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetricsProperty | cdktn.IResolvable | undefined);
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _label?;
        get label(): string;
        set label(value: string);
        resetLabel(): void;
        get labelInput(): string | undefined;
        private _returnData?;
        get returnData(): boolean | cdktn.IResolvable;
        set returnData(value: boolean | cdktn.IResolvable);
        resetReturnData(): void;
        get returnDataInput(): boolean | cdktn.IResolvable | undefined;
        private _metricStat;
        get metricStat(): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatPropertyOutputReference;
        putMetricStat(value: TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatProperty): void;
        resetMetricStat(): void;
        get metricStatInput(): TargetTrackingConfigurationCustomizedMetricSpecificationMetricsMetricStatProperty | undefined;
    }
    class MetricsPropertyList extends cdktn.ComplexList {
        internalValue?: MetricsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetricsPropertyOutputReference;
    }
    interface CustomizedMetricSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_name AwsAutoscalingPolicy#metric_name}
        */
        readonly metricName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#namespace AwsAutoscalingPolicy#namespace}
        */
        readonly namespace?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#period AwsAutoscalingPolicy#period}
        */
        readonly period?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#statistic AwsAutoscalingPolicy#statistic}
        */
        readonly statistic?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#unit AwsAutoscalingPolicy#unit}
        */
        readonly unit?: string;
        /**
        * metric_dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metric_dimension AwsAutoscalingPolicy#metric_dimension}
        */
        readonly metricDimension?: MetricDimensionProperty[] | cdktn.IResolvable;
        /**
        * metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#metrics AwsAutoscalingPolicy#metrics}
        */
        readonly metrics?: MetricsProperty[] | cdktn.IResolvable;
    }
    class CustomizedMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomizedMetricSpecificationProperty | undefined;
        set internalValue(value: CustomizedMetricSpecificationProperty | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        resetMetricName(): void;
        get metricNameInput(): string | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        resetNamespace(): void;
        get namespaceInput(): string | undefined;
        private _period?;
        get period(): number;
        set period(value: number);
        resetPeriod(): void;
        get periodInput(): number | undefined;
        private _statistic?;
        get statistic(): string;
        set statistic(value: string);
        resetStatistic(): void;
        get statisticInput(): string | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
        private _metricDimension;
        get metricDimension(): MetricDimensionPropertyList;
        putMetricDimension(value: MetricDimensionProperty[] | cdktn.IResolvable): void;
        resetMetricDimension(): void;
        get metricDimensionInput(): cdktn.IResolvable | MetricDimensionProperty[] | undefined;
        private _metrics;
        get metrics(): MetricsPropertyList;
        putMetrics(value: MetricsProperty[] | cdktn.IResolvable): void;
        resetMetrics(): void;
        get metricsInput(): cdktn.IResolvable | MetricsProperty[] | undefined;
    }
    interface PredefinedMetricSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predefined_metric_type AwsAutoscalingPolicy#predefined_metric_type}
        */
        readonly predefinedMetricType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#resource_label AwsAutoscalingPolicy#resource_label}
        */
        readonly resourceLabel?: string;
    }
    class PredefinedMetricSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PredefinedMetricSpecificationProperty | undefined;
        set internalValue(value: PredefinedMetricSpecificationProperty | undefined);
        private _predefinedMetricType?;
        get predefinedMetricType(): string;
        set predefinedMetricType(value: string);
        get predefinedMetricTypeInput(): string | undefined;
        private _resourceLabel?;
        get resourceLabel(): string;
        set resourceLabel(value: string);
        resetResourceLabel(): void;
        get resourceLabelInput(): string | undefined;
    }
    interface TargetTrackingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#disable_scale_in AwsAutoscalingPolicy#disable_scale_in}
        */
        readonly disableScaleIn?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#target_value AwsAutoscalingPolicy#target_value}
        */
        readonly targetValue: number;
        /**
        * customized_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#customized_metric_specification AwsAutoscalingPolicy#customized_metric_specification}
        */
        readonly customizedMetricSpecification?: CustomizedMetricSpecificationProperty;
        /**
        * predefined_metric_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_policy#predefined_metric_specification AwsAutoscalingPolicy#predefined_metric_specification}
        */
        readonly predefinedMetricSpecification?: PredefinedMetricSpecificationProperty;
    }
    class TargetTrackingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetTrackingConfigurationProperty | undefined;
        set internalValue(value: TargetTrackingConfigurationProperty | undefined);
        private _disableScaleIn?;
        get disableScaleIn(): boolean | cdktn.IResolvable;
        set disableScaleIn(value: boolean | cdktn.IResolvable);
        resetDisableScaleIn(): void;
        get disableScaleInInput(): boolean | cdktn.IResolvable | undefined;
        private _targetValue?;
        get targetValue(): number;
        set targetValue(value: number);
        get targetValueInput(): number | undefined;
        private _customizedMetricSpecification;
        get customizedMetricSpecification(): CustomizedMetricSpecificationPropertyOutputReference;
        putCustomizedMetricSpecification(value: CustomizedMetricSpecificationProperty): void;
        resetCustomizedMetricSpecification(): void;
        get customizedMetricSpecificationInput(): CustomizedMetricSpecificationProperty | undefined;
        private _predefinedMetricSpecification;
        get predefinedMetricSpecification(): PredefinedMetricSpecificationPropertyOutputReference;
        putPredefinedMetricSpecification(value: PredefinedMetricSpecificationProperty): void;
        resetPredefinedMetricSpecification(): void;
        get predefinedMetricSpecificationInput(): PredefinedMetricSpecificationProperty | undefined;
    }
}
