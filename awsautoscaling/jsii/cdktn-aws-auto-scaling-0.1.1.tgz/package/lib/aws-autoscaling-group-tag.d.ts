import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAutoscalingGroupTagConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group_tag#autoscaling_group_name AwsAutoscalingGroupTag#autoscaling_group_name}
    */
    readonly autoscalingGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group_tag#id AwsAutoscalingGroupTag#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group_tag#region AwsAutoscalingGroupTag#region}
    */
    readonly region?: string;
    /**
    * tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group_tag#tag AwsAutoscalingGroupTag#tag}
    */
    readonly tag: AwsAutoscalingGroupTag.TagProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group_tag aws_autoscaling_group_tag}
*/
export declare class AwsAutoscalingGroupTag extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_autoscaling_group_tag";
    /**
    * Generates CDKTN code for importing a AwsAutoscalingGroupTag resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAutoscalingGroupTag to import
    * @param importFromId The id of the existing AwsAutoscalingGroupTag that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group_tag#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAutoscalingGroupTag to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group_tag aws_autoscaling_group_tag} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAutoscalingGroupTagConfig
    */
    constructor(scope: Construct, id: string, config: AwsAutoscalingGroupTagConfig);
    private _autoscalingGroupName?;
    get autoscalingGroupName(): string;
    set autoscalingGroupName(value: string);
    get autoscalingGroupNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tag;
    get tag(): AwsAutoscalingGroupTag.TagPropertyOutputReference;
    putTag(value: AwsAutoscalingGroupTag.TagProperty): void;
    get tagInput(): AwsAutoscalingGroupTag.TagProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAutoscalingGroupTagTagPropertyToTerraform(struct?: AwsAutoscalingGroupTag.TagPropertyOutputReference | AwsAutoscalingGroupTag.TagProperty): any;
export declare function awsAutoscalingGroupTagTagPropertyToHclTerraform(struct?: AwsAutoscalingGroupTag.TagPropertyOutputReference | AwsAutoscalingGroupTag.TagProperty): any;
export declare namespace AwsAutoscalingGroupTag {
    interface TagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group_tag#key AwsAutoscalingGroupTag#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group_tag#propagate_at_launch AwsAutoscalingGroupTag#propagate_at_launch}
        */
        readonly propagateAtLaunch: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group_tag#value AwsAutoscalingGroupTag#value}
        */
        readonly value: string;
    }
    class TagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TagProperty | undefined;
        set internalValue(value: TagProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _propagateAtLaunch?;
        get propagateAtLaunch(): boolean | cdktn.IResolvable;
        set propagateAtLaunch(value: boolean | cdktn.IResolvable);
        get propagateAtLaunchInput(): boolean | cdktn.IResolvable | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
}
