import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsLaunchConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_configuration#id DataAwsLaunchConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_configuration#name DataAwsLaunchConfiguration#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_configuration#region DataAwsLaunchConfiguration#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_configuration aws_launch_configuration}
*/
export declare class DataAwsLaunchConfiguration extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_launch_configuration";
    /**
    * Generates CDKTN code for importing a DataAwsLaunchConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsLaunchConfiguration to import
    * @param importFromId The id of the existing DataAwsLaunchConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsLaunchConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/launch_configuration aws_launch_configuration} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsLaunchConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsLaunchConfigurationConfig);
    get arn(): string;
    get associatePublicIpAddress(): cdktn.IResolvable;
    private _ebsBlockDevice;
    get ebsBlockDevice(): DataAwsLaunchConfiguration.EbsBlockDevicePropertyList;
    get ebsOptimized(): cdktn.IResolvable;
    get enableMonitoring(): cdktn.IResolvable;
    private _ephemeralBlockDevice;
    get ephemeralBlockDevice(): DataAwsLaunchConfiguration.EphemeralBlockDevicePropertyList;
    get iamInstanceProfile(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get imageId(): string;
    get instanceType(): string;
    get keyName(): string;
    private _metadataOptions;
    get metadataOptions(): DataAwsLaunchConfiguration.MetadataOptionsPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get placementTenancy(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rootBlockDevice;
    get rootBlockDevice(): DataAwsLaunchConfiguration.RootBlockDevicePropertyList;
    get securityGroups(): string[];
    get spotPrice(): string;
    get userData(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsLaunchConfigurationEbsBlockDevicePropertyToTerraform(struct?: DataAwsLaunchConfiguration.EbsBlockDeviceProperty): any;
export declare function dataAwsLaunchConfigurationEbsBlockDevicePropertyToHclTerraform(struct?: DataAwsLaunchConfiguration.EbsBlockDeviceProperty): any;
export declare function dataAwsLaunchConfigurationEphemeralBlockDevicePropertyToTerraform(struct?: DataAwsLaunchConfiguration.EphemeralBlockDeviceProperty): any;
export declare function dataAwsLaunchConfigurationEphemeralBlockDevicePropertyToHclTerraform(struct?: DataAwsLaunchConfiguration.EphemeralBlockDeviceProperty): any;
export declare function dataAwsLaunchConfigurationMetadataOptionsPropertyToTerraform(struct?: DataAwsLaunchConfiguration.MetadataOptionsProperty): any;
export declare function dataAwsLaunchConfigurationMetadataOptionsPropertyToHclTerraform(struct?: DataAwsLaunchConfiguration.MetadataOptionsProperty): any;
export declare function dataAwsLaunchConfigurationRootBlockDevicePropertyToTerraform(struct?: DataAwsLaunchConfiguration.RootBlockDeviceProperty): any;
export declare function dataAwsLaunchConfigurationRootBlockDevicePropertyToHclTerraform(struct?: DataAwsLaunchConfiguration.RootBlockDeviceProperty): any;
export declare namespace DataAwsLaunchConfiguration {
    interface EbsBlockDeviceProperty {
    }
    class EbsBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsBlockDeviceProperty | undefined;
        set internalValue(value: EbsBlockDeviceProperty | undefined);
        get deleteOnTermination(): cdktn.IResolvable;
        get deviceName(): string;
        get encrypted(): cdktn.IResolvable;
        get iops(): number;
        get noDevice(): cdktn.IResolvable;
        get snapshotId(): string;
        get throughput(): number;
        get volumeSize(): number;
        get volumeType(): string;
    }
    class EbsBlockDevicePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsBlockDevicePropertyOutputReference;
    }
    interface EphemeralBlockDeviceProperty {
    }
    class EphemeralBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EphemeralBlockDeviceProperty | undefined;
        set internalValue(value: EphemeralBlockDeviceProperty | undefined);
        get deviceName(): string;
        get virtualName(): string;
    }
    class EphemeralBlockDevicePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EphemeralBlockDevicePropertyOutputReference;
    }
    interface MetadataOptionsProperty {
    }
    class MetadataOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataOptionsProperty | undefined;
        set internalValue(value: MetadataOptionsProperty | undefined);
        get httpEndpoint(): string;
        get httpPutResponseHopLimit(): number;
        get httpTokens(): string;
    }
    class MetadataOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataOptionsPropertyOutputReference;
    }
    interface RootBlockDeviceProperty {
    }
    class RootBlockDevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RootBlockDeviceProperty | undefined;
        set internalValue(value: RootBlockDeviceProperty | undefined);
        get deleteOnTermination(): cdktn.IResolvable;
        get encrypted(): cdktn.IResolvable;
        get iops(): number;
        get throughput(): number;
        get volumeSize(): number;
        get volumeType(): string;
    }
    class RootBlockDevicePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RootBlockDevicePropertyOutputReference;
    }
}
