import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsAutoscalingGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/autoscaling_group#id DataAwsAutoscalingGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/autoscaling_group#name DataAwsAutoscalingGroup#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/autoscaling_group#region DataAwsAutoscalingGroup#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/autoscaling_group aws_autoscaling_group}
*/
export declare class DataAwsAutoscalingGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_autoscaling_group";
    /**
    * Generates CDKTN code for importing a DataAwsAutoscalingGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsAutoscalingGroup to import
    * @param importFromId The id of the existing DataAwsAutoscalingGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/autoscaling_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsAutoscalingGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/autoscaling_group aws_autoscaling_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsAutoscalingGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsAutoscalingGroupConfig);
    get arn(): string;
    get availabilityZones(): string[];
    get defaultCooldown(): number;
    get desiredCapacity(): number;
    get desiredCapacityType(): string;
    get enabledMetrics(): string[];
    get healthCheckGracePeriod(): number;
    get healthCheckType(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceMaintenancePolicy;
    get instanceMaintenancePolicy(): DataAwsAutoscalingGroup.InstanceMaintenancePolicyPropertyList;
    get launchConfiguration(): string;
    private _launchTemplate;
    get launchTemplate(): DataAwsAutoscalingGroup.LaunchTemplatePropertyList;
    get loadBalancers(): string[];
    get maxInstanceLifetime(): number;
    get maxSize(): number;
    get minSize(): number;
    private _mixedInstancesPolicy;
    get mixedInstancesPolicy(): DataAwsAutoscalingGroup.MixedInstancesPolicyPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get newInstancesProtectedFromScaleIn(): cdktn.IResolvable;
    get placementGroup(): string;
    get predictedCapacity(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get serviceLinkedRoleArn(): string;
    get status(): string;
    get suspendedProcesses(): string[];
    private _tag;
    get tag(): DataAwsAutoscalingGroup.TagPropertyList;
    get targetGroupArns(): string[];
    get terminationPolicies(): string[];
    private _trafficSource;
    get trafficSource(): DataAwsAutoscalingGroup.TrafficSourcePropertyList;
    get vpcZoneIdentifier(): string;
    private _warmPool;
    get warmPool(): DataAwsAutoscalingGroup.WarmPoolPropertyList;
    get warmPoolSize(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsAutoscalingGroupInstanceMaintenancePolicyPropertyToTerraform(struct?: DataAwsAutoscalingGroup.InstanceMaintenancePolicyProperty): any;
export declare function dataAwsAutoscalingGroupInstanceMaintenancePolicyPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.InstanceMaintenancePolicyProperty): any;
export declare function dataAwsAutoscalingGroupLaunchTemplatePropertyToTerraform(struct?: DataAwsAutoscalingGroup.LaunchTemplateProperty): any;
export declare function dataAwsAutoscalingGroupLaunchTemplatePropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.LaunchTemplateProperty): any;
export declare function dataAwsAutoscalingGroupInstancesDistributionPropertyToTerraform(struct?: DataAwsAutoscalingGroup.InstancesDistributionProperty): any;
export declare function dataAwsAutoscalingGroupInstancesDistributionPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.InstancesDistributionProperty): any;
export declare function dataAwsAutoscalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyToTerraform(struct?: DataAwsAutoscalingGroup.MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty): any;
export declare function dataAwsAutoscalingGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty): any;
export declare function dataAwsAutoscalingGroupAcceleratorCountPropertyToTerraform(struct?: DataAwsAutoscalingGroup.AcceleratorCountProperty): any;
export declare function dataAwsAutoscalingGroupAcceleratorCountPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.AcceleratorCountProperty): any;
export declare function dataAwsAutoscalingGroupAcceleratorTotalMemoryMibPropertyToTerraform(struct?: DataAwsAutoscalingGroup.AcceleratorTotalMemoryMibProperty): any;
export declare function dataAwsAutoscalingGroupAcceleratorTotalMemoryMibPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.AcceleratorTotalMemoryMibProperty): any;
export declare function dataAwsAutoscalingGroupBaselineEbsBandwidthMbpsPropertyToTerraform(struct?: DataAwsAutoscalingGroup.BaselineEbsBandwidthMbpsProperty): any;
export declare function dataAwsAutoscalingGroupBaselineEbsBandwidthMbpsPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.BaselineEbsBandwidthMbpsProperty): any;
export declare function dataAwsAutoscalingGroupMemoryGibPerVcpuPropertyToTerraform(struct?: DataAwsAutoscalingGroup.MemoryGibPerVcpuProperty): any;
export declare function dataAwsAutoscalingGroupMemoryGibPerVcpuPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.MemoryGibPerVcpuProperty): any;
export declare function dataAwsAutoscalingGroupMemoryMibPropertyToTerraform(struct?: DataAwsAutoscalingGroup.MemoryMibProperty): any;
export declare function dataAwsAutoscalingGroupMemoryMibPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.MemoryMibProperty): any;
export declare function dataAwsAutoscalingGroupNetworkBandwidthGbpsPropertyToTerraform(struct?: DataAwsAutoscalingGroup.NetworkBandwidthGbpsProperty): any;
export declare function dataAwsAutoscalingGroupNetworkBandwidthGbpsPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.NetworkBandwidthGbpsProperty): any;
export declare function dataAwsAutoscalingGroupNetworkInterfaceCountPropertyToTerraform(struct?: DataAwsAutoscalingGroup.NetworkInterfaceCountProperty): any;
export declare function dataAwsAutoscalingGroupNetworkInterfaceCountPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.NetworkInterfaceCountProperty): any;
export declare function dataAwsAutoscalingGroupTotalLocalStorageGbPropertyToTerraform(struct?: DataAwsAutoscalingGroup.TotalLocalStorageGbProperty): any;
export declare function dataAwsAutoscalingGroupTotalLocalStorageGbPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.TotalLocalStorageGbProperty): any;
export declare function dataAwsAutoscalingGroupVcpuCountPropertyToTerraform(struct?: DataAwsAutoscalingGroup.VcpuCountProperty): any;
export declare function dataAwsAutoscalingGroupVcpuCountPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.VcpuCountProperty): any;
export declare function dataAwsAutoscalingGroupInstanceRequirementsPropertyToTerraform(struct?: DataAwsAutoscalingGroup.InstanceRequirementsProperty): any;
export declare function dataAwsAutoscalingGroupInstanceRequirementsPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.InstanceRequirementsProperty): any;
export declare function dataAwsAutoscalingGroupMixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyToTerraform(struct?: DataAwsAutoscalingGroup.MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty): any;
export declare function dataAwsAutoscalingGroupMixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty): any;
export declare function dataAwsAutoscalingGroupOverridePropertyToTerraform(struct?: DataAwsAutoscalingGroup.OverrideProperty): any;
export declare function dataAwsAutoscalingGroupOverridePropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.OverrideProperty): any;
export declare function dataAwsAutoscalingGroupMixedInstancesPolicyLaunchTemplatePropertyToTerraform(struct?: DataAwsAutoscalingGroup.MixedInstancesPolicyLaunchTemplateProperty): any;
export declare function dataAwsAutoscalingGroupMixedInstancesPolicyLaunchTemplatePropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.MixedInstancesPolicyLaunchTemplateProperty): any;
export declare function dataAwsAutoscalingGroupMixedInstancesPolicyPropertyToTerraform(struct?: DataAwsAutoscalingGroup.MixedInstancesPolicyProperty): any;
export declare function dataAwsAutoscalingGroupMixedInstancesPolicyPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.MixedInstancesPolicyProperty): any;
export declare function dataAwsAutoscalingGroupTagPropertyToTerraform(struct?: DataAwsAutoscalingGroup.TagProperty): any;
export declare function dataAwsAutoscalingGroupTagPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.TagProperty): any;
export declare function dataAwsAutoscalingGroupTrafficSourcePropertyToTerraform(struct?: DataAwsAutoscalingGroup.TrafficSourceProperty): any;
export declare function dataAwsAutoscalingGroupTrafficSourcePropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.TrafficSourceProperty): any;
export declare function dataAwsAutoscalingGroupInstanceReusePolicyPropertyToTerraform(struct?: DataAwsAutoscalingGroup.InstanceReusePolicyProperty): any;
export declare function dataAwsAutoscalingGroupInstanceReusePolicyPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.InstanceReusePolicyProperty): any;
export declare function dataAwsAutoscalingGroupWarmPoolPropertyToTerraform(struct?: DataAwsAutoscalingGroup.WarmPoolProperty): any;
export declare function dataAwsAutoscalingGroupWarmPoolPropertyToHclTerraform(struct?: DataAwsAutoscalingGroup.WarmPoolProperty): any;
export declare namespace DataAwsAutoscalingGroup {
    interface InstanceMaintenancePolicyProperty {
    }
    class InstanceMaintenancePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstanceMaintenancePolicyProperty | undefined;
        set internalValue(value: InstanceMaintenancePolicyProperty | undefined);
        get maxHealthyPercentage(): number;
        get minHealthyPercentage(): number;
    }
    class InstanceMaintenancePolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstanceMaintenancePolicyPropertyOutputReference;
    }
    interface LaunchTemplateProperty {
    }
    class LaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LaunchTemplateProperty | undefined;
        set internalValue(value: LaunchTemplateProperty | undefined);
        get id(): string;
        get name(): string;
        get version(): string;
    }
    class LaunchTemplatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LaunchTemplatePropertyOutputReference;
    }
    interface InstancesDistributionProperty {
    }
    class InstancesDistributionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstancesDistributionProperty | undefined;
        set internalValue(value: InstancesDistributionProperty | undefined);
        get onDemandAllocationStrategy(): string;
        get onDemandBaseCapacity(): number;
        get onDemandPercentageAboveBaseCapacity(): number;
        get spotAllocationStrategy(): string;
        get spotInstancePools(): number;
        get spotMaxPrice(): string;
    }
    class InstancesDistributionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstancesDistributionPropertyOutputReference;
    }
    interface MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty {
    }
    class MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty | undefined;
        set internalValue(value: MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty | undefined);
        get launchTemplateId(): string;
        get launchTemplateName(): string;
        get version(): string;
    }
    class MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyOutputReference;
    }
    interface AcceleratorCountProperty {
    }
    class AcceleratorCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AcceleratorCountProperty | undefined;
        set internalValue(value: AcceleratorCountProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class AcceleratorCountPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AcceleratorCountPropertyOutputReference;
    }
    interface AcceleratorTotalMemoryMibProperty {
    }
    class AcceleratorTotalMemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AcceleratorTotalMemoryMibProperty | undefined;
        set internalValue(value: AcceleratorTotalMemoryMibProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class AcceleratorTotalMemoryMibPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AcceleratorTotalMemoryMibPropertyOutputReference;
    }
    interface BaselineEbsBandwidthMbpsProperty {
    }
    class BaselineEbsBandwidthMbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BaselineEbsBandwidthMbpsProperty | undefined;
        set internalValue(value: BaselineEbsBandwidthMbpsProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class BaselineEbsBandwidthMbpsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BaselineEbsBandwidthMbpsPropertyOutputReference;
    }
    interface MemoryGibPerVcpuProperty {
    }
    class MemoryGibPerVcpuPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemoryGibPerVcpuProperty | undefined;
        set internalValue(value: MemoryGibPerVcpuProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class MemoryGibPerVcpuPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemoryGibPerVcpuPropertyOutputReference;
    }
    interface MemoryMibProperty {
    }
    class MemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemoryMibProperty | undefined;
        set internalValue(value: MemoryMibProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class MemoryMibPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemoryMibPropertyOutputReference;
    }
    interface NetworkBandwidthGbpsProperty {
    }
    class NetworkBandwidthGbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkBandwidthGbpsProperty | undefined;
        set internalValue(value: NetworkBandwidthGbpsProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class NetworkBandwidthGbpsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkBandwidthGbpsPropertyOutputReference;
    }
    interface NetworkInterfaceCountProperty {
    }
    class NetworkInterfaceCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkInterfaceCountProperty | undefined;
        set internalValue(value: NetworkInterfaceCountProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class NetworkInterfaceCountPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkInterfaceCountPropertyOutputReference;
    }
    interface TotalLocalStorageGbProperty {
    }
    class TotalLocalStorageGbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TotalLocalStorageGbProperty | undefined;
        set internalValue(value: TotalLocalStorageGbProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class TotalLocalStorageGbPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TotalLocalStorageGbPropertyOutputReference;
    }
    interface VcpuCountProperty {
    }
    class VcpuCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VcpuCountProperty | undefined;
        set internalValue(value: VcpuCountProperty | undefined);
        get max(): number;
        get min(): number;
    }
    class VcpuCountPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VcpuCountPropertyOutputReference;
    }
    interface InstanceRequirementsProperty {
    }
    class InstanceRequirementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstanceRequirementsProperty | undefined;
        set internalValue(value: InstanceRequirementsProperty | undefined);
        private _acceleratorCount;
        get acceleratorCount(): AcceleratorCountPropertyList;
        get acceleratorManufacturers(): string[];
        get acceleratorNames(): string[];
        private _acceleratorTotalMemoryMib;
        get acceleratorTotalMemoryMib(): AcceleratorTotalMemoryMibPropertyList;
        get acceleratorTypes(): string[];
        get allowedInstanceTypes(): string[];
        get bareMetal(): string;
        private _baselineEbsBandwidthMbps;
        get baselineEbsBandwidthMbps(): BaselineEbsBandwidthMbpsPropertyList;
        get burstablePerformance(): string;
        get cpuManufacturers(): string[];
        get excludedInstanceTypes(): string[];
        get instanceGenerations(): string[];
        get localStorage(): string;
        get localStorageTypes(): string[];
        get maxSpotPriceAsPercentageOfOptimalOnDemandPrice(): number;
        private _memoryGibPerVcpu;
        get memoryGibPerVcpu(): MemoryGibPerVcpuPropertyList;
        private _memoryMib;
        get memoryMib(): MemoryMibPropertyList;
        private _networkBandwidthGbps;
        get networkBandwidthGbps(): NetworkBandwidthGbpsPropertyList;
        private _networkInterfaceCount;
        get networkInterfaceCount(): NetworkInterfaceCountPropertyList;
        get onDemandMaxPricePercentageOverLowestPrice(): number;
        get requireHibernateSupport(): cdktn.IResolvable;
        get spotMaxPricePercentageOverLowestPrice(): number;
        private _totalLocalStorageGb;
        get totalLocalStorageGb(): TotalLocalStorageGbPropertyList;
        private _vcpuCount;
        get vcpuCount(): VcpuCountPropertyList;
    }
    class InstanceRequirementsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstanceRequirementsPropertyOutputReference;
    }
    interface MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty {
    }
    class MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty | undefined;
        set internalValue(value: MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty | undefined);
        get launchTemplateId(): string;
        get launchTemplateName(): string;
        get version(): string;
    }
    class MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyOutputReference;
    }
    interface OverrideProperty {
    }
    class OverridePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OverrideProperty | undefined;
        set internalValue(value: OverrideProperty | undefined);
        private _instanceRequirements;
        get instanceRequirements(): InstanceRequirementsPropertyList;
        get instanceType(): string;
        private _launchTemplateSpecification;
        get launchTemplateSpecification(): MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyList;
        get weightedCapacity(): string;
    }
    class OverridePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OverridePropertyOutputReference;
    }
    interface MixedInstancesPolicyLaunchTemplateProperty {
    }
    class MixedInstancesPolicyLaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MixedInstancesPolicyLaunchTemplateProperty | undefined;
        set internalValue(value: MixedInstancesPolicyLaunchTemplateProperty | undefined);
        private _launchTemplateSpecification;
        get launchTemplateSpecification(): MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyList;
        private _override;
        get override(): OverridePropertyList;
    }
    class MixedInstancesPolicyLaunchTemplatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MixedInstancesPolicyLaunchTemplatePropertyOutputReference;
    }
    interface MixedInstancesPolicyProperty {
    }
    class MixedInstancesPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MixedInstancesPolicyProperty | undefined;
        set internalValue(value: MixedInstancesPolicyProperty | undefined);
        private _instancesDistribution;
        get instancesDistribution(): InstancesDistributionPropertyList;
        private _launchTemplate;
        get launchTemplate(): MixedInstancesPolicyLaunchTemplatePropertyList;
    }
    class MixedInstancesPolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MixedInstancesPolicyPropertyOutputReference;
    }
    interface TagProperty {
    }
    class TagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagProperty | undefined;
        set internalValue(value: TagProperty | undefined);
        get key(): string;
        get propagateAtLaunch(): cdktn.IResolvable;
        get value(): string;
    }
    class TagPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagPropertyOutputReference;
    }
    interface TrafficSourceProperty {
    }
    class TrafficSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrafficSourceProperty | undefined;
        set internalValue(value: TrafficSourceProperty | undefined);
        get identifier(): string;
        get type(): string;
    }
    class TrafficSourcePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrafficSourcePropertyOutputReference;
    }
    interface InstanceReusePolicyProperty {
    }
    class InstanceReusePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstanceReusePolicyProperty | undefined;
        set internalValue(value: InstanceReusePolicyProperty | undefined);
        get reuseOnScaleIn(): cdktn.IResolvable;
    }
    class InstanceReusePolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstanceReusePolicyPropertyOutputReference;
    }
    interface WarmPoolProperty {
    }
    class WarmPoolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WarmPoolProperty | undefined;
        set internalValue(value: WarmPoolProperty | undefined);
        private _instanceReusePolicy;
        get instanceReusePolicy(): InstanceReusePolicyPropertyList;
        get maxGroupPreparedCapacity(): number;
        get minSize(): number;
        get poolState(): string;
    }
    class WarmPoolPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WarmPoolPropertyOutputReference;
    }
}
