import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#availability_zones TfGroup#availability_zones}
    */
    readonly availabilityZones?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#capacity_rebalance TfGroup#capacity_rebalance}
    */
    readonly capacityRebalance?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#context TfGroup#context}
    */
    readonly context?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#default_cooldown TfGroup#default_cooldown}
    */
    readonly defaultCooldown?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#default_instance_warmup TfGroup#default_instance_warmup}
    */
    readonly defaultInstanceWarmup?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#desired_capacity TfGroup#desired_capacity}
    */
    readonly desiredCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#desired_capacity_type TfGroup#desired_capacity_type}
    */
    readonly desiredCapacityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#enabled_metrics TfGroup#enabled_metrics}
    */
    readonly enabledMetrics?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#force_delete TfGroup#force_delete}
    */
    readonly forceDelete?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#force_delete_warm_pool TfGroup#force_delete_warm_pool}
    */
    readonly forceDeleteWarmPool?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#health_check_grace_period TfGroup#health_check_grace_period}
    */
    readonly healthCheckGracePeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#health_check_type TfGroup#health_check_type}
    */
    readonly healthCheckType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#id TfGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#ignore_failed_scaling_activities TfGroup#ignore_failed_scaling_activities}
    */
    readonly ignoreFailedScalingActivities?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_configuration TfGroup#launch_configuration}
    */
    readonly launchConfiguration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#load_balancers TfGroup#load_balancers}
    */
    readonly loadBalancers?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max_instance_lifetime TfGroup#max_instance_lifetime}
    */
    readonly maxInstanceLifetime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max_size TfGroup#max_size}
    */
    readonly maxSize: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#metrics_granularity TfGroup#metrics_granularity}
    */
    readonly metricsGranularity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min_elb_capacity TfGroup#min_elb_capacity}
    */
    readonly minElbCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min_size TfGroup#min_size}
    */
    readonly minSize: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#name TfGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#name_prefix TfGroup#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#placement_group TfGroup#placement_group}
    */
    readonly placementGroup?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#protect_from_scale_in TfGroup#protect_from_scale_in}
    */
    readonly protectFromScaleIn?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#region TfGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#service_linked_role_arn TfGroup#service_linked_role_arn}
    */
    readonly serviceLinkedRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#suspended_processes TfGroup#suspended_processes}
    */
    readonly suspendedProcesses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#target_group_arns TfGroup#target_group_arns}
    */
    readonly targetGroupArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#termination_policies TfGroup#termination_policies}
    */
    readonly terminationPolicies?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#vpc_zone_identifier TfGroup#vpc_zone_identifier}
    */
    readonly vpcZoneIdentifier?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#wait_for_capacity_timeout TfGroup#wait_for_capacity_timeout}
    */
    readonly waitForCapacityTimeout?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#wait_for_elb_capacity TfGroup#wait_for_elb_capacity}
    */
    readonly waitForElbCapacity?: number;
    /**
    * availability_zone_distribution block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#availability_zone_distribution TfGroup#availability_zone_distribution}
    */
    readonly availabilityZoneDistribution?: TfGroup.AvailabilityZoneDistributionProperty;
    /**
    * capacity_reservation_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#capacity_reservation_specification TfGroup#capacity_reservation_specification}
    */
    readonly capacityReservationSpecification?: TfGroup.CapacityReservationSpecificationProperty;
    /**
    * initial_lifecycle_hook block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#initial_lifecycle_hook TfGroup#initial_lifecycle_hook}
    */
    readonly initialLifecycleHook?: TfGroup.InitialLifecycleHookProperty[] | cdktn.IResolvable;
    /**
    * instance_lifecycle_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instance_lifecycle_policy TfGroup#instance_lifecycle_policy}
    */
    readonly instanceLifecyclePolicy?: TfGroup.InstanceLifecyclePolicyProperty;
    /**
    * instance_maintenance_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instance_maintenance_policy TfGroup#instance_maintenance_policy}
    */
    readonly instanceMaintenancePolicy?: TfGroup.InstanceMaintenancePolicyProperty;
    /**
    * instance_refresh block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instance_refresh TfGroup#instance_refresh}
    */
    readonly instanceRefresh?: TfGroup.InstanceRefreshProperty;
    /**
    * launch_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_template TfGroup#launch_template}
    */
    readonly launchTemplate?: TfGroup.LaunchTemplateProperty;
    /**
    * mixed_instances_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#mixed_instances_policy TfGroup#mixed_instances_policy}
    */
    readonly mixedInstancesPolicy?: TfGroup.MixedInstancesPolicyProperty;
    /**
    * tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#tag TfGroup#tag}
    */
    readonly tag?: TfGroup.TagProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#timeouts TfGroup#timeouts}
    */
    readonly timeouts?: TfGroup.TimeoutsProperty;
    /**
    * traffic_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#traffic_source TfGroup#traffic_source}
    */
    readonly trafficSource?: TfGroup.TrafficSourceProperty[] | cdktn.IResolvable;
    /**
    * warm_pool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#warm_pool TfGroup#warm_pool}
    */
    readonly warmPool?: TfGroup.WarmPoolProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group aws_autoscaling_group}
*/
export declare class TfGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_autoscaling_group";
    /**
    * Generates CDKTN code for importing a TfGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfGroup to import
    * @param importFromId The id of the existing TfGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group aws_autoscaling_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfGroupConfig
    */
    constructor(scope: Construct, id: string, config: TfGroupConfig);
    get arn(): string;
    private _availabilityZones?;
    get availabilityZones(): string[];
    set availabilityZones(value: string[]);
    resetAvailabilityZones(): void;
    get availabilityZonesInput(): string[] | undefined;
    private _capacityRebalance?;
    get capacityRebalance(): boolean | cdktn.IResolvable;
    set capacityRebalance(value: boolean | cdktn.IResolvable);
    resetCapacityRebalance(): void;
    get capacityRebalanceInput(): boolean | cdktn.IResolvable | undefined;
    private _context?;
    get context(): string;
    set context(value: string);
    resetContext(): void;
    get contextInput(): string | undefined;
    private _defaultCooldown?;
    get defaultCooldown(): number;
    set defaultCooldown(value: number);
    resetDefaultCooldown(): void;
    get defaultCooldownInput(): number | undefined;
    private _defaultInstanceWarmup?;
    get defaultInstanceWarmup(): number;
    set defaultInstanceWarmup(value: number);
    resetDefaultInstanceWarmup(): void;
    get defaultInstanceWarmupInput(): number | undefined;
    private _desiredCapacity?;
    get desiredCapacity(): number;
    set desiredCapacity(value: number);
    resetDesiredCapacity(): void;
    get desiredCapacityInput(): number | undefined;
    private _desiredCapacityType?;
    get desiredCapacityType(): string;
    set desiredCapacityType(value: string);
    resetDesiredCapacityType(): void;
    get desiredCapacityTypeInput(): string | undefined;
    private _enabledMetrics?;
    get enabledMetrics(): string[];
    set enabledMetrics(value: string[]);
    resetEnabledMetrics(): void;
    get enabledMetricsInput(): string[] | undefined;
    private _forceDelete?;
    get forceDelete(): boolean | cdktn.IResolvable;
    set forceDelete(value: boolean | cdktn.IResolvable);
    resetForceDelete(): void;
    get forceDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _forceDeleteWarmPool?;
    get forceDeleteWarmPool(): boolean | cdktn.IResolvable;
    set forceDeleteWarmPool(value: boolean | cdktn.IResolvable);
    resetForceDeleteWarmPool(): void;
    get forceDeleteWarmPoolInput(): boolean | cdktn.IResolvable | undefined;
    private _healthCheckGracePeriod?;
    get healthCheckGracePeriod(): number;
    set healthCheckGracePeriod(value: number);
    resetHealthCheckGracePeriod(): void;
    get healthCheckGracePeriodInput(): number | undefined;
    private _healthCheckType?;
    get healthCheckType(): string;
    set healthCheckType(value: string);
    resetHealthCheckType(): void;
    get healthCheckTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreFailedScalingActivities?;
    get ignoreFailedScalingActivities(): boolean | cdktn.IResolvable;
    set ignoreFailedScalingActivities(value: boolean | cdktn.IResolvable);
    resetIgnoreFailedScalingActivities(): void;
    get ignoreFailedScalingActivitiesInput(): boolean | cdktn.IResolvable | undefined;
    private _launchConfiguration?;
    get launchConfiguration(): string;
    set launchConfiguration(value: string);
    resetLaunchConfiguration(): void;
    get launchConfigurationInput(): string | undefined;
    private _loadBalancers?;
    get loadBalancers(): string[];
    set loadBalancers(value: string[]);
    resetLoadBalancers(): void;
    get loadBalancersInput(): string[] | undefined;
    private _maxInstanceLifetime?;
    get maxInstanceLifetime(): number;
    set maxInstanceLifetime(value: number);
    resetMaxInstanceLifetime(): void;
    get maxInstanceLifetimeInput(): number | undefined;
    private _maxSize?;
    get maxSize(): number;
    set maxSize(value: number);
    get maxSizeInput(): number | undefined;
    private _metricsGranularity?;
    get metricsGranularity(): string;
    set metricsGranularity(value: string);
    resetMetricsGranularity(): void;
    get metricsGranularityInput(): string | undefined;
    private _minElbCapacity?;
    get minElbCapacity(): number;
    set minElbCapacity(value: number);
    resetMinElbCapacity(): void;
    get minElbCapacityInput(): number | undefined;
    private _minSize?;
    get minSize(): number;
    set minSize(value: number);
    get minSizeInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _placementGroup?;
    get placementGroup(): string;
    set placementGroup(value: string);
    resetPlacementGroup(): void;
    get placementGroupInput(): string | undefined;
    get predictedCapacity(): number;
    private _protectFromScaleIn?;
    get protectFromScaleIn(): boolean | cdktn.IResolvable;
    set protectFromScaleIn(value: boolean | cdktn.IResolvable);
    resetProtectFromScaleIn(): void;
    get protectFromScaleInInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceLinkedRoleArn?;
    get serviceLinkedRoleArn(): string;
    set serviceLinkedRoleArn(value: string);
    resetServiceLinkedRoleArn(): void;
    get serviceLinkedRoleArnInput(): string | undefined;
    private _suspendedProcesses?;
    get suspendedProcesses(): string[];
    set suspendedProcesses(value: string[]);
    resetSuspendedProcesses(): void;
    get suspendedProcessesInput(): string[] | undefined;
    private _targetGroupArns?;
    get targetGroupArns(): string[];
    set targetGroupArns(value: string[]);
    resetTargetGroupArns(): void;
    get targetGroupArnsInput(): string[] | undefined;
    private _terminationPolicies?;
    get terminationPolicies(): string[];
    set terminationPolicies(value: string[]);
    resetTerminationPolicies(): void;
    get terminationPoliciesInput(): string[] | undefined;
    private _vpcZoneIdentifier?;
    get vpcZoneIdentifier(): string[];
    set vpcZoneIdentifier(value: string[]);
    resetVpcZoneIdentifier(): void;
    get vpcZoneIdentifierInput(): string[] | undefined;
    private _waitForCapacityTimeout?;
    get waitForCapacityTimeout(): string;
    set waitForCapacityTimeout(value: string);
    resetWaitForCapacityTimeout(): void;
    get waitForCapacityTimeoutInput(): string | undefined;
    private _waitForElbCapacity?;
    get waitForElbCapacity(): number;
    set waitForElbCapacity(value: number);
    resetWaitForElbCapacity(): void;
    get waitForElbCapacityInput(): number | undefined;
    get warmPoolSize(): number;
    private _availabilityZoneDistribution;
    get availabilityZoneDistribution(): TfGroup.AvailabilityZoneDistributionPropertyOutputReference;
    putAvailabilityZoneDistribution(value: TfGroup.AvailabilityZoneDistributionProperty): void;
    resetAvailabilityZoneDistribution(): void;
    get availabilityZoneDistributionInput(): TfGroup.AvailabilityZoneDistributionProperty | undefined;
    private _capacityReservationSpecification;
    get capacityReservationSpecification(): TfGroup.CapacityReservationSpecificationPropertyOutputReference;
    putCapacityReservationSpecification(value: TfGroup.CapacityReservationSpecificationProperty): void;
    resetCapacityReservationSpecification(): void;
    get capacityReservationSpecificationInput(): TfGroup.CapacityReservationSpecificationProperty | undefined;
    private _initialLifecycleHook;
    get initialLifecycleHook(): TfGroup.InitialLifecycleHookPropertyList;
    putInitialLifecycleHook(value: TfGroup.InitialLifecycleHookProperty[] | cdktn.IResolvable): void;
    resetInitialLifecycleHook(): void;
    get initialLifecycleHookInput(): cdktn.IResolvable | TfGroup.InitialLifecycleHookProperty[] | undefined;
    private _instanceLifecyclePolicy;
    get instanceLifecyclePolicy(): TfGroup.InstanceLifecyclePolicyPropertyOutputReference;
    putInstanceLifecyclePolicy(value: TfGroup.InstanceLifecyclePolicyProperty): void;
    resetInstanceLifecyclePolicy(): void;
    get instanceLifecyclePolicyInput(): TfGroup.InstanceLifecyclePolicyProperty | undefined;
    private _instanceMaintenancePolicy;
    get instanceMaintenancePolicy(): TfGroup.InstanceMaintenancePolicyPropertyOutputReference;
    putInstanceMaintenancePolicy(value: TfGroup.InstanceMaintenancePolicyProperty): void;
    resetInstanceMaintenancePolicy(): void;
    get instanceMaintenancePolicyInput(): TfGroup.InstanceMaintenancePolicyProperty | undefined;
    private _instanceRefresh;
    get instanceRefresh(): TfGroup.InstanceRefreshPropertyOutputReference;
    putInstanceRefresh(value: TfGroup.InstanceRefreshProperty): void;
    resetInstanceRefresh(): void;
    get instanceRefreshInput(): TfGroup.InstanceRefreshProperty | undefined;
    private _launchTemplate;
    get launchTemplate(): TfGroup.LaunchTemplatePropertyOutputReference;
    putLaunchTemplate(value: TfGroup.LaunchTemplateProperty): void;
    resetLaunchTemplate(): void;
    get launchTemplateInput(): TfGroup.LaunchTemplateProperty | undefined;
    private _mixedInstancesPolicy;
    get mixedInstancesPolicy(): TfGroup.MixedInstancesPolicyPropertyOutputReference;
    putMixedInstancesPolicy(value: TfGroup.MixedInstancesPolicyProperty): void;
    resetMixedInstancesPolicy(): void;
    get mixedInstancesPolicyInput(): TfGroup.MixedInstancesPolicyProperty | undefined;
    private _tag;
    get tag(): TfGroup.TagPropertyList;
    putTag(value: TfGroup.TagProperty[] | cdktn.IResolvable): void;
    resetTag(): void;
    get tagInput(): cdktn.IResolvable | TfGroup.TagProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfGroup.TimeoutsProperty | undefined;
    private _trafficSource;
    get trafficSource(): TfGroup.TrafficSourcePropertyList;
    putTrafficSource(value: TfGroup.TrafficSourceProperty[] | cdktn.IResolvable): void;
    resetTrafficSource(): void;
    get trafficSourceInput(): cdktn.IResolvable | TfGroup.TrafficSourceProperty[] | undefined;
    private _warmPool;
    get warmPool(): TfGroup.WarmPoolPropertyOutputReference;
    putWarmPool(value: TfGroup.WarmPoolProperty): void;
    resetWarmPool(): void;
    get warmPoolInput(): TfGroup.WarmPoolProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfGroupAvailabilityZoneDistributionPropertyToTerraform(struct?: TfGroup.AvailabilityZoneDistributionPropertyOutputReference | TfGroup.AvailabilityZoneDistributionProperty): any;
export declare function tfGroupAvailabilityZoneDistributionPropertyToHclTerraform(struct?: TfGroup.AvailabilityZoneDistributionPropertyOutputReference | TfGroup.AvailabilityZoneDistributionProperty): any;
export declare function tfGroupCapacityReservationTargetPropertyToTerraform(struct?: TfGroup.CapacityReservationTargetPropertyOutputReference | TfGroup.CapacityReservationTargetProperty): any;
export declare function tfGroupCapacityReservationTargetPropertyToHclTerraform(struct?: TfGroup.CapacityReservationTargetPropertyOutputReference | TfGroup.CapacityReservationTargetProperty): any;
export declare function tfGroupCapacityReservationSpecificationPropertyToTerraform(struct?: TfGroup.CapacityReservationSpecificationPropertyOutputReference | TfGroup.CapacityReservationSpecificationProperty): any;
export declare function tfGroupCapacityReservationSpecificationPropertyToHclTerraform(struct?: TfGroup.CapacityReservationSpecificationPropertyOutputReference | TfGroup.CapacityReservationSpecificationProperty): any;
export declare function tfGroupInitialLifecycleHookPropertyToTerraform(struct?: TfGroup.InitialLifecycleHookProperty | cdktn.IResolvable): any;
export declare function tfGroupInitialLifecycleHookPropertyToHclTerraform(struct?: TfGroup.InitialLifecycleHookProperty | cdktn.IResolvable): any;
export declare function tfGroupRetentionTriggersPropertyToTerraform(struct?: TfGroup.RetentionTriggersPropertyOutputReference | TfGroup.RetentionTriggersProperty): any;
export declare function tfGroupRetentionTriggersPropertyToHclTerraform(struct?: TfGroup.RetentionTriggersPropertyOutputReference | TfGroup.RetentionTriggersProperty): any;
export declare function tfGroupInstanceLifecyclePolicyPropertyToTerraform(struct?: TfGroup.InstanceLifecyclePolicyPropertyOutputReference | TfGroup.InstanceLifecyclePolicyProperty): any;
export declare function tfGroupInstanceLifecyclePolicyPropertyToHclTerraform(struct?: TfGroup.InstanceLifecyclePolicyPropertyOutputReference | TfGroup.InstanceLifecyclePolicyProperty): any;
export declare function tfGroupInstanceMaintenancePolicyPropertyToTerraform(struct?: TfGroup.InstanceMaintenancePolicyPropertyOutputReference | TfGroup.InstanceMaintenancePolicyProperty): any;
export declare function tfGroupInstanceMaintenancePolicyPropertyToHclTerraform(struct?: TfGroup.InstanceMaintenancePolicyPropertyOutputReference | TfGroup.InstanceMaintenancePolicyProperty): any;
export declare function tfGroupAlarmSpecificationPropertyToTerraform(struct?: TfGroup.AlarmSpecificationPropertyOutputReference | TfGroup.AlarmSpecificationProperty): any;
export declare function tfGroupAlarmSpecificationPropertyToHclTerraform(struct?: TfGroup.AlarmSpecificationPropertyOutputReference | TfGroup.AlarmSpecificationProperty): any;
export declare function tfGroupPreferencesPropertyToTerraform(struct?: TfGroup.PreferencesPropertyOutputReference | TfGroup.PreferencesProperty): any;
export declare function tfGroupPreferencesPropertyToHclTerraform(struct?: TfGroup.PreferencesPropertyOutputReference | TfGroup.PreferencesProperty): any;
export declare function tfGroupInstanceRefreshPropertyToTerraform(struct?: TfGroup.InstanceRefreshPropertyOutputReference | TfGroup.InstanceRefreshProperty): any;
export declare function tfGroupInstanceRefreshPropertyToHclTerraform(struct?: TfGroup.InstanceRefreshPropertyOutputReference | TfGroup.InstanceRefreshProperty): any;
export declare function tfGroupLaunchTemplatePropertyToTerraform(struct?: TfGroup.LaunchTemplatePropertyOutputReference | TfGroup.LaunchTemplateProperty): any;
export declare function tfGroupLaunchTemplatePropertyToHclTerraform(struct?: TfGroup.LaunchTemplatePropertyOutputReference | TfGroup.LaunchTemplateProperty): any;
export declare function tfGroupInstancesDistributionPropertyToTerraform(struct?: TfGroup.InstancesDistributionPropertyOutputReference | TfGroup.InstancesDistributionProperty): any;
export declare function tfGroupInstancesDistributionPropertyToHclTerraform(struct?: TfGroup.InstancesDistributionPropertyOutputReference | TfGroup.InstancesDistributionProperty): any;
export declare function tfGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyToTerraform(struct?: TfGroup.MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyOutputReference | TfGroup.MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty): any;
export declare function tfGroupMixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyToHclTerraform(struct?: TfGroup.MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyOutputReference | TfGroup.MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty): any;
export declare function tfGroupAcceleratorCountPropertyToTerraform(struct?: TfGroup.AcceleratorCountPropertyOutputReference | TfGroup.AcceleratorCountProperty): any;
export declare function tfGroupAcceleratorCountPropertyToHclTerraform(struct?: TfGroup.AcceleratorCountPropertyOutputReference | TfGroup.AcceleratorCountProperty): any;
export declare function tfGroupAcceleratorTotalMemoryMibPropertyToTerraform(struct?: TfGroup.AcceleratorTotalMemoryMibPropertyOutputReference | TfGroup.AcceleratorTotalMemoryMibProperty): any;
export declare function tfGroupAcceleratorTotalMemoryMibPropertyToHclTerraform(struct?: TfGroup.AcceleratorTotalMemoryMibPropertyOutputReference | TfGroup.AcceleratorTotalMemoryMibProperty): any;
export declare function tfGroupBaselineEbsBandwidthMbpsPropertyToTerraform(struct?: TfGroup.BaselineEbsBandwidthMbpsPropertyOutputReference | TfGroup.BaselineEbsBandwidthMbpsProperty): any;
export declare function tfGroupBaselineEbsBandwidthMbpsPropertyToHclTerraform(struct?: TfGroup.BaselineEbsBandwidthMbpsPropertyOutputReference | TfGroup.BaselineEbsBandwidthMbpsProperty): any;
export declare function tfGroupMemoryGibPerVcpuPropertyToTerraform(struct?: TfGroup.MemoryGibPerVcpuPropertyOutputReference | TfGroup.MemoryGibPerVcpuProperty): any;
export declare function tfGroupMemoryGibPerVcpuPropertyToHclTerraform(struct?: TfGroup.MemoryGibPerVcpuPropertyOutputReference | TfGroup.MemoryGibPerVcpuProperty): any;
export declare function tfGroupMemoryMibPropertyToTerraform(struct?: TfGroup.MemoryMibPropertyOutputReference | TfGroup.MemoryMibProperty): any;
export declare function tfGroupMemoryMibPropertyToHclTerraform(struct?: TfGroup.MemoryMibPropertyOutputReference | TfGroup.MemoryMibProperty): any;
export declare function tfGroupNetworkBandwidthGbpsPropertyToTerraform(struct?: TfGroup.NetworkBandwidthGbpsPropertyOutputReference | TfGroup.NetworkBandwidthGbpsProperty): any;
export declare function tfGroupNetworkBandwidthGbpsPropertyToHclTerraform(struct?: TfGroup.NetworkBandwidthGbpsPropertyOutputReference | TfGroup.NetworkBandwidthGbpsProperty): any;
export declare function tfGroupNetworkInterfaceCountPropertyToTerraform(struct?: TfGroup.NetworkInterfaceCountPropertyOutputReference | TfGroup.NetworkInterfaceCountProperty): any;
export declare function tfGroupNetworkInterfaceCountPropertyToHclTerraform(struct?: TfGroup.NetworkInterfaceCountPropertyOutputReference | TfGroup.NetworkInterfaceCountProperty): any;
export declare function tfGroupTotalLocalStorageGbPropertyToTerraform(struct?: TfGroup.TotalLocalStorageGbPropertyOutputReference | TfGroup.TotalLocalStorageGbProperty): any;
export declare function tfGroupTotalLocalStorageGbPropertyToHclTerraform(struct?: TfGroup.TotalLocalStorageGbPropertyOutputReference | TfGroup.TotalLocalStorageGbProperty): any;
export declare function tfGroupVcpuCountPropertyToTerraform(struct?: TfGroup.VcpuCountPropertyOutputReference | TfGroup.VcpuCountProperty): any;
export declare function tfGroupVcpuCountPropertyToHclTerraform(struct?: TfGroup.VcpuCountPropertyOutputReference | TfGroup.VcpuCountProperty): any;
export declare function tfGroupInstanceRequirementsPropertyToTerraform(struct?: TfGroup.InstanceRequirementsPropertyOutputReference | TfGroup.InstanceRequirementsProperty): any;
export declare function tfGroupInstanceRequirementsPropertyToHclTerraform(struct?: TfGroup.InstanceRequirementsPropertyOutputReference | TfGroup.InstanceRequirementsProperty): any;
export declare function tfGroupMixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyToTerraform(struct?: TfGroup.MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyOutputReference | TfGroup.MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty): any;
export declare function tfGroupMixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyToHclTerraform(struct?: TfGroup.MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyOutputReference | TfGroup.MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty): any;
export declare function tfGroupOverridePropertyToTerraform(struct?: TfGroup.OverrideProperty | cdktn.IResolvable): any;
export declare function tfGroupOverridePropertyToHclTerraform(struct?: TfGroup.OverrideProperty | cdktn.IResolvable): any;
export declare function tfGroupMixedInstancesPolicyLaunchTemplatePropertyToTerraform(struct?: TfGroup.MixedInstancesPolicyLaunchTemplatePropertyOutputReference | TfGroup.MixedInstancesPolicyLaunchTemplateProperty): any;
export declare function tfGroupMixedInstancesPolicyLaunchTemplatePropertyToHclTerraform(struct?: TfGroup.MixedInstancesPolicyLaunchTemplatePropertyOutputReference | TfGroup.MixedInstancesPolicyLaunchTemplateProperty): any;
export declare function tfGroupMixedInstancesPolicyPropertyToTerraform(struct?: TfGroup.MixedInstancesPolicyPropertyOutputReference | TfGroup.MixedInstancesPolicyProperty): any;
export declare function tfGroupMixedInstancesPolicyPropertyToHclTerraform(struct?: TfGroup.MixedInstancesPolicyPropertyOutputReference | TfGroup.MixedInstancesPolicyProperty): any;
export declare function tfGroupTagPropertyToTerraform(struct?: TfGroup.TagProperty | cdktn.IResolvable): any;
export declare function tfGroupTagPropertyToHclTerraform(struct?: TfGroup.TagProperty | cdktn.IResolvable): any;
export declare function tfGroupTimeoutsPropertyToTerraform(struct?: TfGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfGroupTimeoutsPropertyToHclTerraform(struct?: TfGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfGroupTrafficSourcePropertyToTerraform(struct?: TfGroup.TrafficSourceProperty | cdktn.IResolvable): any;
export declare function tfGroupTrafficSourcePropertyToHclTerraform(struct?: TfGroup.TrafficSourceProperty | cdktn.IResolvable): any;
export declare function tfGroupInstanceReusePolicyPropertyToTerraform(struct?: TfGroup.InstanceReusePolicyPropertyOutputReference | TfGroup.InstanceReusePolicyProperty): any;
export declare function tfGroupInstanceReusePolicyPropertyToHclTerraform(struct?: TfGroup.InstanceReusePolicyPropertyOutputReference | TfGroup.InstanceReusePolicyProperty): any;
export declare function tfGroupWarmPoolPropertyToTerraform(struct?: TfGroup.WarmPoolPropertyOutputReference | TfGroup.WarmPoolProperty): any;
export declare function tfGroupWarmPoolPropertyToHclTerraform(struct?: TfGroup.WarmPoolPropertyOutputReference | TfGroup.WarmPoolProperty): any;
export declare namespace TfGroup {
    interface AvailabilityZoneDistributionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#capacity_distribution_strategy TfGroup#capacity_distribution_strategy}
        */
        readonly capacityDistributionStrategy?: string;
    }
    class AvailabilityZoneDistributionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AvailabilityZoneDistributionProperty | undefined;
        set internalValue(value: AvailabilityZoneDistributionProperty | undefined);
        private _capacityDistributionStrategy?;
        get capacityDistributionStrategy(): string;
        set capacityDistributionStrategy(value: string);
        resetCapacityDistributionStrategy(): void;
        get capacityDistributionStrategyInput(): string | undefined;
    }
    interface CapacityReservationTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#capacity_reservation_ids TfGroup#capacity_reservation_ids}
        */
        readonly capacityReservationIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#capacity_reservation_resource_group_arns TfGroup#capacity_reservation_resource_group_arns}
        */
        readonly capacityReservationResourceGroupArns?: string[];
    }
    class CapacityReservationTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationTargetProperty | undefined;
        set internalValue(value: CapacityReservationTargetProperty | undefined);
        private _capacityReservationIds?;
        get capacityReservationIds(): string[];
        set capacityReservationIds(value: string[]);
        resetCapacityReservationIds(): void;
        get capacityReservationIdsInput(): string[] | undefined;
        private _capacityReservationResourceGroupArns?;
        get capacityReservationResourceGroupArns(): string[];
        set capacityReservationResourceGroupArns(value: string[]);
        resetCapacityReservationResourceGroupArns(): void;
        get capacityReservationResourceGroupArnsInput(): string[] | undefined;
    }
    interface CapacityReservationSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#capacity_reservation_preference TfGroup#capacity_reservation_preference}
        */
        readonly capacityReservationPreference?: string;
        /**
        * capacity_reservation_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#capacity_reservation_target TfGroup#capacity_reservation_target}
        */
        readonly capacityReservationTarget?: CapacityReservationTargetProperty;
    }
    class CapacityReservationSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationSpecificationProperty | undefined;
        set internalValue(value: CapacityReservationSpecificationProperty | undefined);
        private _capacityReservationPreference?;
        get capacityReservationPreference(): string;
        set capacityReservationPreference(value: string);
        resetCapacityReservationPreference(): void;
        get capacityReservationPreferenceInput(): string | undefined;
        private _capacityReservationTarget;
        get capacityReservationTarget(): CapacityReservationTargetPropertyOutputReference;
        putCapacityReservationTarget(value: CapacityReservationTargetProperty): void;
        resetCapacityReservationTarget(): void;
        get capacityReservationTargetInput(): CapacityReservationTargetProperty | undefined;
    }
    interface InitialLifecycleHookProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#default_result TfGroup#default_result}
        */
        readonly defaultResult?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#heartbeat_timeout TfGroup#heartbeat_timeout}
        */
        readonly heartbeatTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#lifecycle_transition TfGroup#lifecycle_transition}
        */
        readonly lifecycleTransition: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#name TfGroup#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#notification_metadata TfGroup#notification_metadata}
        */
        readonly notificationMetadata?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#notification_target_arn TfGroup#notification_target_arn}
        */
        readonly notificationTargetArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#role_arn TfGroup#role_arn}
        */
        readonly roleArn?: string;
    }
    class InitialLifecycleHookPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InitialLifecycleHookProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InitialLifecycleHookProperty | cdktn.IResolvable | undefined);
        private _defaultResult?;
        get defaultResult(): string;
        set defaultResult(value: string);
        resetDefaultResult(): void;
        get defaultResultInput(): string | undefined;
        private _heartbeatTimeout?;
        get heartbeatTimeout(): number;
        set heartbeatTimeout(value: number);
        resetHeartbeatTimeout(): void;
        get heartbeatTimeoutInput(): number | undefined;
        private _lifecycleTransition?;
        get lifecycleTransition(): string;
        set lifecycleTransition(value: string);
        get lifecycleTransitionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _notificationMetadata?;
        get notificationMetadata(): string;
        set notificationMetadata(value: string);
        resetNotificationMetadata(): void;
        get notificationMetadataInput(): string | undefined;
        private _notificationTargetArn?;
        get notificationTargetArn(): string;
        set notificationTargetArn(value: string);
        resetNotificationTargetArn(): void;
        get notificationTargetArnInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
    }
    class InitialLifecycleHookPropertyList extends cdktn.ComplexList {
        internalValue?: InitialLifecycleHookProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InitialLifecycleHookPropertyOutputReference;
    }
    interface RetentionTriggersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#terminate_hook_abandon TfGroup#terminate_hook_abandon}
        */
        readonly terminateHookAbandon?: string;
    }
    class RetentionTriggersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RetentionTriggersProperty | undefined;
        set internalValue(value: RetentionTriggersProperty | undefined);
        private _terminateHookAbandon?;
        get terminateHookAbandon(): string;
        set terminateHookAbandon(value: string);
        resetTerminateHookAbandon(): void;
        get terminateHookAbandonInput(): string | undefined;
    }
    interface InstanceLifecyclePolicyProperty {
        /**
        * retention_triggers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#retention_triggers TfGroup#retention_triggers}
        */
        readonly retentionTriggers?: RetentionTriggersProperty;
    }
    class InstanceLifecyclePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceLifecyclePolicyProperty | undefined;
        set internalValue(value: InstanceLifecyclePolicyProperty | undefined);
        private _retentionTriggers;
        get retentionTriggers(): RetentionTriggersPropertyOutputReference;
        putRetentionTriggers(value: RetentionTriggersProperty): void;
        resetRetentionTriggers(): void;
        get retentionTriggersInput(): RetentionTriggersProperty | undefined;
    }
    interface InstanceMaintenancePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max_healthy_percentage TfGroup#max_healthy_percentage}
        */
        readonly maxHealthyPercentage: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min_healthy_percentage TfGroup#min_healthy_percentage}
        */
        readonly minHealthyPercentage: number;
    }
    class InstanceMaintenancePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceMaintenancePolicyProperty | undefined;
        set internalValue(value: InstanceMaintenancePolicyProperty | undefined);
        private _maxHealthyPercentage?;
        get maxHealthyPercentage(): number;
        set maxHealthyPercentage(value: number);
        get maxHealthyPercentageInput(): number | undefined;
        private _minHealthyPercentage?;
        get minHealthyPercentage(): number;
        set minHealthyPercentage(value: number);
        get minHealthyPercentageInput(): number | undefined;
    }
    interface AlarmSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#alarms TfGroup#alarms}
        */
        readonly alarms?: string[];
    }
    class AlarmSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AlarmSpecificationProperty | undefined;
        set internalValue(value: AlarmSpecificationProperty | undefined);
        private _alarms?;
        get alarms(): string[];
        set alarms(value: string[]);
        resetAlarms(): void;
        get alarmsInput(): string[] | undefined;
    }
    interface PreferencesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#auto_rollback TfGroup#auto_rollback}
        */
        readonly autoRollback?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#checkpoint_delay TfGroup#checkpoint_delay}
        */
        readonly checkpointDelay?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#checkpoint_percentages TfGroup#checkpoint_percentages}
        */
        readonly checkpointPercentages?: number[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instance_warmup TfGroup#instance_warmup}
        */
        readonly instanceWarmup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max_healthy_percentage TfGroup#max_healthy_percentage}
        */
        readonly maxHealthyPercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min_healthy_percentage TfGroup#min_healthy_percentage}
        */
        readonly minHealthyPercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#scale_in_protected_instances TfGroup#scale_in_protected_instances}
        */
        readonly scaleInProtectedInstances?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#skip_matching TfGroup#skip_matching}
        */
        readonly skipMatching?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#standby_instances TfGroup#standby_instances}
        */
        readonly standbyInstances?: string;
        /**
        * alarm_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#alarm_specification TfGroup#alarm_specification}
        */
        readonly alarmSpecification?: AlarmSpecificationProperty;
    }
    class PreferencesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PreferencesProperty | undefined;
        set internalValue(value: PreferencesProperty | undefined);
        private _autoRollback?;
        get autoRollback(): boolean | cdktn.IResolvable;
        set autoRollback(value: boolean | cdktn.IResolvable);
        resetAutoRollback(): void;
        get autoRollbackInput(): boolean | cdktn.IResolvable | undefined;
        private _checkpointDelay?;
        get checkpointDelay(): string;
        set checkpointDelay(value: string);
        resetCheckpointDelay(): void;
        get checkpointDelayInput(): string | undefined;
        private _checkpointPercentages?;
        get checkpointPercentages(): number[];
        set checkpointPercentages(value: number[]);
        resetCheckpointPercentages(): void;
        get checkpointPercentagesInput(): number[] | undefined;
        private _instanceWarmup?;
        get instanceWarmup(): string;
        set instanceWarmup(value: string);
        resetInstanceWarmup(): void;
        get instanceWarmupInput(): string | undefined;
        private _maxHealthyPercentage?;
        get maxHealthyPercentage(): number;
        set maxHealthyPercentage(value: number);
        resetMaxHealthyPercentage(): void;
        get maxHealthyPercentageInput(): number | undefined;
        private _minHealthyPercentage?;
        get minHealthyPercentage(): number;
        set minHealthyPercentage(value: number);
        resetMinHealthyPercentage(): void;
        get minHealthyPercentageInput(): number | undefined;
        private _scaleInProtectedInstances?;
        get scaleInProtectedInstances(): string;
        set scaleInProtectedInstances(value: string);
        resetScaleInProtectedInstances(): void;
        get scaleInProtectedInstancesInput(): string | undefined;
        private _skipMatching?;
        get skipMatching(): boolean | cdktn.IResolvable;
        set skipMatching(value: boolean | cdktn.IResolvable);
        resetSkipMatching(): void;
        get skipMatchingInput(): boolean | cdktn.IResolvable | undefined;
        private _standbyInstances?;
        get standbyInstances(): string;
        set standbyInstances(value: string);
        resetStandbyInstances(): void;
        get standbyInstancesInput(): string | undefined;
        private _alarmSpecification;
        get alarmSpecification(): AlarmSpecificationPropertyOutputReference;
        putAlarmSpecification(value: AlarmSpecificationProperty): void;
        resetAlarmSpecification(): void;
        get alarmSpecificationInput(): AlarmSpecificationProperty | undefined;
    }
    interface InstanceRefreshProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#strategy TfGroup#strategy}
        */
        readonly strategy: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#triggers TfGroup#triggers}
        */
        readonly triggers?: string[];
        /**
        * preferences block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#preferences TfGroup#preferences}
        */
        readonly preferences?: PreferencesProperty;
    }
    class InstanceRefreshPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceRefreshProperty | undefined;
        set internalValue(value: InstanceRefreshProperty | undefined);
        private _strategy?;
        get strategy(): string;
        set strategy(value: string);
        get strategyInput(): string | undefined;
        private _triggers?;
        get triggers(): string[];
        set triggers(value: string[]);
        resetTriggers(): void;
        get triggersInput(): string[] | undefined;
        private _preferences;
        get preferences(): PreferencesPropertyOutputReference;
        putPreferences(value: PreferencesProperty): void;
        resetPreferences(): void;
        get preferencesInput(): PreferencesProperty | undefined;
    }
    interface LaunchTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#id TfGroup#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#name TfGroup#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#version TfGroup#version}
        */
        readonly version?: string;
    }
    class LaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LaunchTemplateProperty | undefined;
        set internalValue(value: LaunchTemplateProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface InstancesDistributionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#on_demand_allocation_strategy TfGroup#on_demand_allocation_strategy}
        */
        readonly onDemandAllocationStrategy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#on_demand_base_capacity TfGroup#on_demand_base_capacity}
        */
        readonly onDemandBaseCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#on_demand_percentage_above_base_capacity TfGroup#on_demand_percentage_above_base_capacity}
        */
        readonly onDemandPercentageAboveBaseCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#spot_allocation_strategy TfGroup#spot_allocation_strategy}
        */
        readonly spotAllocationStrategy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#spot_instance_pools TfGroup#spot_instance_pools}
        */
        readonly spotInstancePools?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#spot_max_price TfGroup#spot_max_price}
        */
        readonly spotMaxPrice?: string;
    }
    class InstancesDistributionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstancesDistributionProperty | undefined;
        set internalValue(value: InstancesDistributionProperty | undefined);
        private _onDemandAllocationStrategy?;
        get onDemandAllocationStrategy(): string;
        set onDemandAllocationStrategy(value: string);
        resetOnDemandAllocationStrategy(): void;
        get onDemandAllocationStrategyInput(): string | undefined;
        private _onDemandBaseCapacity?;
        get onDemandBaseCapacity(): number;
        set onDemandBaseCapacity(value: number);
        resetOnDemandBaseCapacity(): void;
        get onDemandBaseCapacityInput(): number | undefined;
        private _onDemandPercentageAboveBaseCapacity?;
        get onDemandPercentageAboveBaseCapacity(): number;
        set onDemandPercentageAboveBaseCapacity(value: number);
        resetOnDemandPercentageAboveBaseCapacity(): void;
        get onDemandPercentageAboveBaseCapacityInput(): number | undefined;
        private _spotAllocationStrategy?;
        get spotAllocationStrategy(): string;
        set spotAllocationStrategy(value: string);
        resetSpotAllocationStrategy(): void;
        get spotAllocationStrategyInput(): string | undefined;
        private _spotInstancePools?;
        get spotInstancePools(): number;
        set spotInstancePools(value: number);
        resetSpotInstancePools(): void;
        get spotInstancePoolsInput(): number | undefined;
        private _spotMaxPrice?;
        get spotMaxPrice(): string;
        set spotMaxPrice(value: string);
        resetSpotMaxPrice(): void;
        get spotMaxPriceInput(): string | undefined;
    }
    interface MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_template_id TfGroup#launch_template_id}
        */
        readonly launchTemplateId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_template_name TfGroup#launch_template_name}
        */
        readonly launchTemplateName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#version TfGroup#version}
        */
        readonly version?: string;
    }
    class MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty | undefined;
        set internalValue(value: MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty | undefined);
        private _launchTemplateId?;
        get launchTemplateId(): string;
        set launchTemplateId(value: string);
        resetLaunchTemplateId(): void;
        get launchTemplateIdInput(): string | undefined;
        private _launchTemplateName?;
        get launchTemplateName(): string;
        set launchTemplateName(value: string);
        resetLaunchTemplateName(): void;
        get launchTemplateNameInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface AcceleratorCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max TfGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min TfGroup#min}
        */
        readonly min?: number;
    }
    class AcceleratorCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorCountProperty | undefined;
        set internalValue(value: AcceleratorCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface AcceleratorTotalMemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max TfGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min TfGroup#min}
        */
        readonly min?: number;
    }
    class AcceleratorTotalMemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorTotalMemoryMibProperty | undefined;
        set internalValue(value: AcceleratorTotalMemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface BaselineEbsBandwidthMbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max TfGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min TfGroup#min}
        */
        readonly min?: number;
    }
    class BaselineEbsBandwidthMbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BaselineEbsBandwidthMbpsProperty | undefined;
        set internalValue(value: BaselineEbsBandwidthMbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryGibPerVcpuProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max TfGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min TfGroup#min}
        */
        readonly min?: number;
    }
    class MemoryGibPerVcpuPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryGibPerVcpuProperty | undefined;
        set internalValue(value: MemoryGibPerVcpuProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max TfGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min TfGroup#min}
        */
        readonly min?: number;
    }
    class MemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryMibProperty | undefined;
        set internalValue(value: MemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface NetworkBandwidthGbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max TfGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min TfGroup#min}
        */
        readonly min?: number;
    }
    class NetworkBandwidthGbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkBandwidthGbpsProperty | undefined;
        set internalValue(value: NetworkBandwidthGbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface NetworkInterfaceCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max TfGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min TfGroup#min}
        */
        readonly min?: number;
    }
    class NetworkInterfaceCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkInterfaceCountProperty | undefined;
        set internalValue(value: NetworkInterfaceCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface TotalLocalStorageGbProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max TfGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min TfGroup#min}
        */
        readonly min?: number;
    }
    class TotalLocalStorageGbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TotalLocalStorageGbProperty | undefined;
        set internalValue(value: TotalLocalStorageGbProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface VcpuCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max TfGroup#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min TfGroup#min}
        */
        readonly min?: number;
    }
    class VcpuCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VcpuCountProperty | undefined;
        set internalValue(value: VcpuCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface InstanceRequirementsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#accelerator_manufacturers TfGroup#accelerator_manufacturers}
        */
        readonly acceleratorManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#accelerator_names TfGroup#accelerator_names}
        */
        readonly acceleratorNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#accelerator_types TfGroup#accelerator_types}
        */
        readonly acceleratorTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#allowed_instance_types TfGroup#allowed_instance_types}
        */
        readonly allowedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#bare_metal TfGroup#bare_metal}
        */
        readonly bareMetal?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#burstable_performance TfGroup#burstable_performance}
        */
        readonly burstablePerformance?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#cpu_manufacturers TfGroup#cpu_manufacturers}
        */
        readonly cpuManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#excluded_instance_types TfGroup#excluded_instance_types}
        */
        readonly excludedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instance_generations TfGroup#instance_generations}
        */
        readonly instanceGenerations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#local_storage TfGroup#local_storage}
        */
        readonly localStorage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#local_storage_types TfGroup#local_storage_types}
        */
        readonly localStorageTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max_spot_price_as_percentage_of_optimal_on_demand_price TfGroup#max_spot_price_as_percentage_of_optimal_on_demand_price}
        */
        readonly maxSpotPriceAsPercentageOfOptimalOnDemandPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#on_demand_max_price_percentage_over_lowest_price TfGroup#on_demand_max_price_percentage_over_lowest_price}
        */
        readonly onDemandMaxPricePercentageOverLowestPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#require_hibernate_support TfGroup#require_hibernate_support}
        */
        readonly requireHibernateSupport?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#spot_max_price_percentage_over_lowest_price TfGroup#spot_max_price_percentage_over_lowest_price}
        */
        readonly spotMaxPricePercentageOverLowestPrice?: number;
        /**
        * accelerator_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#accelerator_count TfGroup#accelerator_count}
        */
        readonly acceleratorCount?: AcceleratorCountProperty;
        /**
        * accelerator_total_memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#accelerator_total_memory_mib TfGroup#accelerator_total_memory_mib}
        */
        readonly acceleratorTotalMemoryMib?: AcceleratorTotalMemoryMibProperty;
        /**
        * baseline_ebs_bandwidth_mbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#baseline_ebs_bandwidth_mbps TfGroup#baseline_ebs_bandwidth_mbps}
        */
        readonly baselineEbsBandwidthMbps?: BaselineEbsBandwidthMbpsProperty;
        /**
        * memory_gib_per_vcpu block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#memory_gib_per_vcpu TfGroup#memory_gib_per_vcpu}
        */
        readonly memoryGibPerVcpu?: MemoryGibPerVcpuProperty;
        /**
        * memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#memory_mib TfGroup#memory_mib}
        */
        readonly memoryMib?: MemoryMibProperty;
        /**
        * network_bandwidth_gbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#network_bandwidth_gbps TfGroup#network_bandwidth_gbps}
        */
        readonly networkBandwidthGbps?: NetworkBandwidthGbpsProperty;
        /**
        * network_interface_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#network_interface_count TfGroup#network_interface_count}
        */
        readonly networkInterfaceCount?: NetworkInterfaceCountProperty;
        /**
        * total_local_storage_gb block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#total_local_storage_gb TfGroup#total_local_storage_gb}
        */
        readonly totalLocalStorageGb?: TotalLocalStorageGbProperty;
        /**
        * vcpu_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#vcpu_count TfGroup#vcpu_count}
        */
        readonly vcpuCount?: VcpuCountProperty;
    }
    class InstanceRequirementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceRequirementsProperty | undefined;
        set internalValue(value: InstanceRequirementsProperty | undefined);
        private _acceleratorManufacturers?;
        get acceleratorManufacturers(): string[];
        set acceleratorManufacturers(value: string[]);
        resetAcceleratorManufacturers(): void;
        get acceleratorManufacturersInput(): string[] | undefined;
        private _acceleratorNames?;
        get acceleratorNames(): string[];
        set acceleratorNames(value: string[]);
        resetAcceleratorNames(): void;
        get acceleratorNamesInput(): string[] | undefined;
        private _acceleratorTypes?;
        get acceleratorTypes(): string[];
        set acceleratorTypes(value: string[]);
        resetAcceleratorTypes(): void;
        get acceleratorTypesInput(): string[] | undefined;
        private _allowedInstanceTypes?;
        get allowedInstanceTypes(): string[];
        set allowedInstanceTypes(value: string[]);
        resetAllowedInstanceTypes(): void;
        get allowedInstanceTypesInput(): string[] | undefined;
        private _bareMetal?;
        get bareMetal(): string;
        set bareMetal(value: string);
        resetBareMetal(): void;
        get bareMetalInput(): string | undefined;
        private _burstablePerformance?;
        get burstablePerformance(): string;
        set burstablePerformance(value: string);
        resetBurstablePerformance(): void;
        get burstablePerformanceInput(): string | undefined;
        private _cpuManufacturers?;
        get cpuManufacturers(): string[];
        set cpuManufacturers(value: string[]);
        resetCpuManufacturers(): void;
        get cpuManufacturersInput(): string[] | undefined;
        private _excludedInstanceTypes?;
        get excludedInstanceTypes(): string[];
        set excludedInstanceTypes(value: string[]);
        resetExcludedInstanceTypes(): void;
        get excludedInstanceTypesInput(): string[] | undefined;
        private _instanceGenerations?;
        get instanceGenerations(): string[];
        set instanceGenerations(value: string[]);
        resetInstanceGenerations(): void;
        get instanceGenerationsInput(): string[] | undefined;
        private _localStorage?;
        get localStorage(): string;
        set localStorage(value: string);
        resetLocalStorage(): void;
        get localStorageInput(): string | undefined;
        private _localStorageTypes?;
        get localStorageTypes(): string[];
        set localStorageTypes(value: string[]);
        resetLocalStorageTypes(): void;
        get localStorageTypesInput(): string[] | undefined;
        private _maxSpotPriceAsPercentageOfOptimalOnDemandPrice?;
        get maxSpotPriceAsPercentageOfOptimalOnDemandPrice(): number;
        set maxSpotPriceAsPercentageOfOptimalOnDemandPrice(value: number);
        resetMaxSpotPriceAsPercentageOfOptimalOnDemandPrice(): void;
        get maxSpotPriceAsPercentageOfOptimalOnDemandPriceInput(): number | undefined;
        private _onDemandMaxPricePercentageOverLowestPrice?;
        get onDemandMaxPricePercentageOverLowestPrice(): number;
        set onDemandMaxPricePercentageOverLowestPrice(value: number);
        resetOnDemandMaxPricePercentageOverLowestPrice(): void;
        get onDemandMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _requireHibernateSupport?;
        get requireHibernateSupport(): boolean | cdktn.IResolvable;
        set requireHibernateSupport(value: boolean | cdktn.IResolvable);
        resetRequireHibernateSupport(): void;
        get requireHibernateSupportInput(): boolean | cdktn.IResolvable | undefined;
        private _spotMaxPricePercentageOverLowestPrice?;
        get spotMaxPricePercentageOverLowestPrice(): number;
        set spotMaxPricePercentageOverLowestPrice(value: number);
        resetSpotMaxPricePercentageOverLowestPrice(): void;
        get spotMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _acceleratorCount;
        get acceleratorCount(): AcceleratorCountPropertyOutputReference;
        putAcceleratorCount(value: AcceleratorCountProperty): void;
        resetAcceleratorCount(): void;
        get acceleratorCountInput(): AcceleratorCountProperty | undefined;
        private _acceleratorTotalMemoryMib;
        get acceleratorTotalMemoryMib(): AcceleratorTotalMemoryMibPropertyOutputReference;
        putAcceleratorTotalMemoryMib(value: AcceleratorTotalMemoryMibProperty): void;
        resetAcceleratorTotalMemoryMib(): void;
        get acceleratorTotalMemoryMibInput(): AcceleratorTotalMemoryMibProperty | undefined;
        private _baselineEbsBandwidthMbps;
        get baselineEbsBandwidthMbps(): BaselineEbsBandwidthMbpsPropertyOutputReference;
        putBaselineEbsBandwidthMbps(value: BaselineEbsBandwidthMbpsProperty): void;
        resetBaselineEbsBandwidthMbps(): void;
        get baselineEbsBandwidthMbpsInput(): BaselineEbsBandwidthMbpsProperty | undefined;
        private _memoryGibPerVcpu;
        get memoryGibPerVcpu(): MemoryGibPerVcpuPropertyOutputReference;
        putMemoryGibPerVcpu(value: MemoryGibPerVcpuProperty): void;
        resetMemoryGibPerVcpu(): void;
        get memoryGibPerVcpuInput(): MemoryGibPerVcpuProperty | undefined;
        private _memoryMib;
        get memoryMib(): MemoryMibPropertyOutputReference;
        putMemoryMib(value: MemoryMibProperty): void;
        resetMemoryMib(): void;
        get memoryMibInput(): MemoryMibProperty | undefined;
        private _networkBandwidthGbps;
        get networkBandwidthGbps(): NetworkBandwidthGbpsPropertyOutputReference;
        putNetworkBandwidthGbps(value: NetworkBandwidthGbpsProperty): void;
        resetNetworkBandwidthGbps(): void;
        get networkBandwidthGbpsInput(): NetworkBandwidthGbpsProperty | undefined;
        private _networkInterfaceCount;
        get networkInterfaceCount(): NetworkInterfaceCountPropertyOutputReference;
        putNetworkInterfaceCount(value: NetworkInterfaceCountProperty): void;
        resetNetworkInterfaceCount(): void;
        get networkInterfaceCountInput(): NetworkInterfaceCountProperty | undefined;
        private _totalLocalStorageGb;
        get totalLocalStorageGb(): TotalLocalStorageGbPropertyOutputReference;
        putTotalLocalStorageGb(value: TotalLocalStorageGbProperty): void;
        resetTotalLocalStorageGb(): void;
        get totalLocalStorageGbInput(): TotalLocalStorageGbProperty | undefined;
        private _vcpuCount;
        get vcpuCount(): VcpuCountPropertyOutputReference;
        putVcpuCount(value: VcpuCountProperty): void;
        resetVcpuCount(): void;
        get vcpuCountInput(): VcpuCountProperty | undefined;
    }
    interface MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_template_id TfGroup#launch_template_id}
        */
        readonly launchTemplateId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_template_name TfGroup#launch_template_name}
        */
        readonly launchTemplateName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#version TfGroup#version}
        */
        readonly version?: string;
    }
    class MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty | undefined;
        set internalValue(value: MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty | undefined);
        private _launchTemplateId?;
        get launchTemplateId(): string;
        set launchTemplateId(value: string);
        resetLaunchTemplateId(): void;
        get launchTemplateIdInput(): string | undefined;
        private _launchTemplateName?;
        get launchTemplateName(): string;
        set launchTemplateName(value: string);
        resetLaunchTemplateName(): void;
        get launchTemplateNameInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        resetVersion(): void;
        get versionInput(): string | undefined;
    }
    interface OverrideProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instance_type TfGroup#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#weighted_capacity TfGroup#weighted_capacity}
        */
        readonly weightedCapacity?: string;
        /**
        * instance_requirements block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instance_requirements TfGroup#instance_requirements}
        */
        readonly instanceRequirements?: InstanceRequirementsProperty;
        /**
        * launch_template_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_template_specification TfGroup#launch_template_specification}
        */
        readonly launchTemplateSpecification?: MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty;
    }
    class OverridePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OverrideProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OverrideProperty | cdktn.IResolvable | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _weightedCapacity?;
        get weightedCapacity(): string;
        set weightedCapacity(value: string);
        resetWeightedCapacity(): void;
        get weightedCapacityInput(): string | undefined;
        private _instanceRequirements;
        get instanceRequirements(): InstanceRequirementsPropertyOutputReference;
        putInstanceRequirements(value: InstanceRequirementsProperty): void;
        resetInstanceRequirements(): void;
        get instanceRequirementsInput(): InstanceRequirementsProperty | undefined;
        private _launchTemplateSpecification;
        get launchTemplateSpecification(): MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationPropertyOutputReference;
        putLaunchTemplateSpecification(value: MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty): void;
        resetLaunchTemplateSpecification(): void;
        get launchTemplateSpecificationInput(): MixedInstancesPolicyLaunchTemplateOverrideLaunchTemplateSpecificationProperty | undefined;
    }
    class OverridePropertyList extends cdktn.ComplexList {
        internalValue?: OverrideProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OverridePropertyOutputReference;
    }
    interface MixedInstancesPolicyLaunchTemplateProperty {
        /**
        * launch_template_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_template_specification TfGroup#launch_template_specification}
        */
        readonly launchTemplateSpecification: MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty;
        /**
        * override block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#override TfGroup#override}
        */
        readonly override?: OverrideProperty[] | cdktn.IResolvable;
    }
    class MixedInstancesPolicyLaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MixedInstancesPolicyLaunchTemplateProperty | undefined;
        set internalValue(value: MixedInstancesPolicyLaunchTemplateProperty | undefined);
        private _launchTemplateSpecification;
        get launchTemplateSpecification(): MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationPropertyOutputReference;
        putLaunchTemplateSpecification(value: MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty): void;
        get launchTemplateSpecificationInput(): MixedInstancesPolicyLaunchTemplateLaunchTemplateSpecificationProperty | undefined;
        private _override;
        get override(): OverridePropertyList;
        putOverride(value: OverrideProperty[] | cdktn.IResolvable): void;
        resetOverride(): void;
        get overrideInput(): cdktn.IResolvable | OverrideProperty[] | undefined;
    }
    interface MixedInstancesPolicyProperty {
        /**
        * instances_distribution block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instances_distribution TfGroup#instances_distribution}
        */
        readonly instancesDistribution?: InstancesDistributionProperty;
        /**
        * launch_template block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#launch_template TfGroup#launch_template}
        */
        readonly launchTemplate: MixedInstancesPolicyLaunchTemplateProperty;
    }
    class MixedInstancesPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MixedInstancesPolicyProperty | undefined;
        set internalValue(value: MixedInstancesPolicyProperty | undefined);
        private _instancesDistribution;
        get instancesDistribution(): InstancesDistributionPropertyOutputReference;
        putInstancesDistribution(value: InstancesDistributionProperty): void;
        resetInstancesDistribution(): void;
        get instancesDistributionInput(): InstancesDistributionProperty | undefined;
        private _launchTemplate;
        get launchTemplate(): MixedInstancesPolicyLaunchTemplatePropertyOutputReference;
        putLaunchTemplate(value: MixedInstancesPolicyLaunchTemplateProperty): void;
        get launchTemplateInput(): MixedInstancesPolicyLaunchTemplateProperty | undefined;
    }
    interface TagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#key TfGroup#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#propagate_at_launch TfGroup#propagate_at_launch}
        */
        readonly propagateAtLaunch: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#value TfGroup#value}
        */
        readonly value: string;
    }
    class TagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _propagateAtLaunch?;
        get propagateAtLaunch(): boolean | cdktn.IResolvable;
        set propagateAtLaunch(value: boolean | cdktn.IResolvable);
        get propagateAtLaunchInput(): boolean | cdktn.IResolvable | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TagPropertyList extends cdktn.ComplexList {
        internalValue?: TagProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#delete TfGroup#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#update TfGroup#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface TrafficSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#identifier TfGroup#identifier}
        */
        readonly identifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#type TfGroup#type}
        */
        readonly type?: string;
    }
    class TrafficSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrafficSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrafficSourceProperty | cdktn.IResolvable | undefined);
        private _identifier?;
        get identifier(): string;
        set identifier(value: string);
        get identifierInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class TrafficSourcePropertyList extends cdktn.ComplexList {
        internalValue?: TrafficSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrafficSourcePropertyOutputReference;
    }
    interface InstanceReusePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#reuse_on_scale_in TfGroup#reuse_on_scale_in}
        */
        readonly reuseOnScaleIn?: boolean | cdktn.IResolvable;
    }
    class InstanceReusePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceReusePolicyProperty | undefined;
        set internalValue(value: InstanceReusePolicyProperty | undefined);
        private _reuseOnScaleIn?;
        get reuseOnScaleIn(): boolean | cdktn.IResolvable;
        set reuseOnScaleIn(value: boolean | cdktn.IResolvable);
        resetReuseOnScaleIn(): void;
        get reuseOnScaleInInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface WarmPoolProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#max_group_prepared_capacity TfGroup#max_group_prepared_capacity}
        */
        readonly maxGroupPreparedCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#min_size TfGroup#min_size}
        */
        readonly minSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#pool_state TfGroup#pool_state}
        */
        readonly poolState?: string;
        /**
        * instance_reuse_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_group#instance_reuse_policy TfGroup#instance_reuse_policy}
        */
        readonly instanceReusePolicy?: InstanceReusePolicyProperty;
    }
    class WarmPoolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WarmPoolProperty | undefined;
        set internalValue(value: WarmPoolProperty | undefined);
        private _maxGroupPreparedCapacity?;
        get maxGroupPreparedCapacity(): number;
        set maxGroupPreparedCapacity(value: number);
        resetMaxGroupPreparedCapacity(): void;
        get maxGroupPreparedCapacityInput(): number | undefined;
        private _minSize?;
        get minSize(): number;
        set minSize(value: number);
        resetMinSize(): void;
        get minSizeInput(): number | undefined;
        private _poolState?;
        get poolState(): string;
        set poolState(value: string);
        resetPoolState(): void;
        get poolStateInput(): string | undefined;
        private _instanceReusePolicy;
        get instanceReusePolicy(): InstanceReusePolicyPropertyOutputReference;
        putInstanceReusePolicy(value: InstanceReusePolicyProperty): void;
        resetInstanceReusePolicy(): void;
        get instanceReusePolicyInput(): InstanceReusePolicyProperty | undefined;
    }
}
