import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfTrafficSourceAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_traffic_source_attachment#autoscaling_group_name TfTrafficSourceAttachment#autoscaling_group_name}
    */
    readonly autoscalingGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_traffic_source_attachment#id TfTrafficSourceAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_traffic_source_attachment#region TfTrafficSourceAttachment#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_traffic_source_attachment#timeouts TfTrafficSourceAttachment#timeouts}
    */
    readonly timeouts?: TfTrafficSourceAttachment.TimeoutsProperty;
    /**
    * traffic_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_traffic_source_attachment#traffic_source TfTrafficSourceAttachment#traffic_source}
    */
    readonly trafficSource?: TfTrafficSourceAttachment.TrafficSourceProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_traffic_source_attachment aws_autoscaling_traffic_source_attachment}
*/
export declare class TfTrafficSourceAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_autoscaling_traffic_source_attachment";
    /**
    * Generates CDKTN code for importing a TfTrafficSourceAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfTrafficSourceAttachment to import
    * @param importFromId The id of the existing TfTrafficSourceAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_traffic_source_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfTrafficSourceAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_traffic_source_attachment aws_autoscaling_traffic_source_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfTrafficSourceAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: TfTrafficSourceAttachmentConfig);
    private _autoscalingGroupName?;
    get autoscalingGroupName(): string;
    set autoscalingGroupName(value: string);
    get autoscalingGroupNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): TfTrafficSourceAttachment.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfTrafficSourceAttachment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfTrafficSourceAttachment.TimeoutsProperty | undefined;
    private _trafficSource;
    get trafficSource(): TfTrafficSourceAttachment.TrafficSourcePropertyOutputReference;
    putTrafficSource(value: TfTrafficSourceAttachment.TrafficSourceProperty): void;
    resetTrafficSource(): void;
    get trafficSourceInput(): TfTrafficSourceAttachment.TrafficSourceProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfTrafficSourceAttachmentTimeoutsPropertyToTerraform(struct?: TfTrafficSourceAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfTrafficSourceAttachmentTimeoutsPropertyToHclTerraform(struct?: TfTrafficSourceAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfTrafficSourceAttachmentTrafficSourcePropertyToTerraform(struct?: TfTrafficSourceAttachment.TrafficSourcePropertyOutputReference | TfTrafficSourceAttachment.TrafficSourceProperty): any;
export declare function tfTrafficSourceAttachmentTrafficSourcePropertyToHclTerraform(struct?: TfTrafficSourceAttachment.TrafficSourcePropertyOutputReference | TfTrafficSourceAttachment.TrafficSourceProperty): any;
export declare namespace TfTrafficSourceAttachment {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_traffic_source_attachment#create TfTrafficSourceAttachment#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_traffic_source_attachment#delete TfTrafficSourceAttachment#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
    interface TrafficSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_traffic_source_attachment#identifier TfTrafficSourceAttachment#identifier}
        */
        readonly identifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/autoscaling_traffic_source_attachment#type TfTrafficSourceAttachment#type}
        */
        readonly type: string;
    }
    class TrafficSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TrafficSourceProperty | undefined;
        set internalValue(value: TrafficSourceProperty | undefined);
        private _identifier?;
        get identifier(): string;
        set identifier(value: string);
        get identifierInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
}
