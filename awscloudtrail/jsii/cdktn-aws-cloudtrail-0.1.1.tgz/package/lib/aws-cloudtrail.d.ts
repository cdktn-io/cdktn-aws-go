import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCloudtrailConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#cloud_watch_logs_group_arn AwsCloudtrail#cloud_watch_logs_group_arn}
    */
    readonly cloudWatchLogsGroupArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#cloud_watch_logs_role_arn AwsCloudtrail#cloud_watch_logs_role_arn}
    */
    readonly cloudWatchLogsRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#enable_log_file_validation AwsCloudtrail#enable_log_file_validation}
    */
    readonly enableLogFileValidation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#enable_logging AwsCloudtrail#enable_logging}
    */
    readonly enableLogging?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#id AwsCloudtrail#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#include_global_service_events AwsCloudtrail#include_global_service_events}
    */
    readonly includeGlobalServiceEvents?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#is_multi_region_trail AwsCloudtrail#is_multi_region_trail}
    */
    readonly isMultiRegionTrail?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#is_organization_trail AwsCloudtrail#is_organization_trail}
    */
    readonly isOrganizationTrail?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#kms_key_id AwsCloudtrail#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#name AwsCloudtrail#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#region AwsCloudtrail#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#s3_bucket_name AwsCloudtrail#s3_bucket_name}
    */
    readonly s3BucketName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#s3_key_prefix AwsCloudtrail#s3_key_prefix}
    */
    readonly s3KeyPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#sns_topic_name AwsCloudtrail#sns_topic_name}
    */
    readonly snsTopicName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#tags AwsCloudtrail#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#tags_all AwsCloudtrail#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * advanced_event_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#advanced_event_selector AwsCloudtrail#advanced_event_selector}
    */
    readonly advancedEventSelector?: AwsCloudtrail.AdvancedEventSelectorProperty[] | cdktn.IResolvable;
    /**
    * event_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#event_selector AwsCloudtrail#event_selector}
    */
    readonly eventSelector?: AwsCloudtrail.EventSelectorProperty[] | cdktn.IResolvable;
    /**
    * insight_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#insight_selector AwsCloudtrail#insight_selector}
    */
    readonly insightSelector?: AwsCloudtrail.InsightSelectorProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail aws_cloudtrail}
*/
export declare class AwsCloudtrail extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudtrail";
    /**
    * Generates CDKTN code for importing a AwsCloudtrail resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCloudtrail to import
    * @param importFromId The id of the existing AwsCloudtrail that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCloudtrail to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail aws_cloudtrail} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCloudtrailConfig
    */
    constructor(scope: Construct, id: string, config: AwsCloudtrailConfig);
    get arn(): string;
    private _cloudWatchLogsGroupArn?;
    get cloudWatchLogsGroupArn(): string;
    set cloudWatchLogsGroupArn(value: string);
    resetCloudWatchLogsGroupArn(): void;
    get cloudWatchLogsGroupArnInput(): string | undefined;
    private _cloudWatchLogsRoleArn?;
    get cloudWatchLogsRoleArn(): string;
    set cloudWatchLogsRoleArn(value: string);
    resetCloudWatchLogsRoleArn(): void;
    get cloudWatchLogsRoleArnInput(): string | undefined;
    private _enableLogFileValidation?;
    get enableLogFileValidation(): boolean | cdktn.IResolvable;
    set enableLogFileValidation(value: boolean | cdktn.IResolvable);
    resetEnableLogFileValidation(): void;
    get enableLogFileValidationInput(): boolean | cdktn.IResolvable | undefined;
    private _enableLogging?;
    get enableLogging(): boolean | cdktn.IResolvable;
    set enableLogging(value: boolean | cdktn.IResolvable);
    resetEnableLogging(): void;
    get enableLoggingInput(): boolean | cdktn.IResolvable | undefined;
    get homeRegion(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includeGlobalServiceEvents?;
    get includeGlobalServiceEvents(): boolean | cdktn.IResolvable;
    set includeGlobalServiceEvents(value: boolean | cdktn.IResolvable);
    resetIncludeGlobalServiceEvents(): void;
    get includeGlobalServiceEventsInput(): boolean | cdktn.IResolvable | undefined;
    private _isMultiRegionTrail?;
    get isMultiRegionTrail(): boolean | cdktn.IResolvable;
    set isMultiRegionTrail(value: boolean | cdktn.IResolvable);
    resetIsMultiRegionTrail(): void;
    get isMultiRegionTrailInput(): boolean | cdktn.IResolvable | undefined;
    private _isOrganizationTrail?;
    get isOrganizationTrail(): boolean | cdktn.IResolvable;
    set isOrganizationTrail(value: boolean | cdktn.IResolvable);
    resetIsOrganizationTrail(): void;
    get isOrganizationTrailInput(): boolean | cdktn.IResolvable | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _s3BucketName?;
    get s3BucketName(): string;
    set s3BucketName(value: string);
    get s3BucketNameInput(): string | undefined;
    private _s3KeyPrefix?;
    get s3KeyPrefix(): string;
    set s3KeyPrefix(value: string);
    resetS3KeyPrefix(): void;
    get s3KeyPrefixInput(): string | undefined;
    get snsTopicArn(): string;
    private _snsTopicName?;
    get snsTopicName(): string;
    set snsTopicName(value: string);
    resetSnsTopicName(): void;
    get snsTopicNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _advancedEventSelector;
    get advancedEventSelector(): AwsCloudtrail.AdvancedEventSelectorPropertyList;
    putAdvancedEventSelector(value: AwsCloudtrail.AdvancedEventSelectorProperty[] | cdktn.IResolvable): void;
    resetAdvancedEventSelector(): void;
    get advancedEventSelectorInput(): cdktn.IResolvable | AwsCloudtrail.AdvancedEventSelectorProperty[] | undefined;
    private _eventSelector;
    get eventSelector(): AwsCloudtrail.EventSelectorPropertyList;
    putEventSelector(value: AwsCloudtrail.EventSelectorProperty[] | cdktn.IResolvable): void;
    resetEventSelector(): void;
    get eventSelectorInput(): cdktn.IResolvable | AwsCloudtrail.EventSelectorProperty[] | undefined;
    private _insightSelector;
    get insightSelector(): AwsCloudtrail.InsightSelectorPropertyList;
    putInsightSelector(value: AwsCloudtrail.InsightSelectorProperty[] | cdktn.IResolvable): void;
    resetInsightSelector(): void;
    get insightSelectorInput(): cdktn.IResolvable | AwsCloudtrail.InsightSelectorProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCloudtrailFieldSelectorPropertyToTerraform(struct?: AwsCloudtrail.FieldSelectorProperty | cdktn.IResolvable): any;
export declare function awsCloudtrailFieldSelectorPropertyToHclTerraform(struct?: AwsCloudtrail.FieldSelectorProperty | cdktn.IResolvable): any;
export declare function awsCloudtrailAdvancedEventSelectorPropertyToTerraform(struct?: AwsCloudtrail.AdvancedEventSelectorProperty | cdktn.IResolvable): any;
export declare function awsCloudtrailAdvancedEventSelectorPropertyToHclTerraform(struct?: AwsCloudtrail.AdvancedEventSelectorProperty | cdktn.IResolvable): any;
export declare function awsCloudtrailDataResourcePropertyToTerraform(struct?: AwsCloudtrail.DataResourceProperty | cdktn.IResolvable): any;
export declare function awsCloudtrailDataResourcePropertyToHclTerraform(struct?: AwsCloudtrail.DataResourceProperty | cdktn.IResolvable): any;
export declare function awsCloudtrailEventSelectorPropertyToTerraform(struct?: AwsCloudtrail.EventSelectorProperty | cdktn.IResolvable): any;
export declare function awsCloudtrailEventSelectorPropertyToHclTerraform(struct?: AwsCloudtrail.EventSelectorProperty | cdktn.IResolvable): any;
export declare function awsCloudtrailInsightSelectorPropertyToTerraform(struct?: AwsCloudtrail.InsightSelectorProperty | cdktn.IResolvable): any;
export declare function awsCloudtrailInsightSelectorPropertyToHclTerraform(struct?: AwsCloudtrail.InsightSelectorProperty | cdktn.IResolvable): any;
export declare namespace AwsCloudtrail {
    interface FieldSelectorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#ends_with AwsCloudtrail#ends_with}
        */
        readonly endsWith?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#equals AwsCloudtrail#equals}
        */
        readonly equalTo?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#field AwsCloudtrail#field}
        */
        readonly field: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#not_ends_with AwsCloudtrail#not_ends_with}
        */
        readonly notEndsWith?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#not_equals AwsCloudtrail#not_equals}
        */
        readonly notEquals?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#not_starts_with AwsCloudtrail#not_starts_with}
        */
        readonly notStartsWith?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#starts_with AwsCloudtrail#starts_with}
        */
        readonly startsWith?: string[];
    }
    class FieldSelectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FieldSelectorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FieldSelectorProperty | cdktn.IResolvable | undefined);
        private _endsWith?;
        get endsWith(): string[];
        set endsWith(value: string[]);
        resetEndsWith(): void;
        get endsWithInput(): string[] | undefined;
        private _equals?;
        get equalTo(): string[];
        set equalTo(value: string[]);
        resetEqualTo(): void;
        get equalToInput(): string[] | undefined;
        private _field?;
        get field(): string;
        set field(value: string);
        get fieldInput(): string | undefined;
        private _notEndsWith?;
        get notEndsWith(): string[];
        set notEndsWith(value: string[]);
        resetNotEndsWith(): void;
        get notEndsWithInput(): string[] | undefined;
        private _notEquals?;
        get notEquals(): string[];
        set notEquals(value: string[]);
        resetNotEquals(): void;
        get notEqualsInput(): string[] | undefined;
        private _notStartsWith?;
        get notStartsWith(): string[];
        set notStartsWith(value: string[]);
        resetNotStartsWith(): void;
        get notStartsWithInput(): string[] | undefined;
        private _startsWith?;
        get startsWith(): string[];
        set startsWith(value: string[]);
        resetStartsWith(): void;
        get startsWithInput(): string[] | undefined;
    }
    class FieldSelectorPropertyList extends cdktn.ComplexList {
        internalValue?: FieldSelectorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FieldSelectorPropertyOutputReference;
    }
    interface AdvancedEventSelectorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#name AwsCloudtrail#name}
        */
        readonly name?: string;
        /**
        * field_selector block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#field_selector AwsCloudtrail#field_selector}
        */
        readonly fieldSelector: FieldSelectorProperty[] | cdktn.IResolvable;
    }
    class AdvancedEventSelectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdvancedEventSelectorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdvancedEventSelectorProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _fieldSelector;
        get fieldSelector(): FieldSelectorPropertyList;
        putFieldSelector(value: FieldSelectorProperty[] | cdktn.IResolvable): void;
        get fieldSelectorInput(): cdktn.IResolvable | FieldSelectorProperty[] | undefined;
    }
    class AdvancedEventSelectorPropertyList extends cdktn.ComplexList {
        internalValue?: AdvancedEventSelectorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdvancedEventSelectorPropertyOutputReference;
    }
    interface DataResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#type AwsCloudtrail#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#values AwsCloudtrail#values}
        */
        readonly values: string[];
    }
    class DataResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataResourceProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class DataResourcePropertyList extends cdktn.ComplexList {
        internalValue?: DataResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataResourcePropertyOutputReference;
    }
    interface EventSelectorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#exclude_management_event_sources AwsCloudtrail#exclude_management_event_sources}
        */
        readonly excludeManagementEventSources?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#include_management_events AwsCloudtrail#include_management_events}
        */
        readonly includeManagementEvents?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#read_write_type AwsCloudtrail#read_write_type}
        */
        readonly readWriteType?: string;
        /**
        * data_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#data_resource AwsCloudtrail#data_resource}
        */
        readonly dataResource?: DataResourceProperty[] | cdktn.IResolvable;
    }
    class EventSelectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EventSelectorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EventSelectorProperty | cdktn.IResolvable | undefined);
        private _excludeManagementEventSources?;
        get excludeManagementEventSources(): string[];
        set excludeManagementEventSources(value: string[]);
        resetExcludeManagementEventSources(): void;
        get excludeManagementEventSourcesInput(): string[] | undefined;
        private _includeManagementEvents?;
        get includeManagementEvents(): boolean | cdktn.IResolvable;
        set includeManagementEvents(value: boolean | cdktn.IResolvable);
        resetIncludeManagementEvents(): void;
        get includeManagementEventsInput(): boolean | cdktn.IResolvable | undefined;
        private _readWriteType?;
        get readWriteType(): string;
        set readWriteType(value: string);
        resetReadWriteType(): void;
        get readWriteTypeInput(): string | undefined;
        private _dataResource;
        get dataResource(): DataResourcePropertyList;
        putDataResource(value: DataResourceProperty[] | cdktn.IResolvable): void;
        resetDataResource(): void;
        get dataResourceInput(): cdktn.IResolvable | DataResourceProperty[] | undefined;
    }
    class EventSelectorPropertyList extends cdktn.ComplexList {
        internalValue?: EventSelectorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EventSelectorPropertyOutputReference;
    }
    interface InsightSelectorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail#insight_type AwsCloudtrail#insight_type}
        */
        readonly insightType: string;
    }
    class InsightSelectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InsightSelectorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InsightSelectorProperty | cdktn.IResolvable | undefined);
        private _insightType?;
        get insightType(): string;
        set insightType(value: string);
        get insightTypeInput(): string | undefined;
    }
    class InsightSelectorPropertyList extends cdktn.ComplexList {
        internalValue?: InsightSelectorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InsightSelectorPropertyOutputReference;
    }
}
