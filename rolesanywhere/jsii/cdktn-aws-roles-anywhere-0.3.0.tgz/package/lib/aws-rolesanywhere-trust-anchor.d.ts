import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTrustAnchorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor#enabled AwsTrustAnchor#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor#id AwsTrustAnchor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor#name AwsTrustAnchor#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor#tags AwsTrustAnchor#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor#tags_all AwsTrustAnchor#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * notification_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor#notification_settings AwsTrustAnchor#notification_settings}
    */
    readonly notificationSettings?: AwsTrustAnchor.NotificationSettingsProperty[] | cdktn.IResolvable;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor#source AwsTrustAnchor#source}
    */
    readonly source: AwsTrustAnchor.SourceProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor aws_rolesanywhere_trust_anchor}
*/
export declare class AwsTrustAnchor extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_rolesanywhere_trust_anchor";
    /**
    * Generates CDKTN code for importing a AwsTrustAnchor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTrustAnchor to import
    * @param importFromId The id of the existing AwsTrustAnchor that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTrustAnchor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor aws_rolesanywhere_trust_anchor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTrustAnchorConfig
    */
    constructor(scope: Construct, id: string, config: AwsTrustAnchorConfig);
    get arn(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _notificationSettings;
    get notificationSettings(): AwsTrustAnchor.NotificationSettingsPropertyList;
    putNotificationSettings(value: AwsTrustAnchor.NotificationSettingsProperty[] | cdktn.IResolvable): void;
    resetNotificationSettings(): void;
    get notificationSettingsInput(): cdktn.IResolvable | AwsTrustAnchor.NotificationSettingsProperty[] | undefined;
    private _source;
    get source(): AwsTrustAnchor.SourcePropertyOutputReference;
    putSource(value: AwsTrustAnchor.SourceProperty): void;
    get sourceInput(): AwsTrustAnchor.SourceProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTrustAnchorNotificationSettingsPropertyToTerraform(struct?: AwsTrustAnchor.NotificationSettingsProperty | cdktn.IResolvable): any;
export declare function awsTrustAnchorNotificationSettingsPropertyToHclTerraform(struct?: AwsTrustAnchor.NotificationSettingsProperty | cdktn.IResolvable): any;
export declare function awsTrustAnchorSourceDataPropertyToTerraform(struct?: AwsTrustAnchor.SourceDataPropertyOutputReference | AwsTrustAnchor.SourceDataProperty): any;
export declare function awsTrustAnchorSourceDataPropertyToHclTerraform(struct?: AwsTrustAnchor.SourceDataPropertyOutputReference | AwsTrustAnchor.SourceDataProperty): any;
export declare function awsTrustAnchorSourcePropertyToTerraform(struct?: AwsTrustAnchor.SourcePropertyOutputReference | AwsTrustAnchor.SourceProperty): any;
export declare function awsTrustAnchorSourcePropertyToHclTerraform(struct?: AwsTrustAnchor.SourcePropertyOutputReference | AwsTrustAnchor.SourceProperty): any;
export declare namespace AwsTrustAnchor {
    interface NotificationSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor#channel AwsTrustAnchor#channel}
        */
        readonly channel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor#enabled AwsTrustAnchor#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor#event AwsTrustAnchor#event}
        */
        readonly event?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor#threshold AwsTrustAnchor#threshold}
        */
        readonly threshold?: number;
    }
    class NotificationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NotificationSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NotificationSettingsProperty | cdktn.IResolvable | undefined);
        private _channel?;
        get channel(): string;
        set channel(value: string);
        resetChannel(): void;
        get channelInput(): string | undefined;
        get configuredBy(): string;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _event?;
        get event(): string;
        set event(value: string);
        resetEvent(): void;
        get eventInput(): string | undefined;
        private _threshold?;
        get threshold(): number;
        set threshold(value: number);
        resetThreshold(): void;
        get thresholdInput(): number | undefined;
    }
    class NotificationSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: NotificationSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NotificationSettingsPropertyOutputReference;
    }
    interface SourceDataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor#acm_pca_arn AwsTrustAnchor#acm_pca_arn}
        */
        readonly acmPcaArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor#x509_certificate_data AwsTrustAnchor#x509_certificate_data}
        */
        readonly x509CertificateData?: string;
    }
    class SourceDataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceDataProperty | undefined;
        set internalValue(value: SourceDataProperty | undefined);
        private _acmPcaArn?;
        get acmPcaArn(): string;
        set acmPcaArn(value: string);
        resetAcmPcaArn(): void;
        get acmPcaArnInput(): string | undefined;
        private _x509CertificateData?;
        get x509CertificateData(): string;
        set x509CertificateData(value: string);
        resetX509CertificateData(): void;
        get x509CertificateDataInput(): string | undefined;
    }
    interface SourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor#source_type AwsTrustAnchor#source_type}
        */
        readonly sourceType: string;
        /**
        * source_data block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rolesanywhere_trust_anchor#source_data AwsTrustAnchor#source_data}
        */
        readonly sourceData: SourceDataProperty;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceProperty | undefined;
        set internalValue(value: SourceProperty | undefined);
        private _sourceType?;
        get sourceType(): string;
        set sourceType(value: string);
        get sourceTypeInput(): string | undefined;
        private _sourceData;
        get sourceData(): SourceDataPropertyOutputReference;
        putSourceData(value: SourceDataProperty): void;
        get sourceDataInput(): SourceDataProperty | undefined;
    }
}
