import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsScheduledQueryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#execution_role_arn AwsScheduledQuery#execution_role_arn}
    */
    readonly executionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#kms_key_id AwsScheduledQuery#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#name AwsScheduledQuery#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#query_string AwsScheduledQuery#query_string}
    */
    readonly queryString: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#region AwsScheduledQuery#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#tags AwsScheduledQuery#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * error_report_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#error_report_configuration AwsScheduledQuery#error_report_configuration}
    */
    readonly errorReportConfiguration?: AwsScheduledQuery.ErrorReportConfigurationProperty[] | cdktn.IResolvable;
    /**
    * last_run_summary block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#last_run_summary AwsScheduledQuery#last_run_summary}
    */
    readonly lastRunSummary?: AwsScheduledQuery.LastRunSummaryProperty[] | cdktn.IResolvable;
    /**
    * notification_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#notification_configuration AwsScheduledQuery#notification_configuration}
    */
    readonly notificationConfiguration?: AwsScheduledQuery.NotificationConfigurationProperty[] | cdktn.IResolvable;
    /**
    * recently_failed_runs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#recently_failed_runs AwsScheduledQuery#recently_failed_runs}
    */
    readonly recentlyFailedRuns?: AwsScheduledQuery.RecentlyFailedRunsProperty[] | cdktn.IResolvable;
    /**
    * schedule_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#schedule_configuration AwsScheduledQuery#schedule_configuration}
    */
    readonly scheduleConfiguration?: AwsScheduledQuery.ScheduleConfigurationProperty[] | cdktn.IResolvable;
    /**
    * target_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#target_configuration AwsScheduledQuery#target_configuration}
    */
    readonly targetConfiguration?: AwsScheduledQuery.TargetConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#timeouts AwsScheduledQuery#timeouts}
    */
    readonly timeouts?: AwsScheduledQuery.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query aws_timestreamquery_scheduled_query}
*/
export declare class AwsScheduledQuery extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_timestreamquery_scheduled_query";
    /**
    * Generates CDKTN code for importing a AwsScheduledQuery resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsScheduledQuery to import
    * @param importFromId The id of the existing AwsScheduledQuery that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsScheduledQuery to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query aws_timestreamquery_scheduled_query} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsScheduledQueryConfig
    */
    constructor(scope: Construct, id: string, config: AwsScheduledQueryConfig);
    get arn(): string;
    get creationTime(): string;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    get executionRoleArnInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get nextInvocationTime(): string;
    get previousInvocationTime(): string;
    private _queryString?;
    get queryString(): string;
    set queryString(value: string);
    get queryStringInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _errorReportConfiguration;
    get errorReportConfiguration(): AwsScheduledQuery.ErrorReportConfigurationPropertyList;
    putErrorReportConfiguration(value: AwsScheduledQuery.ErrorReportConfigurationProperty[] | cdktn.IResolvable): void;
    resetErrorReportConfiguration(): void;
    get errorReportConfigurationInput(): cdktn.IResolvable | AwsScheduledQuery.ErrorReportConfigurationProperty[] | undefined;
    private _lastRunSummary;
    get lastRunSummary(): AwsScheduledQuery.LastRunSummaryPropertyList;
    putLastRunSummary(value: AwsScheduledQuery.LastRunSummaryProperty[] | cdktn.IResolvable): void;
    resetLastRunSummary(): void;
    get lastRunSummaryInput(): cdktn.IResolvable | AwsScheduledQuery.LastRunSummaryProperty[] | undefined;
    private _notificationConfiguration;
    get notificationConfiguration(): AwsScheduledQuery.NotificationConfigurationPropertyList;
    putNotificationConfiguration(value: AwsScheduledQuery.NotificationConfigurationProperty[] | cdktn.IResolvable): void;
    resetNotificationConfiguration(): void;
    get notificationConfigurationInput(): cdktn.IResolvable | AwsScheduledQuery.NotificationConfigurationProperty[] | undefined;
    private _recentlyFailedRuns;
    get recentlyFailedRuns(): AwsScheduledQuery.RecentlyFailedRunsPropertyList;
    putRecentlyFailedRuns(value: AwsScheduledQuery.RecentlyFailedRunsProperty[] | cdktn.IResolvable): void;
    resetRecentlyFailedRuns(): void;
    get recentlyFailedRunsInput(): cdktn.IResolvable | AwsScheduledQuery.RecentlyFailedRunsProperty[] | undefined;
    private _scheduleConfiguration;
    get scheduleConfiguration(): AwsScheduledQuery.ScheduleConfigurationPropertyList;
    putScheduleConfiguration(value: AwsScheduledQuery.ScheduleConfigurationProperty[] | cdktn.IResolvable): void;
    resetScheduleConfiguration(): void;
    get scheduleConfigurationInput(): cdktn.IResolvable | AwsScheduledQuery.ScheduleConfigurationProperty[] | undefined;
    private _targetConfiguration;
    get targetConfiguration(): AwsScheduledQuery.TargetConfigurationPropertyList;
    putTargetConfiguration(value: AwsScheduledQuery.TargetConfigurationProperty[] | cdktn.IResolvable): void;
    resetTargetConfiguration(): void;
    get targetConfigurationInput(): cdktn.IResolvable | AwsScheduledQuery.TargetConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsScheduledQuery.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsScheduledQuery.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsScheduledQuery.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsScheduledQueryS3ConfigurationPropertyToTerraform(struct?: AwsScheduledQuery.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryS3ConfigurationPropertyToHclTerraform(struct?: AwsScheduledQuery.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryErrorReportConfigurationPropertyToTerraform(struct?: AwsScheduledQuery.ErrorReportConfigurationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryErrorReportConfigurationPropertyToHclTerraform(struct?: AwsScheduledQuery.ErrorReportConfigurationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryErrorReportLocationS3ReportLocationPropertyToTerraform(struct?: AwsScheduledQuery.LastRunSummaryErrorReportLocationS3ReportLocationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryErrorReportLocationS3ReportLocationPropertyToHclTerraform(struct?: AwsScheduledQuery.LastRunSummaryErrorReportLocationS3ReportLocationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryErrorReportLocationPropertyToTerraform(struct?: AwsScheduledQuery.LastRunSummaryErrorReportLocationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryErrorReportLocationPropertyToHclTerraform(struct?: AwsScheduledQuery.LastRunSummaryErrorReportLocationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryExecutionStatsPropertyToTerraform(struct?: AwsScheduledQuery.LastRunSummaryExecutionStatsProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryExecutionStatsPropertyToHclTerraform(struct?: AwsScheduledQuery.LastRunSummaryExecutionStatsProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxPropertyToTerraform(struct?: AwsScheduledQuery.LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxPropertyToHclTerraform(struct?: AwsScheduledQuery.LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryQueryInsightsResponseQuerySpatialCoveragePropertyToTerraform(struct?: AwsScheduledQuery.LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryQueryInsightsResponseQuerySpatialCoveragePropertyToHclTerraform(struct?: AwsScheduledQuery.LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxPropertyToTerraform(struct?: AwsScheduledQuery.LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxPropertyToHclTerraform(struct?: AwsScheduledQuery.LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryQueryInsightsResponseQueryTemporalRangePropertyToTerraform(struct?: AwsScheduledQuery.LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryQueryInsightsResponseQueryTemporalRangePropertyToHclTerraform(struct?: AwsScheduledQuery.LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryQueryInsightsResponsePropertyToTerraform(struct?: AwsScheduledQuery.LastRunSummaryQueryInsightsResponseProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryQueryInsightsResponsePropertyToHclTerraform(struct?: AwsScheduledQuery.LastRunSummaryQueryInsightsResponseProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryPropertyToTerraform(struct?: AwsScheduledQuery.LastRunSummaryProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryLastRunSummaryPropertyToHclTerraform(struct?: AwsScheduledQuery.LastRunSummaryProperty | cdktn.IResolvable): any;
export declare function awsScheduledQuerySnsConfigurationPropertyToTerraform(struct?: AwsScheduledQuery.SnsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQuerySnsConfigurationPropertyToHclTerraform(struct?: AwsScheduledQuery.SnsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryNotificationConfigurationPropertyToTerraform(struct?: AwsScheduledQuery.NotificationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryNotificationConfigurationPropertyToHclTerraform(struct?: AwsScheduledQuery.NotificationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsErrorReportLocationS3ReportLocationPropertyToTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsErrorReportLocationS3ReportLocationPropertyToHclTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsErrorReportLocationPropertyToTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsErrorReportLocationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsErrorReportLocationPropertyToHclTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsErrorReportLocationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsExecutionStatsPropertyToTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsExecutionStatsProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsExecutionStatsPropertyToHclTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsExecutionStatsProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxPropertyToTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxPropertyToHclTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsQueryInsightsResponseQuerySpatialCoveragePropertyToTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsQueryInsightsResponseQuerySpatialCoveragePropertyToHclTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxPropertyToTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxPropertyToHclTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsQueryInsightsResponseQueryTemporalRangePropertyToTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsQueryInsightsResponseQueryTemporalRangePropertyToHclTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsQueryInsightsResponsePropertyToTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsQueryInsightsResponseProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsQueryInsightsResponsePropertyToHclTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsQueryInsightsResponseProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsPropertyToTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryRecentlyFailedRunsPropertyToHclTerraform(struct?: AwsScheduledQuery.RecentlyFailedRunsProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryScheduleConfigurationPropertyToTerraform(struct?: AwsScheduledQuery.ScheduleConfigurationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryScheduleConfigurationPropertyToHclTerraform(struct?: AwsScheduledQuery.ScheduleConfigurationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryDimensionMappingPropertyToTerraform(struct?: AwsScheduledQuery.DimensionMappingProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryDimensionMappingPropertyToHclTerraform(struct?: AwsScheduledQuery.DimensionMappingProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryTargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingPropertyToTerraform(struct?: AwsScheduledQuery.TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryTargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingPropertyToHclTerraform(struct?: AwsScheduledQuery.TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryMixedMeasureMappingPropertyToTerraform(struct?: AwsScheduledQuery.MixedMeasureMappingProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryMixedMeasureMappingPropertyToHclTerraform(struct?: AwsScheduledQuery.MixedMeasureMappingProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryTargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingPropertyToTerraform(struct?: AwsScheduledQuery.TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryTargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingPropertyToHclTerraform(struct?: AwsScheduledQuery.TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryMultiMeasureMappingsPropertyToTerraform(struct?: AwsScheduledQuery.MultiMeasureMappingsProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryMultiMeasureMappingsPropertyToHclTerraform(struct?: AwsScheduledQuery.MultiMeasureMappingsProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryTimestreamConfigurationPropertyToTerraform(struct?: AwsScheduledQuery.TimestreamConfigurationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryTimestreamConfigurationPropertyToHclTerraform(struct?: AwsScheduledQuery.TimestreamConfigurationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryTargetConfigurationPropertyToTerraform(struct?: AwsScheduledQuery.TargetConfigurationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryTargetConfigurationPropertyToHclTerraform(struct?: AwsScheduledQuery.TargetConfigurationProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryTimeoutsPropertyToTerraform(struct?: AwsScheduledQuery.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsScheduledQueryTimeoutsPropertyToHclTerraform(struct?: AwsScheduledQuery.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsScheduledQuery {
    interface S3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#bucket_name AwsScheduledQuery#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#encryption_option AwsScheduledQuery#encryption_option}
        */
        readonly encryptionOption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#object_key_prefix AwsScheduledQuery#object_key_prefix}
        */
        readonly objectKeyPrefix?: string;
    }
    class S3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3ConfigurationProperty | cdktn.IResolvable | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _encryptionOption?;
        get encryptionOption(): string;
        set encryptionOption(value: string);
        resetEncryptionOption(): void;
        get encryptionOptionInput(): string | undefined;
        private _objectKeyPrefix?;
        get objectKeyPrefix(): string;
        set objectKeyPrefix(value: string);
        resetObjectKeyPrefix(): void;
        get objectKeyPrefixInput(): string | undefined;
    }
    class S3ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: S3ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3ConfigurationPropertyOutputReference;
    }
    interface ErrorReportConfigurationProperty {
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#s3_configuration AwsScheduledQuery#s3_configuration}
        */
        readonly s3Configuration?: S3ConfigurationProperty[] | cdktn.IResolvable;
    }
    class ErrorReportConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ErrorReportConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ErrorReportConfigurationProperty | cdktn.IResolvable | undefined);
        private _s3Configuration;
        get s3Configuration(): S3ConfigurationPropertyList;
        putS3Configuration(value: S3ConfigurationProperty[] | cdktn.IResolvable): void;
        resetS3Configuration(): void;
        get s3ConfigurationInput(): cdktn.IResolvable | S3ConfigurationProperty[] | undefined;
    }
    class ErrorReportConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ErrorReportConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ErrorReportConfigurationPropertyOutputReference;
    }
    interface LastRunSummaryErrorReportLocationS3ReportLocationProperty {
    }
    class LastRunSummaryErrorReportLocationS3ReportLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryErrorReportLocationS3ReportLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryErrorReportLocationS3ReportLocationProperty | cdktn.IResolvable | undefined);
        get bucketName(): string;
        get objectKey(): string;
    }
    class LastRunSummaryErrorReportLocationS3ReportLocationPropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryErrorReportLocationS3ReportLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryErrorReportLocationS3ReportLocationPropertyOutputReference;
    }
    interface LastRunSummaryErrorReportLocationProperty {
        /**
        * s3_report_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#s3_report_location AwsScheduledQuery#s3_report_location}
        */
        readonly s3ReportLocation?: LastRunSummaryErrorReportLocationS3ReportLocationProperty[] | cdktn.IResolvable;
    }
    class LastRunSummaryErrorReportLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryErrorReportLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryErrorReportLocationProperty | cdktn.IResolvable | undefined);
        private _s3ReportLocation;
        get s3ReportLocation(): LastRunSummaryErrorReportLocationS3ReportLocationPropertyList;
        putS3ReportLocation(value: LastRunSummaryErrorReportLocationS3ReportLocationProperty[] | cdktn.IResolvable): void;
        resetS3ReportLocation(): void;
        get s3ReportLocationInput(): cdktn.IResolvable | LastRunSummaryErrorReportLocationS3ReportLocationProperty[] | undefined;
    }
    class LastRunSummaryErrorReportLocationPropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryErrorReportLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryErrorReportLocationPropertyOutputReference;
    }
    interface LastRunSummaryExecutionStatsProperty {
    }
    class LastRunSummaryExecutionStatsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryExecutionStatsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryExecutionStatsProperty | cdktn.IResolvable | undefined);
        get bytesMetered(): number;
        get cumulativeBytesScanned(): number;
        get dataWrites(): number;
        get executionTimeInMillis(): number;
        get queryResultRows(): number;
        get recordsIngested(): number;
    }
    class LastRunSummaryExecutionStatsPropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryExecutionStatsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryExecutionStatsPropertyOutputReference;
    }
    interface LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty {
    }
    class LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty | cdktn.IResolvable | undefined);
        get partitionKey(): string[];
        get tableArn(): string;
        get value(): number;
    }
    class LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxPropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxPropertyOutputReference;
    }
    interface LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty {
        /**
        * max block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#max AwsScheduledQuery#max}
        */
        readonly max?: LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty[] | cdktn.IResolvable;
    }
    class LastRunSummaryQueryInsightsResponseQuerySpatialCoveragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty | cdktn.IResolvable | undefined);
        private _max;
        get max(): LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxPropertyList;
        putMax(value: LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty[] | cdktn.IResolvable): void;
        resetMax(): void;
        get maxInput(): cdktn.IResolvable | LastRunSummaryQueryInsightsResponseQuerySpatialCoverageMaxProperty[] | undefined;
    }
    class LastRunSummaryQueryInsightsResponseQuerySpatialCoveragePropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryQueryInsightsResponseQuerySpatialCoveragePropertyOutputReference;
    }
    interface LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty {
    }
    class LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty | cdktn.IResolvable | undefined);
        get tableArn(): string;
        get value(): number;
    }
    class LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxPropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxPropertyOutputReference;
    }
    interface LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty {
        /**
        * max block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#max AwsScheduledQuery#max}
        */
        readonly max?: LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty[] | cdktn.IResolvable;
    }
    class LastRunSummaryQueryInsightsResponseQueryTemporalRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty | cdktn.IResolvable | undefined);
        private _max;
        get max(): LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxPropertyList;
        putMax(value: LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty[] | cdktn.IResolvable): void;
        resetMax(): void;
        get maxInput(): cdktn.IResolvable | LastRunSummaryQueryInsightsResponseQueryTemporalRangeMaxProperty[] | undefined;
    }
    class LastRunSummaryQueryInsightsResponseQueryTemporalRangePropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryQueryInsightsResponseQueryTemporalRangePropertyOutputReference;
    }
    interface LastRunSummaryQueryInsightsResponseProperty {
        /**
        * query_spatial_coverage block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#query_spatial_coverage AwsScheduledQuery#query_spatial_coverage}
        */
        readonly querySpatialCoverage?: LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty[] | cdktn.IResolvable;
        /**
        * query_temporal_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#query_temporal_range AwsScheduledQuery#query_temporal_range}
        */
        readonly queryTemporalRange?: LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty[] | cdktn.IResolvable;
    }
    class LastRunSummaryQueryInsightsResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryQueryInsightsResponseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryQueryInsightsResponseProperty | cdktn.IResolvable | undefined);
        get outputBytes(): number;
        get outputRows(): number;
        get queryTableCount(): number;
        private _querySpatialCoverage;
        get querySpatialCoverage(): LastRunSummaryQueryInsightsResponseQuerySpatialCoveragePropertyList;
        putQuerySpatialCoverage(value: LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty[] | cdktn.IResolvable): void;
        resetQuerySpatialCoverage(): void;
        get querySpatialCoverageInput(): cdktn.IResolvable | LastRunSummaryQueryInsightsResponseQuerySpatialCoverageProperty[] | undefined;
        private _queryTemporalRange;
        get queryTemporalRange(): LastRunSummaryQueryInsightsResponseQueryTemporalRangePropertyList;
        putQueryTemporalRange(value: LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty[] | cdktn.IResolvable): void;
        resetQueryTemporalRange(): void;
        get queryTemporalRangeInput(): cdktn.IResolvable | LastRunSummaryQueryInsightsResponseQueryTemporalRangeProperty[] | undefined;
    }
    class LastRunSummaryQueryInsightsResponsePropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryQueryInsightsResponseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryQueryInsightsResponsePropertyOutputReference;
    }
    interface LastRunSummaryProperty {
        /**
        * error_report_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#error_report_location AwsScheduledQuery#error_report_location}
        */
        readonly errorReportLocation?: LastRunSummaryErrorReportLocationProperty[] | cdktn.IResolvable;
        /**
        * execution_stats block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#execution_stats AwsScheduledQuery#execution_stats}
        */
        readonly executionStats?: LastRunSummaryExecutionStatsProperty[] | cdktn.IResolvable;
        /**
        * query_insights_response block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#query_insights_response AwsScheduledQuery#query_insights_response}
        */
        readonly queryInsightsResponse?: LastRunSummaryQueryInsightsResponseProperty[] | cdktn.IResolvable;
    }
    class LastRunSummaryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastRunSummaryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastRunSummaryProperty | cdktn.IResolvable | undefined);
        get failureReason(): string;
        get invocationTime(): string;
        get runStatus(): string;
        get triggerTime(): string;
        private _errorReportLocation;
        get errorReportLocation(): LastRunSummaryErrorReportLocationPropertyList;
        putErrorReportLocation(value: LastRunSummaryErrorReportLocationProperty[] | cdktn.IResolvable): void;
        resetErrorReportLocation(): void;
        get errorReportLocationInput(): cdktn.IResolvable | LastRunSummaryErrorReportLocationProperty[] | undefined;
        private _executionStats;
        get executionStats(): LastRunSummaryExecutionStatsPropertyList;
        putExecutionStats(value: LastRunSummaryExecutionStatsProperty[] | cdktn.IResolvable): void;
        resetExecutionStats(): void;
        get executionStatsInput(): cdktn.IResolvable | LastRunSummaryExecutionStatsProperty[] | undefined;
        private _queryInsightsResponse;
        get queryInsightsResponse(): LastRunSummaryQueryInsightsResponsePropertyList;
        putQueryInsightsResponse(value: LastRunSummaryQueryInsightsResponseProperty[] | cdktn.IResolvable): void;
        resetQueryInsightsResponse(): void;
        get queryInsightsResponseInput(): cdktn.IResolvable | LastRunSummaryQueryInsightsResponseProperty[] | undefined;
    }
    class LastRunSummaryPropertyList extends cdktn.ComplexList {
        internalValue?: LastRunSummaryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastRunSummaryPropertyOutputReference;
    }
    interface SnsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#topic_arn AwsScheduledQuery#topic_arn}
        */
        readonly topicArn: string;
    }
    class SnsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SnsConfigurationProperty | cdktn.IResolvable | undefined);
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        get topicArnInput(): string | undefined;
    }
    class SnsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SnsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnsConfigurationPropertyOutputReference;
    }
    interface NotificationConfigurationProperty {
        /**
        * sns_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#sns_configuration AwsScheduledQuery#sns_configuration}
        */
        readonly snsConfiguration?: SnsConfigurationProperty[] | cdktn.IResolvable;
    }
    class NotificationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NotificationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NotificationConfigurationProperty | cdktn.IResolvable | undefined);
        private _snsConfiguration;
        get snsConfiguration(): SnsConfigurationPropertyList;
        putSnsConfiguration(value: SnsConfigurationProperty[] | cdktn.IResolvable): void;
        resetSnsConfiguration(): void;
        get snsConfigurationInput(): cdktn.IResolvable | SnsConfigurationProperty[] | undefined;
    }
    class NotificationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: NotificationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NotificationConfigurationPropertyOutputReference;
    }
    interface RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty {
    }
    class RecentlyFailedRunsErrorReportLocationS3ReportLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty | cdktn.IResolvable | undefined);
        get bucketName(): string;
        get objectKey(): string;
    }
    class RecentlyFailedRunsErrorReportLocationS3ReportLocationPropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsErrorReportLocationS3ReportLocationPropertyOutputReference;
    }
    interface RecentlyFailedRunsErrorReportLocationProperty {
        /**
        * s3_report_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#s3_report_location AwsScheduledQuery#s3_report_location}
        */
        readonly s3ReportLocation?: RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty[] | cdktn.IResolvable;
    }
    class RecentlyFailedRunsErrorReportLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsErrorReportLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsErrorReportLocationProperty | cdktn.IResolvable | undefined);
        private _s3ReportLocation;
        get s3ReportLocation(): RecentlyFailedRunsErrorReportLocationS3ReportLocationPropertyList;
        putS3ReportLocation(value: RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty[] | cdktn.IResolvable): void;
        resetS3ReportLocation(): void;
        get s3ReportLocationInput(): cdktn.IResolvable | RecentlyFailedRunsErrorReportLocationS3ReportLocationProperty[] | undefined;
    }
    class RecentlyFailedRunsErrorReportLocationPropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsErrorReportLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsErrorReportLocationPropertyOutputReference;
    }
    interface RecentlyFailedRunsExecutionStatsProperty {
    }
    class RecentlyFailedRunsExecutionStatsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsExecutionStatsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsExecutionStatsProperty | cdktn.IResolvable | undefined);
        get bytesMetered(): number;
        get cumulativeBytesScanned(): number;
        get dataWrites(): number;
        get executionTimeInMillis(): number;
        get queryResultRows(): number;
        get recordsIngested(): number;
    }
    class RecentlyFailedRunsExecutionStatsPropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsExecutionStatsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsExecutionStatsPropertyOutputReference;
    }
    interface RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty {
    }
    class RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty | cdktn.IResolvable | undefined);
        get partitionKey(): string[];
        get tableArn(): string;
        get value(): number;
    }
    class RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxPropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxPropertyOutputReference;
    }
    interface RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty {
        /**
        * max block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#max AwsScheduledQuery#max}
        */
        readonly max?: RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty[] | cdktn.IResolvable;
    }
    class RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoveragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty | cdktn.IResolvable | undefined);
        private _max;
        get max(): RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxPropertyList;
        putMax(value: RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty[] | cdktn.IResolvable): void;
        resetMax(): void;
        get maxInput(): cdktn.IResolvable | RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageMaxProperty[] | undefined;
    }
    class RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoveragePropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoveragePropertyOutputReference;
    }
    interface RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty {
    }
    class RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty | cdktn.IResolvable | undefined);
        get tableArn(): string;
        get value(): number;
    }
    class RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxPropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxPropertyOutputReference;
    }
    interface RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty {
        /**
        * max block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#max AwsScheduledQuery#max}
        */
        readonly max?: RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty[] | cdktn.IResolvable;
    }
    class RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty | cdktn.IResolvable | undefined);
        private _max;
        get max(): RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxPropertyList;
        putMax(value: RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty[] | cdktn.IResolvable): void;
        resetMax(): void;
        get maxInput(): cdktn.IResolvable | RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeMaxProperty[] | undefined;
    }
    class RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangePropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangePropertyOutputReference;
    }
    interface RecentlyFailedRunsQueryInsightsResponseProperty {
        /**
        * query_spatial_coverage block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#query_spatial_coverage AwsScheduledQuery#query_spatial_coverage}
        */
        readonly querySpatialCoverage?: RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty[] | cdktn.IResolvable;
        /**
        * query_temporal_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#query_temporal_range AwsScheduledQuery#query_temporal_range}
        */
        readonly queryTemporalRange?: RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty[] | cdktn.IResolvable;
    }
    class RecentlyFailedRunsQueryInsightsResponsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsQueryInsightsResponseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsQueryInsightsResponseProperty | cdktn.IResolvable | undefined);
        get outputBytes(): number;
        get outputRows(): number;
        get queryTableCount(): number;
        private _querySpatialCoverage;
        get querySpatialCoverage(): RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoveragePropertyList;
        putQuerySpatialCoverage(value: RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty[] | cdktn.IResolvable): void;
        resetQuerySpatialCoverage(): void;
        get querySpatialCoverageInput(): cdktn.IResolvable | RecentlyFailedRunsQueryInsightsResponseQuerySpatialCoverageProperty[] | undefined;
        private _queryTemporalRange;
        get queryTemporalRange(): RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangePropertyList;
        putQueryTemporalRange(value: RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty[] | cdktn.IResolvable): void;
        resetQueryTemporalRange(): void;
        get queryTemporalRangeInput(): cdktn.IResolvable | RecentlyFailedRunsQueryInsightsResponseQueryTemporalRangeProperty[] | undefined;
    }
    class RecentlyFailedRunsQueryInsightsResponsePropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsQueryInsightsResponseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsQueryInsightsResponsePropertyOutputReference;
    }
    interface RecentlyFailedRunsProperty {
        /**
        * error_report_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#error_report_location AwsScheduledQuery#error_report_location}
        */
        readonly errorReportLocation?: RecentlyFailedRunsErrorReportLocationProperty[] | cdktn.IResolvable;
        /**
        * execution_stats block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#execution_stats AwsScheduledQuery#execution_stats}
        */
        readonly executionStats?: RecentlyFailedRunsExecutionStatsProperty[] | cdktn.IResolvable;
        /**
        * query_insights_response block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#query_insights_response AwsScheduledQuery#query_insights_response}
        */
        readonly queryInsightsResponse?: RecentlyFailedRunsQueryInsightsResponseProperty[] | cdktn.IResolvable;
    }
    class RecentlyFailedRunsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecentlyFailedRunsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecentlyFailedRunsProperty | cdktn.IResolvable | undefined);
        get failureReason(): string;
        get invocationTime(): string;
        get runStatus(): string;
        get triggerTime(): string;
        private _errorReportLocation;
        get errorReportLocation(): RecentlyFailedRunsErrorReportLocationPropertyList;
        putErrorReportLocation(value: RecentlyFailedRunsErrorReportLocationProperty[] | cdktn.IResolvable): void;
        resetErrorReportLocation(): void;
        get errorReportLocationInput(): cdktn.IResolvable | RecentlyFailedRunsErrorReportLocationProperty[] | undefined;
        private _executionStats;
        get executionStats(): RecentlyFailedRunsExecutionStatsPropertyList;
        putExecutionStats(value: RecentlyFailedRunsExecutionStatsProperty[] | cdktn.IResolvable): void;
        resetExecutionStats(): void;
        get executionStatsInput(): cdktn.IResolvable | RecentlyFailedRunsExecutionStatsProperty[] | undefined;
        private _queryInsightsResponse;
        get queryInsightsResponse(): RecentlyFailedRunsQueryInsightsResponsePropertyList;
        putQueryInsightsResponse(value: RecentlyFailedRunsQueryInsightsResponseProperty[] | cdktn.IResolvable): void;
        resetQueryInsightsResponse(): void;
        get queryInsightsResponseInput(): cdktn.IResolvable | RecentlyFailedRunsQueryInsightsResponseProperty[] | undefined;
    }
    class RecentlyFailedRunsPropertyList extends cdktn.ComplexList {
        internalValue?: RecentlyFailedRunsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecentlyFailedRunsPropertyOutputReference;
    }
    interface ScheduleConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#schedule_expression AwsScheduledQuery#schedule_expression}
        */
        readonly scheduleExpression: string;
    }
    class ScheduleConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScheduleConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScheduleConfigurationProperty | cdktn.IResolvable | undefined);
        private _scheduleExpression?;
        get scheduleExpression(): string;
        set scheduleExpression(value: string);
        get scheduleExpressionInput(): string | undefined;
    }
    class ScheduleConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ScheduleConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScheduleConfigurationPropertyOutputReference;
    }
    interface DimensionMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#dimension_value_type AwsScheduledQuery#dimension_value_type}
        */
        readonly dimensionValueType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#name AwsScheduledQuery#name}
        */
        readonly name: string;
    }
    class DimensionMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DimensionMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DimensionMappingProperty | cdktn.IResolvable | undefined);
        private _dimensionValueType?;
        get dimensionValueType(): string;
        set dimensionValueType(value: string);
        get dimensionValueTypeInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class DimensionMappingPropertyList extends cdktn.ComplexList {
        internalValue?: DimensionMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DimensionMappingPropertyOutputReference;
    }
    interface TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#measure_value_type AwsScheduledQuery#measure_value_type}
        */
        readonly measureValueType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#source_column AwsScheduledQuery#source_column}
        */
        readonly sourceColumn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#target_multi_measure_attribute_name AwsScheduledQuery#target_multi_measure_attribute_name}
        */
        readonly targetMultiMeasureAttributeName?: string;
    }
    class TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty | cdktn.IResolvable | undefined);
        private _measureValueType?;
        get measureValueType(): string;
        set measureValueType(value: string);
        get measureValueTypeInput(): string | undefined;
        private _sourceColumn?;
        get sourceColumn(): string;
        set sourceColumn(value: string);
        get sourceColumnInput(): string | undefined;
        private _targetMultiMeasureAttributeName?;
        get targetMultiMeasureAttributeName(): string;
        set targetMultiMeasureAttributeName(value: string);
        resetTargetMultiMeasureAttributeName(): void;
        get targetMultiMeasureAttributeNameInput(): string | undefined;
    }
    class TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingPropertyOutputReference;
    }
    interface MixedMeasureMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#measure_name AwsScheduledQuery#measure_name}
        */
        readonly measureName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#measure_value_type AwsScheduledQuery#measure_value_type}
        */
        readonly measureValueType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#source_column AwsScheduledQuery#source_column}
        */
        readonly sourceColumn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#target_measure_name AwsScheduledQuery#target_measure_name}
        */
        readonly targetMeasureName?: string;
        /**
        * multi_measure_attribute_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#multi_measure_attribute_mapping AwsScheduledQuery#multi_measure_attribute_mapping}
        */
        readonly multiMeasureAttributeMapping?: TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty[] | cdktn.IResolvable;
    }
    class MixedMeasureMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MixedMeasureMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MixedMeasureMappingProperty | cdktn.IResolvable | undefined);
        private _measureName?;
        get measureName(): string;
        set measureName(value: string);
        resetMeasureName(): void;
        get measureNameInput(): string | undefined;
        private _measureValueType?;
        get measureValueType(): string;
        set measureValueType(value: string);
        get measureValueTypeInput(): string | undefined;
        private _sourceColumn?;
        get sourceColumn(): string;
        set sourceColumn(value: string);
        resetSourceColumn(): void;
        get sourceColumnInput(): string | undefined;
        private _targetMeasureName?;
        get targetMeasureName(): string;
        set targetMeasureName(value: string);
        resetTargetMeasureName(): void;
        get targetMeasureNameInput(): string | undefined;
        private _multiMeasureAttributeMapping;
        get multiMeasureAttributeMapping(): TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingPropertyList;
        putMultiMeasureAttributeMapping(value: TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty[] | cdktn.IResolvable): void;
        resetMultiMeasureAttributeMapping(): void;
        get multiMeasureAttributeMappingInput(): cdktn.IResolvable | TargetConfigurationTimestreamConfigurationMixedMeasureMappingMultiMeasureAttributeMappingProperty[] | undefined;
    }
    class MixedMeasureMappingPropertyList extends cdktn.ComplexList {
        internalValue?: MixedMeasureMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MixedMeasureMappingPropertyOutputReference;
    }
    interface TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#measure_value_type AwsScheduledQuery#measure_value_type}
        */
        readonly measureValueType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#source_column AwsScheduledQuery#source_column}
        */
        readonly sourceColumn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#target_multi_measure_attribute_name AwsScheduledQuery#target_multi_measure_attribute_name}
        */
        readonly targetMultiMeasureAttributeName?: string;
    }
    class TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty | cdktn.IResolvable | undefined);
        private _measureValueType?;
        get measureValueType(): string;
        set measureValueType(value: string);
        get measureValueTypeInput(): string | undefined;
        private _sourceColumn?;
        get sourceColumn(): string;
        set sourceColumn(value: string);
        get sourceColumnInput(): string | undefined;
        private _targetMultiMeasureAttributeName?;
        get targetMultiMeasureAttributeName(): string;
        set targetMultiMeasureAttributeName(value: string);
        resetTargetMultiMeasureAttributeName(): void;
        get targetMultiMeasureAttributeNameInput(): string | undefined;
    }
    class TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingPropertyOutputReference;
    }
    interface MultiMeasureMappingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#target_multi_measure_name AwsScheduledQuery#target_multi_measure_name}
        */
        readonly targetMultiMeasureName?: string;
        /**
        * multi_measure_attribute_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#multi_measure_attribute_mapping AwsScheduledQuery#multi_measure_attribute_mapping}
        */
        readonly multiMeasureAttributeMapping?: TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty[] | cdktn.IResolvable;
    }
    class MultiMeasureMappingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MultiMeasureMappingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MultiMeasureMappingsProperty | cdktn.IResolvable | undefined);
        private _targetMultiMeasureName?;
        get targetMultiMeasureName(): string;
        set targetMultiMeasureName(value: string);
        resetTargetMultiMeasureName(): void;
        get targetMultiMeasureNameInput(): string | undefined;
        private _multiMeasureAttributeMapping;
        get multiMeasureAttributeMapping(): TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingPropertyList;
        putMultiMeasureAttributeMapping(value: TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty[] | cdktn.IResolvable): void;
        resetMultiMeasureAttributeMapping(): void;
        get multiMeasureAttributeMappingInput(): cdktn.IResolvable | TargetConfigurationTimestreamConfigurationMultiMeasureMappingsMultiMeasureAttributeMappingProperty[] | undefined;
    }
    class MultiMeasureMappingsPropertyList extends cdktn.ComplexList {
        internalValue?: MultiMeasureMappingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MultiMeasureMappingsPropertyOutputReference;
    }
    interface TimestreamConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#database_name AwsScheduledQuery#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#measure_name_column AwsScheduledQuery#measure_name_column}
        */
        readonly measureNameColumn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#table_name AwsScheduledQuery#table_name}
        */
        readonly tableName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#time_column AwsScheduledQuery#time_column}
        */
        readonly timeColumn: string;
        /**
        * dimension_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#dimension_mapping AwsScheduledQuery#dimension_mapping}
        */
        readonly dimensionMapping?: DimensionMappingProperty[] | cdktn.IResolvable;
        /**
        * mixed_measure_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#mixed_measure_mapping AwsScheduledQuery#mixed_measure_mapping}
        */
        readonly mixedMeasureMapping?: MixedMeasureMappingProperty[] | cdktn.IResolvable;
        /**
        * multi_measure_mappings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#multi_measure_mappings AwsScheduledQuery#multi_measure_mappings}
        */
        readonly multiMeasureMappings?: MultiMeasureMappingsProperty[] | cdktn.IResolvable;
    }
    class TimestreamConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TimestreamConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimestreamConfigurationProperty | cdktn.IResolvable | undefined);
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _measureNameColumn?;
        get measureNameColumn(): string;
        set measureNameColumn(value: string);
        resetMeasureNameColumn(): void;
        get measureNameColumnInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
        private _timeColumn?;
        get timeColumn(): string;
        set timeColumn(value: string);
        get timeColumnInput(): string | undefined;
        private _dimensionMapping;
        get dimensionMapping(): DimensionMappingPropertyList;
        putDimensionMapping(value: DimensionMappingProperty[] | cdktn.IResolvable): void;
        resetDimensionMapping(): void;
        get dimensionMappingInput(): cdktn.IResolvable | DimensionMappingProperty[] | undefined;
        private _mixedMeasureMapping;
        get mixedMeasureMapping(): MixedMeasureMappingPropertyList;
        putMixedMeasureMapping(value: MixedMeasureMappingProperty[] | cdktn.IResolvable): void;
        resetMixedMeasureMapping(): void;
        get mixedMeasureMappingInput(): cdktn.IResolvable | MixedMeasureMappingProperty[] | undefined;
        private _multiMeasureMappings;
        get multiMeasureMappings(): MultiMeasureMappingsPropertyList;
        putMultiMeasureMappings(value: MultiMeasureMappingsProperty[] | cdktn.IResolvable): void;
        resetMultiMeasureMappings(): void;
        get multiMeasureMappingsInput(): cdktn.IResolvable | MultiMeasureMappingsProperty[] | undefined;
    }
    class TimestreamConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TimestreamConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TimestreamConfigurationPropertyOutputReference;
    }
    interface TargetConfigurationProperty {
        /**
        * timestream_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#timestream_configuration AwsScheduledQuery#timestream_configuration}
        */
        readonly timestreamConfiguration?: TimestreamConfigurationProperty[] | cdktn.IResolvable;
    }
    class TargetConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationProperty | cdktn.IResolvable | undefined);
        private _timestreamConfiguration;
        get timestreamConfiguration(): TimestreamConfigurationPropertyList;
        putTimestreamConfiguration(value: TimestreamConfigurationProperty[] | cdktn.IResolvable): void;
        resetTimestreamConfiguration(): void;
        get timestreamConfigurationInput(): cdktn.IResolvable | TimestreamConfigurationProperty[] | undefined;
    }
    class TargetConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#create AwsScheduledQuery#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#delete AwsScheduledQuery#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreamquery_scheduled_query#update AwsScheduledQuery#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
