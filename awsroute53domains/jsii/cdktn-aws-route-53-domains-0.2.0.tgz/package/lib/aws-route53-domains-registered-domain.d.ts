import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfRegisteredDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#admin_privacy TfRegisteredDomain#admin_privacy}
    */
    readonly adminPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#auto_renew TfRegisteredDomain#auto_renew}
    */
    readonly autoRenew?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#billing_privacy TfRegisteredDomain#billing_privacy}
    */
    readonly billingPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#domain_name TfRegisteredDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#id TfRegisteredDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#registrant_privacy TfRegisteredDomain#registrant_privacy}
    */
    readonly registrantPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#tags TfRegisteredDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#tags_all TfRegisteredDomain#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#tech_privacy TfRegisteredDomain#tech_privacy}
    */
    readonly techPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#transfer_lock TfRegisteredDomain#transfer_lock}
    */
    readonly transferLock?: boolean | cdktn.IResolvable;
    /**
    * admin_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#admin_contact TfRegisteredDomain#admin_contact}
    */
    readonly adminContact?: TfRegisteredDomain.AdminContactProperty;
    /**
    * billing_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#billing_contact TfRegisteredDomain#billing_contact}
    */
    readonly billingContact?: TfRegisteredDomain.BillingContactProperty;
    /**
    * name_server block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#name_server TfRegisteredDomain#name_server}
    */
    readonly nameServer?: TfRegisteredDomain.NameServerProperty[] | cdktn.IResolvable;
    /**
    * registrant_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#registrant_contact TfRegisteredDomain#registrant_contact}
    */
    readonly registrantContact?: TfRegisteredDomain.RegistrantContactProperty;
    /**
    * tech_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#tech_contact TfRegisteredDomain#tech_contact}
    */
    readonly techContact?: TfRegisteredDomain.TechContactProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#timeouts TfRegisteredDomain#timeouts}
    */
    readonly timeouts?: TfRegisteredDomain.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain aws_route53domains_registered_domain}
*/
export declare class TfRegisteredDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53domains_registered_domain";
    /**
    * Generates CDKTN code for importing a TfRegisteredDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfRegisteredDomain to import
    * @param importFromId The id of the existing TfRegisteredDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfRegisteredDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain aws_route53domains_registered_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfRegisteredDomainConfig
    */
    constructor(scope: Construct, id: string, config: TfRegisteredDomainConfig);
    get abuseContactEmail(): string;
    get abuseContactPhone(): string;
    private _adminPrivacy?;
    get adminPrivacy(): boolean | cdktn.IResolvable;
    set adminPrivacy(value: boolean | cdktn.IResolvable);
    resetAdminPrivacy(): void;
    get adminPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    private _autoRenew?;
    get autoRenew(): boolean | cdktn.IResolvable;
    set autoRenew(value: boolean | cdktn.IResolvable);
    resetAutoRenew(): void;
    get autoRenewInput(): boolean | cdktn.IResolvable | undefined;
    private _billingPrivacy?;
    get billingPrivacy(): boolean | cdktn.IResolvable;
    set billingPrivacy(value: boolean | cdktn.IResolvable);
    resetBillingPrivacy(): void;
    get billingPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    get creationDate(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get expirationDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _registrantPrivacy?;
    get registrantPrivacy(): boolean | cdktn.IResolvable;
    set registrantPrivacy(value: boolean | cdktn.IResolvable);
    resetRegistrantPrivacy(): void;
    get registrantPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    get registrarName(): string;
    get registrarUrl(): string;
    get reseller(): string;
    get statusList(): string[];
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _techPrivacy?;
    get techPrivacy(): boolean | cdktn.IResolvable;
    set techPrivacy(value: boolean | cdktn.IResolvable);
    resetTechPrivacy(): void;
    get techPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    private _transferLock?;
    get transferLock(): boolean | cdktn.IResolvable;
    set transferLock(value: boolean | cdktn.IResolvable);
    resetTransferLock(): void;
    get transferLockInput(): boolean | cdktn.IResolvable | undefined;
    get updatedDate(): string;
    get whoisServer(): string;
    private _adminContact;
    get adminContact(): TfRegisteredDomain.AdminContactPropertyOutputReference;
    putAdminContact(value: TfRegisteredDomain.AdminContactProperty): void;
    resetAdminContact(): void;
    get adminContactInput(): TfRegisteredDomain.AdminContactProperty | undefined;
    private _billingContact;
    get billingContact(): TfRegisteredDomain.BillingContactPropertyOutputReference;
    putBillingContact(value: TfRegisteredDomain.BillingContactProperty): void;
    resetBillingContact(): void;
    get billingContactInput(): TfRegisteredDomain.BillingContactProperty | undefined;
    private _nameServer;
    get nameServer(): TfRegisteredDomain.NameServerPropertyList;
    putNameServer(value: TfRegisteredDomain.NameServerProperty[] | cdktn.IResolvable): void;
    resetNameServer(): void;
    get nameServerInput(): cdktn.IResolvable | TfRegisteredDomain.NameServerProperty[] | undefined;
    private _registrantContact;
    get registrantContact(): TfRegisteredDomain.RegistrantContactPropertyOutputReference;
    putRegistrantContact(value: TfRegisteredDomain.RegistrantContactProperty): void;
    resetRegistrantContact(): void;
    get registrantContactInput(): TfRegisteredDomain.RegistrantContactProperty | undefined;
    private _techContact;
    get techContact(): TfRegisteredDomain.TechContactPropertyOutputReference;
    putTechContact(value: TfRegisteredDomain.TechContactProperty): void;
    resetTechContact(): void;
    get techContactInput(): TfRegisteredDomain.TechContactProperty | undefined;
    private _timeouts;
    get timeouts(): TfRegisteredDomain.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfRegisteredDomain.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfRegisteredDomain.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfRegisteredDomainAdminContactPropertyToTerraform(struct?: TfRegisteredDomain.AdminContactPropertyOutputReference | TfRegisteredDomain.AdminContactProperty): any;
export declare function tfRegisteredDomainAdminContactPropertyToHclTerraform(struct?: TfRegisteredDomain.AdminContactPropertyOutputReference | TfRegisteredDomain.AdminContactProperty): any;
export declare function tfRegisteredDomainBillingContactPropertyToTerraform(struct?: TfRegisteredDomain.BillingContactPropertyOutputReference | TfRegisteredDomain.BillingContactProperty): any;
export declare function tfRegisteredDomainBillingContactPropertyToHclTerraform(struct?: TfRegisteredDomain.BillingContactPropertyOutputReference | TfRegisteredDomain.BillingContactProperty): any;
export declare function tfRegisteredDomainNameServerPropertyToTerraform(struct?: TfRegisteredDomain.NameServerProperty | cdktn.IResolvable): any;
export declare function tfRegisteredDomainNameServerPropertyToHclTerraform(struct?: TfRegisteredDomain.NameServerProperty | cdktn.IResolvable): any;
export declare function tfRegisteredDomainRegistrantContactPropertyToTerraform(struct?: TfRegisteredDomain.RegistrantContactPropertyOutputReference | TfRegisteredDomain.RegistrantContactProperty): any;
export declare function tfRegisteredDomainRegistrantContactPropertyToHclTerraform(struct?: TfRegisteredDomain.RegistrantContactPropertyOutputReference | TfRegisteredDomain.RegistrantContactProperty): any;
export declare function tfRegisteredDomainTechContactPropertyToTerraform(struct?: TfRegisteredDomain.TechContactPropertyOutputReference | TfRegisteredDomain.TechContactProperty): any;
export declare function tfRegisteredDomainTechContactPropertyToHclTerraform(struct?: TfRegisteredDomain.TechContactPropertyOutputReference | TfRegisteredDomain.TechContactProperty): any;
export declare function tfRegisteredDomainTimeoutsPropertyToTerraform(struct?: TfRegisteredDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfRegisteredDomainTimeoutsPropertyToHclTerraform(struct?: TfRegisteredDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfRegisteredDomain {
    interface AdminContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_1 TfRegisteredDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_2 TfRegisteredDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#city TfRegisteredDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#contact_type TfRegisteredDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#country_code TfRegisteredDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#email TfRegisteredDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#extra_params TfRegisteredDomain#extra_params}
        */
        readonly extraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#fax TfRegisteredDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#first_name TfRegisteredDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#last_name TfRegisteredDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#organization_name TfRegisteredDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#phone_number TfRegisteredDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#state TfRegisteredDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#zip_code TfRegisteredDomain#zip_code}
        */
        readonly zipCode?: string;
    }
    class AdminContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdminContactProperty | undefined;
        set internalValue(value: AdminContactProperty | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _extraParams?;
        get extraParams(): {
            [key: string]: string;
        };
        set extraParams(value: {
            [key: string]: string;
        });
        resetExtraParams(): void;
        get extraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
    }
    interface BillingContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_1 TfRegisteredDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_2 TfRegisteredDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#city TfRegisteredDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#contact_type TfRegisteredDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#country_code TfRegisteredDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#email TfRegisteredDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#extra_params TfRegisteredDomain#extra_params}
        */
        readonly extraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#fax TfRegisteredDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#first_name TfRegisteredDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#last_name TfRegisteredDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#organization_name TfRegisteredDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#phone_number TfRegisteredDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#state TfRegisteredDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#zip_code TfRegisteredDomain#zip_code}
        */
        readonly zipCode?: string;
    }
    class BillingContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BillingContactProperty | undefined;
        set internalValue(value: BillingContactProperty | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _extraParams?;
        get extraParams(): {
            [key: string]: string;
        };
        set extraParams(value: {
            [key: string]: string;
        });
        resetExtraParams(): void;
        get extraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
    }
    interface NameServerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#glue_ips TfRegisteredDomain#glue_ips}
        */
        readonly glueIps?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#name TfRegisteredDomain#name}
        */
        readonly name: string;
    }
    class NameServerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NameServerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NameServerProperty | cdktn.IResolvable | undefined);
        private _glueIps?;
        get glueIps(): string[];
        set glueIps(value: string[]);
        resetGlueIps(): void;
        get glueIpsInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class NameServerPropertyList extends cdktn.ComplexList {
        internalValue?: NameServerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NameServerPropertyOutputReference;
    }
    interface RegistrantContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_1 TfRegisteredDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_2 TfRegisteredDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#city TfRegisteredDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#contact_type TfRegisteredDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#country_code TfRegisteredDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#email TfRegisteredDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#extra_params TfRegisteredDomain#extra_params}
        */
        readonly extraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#fax TfRegisteredDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#first_name TfRegisteredDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#last_name TfRegisteredDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#organization_name TfRegisteredDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#phone_number TfRegisteredDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#state TfRegisteredDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#zip_code TfRegisteredDomain#zip_code}
        */
        readonly zipCode?: string;
    }
    class RegistrantContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RegistrantContactProperty | undefined;
        set internalValue(value: RegistrantContactProperty | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _extraParams?;
        get extraParams(): {
            [key: string]: string;
        };
        set extraParams(value: {
            [key: string]: string;
        });
        resetExtraParams(): void;
        get extraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
    }
    interface TechContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_1 TfRegisteredDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_2 TfRegisteredDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#city TfRegisteredDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#contact_type TfRegisteredDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#country_code TfRegisteredDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#email TfRegisteredDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#extra_params TfRegisteredDomain#extra_params}
        */
        readonly extraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#fax TfRegisteredDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#first_name TfRegisteredDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#last_name TfRegisteredDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#organization_name TfRegisteredDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#phone_number TfRegisteredDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#state TfRegisteredDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#zip_code TfRegisteredDomain#zip_code}
        */
        readonly zipCode?: string;
    }
    class TechContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TechContactProperty | undefined;
        set internalValue(value: TechContactProperty | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _extraParams?;
        get extraParams(): {
            [key: string]: string;
        };
        set extraParams(value: {
            [key: string]: string;
        });
        resetExtraParams(): void;
        get extraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#create TfRegisteredDomain#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#update TfRegisteredDomain#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
