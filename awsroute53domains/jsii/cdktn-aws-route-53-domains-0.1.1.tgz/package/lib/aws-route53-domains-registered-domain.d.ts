import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRoute53DomainsRegisteredDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#admin_privacy AwsRoute53DomainsRegisteredDomain#admin_privacy}
    */
    readonly adminPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#auto_renew AwsRoute53DomainsRegisteredDomain#auto_renew}
    */
    readonly autoRenew?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#billing_privacy AwsRoute53DomainsRegisteredDomain#billing_privacy}
    */
    readonly billingPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#domain_name AwsRoute53DomainsRegisteredDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#id AwsRoute53DomainsRegisteredDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#registrant_privacy AwsRoute53DomainsRegisteredDomain#registrant_privacy}
    */
    readonly registrantPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#tags AwsRoute53DomainsRegisteredDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#tags_all AwsRoute53DomainsRegisteredDomain#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#tech_privacy AwsRoute53DomainsRegisteredDomain#tech_privacy}
    */
    readonly techPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#transfer_lock AwsRoute53DomainsRegisteredDomain#transfer_lock}
    */
    readonly transferLock?: boolean | cdktn.IResolvable;
    /**
    * admin_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#admin_contact AwsRoute53DomainsRegisteredDomain#admin_contact}
    */
    readonly adminContact?: AwsRoute53DomainsRegisteredDomain.AdminContactProperty;
    /**
    * billing_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#billing_contact AwsRoute53DomainsRegisteredDomain#billing_contact}
    */
    readonly billingContact?: AwsRoute53DomainsRegisteredDomain.BillingContactProperty;
    /**
    * name_server block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#name_server AwsRoute53DomainsRegisteredDomain#name_server}
    */
    readonly nameServer?: AwsRoute53DomainsRegisteredDomain.NameServerProperty[] | cdktn.IResolvable;
    /**
    * registrant_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#registrant_contact AwsRoute53DomainsRegisteredDomain#registrant_contact}
    */
    readonly registrantContact?: AwsRoute53DomainsRegisteredDomain.RegistrantContactProperty;
    /**
    * tech_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#tech_contact AwsRoute53DomainsRegisteredDomain#tech_contact}
    */
    readonly techContact?: AwsRoute53DomainsRegisteredDomain.TechContactProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#timeouts AwsRoute53DomainsRegisteredDomain#timeouts}
    */
    readonly timeouts?: AwsRoute53DomainsRegisteredDomain.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain aws_route53domains_registered_domain}
*/
export declare class AwsRoute53DomainsRegisteredDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53domains_registered_domain";
    /**
    * Generates CDKTN code for importing a AwsRoute53DomainsRegisteredDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRoute53DomainsRegisteredDomain to import
    * @param importFromId The id of the existing AwsRoute53DomainsRegisteredDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRoute53DomainsRegisteredDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain aws_route53domains_registered_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRoute53DomainsRegisteredDomainConfig
    */
    constructor(scope: Construct, id: string, config: AwsRoute53DomainsRegisteredDomainConfig);
    get abuseContactEmail(): string;
    get abuseContactPhone(): string;
    private _adminPrivacy?;
    get adminPrivacy(): boolean | cdktn.IResolvable;
    set adminPrivacy(value: boolean | cdktn.IResolvable);
    resetAdminPrivacy(): void;
    get adminPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    private _autoRenew?;
    get autoRenew(): boolean | cdktn.IResolvable;
    set autoRenew(value: boolean | cdktn.IResolvable);
    resetAutoRenew(): void;
    get autoRenewInput(): boolean | cdktn.IResolvable | undefined;
    private _billingPrivacy?;
    get billingPrivacy(): boolean | cdktn.IResolvable;
    set billingPrivacy(value: boolean | cdktn.IResolvable);
    resetBillingPrivacy(): void;
    get billingPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    get creationDate(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get expirationDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _registrantPrivacy?;
    get registrantPrivacy(): boolean | cdktn.IResolvable;
    set registrantPrivacy(value: boolean | cdktn.IResolvable);
    resetRegistrantPrivacy(): void;
    get registrantPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    get registrarName(): string;
    get registrarUrl(): string;
    get reseller(): string;
    get statusList(): string[];
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _techPrivacy?;
    get techPrivacy(): boolean | cdktn.IResolvable;
    set techPrivacy(value: boolean | cdktn.IResolvable);
    resetTechPrivacy(): void;
    get techPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    private _transferLock?;
    get transferLock(): boolean | cdktn.IResolvable;
    set transferLock(value: boolean | cdktn.IResolvable);
    resetTransferLock(): void;
    get transferLockInput(): boolean | cdktn.IResolvable | undefined;
    get updatedDate(): string;
    get whoisServer(): string;
    private _adminContact;
    get adminContact(): AwsRoute53DomainsRegisteredDomain.AdminContactPropertyOutputReference;
    putAdminContact(value: AwsRoute53DomainsRegisteredDomain.AdminContactProperty): void;
    resetAdminContact(): void;
    get adminContactInput(): AwsRoute53DomainsRegisteredDomain.AdminContactProperty | undefined;
    private _billingContact;
    get billingContact(): AwsRoute53DomainsRegisteredDomain.BillingContactPropertyOutputReference;
    putBillingContact(value: AwsRoute53DomainsRegisteredDomain.BillingContactProperty): void;
    resetBillingContact(): void;
    get billingContactInput(): AwsRoute53DomainsRegisteredDomain.BillingContactProperty | undefined;
    private _nameServer;
    get nameServer(): AwsRoute53DomainsRegisteredDomain.NameServerPropertyList;
    putNameServer(value: AwsRoute53DomainsRegisteredDomain.NameServerProperty[] | cdktn.IResolvable): void;
    resetNameServer(): void;
    get nameServerInput(): cdktn.IResolvable | AwsRoute53DomainsRegisteredDomain.NameServerProperty[] | undefined;
    private _registrantContact;
    get registrantContact(): AwsRoute53DomainsRegisteredDomain.RegistrantContactPropertyOutputReference;
    putRegistrantContact(value: AwsRoute53DomainsRegisteredDomain.RegistrantContactProperty): void;
    resetRegistrantContact(): void;
    get registrantContactInput(): AwsRoute53DomainsRegisteredDomain.RegistrantContactProperty | undefined;
    private _techContact;
    get techContact(): AwsRoute53DomainsRegisteredDomain.TechContactPropertyOutputReference;
    putTechContact(value: AwsRoute53DomainsRegisteredDomain.TechContactProperty): void;
    resetTechContact(): void;
    get techContactInput(): AwsRoute53DomainsRegisteredDomain.TechContactProperty | undefined;
    private _timeouts;
    get timeouts(): AwsRoute53DomainsRegisteredDomain.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsRoute53DomainsRegisteredDomain.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsRoute53DomainsRegisteredDomain.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRoute53DomainsRegisteredDomainAdminContactPropertyToTerraform(struct?: AwsRoute53DomainsRegisteredDomain.AdminContactPropertyOutputReference | AwsRoute53DomainsRegisteredDomain.AdminContactProperty): any;
export declare function awsRoute53DomainsRegisteredDomainAdminContactPropertyToHclTerraform(struct?: AwsRoute53DomainsRegisteredDomain.AdminContactPropertyOutputReference | AwsRoute53DomainsRegisteredDomain.AdminContactProperty): any;
export declare function awsRoute53DomainsRegisteredDomainBillingContactPropertyToTerraform(struct?: AwsRoute53DomainsRegisteredDomain.BillingContactPropertyOutputReference | AwsRoute53DomainsRegisteredDomain.BillingContactProperty): any;
export declare function awsRoute53DomainsRegisteredDomainBillingContactPropertyToHclTerraform(struct?: AwsRoute53DomainsRegisteredDomain.BillingContactPropertyOutputReference | AwsRoute53DomainsRegisteredDomain.BillingContactProperty): any;
export declare function awsRoute53DomainsRegisteredDomainNameServerPropertyToTerraform(struct?: AwsRoute53DomainsRegisteredDomain.NameServerProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsRegisteredDomainNameServerPropertyToHclTerraform(struct?: AwsRoute53DomainsRegisteredDomain.NameServerProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsRegisteredDomainRegistrantContactPropertyToTerraform(struct?: AwsRoute53DomainsRegisteredDomain.RegistrantContactPropertyOutputReference | AwsRoute53DomainsRegisteredDomain.RegistrantContactProperty): any;
export declare function awsRoute53DomainsRegisteredDomainRegistrantContactPropertyToHclTerraform(struct?: AwsRoute53DomainsRegisteredDomain.RegistrantContactPropertyOutputReference | AwsRoute53DomainsRegisteredDomain.RegistrantContactProperty): any;
export declare function awsRoute53DomainsRegisteredDomainTechContactPropertyToTerraform(struct?: AwsRoute53DomainsRegisteredDomain.TechContactPropertyOutputReference | AwsRoute53DomainsRegisteredDomain.TechContactProperty): any;
export declare function awsRoute53DomainsRegisteredDomainTechContactPropertyToHclTerraform(struct?: AwsRoute53DomainsRegisteredDomain.TechContactPropertyOutputReference | AwsRoute53DomainsRegisteredDomain.TechContactProperty): any;
export declare function awsRoute53DomainsRegisteredDomainTimeoutsPropertyToTerraform(struct?: AwsRoute53DomainsRegisteredDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsRegisteredDomainTimeoutsPropertyToHclTerraform(struct?: AwsRoute53DomainsRegisteredDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsRoute53DomainsRegisteredDomain {
    interface AdminContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_1 AwsRoute53DomainsRegisteredDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_2 AwsRoute53DomainsRegisteredDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#city AwsRoute53DomainsRegisteredDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#contact_type AwsRoute53DomainsRegisteredDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#country_code AwsRoute53DomainsRegisteredDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#email AwsRoute53DomainsRegisteredDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#extra_params AwsRoute53DomainsRegisteredDomain#extra_params}
        */
        readonly extraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#fax AwsRoute53DomainsRegisteredDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#first_name AwsRoute53DomainsRegisteredDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#last_name AwsRoute53DomainsRegisteredDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#organization_name AwsRoute53DomainsRegisteredDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#phone_number AwsRoute53DomainsRegisteredDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#state AwsRoute53DomainsRegisteredDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#zip_code AwsRoute53DomainsRegisteredDomain#zip_code}
        */
        readonly zipCode?: string;
    }
    class AdminContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdminContactProperty | undefined;
        set internalValue(value: AdminContactProperty | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _extraParams?;
        get extraParams(): {
            [key: string]: string;
        };
        set extraParams(value: {
            [key: string]: string;
        });
        resetExtraParams(): void;
        get extraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
    }
    interface BillingContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_1 AwsRoute53DomainsRegisteredDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_2 AwsRoute53DomainsRegisteredDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#city AwsRoute53DomainsRegisteredDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#contact_type AwsRoute53DomainsRegisteredDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#country_code AwsRoute53DomainsRegisteredDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#email AwsRoute53DomainsRegisteredDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#extra_params AwsRoute53DomainsRegisteredDomain#extra_params}
        */
        readonly extraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#fax AwsRoute53DomainsRegisteredDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#first_name AwsRoute53DomainsRegisteredDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#last_name AwsRoute53DomainsRegisteredDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#organization_name AwsRoute53DomainsRegisteredDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#phone_number AwsRoute53DomainsRegisteredDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#state AwsRoute53DomainsRegisteredDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#zip_code AwsRoute53DomainsRegisteredDomain#zip_code}
        */
        readonly zipCode?: string;
    }
    class BillingContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BillingContactProperty | undefined;
        set internalValue(value: BillingContactProperty | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _extraParams?;
        get extraParams(): {
            [key: string]: string;
        };
        set extraParams(value: {
            [key: string]: string;
        });
        resetExtraParams(): void;
        get extraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
    }
    interface NameServerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#glue_ips AwsRoute53DomainsRegisteredDomain#glue_ips}
        */
        readonly glueIps?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#name AwsRoute53DomainsRegisteredDomain#name}
        */
        readonly name: string;
    }
    class NameServerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NameServerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NameServerProperty | cdktn.IResolvable | undefined);
        private _glueIps?;
        get glueIps(): string[];
        set glueIps(value: string[]);
        resetGlueIps(): void;
        get glueIpsInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class NameServerPropertyList extends cdktn.ComplexList {
        internalValue?: NameServerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NameServerPropertyOutputReference;
    }
    interface RegistrantContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_1 AwsRoute53DomainsRegisteredDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_2 AwsRoute53DomainsRegisteredDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#city AwsRoute53DomainsRegisteredDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#contact_type AwsRoute53DomainsRegisteredDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#country_code AwsRoute53DomainsRegisteredDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#email AwsRoute53DomainsRegisteredDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#extra_params AwsRoute53DomainsRegisteredDomain#extra_params}
        */
        readonly extraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#fax AwsRoute53DomainsRegisteredDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#first_name AwsRoute53DomainsRegisteredDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#last_name AwsRoute53DomainsRegisteredDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#organization_name AwsRoute53DomainsRegisteredDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#phone_number AwsRoute53DomainsRegisteredDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#state AwsRoute53DomainsRegisteredDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#zip_code AwsRoute53DomainsRegisteredDomain#zip_code}
        */
        readonly zipCode?: string;
    }
    class RegistrantContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RegistrantContactProperty | undefined;
        set internalValue(value: RegistrantContactProperty | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _extraParams?;
        get extraParams(): {
            [key: string]: string;
        };
        set extraParams(value: {
            [key: string]: string;
        });
        resetExtraParams(): void;
        get extraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
    }
    interface TechContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_1 AwsRoute53DomainsRegisteredDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_2 AwsRoute53DomainsRegisteredDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#city AwsRoute53DomainsRegisteredDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#contact_type AwsRoute53DomainsRegisteredDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#country_code AwsRoute53DomainsRegisteredDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#email AwsRoute53DomainsRegisteredDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#extra_params AwsRoute53DomainsRegisteredDomain#extra_params}
        */
        readonly extraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#fax AwsRoute53DomainsRegisteredDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#first_name AwsRoute53DomainsRegisteredDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#last_name AwsRoute53DomainsRegisteredDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#organization_name AwsRoute53DomainsRegisteredDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#phone_number AwsRoute53DomainsRegisteredDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#state AwsRoute53DomainsRegisteredDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#zip_code AwsRoute53DomainsRegisteredDomain#zip_code}
        */
        readonly zipCode?: string;
    }
    class TechContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TechContactProperty | undefined;
        set internalValue(value: TechContactProperty | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _extraParams?;
        get extraParams(): {
            [key: string]: string;
        };
        set extraParams(value: {
            [key: string]: string;
        });
        resetExtraParams(): void;
        get extraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#create AwsRoute53DomainsRegisteredDomain#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#update AwsRoute53DomainsRegisteredDomain#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
