import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRoute53DomainsDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#admin_privacy AwsRoute53DomainsDomain#admin_privacy}
    */
    readonly adminPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#auto_renew AwsRoute53DomainsDomain#auto_renew}
    */
    readonly autoRenew?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#billing_contact AwsRoute53DomainsDomain#billing_contact}
    */
    readonly billingContact?: AwsRoute53DomainsDomain.BillingContactProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#billing_privacy AwsRoute53DomainsDomain#billing_privacy}
    */
    readonly billingPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#domain_name AwsRoute53DomainsDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#duration_in_years AwsRoute53DomainsDomain#duration_in_years}
    */
    readonly durationInYears?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#name_server AwsRoute53DomainsDomain#name_server}
    */
    readonly nameServer?: AwsRoute53DomainsDomain.NameServerProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#registrant_privacy AwsRoute53DomainsDomain#registrant_privacy}
    */
    readonly registrantPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#tags AwsRoute53DomainsDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#tech_privacy AwsRoute53DomainsDomain#tech_privacy}
    */
    readonly techPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#transfer_lock AwsRoute53DomainsDomain#transfer_lock}
    */
    readonly transferLock?: boolean | cdktn.IResolvable;
    /**
    * admin_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#admin_contact AwsRoute53DomainsDomain#admin_contact}
    */
    readonly adminContact?: AwsRoute53DomainsDomain.AdminContactProperty[] | cdktn.IResolvable;
    /**
    * registrant_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#registrant_contact AwsRoute53DomainsDomain#registrant_contact}
    */
    readonly registrantContact?: AwsRoute53DomainsDomain.RegistrantContactProperty[] | cdktn.IResolvable;
    /**
    * tech_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#tech_contact AwsRoute53DomainsDomain#tech_contact}
    */
    readonly techContact?: AwsRoute53DomainsDomain.TechContactProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#timeouts AwsRoute53DomainsDomain#timeouts}
    */
    readonly timeouts?: AwsRoute53DomainsDomain.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain aws_route53domains_domain}
*/
export declare class AwsRoute53DomainsDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53domains_domain";
    /**
    * Generates CDKTN code for importing a AwsRoute53DomainsDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRoute53DomainsDomain to import
    * @param importFromId The id of the existing AwsRoute53DomainsDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRoute53DomainsDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain aws_route53domains_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRoute53DomainsDomainConfig
    */
    constructor(scope: Construct, id: string, config: AwsRoute53DomainsDomainConfig);
    get abuseContactEmail(): string;
    get abuseContactPhone(): string;
    private _adminPrivacy?;
    get adminPrivacy(): boolean | cdktn.IResolvable;
    set adminPrivacy(value: boolean | cdktn.IResolvable);
    resetAdminPrivacy(): void;
    get adminPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    private _autoRenew?;
    get autoRenew(): boolean | cdktn.IResolvable;
    set autoRenew(value: boolean | cdktn.IResolvable);
    resetAutoRenew(): void;
    get autoRenewInput(): boolean | cdktn.IResolvable | undefined;
    private _billingContact;
    get billingContact(): AwsRoute53DomainsDomain.BillingContactPropertyList;
    putBillingContact(value: AwsRoute53DomainsDomain.BillingContactProperty[] | cdktn.IResolvable): void;
    resetBillingContact(): void;
    get billingContactInput(): cdktn.IResolvable | AwsRoute53DomainsDomain.BillingContactProperty[] | undefined;
    private _billingPrivacy?;
    get billingPrivacy(): boolean | cdktn.IResolvable;
    set billingPrivacy(value: boolean | cdktn.IResolvable);
    resetBillingPrivacy(): void;
    get billingPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    get creationDate(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _durationInYears?;
    get durationInYears(): number;
    set durationInYears(value: number);
    resetDurationInYears(): void;
    get durationInYearsInput(): number | undefined;
    get expirationDate(): string;
    get hostedZoneId(): string;
    private _nameServer;
    get nameServer(): AwsRoute53DomainsDomain.NameServerPropertyList;
    putNameServer(value: AwsRoute53DomainsDomain.NameServerProperty[] | cdktn.IResolvable): void;
    resetNameServer(): void;
    get nameServerInput(): cdktn.IResolvable | AwsRoute53DomainsDomain.NameServerProperty[] | undefined;
    private _registrantPrivacy?;
    get registrantPrivacy(): boolean | cdktn.IResolvable;
    set registrantPrivacy(value: boolean | cdktn.IResolvable);
    resetRegistrantPrivacy(): void;
    get registrantPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    get registrarName(): string;
    get registrarUrl(): string;
    get statusList(): string[];
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _techPrivacy?;
    get techPrivacy(): boolean | cdktn.IResolvable;
    set techPrivacy(value: boolean | cdktn.IResolvable);
    resetTechPrivacy(): void;
    get techPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    private _transferLock?;
    get transferLock(): boolean | cdktn.IResolvable;
    set transferLock(value: boolean | cdktn.IResolvable);
    resetTransferLock(): void;
    get transferLockInput(): boolean | cdktn.IResolvable | undefined;
    get updatedDate(): string;
    get whoisServer(): string;
    private _adminContact;
    get adminContact(): AwsRoute53DomainsDomain.AdminContactPropertyList;
    putAdminContact(value: AwsRoute53DomainsDomain.AdminContactProperty[] | cdktn.IResolvable): void;
    resetAdminContact(): void;
    get adminContactInput(): cdktn.IResolvable | AwsRoute53DomainsDomain.AdminContactProperty[] | undefined;
    private _registrantContact;
    get registrantContact(): AwsRoute53DomainsDomain.RegistrantContactPropertyList;
    putRegistrantContact(value: AwsRoute53DomainsDomain.RegistrantContactProperty[] | cdktn.IResolvable): void;
    resetRegistrantContact(): void;
    get registrantContactInput(): cdktn.IResolvable | AwsRoute53DomainsDomain.RegistrantContactProperty[] | undefined;
    private _techContact;
    get techContact(): AwsRoute53DomainsDomain.TechContactPropertyList;
    putTechContact(value: AwsRoute53DomainsDomain.TechContactProperty[] | cdktn.IResolvable): void;
    resetTechContact(): void;
    get techContactInput(): cdktn.IResolvable | AwsRoute53DomainsDomain.TechContactProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsRoute53DomainsDomain.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsRoute53DomainsDomain.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsRoute53DomainsDomain.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRoute53DomainsDomainBillingContactExtraParamPropertyToTerraform(struct?: AwsRoute53DomainsDomain.BillingContactExtraParamProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainBillingContactExtraParamPropertyToHclTerraform(struct?: AwsRoute53DomainsDomain.BillingContactExtraParamProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainBillingContactPropertyToTerraform(struct?: AwsRoute53DomainsDomain.BillingContactProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainBillingContactPropertyToHclTerraform(struct?: AwsRoute53DomainsDomain.BillingContactProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainNameServerPropertyToTerraform(struct?: AwsRoute53DomainsDomain.NameServerProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainNameServerPropertyToHclTerraform(struct?: AwsRoute53DomainsDomain.NameServerProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainAdminContactExtraParamPropertyToTerraform(struct?: AwsRoute53DomainsDomain.AdminContactExtraParamProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainAdminContactExtraParamPropertyToHclTerraform(struct?: AwsRoute53DomainsDomain.AdminContactExtraParamProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainAdminContactPropertyToTerraform(struct?: AwsRoute53DomainsDomain.AdminContactProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainAdminContactPropertyToHclTerraform(struct?: AwsRoute53DomainsDomain.AdminContactProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainRegistrantContactExtraParamPropertyToTerraform(struct?: AwsRoute53DomainsDomain.RegistrantContactExtraParamProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainRegistrantContactExtraParamPropertyToHclTerraform(struct?: AwsRoute53DomainsDomain.RegistrantContactExtraParamProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainRegistrantContactPropertyToTerraform(struct?: AwsRoute53DomainsDomain.RegistrantContactProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainRegistrantContactPropertyToHclTerraform(struct?: AwsRoute53DomainsDomain.RegistrantContactProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainTechContactExtraParamPropertyToTerraform(struct?: AwsRoute53DomainsDomain.TechContactExtraParamProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainTechContactExtraParamPropertyToHclTerraform(struct?: AwsRoute53DomainsDomain.TechContactExtraParamProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainTechContactPropertyToTerraform(struct?: AwsRoute53DomainsDomain.TechContactProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainTechContactPropertyToHclTerraform(struct?: AwsRoute53DomainsDomain.TechContactProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainTimeoutsPropertyToTerraform(struct?: AwsRoute53DomainsDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsRoute53DomainsDomainTimeoutsPropertyToHclTerraform(struct?: AwsRoute53DomainsDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsRoute53DomainsDomain {
    interface BillingContactExtraParamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#name AwsRoute53DomainsDomain#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#value AwsRoute53DomainsDomain#value}
        */
        readonly value?: string;
    }
    class BillingContactExtraParamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BillingContactExtraParamProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BillingContactExtraParamProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class BillingContactExtraParamPropertyList extends cdktn.ComplexList {
        internalValue?: BillingContactExtraParamProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BillingContactExtraParamPropertyOutputReference;
    }
    interface BillingContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#address_line_1 AwsRoute53DomainsDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#address_line_2 AwsRoute53DomainsDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#city AwsRoute53DomainsDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#contact_type AwsRoute53DomainsDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#country_code AwsRoute53DomainsDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#email AwsRoute53DomainsDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#extra_param AwsRoute53DomainsDomain#extra_param}
        */
        readonly extraParam?: BillingContactExtraParamProperty[] | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#fax AwsRoute53DomainsDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#first_name AwsRoute53DomainsDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#last_name AwsRoute53DomainsDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#organization_name AwsRoute53DomainsDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#phone_number AwsRoute53DomainsDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#state AwsRoute53DomainsDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#zip_code AwsRoute53DomainsDomain#zip_code}
        */
        readonly zipCode?: string;
    }
    class BillingContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BillingContactProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BillingContactProperty | cdktn.IResolvable | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _extraParam;
        get extraParam(): BillingContactExtraParamPropertyList;
        putExtraParam(value: BillingContactExtraParamProperty[] | cdktn.IResolvable): void;
        resetExtraParam(): void;
        get extraParamInput(): cdktn.IResolvable | BillingContactExtraParamProperty[] | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
    }
    class BillingContactPropertyList extends cdktn.ComplexList {
        internalValue?: BillingContactProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BillingContactPropertyOutputReference;
    }
    interface NameServerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#glue_ips AwsRoute53DomainsDomain#glue_ips}
        */
        readonly glueIps?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#name AwsRoute53DomainsDomain#name}
        */
        readonly name?: string;
    }
    class NameServerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NameServerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NameServerProperty | cdktn.IResolvable | undefined);
        private _glueIps?;
        get glueIps(): string[];
        set glueIps(value: string[]);
        resetGlueIps(): void;
        get glueIpsInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
    }
    class NameServerPropertyList extends cdktn.ComplexList {
        internalValue?: NameServerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NameServerPropertyOutputReference;
    }
    interface AdminContactExtraParamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#name AwsRoute53DomainsDomain#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#value AwsRoute53DomainsDomain#value}
        */
        readonly value: string;
    }
    class AdminContactExtraParamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdminContactExtraParamProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdminContactExtraParamProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class AdminContactExtraParamPropertyList extends cdktn.ComplexList {
        internalValue?: AdminContactExtraParamProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdminContactExtraParamPropertyOutputReference;
    }
    interface AdminContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#address_line_1 AwsRoute53DomainsDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#address_line_2 AwsRoute53DomainsDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#city AwsRoute53DomainsDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#contact_type AwsRoute53DomainsDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#country_code AwsRoute53DomainsDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#email AwsRoute53DomainsDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#fax AwsRoute53DomainsDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#first_name AwsRoute53DomainsDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#last_name AwsRoute53DomainsDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#organization_name AwsRoute53DomainsDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#phone_number AwsRoute53DomainsDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#state AwsRoute53DomainsDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#zip_code AwsRoute53DomainsDomain#zip_code}
        */
        readonly zipCode?: string;
        /**
        * extra_param block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#extra_param AwsRoute53DomainsDomain#extra_param}
        */
        readonly extraParam?: AdminContactExtraParamProperty[] | cdktn.IResolvable;
    }
    class AdminContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdminContactProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdminContactProperty | cdktn.IResolvable | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
        private _extraParam;
        get extraParam(): AdminContactExtraParamPropertyList;
        putExtraParam(value: AdminContactExtraParamProperty[] | cdktn.IResolvable): void;
        resetExtraParam(): void;
        get extraParamInput(): cdktn.IResolvable | AdminContactExtraParamProperty[] | undefined;
    }
    class AdminContactPropertyList extends cdktn.ComplexList {
        internalValue?: AdminContactProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdminContactPropertyOutputReference;
    }
    interface RegistrantContactExtraParamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#name AwsRoute53DomainsDomain#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#value AwsRoute53DomainsDomain#value}
        */
        readonly value: string;
    }
    class RegistrantContactExtraParamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegistrantContactExtraParamProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RegistrantContactExtraParamProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RegistrantContactExtraParamPropertyList extends cdktn.ComplexList {
        internalValue?: RegistrantContactExtraParamProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegistrantContactExtraParamPropertyOutputReference;
    }
    interface RegistrantContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#address_line_1 AwsRoute53DomainsDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#address_line_2 AwsRoute53DomainsDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#city AwsRoute53DomainsDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#contact_type AwsRoute53DomainsDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#country_code AwsRoute53DomainsDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#email AwsRoute53DomainsDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#fax AwsRoute53DomainsDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#first_name AwsRoute53DomainsDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#last_name AwsRoute53DomainsDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#organization_name AwsRoute53DomainsDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#phone_number AwsRoute53DomainsDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#state AwsRoute53DomainsDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#zip_code AwsRoute53DomainsDomain#zip_code}
        */
        readonly zipCode?: string;
        /**
        * extra_param block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#extra_param AwsRoute53DomainsDomain#extra_param}
        */
        readonly extraParam?: RegistrantContactExtraParamProperty[] | cdktn.IResolvable;
    }
    class RegistrantContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegistrantContactProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RegistrantContactProperty | cdktn.IResolvable | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
        private _extraParam;
        get extraParam(): RegistrantContactExtraParamPropertyList;
        putExtraParam(value: RegistrantContactExtraParamProperty[] | cdktn.IResolvable): void;
        resetExtraParam(): void;
        get extraParamInput(): cdktn.IResolvable | RegistrantContactExtraParamProperty[] | undefined;
    }
    class RegistrantContactPropertyList extends cdktn.ComplexList {
        internalValue?: RegistrantContactProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegistrantContactPropertyOutputReference;
    }
    interface TechContactExtraParamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#name AwsRoute53DomainsDomain#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#value AwsRoute53DomainsDomain#value}
        */
        readonly value: string;
    }
    class TechContactExtraParamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TechContactExtraParamProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TechContactExtraParamProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TechContactExtraParamPropertyList extends cdktn.ComplexList {
        internalValue?: TechContactExtraParamProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TechContactExtraParamPropertyOutputReference;
    }
    interface TechContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#address_line_1 AwsRoute53DomainsDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#address_line_2 AwsRoute53DomainsDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#city AwsRoute53DomainsDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#contact_type AwsRoute53DomainsDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#country_code AwsRoute53DomainsDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#email AwsRoute53DomainsDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#fax AwsRoute53DomainsDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#first_name AwsRoute53DomainsDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#last_name AwsRoute53DomainsDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#organization_name AwsRoute53DomainsDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#phone_number AwsRoute53DomainsDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#state AwsRoute53DomainsDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#zip_code AwsRoute53DomainsDomain#zip_code}
        */
        readonly zipCode?: string;
        /**
        * extra_param block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#extra_param AwsRoute53DomainsDomain#extra_param}
        */
        readonly extraParam?: TechContactExtraParamProperty[] | cdktn.IResolvable;
    }
    class TechContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TechContactProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TechContactProperty | cdktn.IResolvable | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
        private _extraParam;
        get extraParam(): TechContactExtraParamPropertyList;
        putExtraParam(value: TechContactExtraParamProperty[] | cdktn.IResolvable): void;
        resetExtraParam(): void;
        get extraParamInput(): cdktn.IResolvable | TechContactExtraParamProperty[] | undefined;
    }
    class TechContactPropertyList extends cdktn.ComplexList {
        internalValue?: TechContactProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TechContactPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#create AwsRoute53DomainsDomain#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#delete AwsRoute53DomainsDomain#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#update AwsRoute53DomainsDomain#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
