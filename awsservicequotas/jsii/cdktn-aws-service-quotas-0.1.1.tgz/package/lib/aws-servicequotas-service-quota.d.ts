import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsServicequotasServiceQuotaConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_service_quota#id AwsServicequotasServiceQuota#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_service_quota#quota_code AwsServicequotasServiceQuota#quota_code}
    */
    readonly quotaCode: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_service_quota#region AwsServicequotasServiceQuota#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_service_quota#service_code AwsServicequotasServiceQuota#service_code}
    */
    readonly serviceCode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_service_quota#value AwsServicequotasServiceQuota#value}
    */
    readonly value: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_service_quota aws_servicequotas_service_quota}
*/
export declare class AwsServicequotasServiceQuota extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_servicequotas_service_quota";
    /**
    * Generates CDKTN code for importing a AwsServicequotasServiceQuota resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsServicequotasServiceQuota to import
    * @param importFromId The id of the existing AwsServicequotasServiceQuota that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_service_quota#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsServicequotasServiceQuota to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_service_quota aws_servicequotas_service_quota} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsServicequotasServiceQuotaConfig
    */
    constructor(scope: Construct, id: string, config: AwsServicequotasServiceQuotaConfig);
    get adjustable(): cdktn.IResolvable;
    get arn(): string;
    get defaultValue(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _quotaCode?;
    get quotaCode(): string;
    set quotaCode(value: string);
    get quotaCodeInput(): string | undefined;
    get quotaName(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get requestId(): string;
    get requestStatus(): string;
    private _serviceCode?;
    get serviceCode(): string;
    set serviceCode(value: string);
    get serviceCodeInput(): string | undefined;
    get serviceName(): string;
    private _usageMetric;
    get usageMetric(): AwsServicequotasServiceQuota.UsageMetricPropertyList;
    private _value?;
    get value(): number;
    set value(value: number);
    get valueInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsServicequotasServiceQuotaMetricDimensionsPropertyToTerraform(struct?: AwsServicequotasServiceQuota.MetricDimensionsProperty): any;
export declare function awsServicequotasServiceQuotaMetricDimensionsPropertyToHclTerraform(struct?: AwsServicequotasServiceQuota.MetricDimensionsProperty): any;
export declare function awsServicequotasServiceQuotaUsageMetricPropertyToTerraform(struct?: AwsServicequotasServiceQuota.UsageMetricProperty): any;
export declare function awsServicequotasServiceQuotaUsageMetricPropertyToHclTerraform(struct?: AwsServicequotasServiceQuota.UsageMetricProperty): any;
export declare namespace AwsServicequotasServiceQuota {
    interface MetricDimensionsProperty {
    }
    class MetricDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetricDimensionsProperty | undefined;
        set internalValue(value: MetricDimensionsProperty | undefined);
        get class(): string;
        get resource(): string;
        get service(): string;
        get type(): string;
    }
    class MetricDimensionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetricDimensionsPropertyOutputReference;
    }
    interface UsageMetricProperty {
    }
    class UsageMetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UsageMetricProperty | undefined;
        set internalValue(value: UsageMetricProperty | undefined);
        private _metricDimensions;
        get metricDimensions(): MetricDimensionsPropertyList;
        get metricName(): string;
        get metricNamespace(): string;
        get metricStatisticRecommendation(): string;
    }
    class UsageMetricPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UsageMetricPropertyOutputReference;
    }
}
