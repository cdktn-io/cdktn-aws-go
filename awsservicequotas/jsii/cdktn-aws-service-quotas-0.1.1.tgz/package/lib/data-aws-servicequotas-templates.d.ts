import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsServicequotasTemplatesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicequotas_templates#aws_region DataAwsServicequotasTemplates#aws_region}
    */
    readonly awsRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicequotas_templates#region DataAwsServicequotasTemplates#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicequotas_templates aws_servicequotas_templates}
*/
export declare class DataAwsServicequotasTemplates extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_servicequotas_templates";
    /**
    * Generates CDKTN code for importing a DataAwsServicequotasTemplates resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsServicequotasTemplates to import
    * @param importFromId The id of the existing DataAwsServicequotasTemplates that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicequotas_templates#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsServicequotasTemplates to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicequotas_templates aws_servicequotas_templates} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsServicequotasTemplatesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsServicequotasTemplatesConfig);
    private _awsRegion?;
    get awsRegion(): string;
    set awsRegion(value: string);
    resetAwsRegion(): void;
    get awsRegionInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _templates;
    get templates(): DataAwsServicequotasTemplates.TemplatesPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsServicequotasTemplatesTemplatesPropertyToTerraform(struct?: DataAwsServicequotasTemplates.TemplatesProperty): any;
export declare function dataAwsServicequotasTemplatesTemplatesPropertyToHclTerraform(struct?: DataAwsServicequotasTemplates.TemplatesProperty): any;
export declare namespace DataAwsServicequotasTemplates {
    interface TemplatesProperty {
    }
    class TemplatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TemplatesProperty | undefined;
        set internalValue(value: TemplatesProperty | undefined);
        get globalQuota(): cdktn.IResolvable;
        get quotaCode(): string;
        get quotaName(): string;
        get region(): string;
        get serviceCode(): string;
        get serviceName(): string;
        get unit(): string;
        get value(): number;
    }
    class TemplatesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TemplatesPropertyOutputReference;
    }
}
