import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAutoManagementConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_auto_management#exclusion_list TfAutoManagement#exclusion_list}
    */
    readonly exclusionList?: {
        [key: string]: string[];
    } | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_auto_management#notification_arn TfAutoManagement#notification_arn}
    */
    readonly notificationArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_auto_management#opt_in_level TfAutoManagement#opt_in_level}
    */
    readonly optInLevel: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_auto_management#opt_in_type TfAutoManagement#opt_in_type}
    */
    readonly optInType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_auto_management#region TfAutoManagement#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_auto_management aws_servicequotas_auto_management}
*/
export declare class TfAutoManagement extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_servicequotas_auto_management";
    /**
    * Generates CDKTN code for importing a TfAutoManagement resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAutoManagement to import
    * @param importFromId The id of the existing TfAutoManagement that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_auto_management#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAutoManagement to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_auto_management aws_servicequotas_auto_management} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAutoManagementConfig
    */
    constructor(scope: Construct, id: string, config: TfAutoManagementConfig);
    private _exclusionList?;
    get exclusionList(): {
        [key: string]: string[];
    } | cdktn.IResolvable;
    set exclusionList(value: {
        [key: string]: string[];
    } | cdktn.IResolvable);
    resetExclusionList(): void;
    get exclusionListInput(): cdktn.IResolvable | {
        [key: string]: string[];
    } | undefined;
    get id(): string;
    private _notificationArn?;
    get notificationArn(): string;
    set notificationArn(value: string);
    resetNotificationArn(): void;
    get notificationArnInput(): string | undefined;
    private _optInLevel?;
    get optInLevel(): string;
    set optInLevel(value: string);
    get optInLevelInput(): string | undefined;
    private _optInType?;
    get optInType(): string;
    set optInType(value: string);
    get optInTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
