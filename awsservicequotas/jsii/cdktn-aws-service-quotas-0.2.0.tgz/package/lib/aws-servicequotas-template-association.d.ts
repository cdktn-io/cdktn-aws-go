import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfTemplateAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_template_association#region TfTemplateAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_template_association#skip_destroy TfTemplateAssociation#skip_destroy}
    */
    readonly skipDestroy?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_template_association aws_servicequotas_template_association}
*/
export declare class TfTemplateAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_servicequotas_template_association";
    /**
    * Generates CDKTN code for importing a TfTemplateAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfTemplateAssociation to import
    * @param importFromId The id of the existing TfTemplateAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_template_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfTemplateAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicequotas_template_association aws_servicequotas_template_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfTemplateAssociationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfTemplateAssociationConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _skipDestroy?;
    get skipDestroy(): boolean | cdktn.IResolvable;
    set skipDestroy(value: boolean | cdktn.IResolvable);
    resetSkipDestroy(): void;
    get skipDestroyInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
