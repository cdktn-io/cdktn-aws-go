import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfLaunchPathsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_launch_paths#accept_language DataTfLaunchPaths#accept_language}
    */
    readonly acceptLanguage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_launch_paths#id DataTfLaunchPaths#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_launch_paths#product_id DataTfLaunchPaths#product_id}
    */
    readonly productId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_launch_paths#region DataTfLaunchPaths#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_launch_paths#timeouts DataTfLaunchPaths#timeouts}
    */
    readonly timeouts?: DataTfLaunchPaths.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_launch_paths aws_servicecatalog_launch_paths}
*/
export declare class DataTfLaunchPaths extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_servicecatalog_launch_paths";
    /**
    * Generates CDKTN code for importing a DataTfLaunchPaths resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfLaunchPaths to import
    * @param importFromId The id of the existing DataTfLaunchPaths that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_launch_paths#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfLaunchPaths to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_launch_paths aws_servicecatalog_launch_paths} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfLaunchPathsConfig
    */
    constructor(scope: Construct, id: string, config: DataTfLaunchPathsConfig);
    private _acceptLanguage?;
    get acceptLanguage(): string;
    set acceptLanguage(value: string);
    resetAcceptLanguage(): void;
    get acceptLanguageInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _productId?;
    get productId(): string;
    set productId(value: string);
    get productIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _summaries;
    get summaries(): DataTfLaunchPaths.SummariesPropertyList;
    private _timeouts;
    get timeouts(): DataTfLaunchPaths.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataTfLaunchPaths.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataTfLaunchPaths.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfLaunchPathsConstraintSummariesPropertyToTerraform(struct?: DataTfLaunchPaths.ConstraintSummariesProperty): any;
export declare function dataTfLaunchPathsConstraintSummariesPropertyToHclTerraform(struct?: DataTfLaunchPaths.ConstraintSummariesProperty): any;
export declare function dataTfLaunchPathsSummariesPropertyToTerraform(struct?: DataTfLaunchPaths.SummariesProperty): any;
export declare function dataTfLaunchPathsSummariesPropertyToHclTerraform(struct?: DataTfLaunchPaths.SummariesProperty): any;
export declare function dataTfLaunchPathsTimeoutsPropertyToTerraform(struct?: DataTfLaunchPaths.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataTfLaunchPathsTimeoutsPropertyToHclTerraform(struct?: DataTfLaunchPaths.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataTfLaunchPaths {
    interface ConstraintSummariesProperty {
    }
    class ConstraintSummariesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConstraintSummariesProperty | undefined;
        set internalValue(value: ConstraintSummariesProperty | undefined);
        get description(): string;
        get type(): string;
    }
    class ConstraintSummariesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConstraintSummariesPropertyOutputReference;
    }
    interface SummariesProperty {
    }
    class SummariesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SummariesProperty | undefined;
        set internalValue(value: SummariesProperty | undefined);
        private _constraintSummaries;
        get constraintSummaries(): ConstraintSummariesPropertyList;
        get name(): string;
        get pathId(): string;
        private _tags;
        get tags(): cdktn.StringMap;
    }
    class SummariesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SummariesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_launch_paths#read DataTfLaunchPaths#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
