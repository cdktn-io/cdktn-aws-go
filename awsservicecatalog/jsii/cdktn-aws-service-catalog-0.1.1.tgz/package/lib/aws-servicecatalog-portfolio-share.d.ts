import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsServicecatalogPortfolioShareConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share#accept_language AwsServicecatalogPortfolioShare#accept_language}
    */
    readonly acceptLanguage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share#id AwsServicecatalogPortfolioShare#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share#portfolio_id AwsServicecatalogPortfolioShare#portfolio_id}
    */
    readonly portfolioId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share#principal_id AwsServicecatalogPortfolioShare#principal_id}
    */
    readonly principalId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share#region AwsServicecatalogPortfolioShare#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share#share_principals AwsServicecatalogPortfolioShare#share_principals}
    */
    readonly sharePrincipals?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share#share_tag_options AwsServicecatalogPortfolioShare#share_tag_options}
    */
    readonly shareTagOptions?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share#type AwsServicecatalogPortfolioShare#type}
    */
    readonly type: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share#wait_for_acceptance AwsServicecatalogPortfolioShare#wait_for_acceptance}
    */
    readonly waitForAcceptance?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share#timeouts AwsServicecatalogPortfolioShare#timeouts}
    */
    readonly timeouts?: AwsServicecatalogPortfolioShare.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share aws_servicecatalog_portfolio_share}
*/
export declare class AwsServicecatalogPortfolioShare extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_servicecatalog_portfolio_share";
    /**
    * Generates CDKTN code for importing a AwsServicecatalogPortfolioShare resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsServicecatalogPortfolioShare to import
    * @param importFromId The id of the existing AwsServicecatalogPortfolioShare that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsServicecatalogPortfolioShare to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share aws_servicecatalog_portfolio_share} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsServicecatalogPortfolioShareConfig
    */
    constructor(scope: Construct, id: string, config: AwsServicecatalogPortfolioShareConfig);
    private _acceptLanguage?;
    get acceptLanguage(): string;
    set acceptLanguage(value: string);
    resetAcceptLanguage(): void;
    get acceptLanguageInput(): string | undefined;
    get accepted(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _portfolioId?;
    get portfolioId(): string;
    set portfolioId(value: string);
    get portfolioIdInput(): string | undefined;
    private _principalId?;
    get principalId(): string;
    set principalId(value: string);
    get principalIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sharePrincipals?;
    get sharePrincipals(): boolean | cdktn.IResolvable;
    set sharePrincipals(value: boolean | cdktn.IResolvable);
    resetSharePrincipals(): void;
    get sharePrincipalsInput(): boolean | cdktn.IResolvable | undefined;
    private _shareTagOptions?;
    get shareTagOptions(): boolean | cdktn.IResolvable;
    set shareTagOptions(value: boolean | cdktn.IResolvable);
    resetShareTagOptions(): void;
    get shareTagOptionsInput(): boolean | cdktn.IResolvable | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _waitForAcceptance?;
    get waitForAcceptance(): boolean | cdktn.IResolvable;
    set waitForAcceptance(value: boolean | cdktn.IResolvable);
    resetWaitForAcceptance(): void;
    get waitForAcceptanceInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): AwsServicecatalogPortfolioShare.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsServicecatalogPortfolioShare.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsServicecatalogPortfolioShare.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsServicecatalogPortfolioShareTimeoutsPropertyToTerraform(struct?: AwsServicecatalogPortfolioShare.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsServicecatalogPortfolioShareTimeoutsPropertyToHclTerraform(struct?: AwsServicecatalogPortfolioShare.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsServicecatalogPortfolioShare {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share#create AwsServicecatalogPortfolioShare#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share#delete AwsServicecatalogPortfolioShare#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share#read AwsServicecatalogPortfolioShare#read}
        */
        readonly read?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_portfolio_share#update AwsServicecatalogPortfolioShare#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
