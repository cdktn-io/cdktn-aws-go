import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsServicecatalogBudgetResourceAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_budget_resource_association#budget_name AwsServicecatalogBudgetResourceAssociation#budget_name}
    */
    readonly budgetName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_budget_resource_association#id AwsServicecatalogBudgetResourceAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_budget_resource_association#region AwsServicecatalogBudgetResourceAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_budget_resource_association#resource_id AwsServicecatalogBudgetResourceAssociation#resource_id}
    */
    readonly resourceId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_budget_resource_association#timeouts AwsServicecatalogBudgetResourceAssociation#timeouts}
    */
    readonly timeouts?: AwsServicecatalogBudgetResourceAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_budget_resource_association aws_servicecatalog_budget_resource_association}
*/
export declare class AwsServicecatalogBudgetResourceAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_servicecatalog_budget_resource_association";
    /**
    * Generates CDKTN code for importing a AwsServicecatalogBudgetResourceAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsServicecatalogBudgetResourceAssociation to import
    * @param importFromId The id of the existing AwsServicecatalogBudgetResourceAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_budget_resource_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsServicecatalogBudgetResourceAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_budget_resource_association aws_servicecatalog_budget_resource_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsServicecatalogBudgetResourceAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsServicecatalogBudgetResourceAssociationConfig);
    private _budgetName?;
    get budgetName(): string;
    set budgetName(value: string);
    get budgetNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsServicecatalogBudgetResourceAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsServicecatalogBudgetResourceAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsServicecatalogBudgetResourceAssociation.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsServicecatalogBudgetResourceAssociationTimeoutsPropertyToTerraform(struct?: AwsServicecatalogBudgetResourceAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsServicecatalogBudgetResourceAssociationTimeoutsPropertyToHclTerraform(struct?: AwsServicecatalogBudgetResourceAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsServicecatalogBudgetResourceAssociation {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_budget_resource_association#create AwsServicecatalogBudgetResourceAssociation#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_budget_resource_association#delete AwsServicecatalogBudgetResourceAssociation#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_budget_resource_association#read AwsServicecatalogBudgetResourceAssociation#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
