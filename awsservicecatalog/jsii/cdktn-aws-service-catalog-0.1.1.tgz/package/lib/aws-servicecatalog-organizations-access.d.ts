import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsServicecatalogOrganizationsAccessConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_organizations_access#enabled AwsServicecatalogOrganizationsAccess#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_organizations_access#id AwsServicecatalogOrganizationsAccess#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_organizations_access#timeouts AwsServicecatalogOrganizationsAccess#timeouts}
    */
    readonly timeouts?: AwsServicecatalogOrganizationsAccess.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_organizations_access aws_servicecatalog_organizations_access}
*/
export declare class AwsServicecatalogOrganizationsAccess extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_servicecatalog_organizations_access";
    /**
    * Generates CDKTN code for importing a AwsServicecatalogOrganizationsAccess resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsServicecatalogOrganizationsAccess to import
    * @param importFromId The id of the existing AwsServicecatalogOrganizationsAccess that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_organizations_access#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsServicecatalogOrganizationsAccess to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_organizations_access aws_servicecatalog_organizations_access} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsServicecatalogOrganizationsAccessConfig
    */
    constructor(scope: Construct, id: string, config: AwsServicecatalogOrganizationsAccessConfig);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsServicecatalogOrganizationsAccess.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsServicecatalogOrganizationsAccess.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsServicecatalogOrganizationsAccess.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsServicecatalogOrganizationsAccessTimeoutsPropertyToTerraform(struct?: AwsServicecatalogOrganizationsAccess.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsServicecatalogOrganizationsAccessTimeoutsPropertyToHclTerraform(struct?: AwsServicecatalogOrganizationsAccess.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsServicecatalogOrganizationsAccess {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_organizations_access#read AwsServicecatalogOrganizationsAccess#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
