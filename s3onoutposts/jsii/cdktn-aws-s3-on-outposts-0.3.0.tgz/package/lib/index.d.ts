export * from './aws-s3-outposts-endpoint';
