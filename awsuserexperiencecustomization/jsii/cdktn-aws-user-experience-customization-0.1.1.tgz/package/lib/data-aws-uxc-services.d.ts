import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsUxcServicesConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/uxc_services aws_uxc_services}
*/
export declare class DataAwsUxcServices extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_uxc_services";
    /**
    * Generates CDKTN code for importing a DataAwsUxcServices resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsUxcServices to import
    * @param importFromId The id of the existing DataAwsUxcServices that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/uxc_services#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsUxcServices to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/uxc_services aws_uxc_services} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsUxcServicesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsUxcServicesConfig);
    get services(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
