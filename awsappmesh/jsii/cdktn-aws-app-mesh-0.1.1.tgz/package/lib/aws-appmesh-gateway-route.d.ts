import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppmeshGatewayRouteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#id AwsAppmeshGatewayRoute#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#mesh_name AwsAppmeshGatewayRoute#mesh_name}
    */
    readonly meshName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#mesh_owner AwsAppmeshGatewayRoute#mesh_owner}
    */
    readonly meshOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#name AwsAppmeshGatewayRoute#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#region AwsAppmeshGatewayRoute#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#tags AwsAppmeshGatewayRoute#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#tags_all AwsAppmeshGatewayRoute#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#virtual_gateway_name AwsAppmeshGatewayRoute#virtual_gateway_name}
    */
    readonly virtualGatewayName: string;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#spec AwsAppmeshGatewayRoute#spec}
    */
    readonly spec: AwsAppmeshGatewayRoute.SpecProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route aws_appmesh_gateway_route}
*/
export declare class AwsAppmeshGatewayRoute extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appmesh_gateway_route";
    /**
    * Generates CDKTN code for importing a AwsAppmeshGatewayRoute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppmeshGatewayRoute to import
    * @param importFromId The id of the existing AwsAppmeshGatewayRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppmeshGatewayRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route aws_appmesh_gateway_route} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppmeshGatewayRouteConfig
    */
    constructor(scope: Construct, id: string, config: AwsAppmeshGatewayRouteConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _meshName?;
    get meshName(): string;
    set meshName(value: string);
    get meshNameInput(): string | undefined;
    private _meshOwner?;
    get meshOwner(): string;
    set meshOwner(value: string);
    resetMeshOwner(): void;
    get meshOwnerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _virtualGatewayName?;
    get virtualGatewayName(): string;
    set virtualGatewayName(value: string);
    get virtualGatewayNameInput(): string | undefined;
    private _spec;
    get spec(): AwsAppmeshGatewayRoute.SpecPropertyOutputReference;
    putSpec(value: AwsAppmeshGatewayRoute.SpecProperty): void;
    get specInput(): AwsAppmeshGatewayRoute.SpecProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppmeshGatewayRouteSpecGrpcRouteActionTargetVirtualServicePropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecGrpcRouteActionTargetVirtualServicePropertyOutputReference | AwsAppmeshGatewayRoute.SpecGrpcRouteActionTargetVirtualServiceProperty): any;
export declare function awsAppmeshGatewayRouteSpecGrpcRouteActionTargetVirtualServicePropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecGrpcRouteActionTargetVirtualServicePropertyOutputReference | AwsAppmeshGatewayRoute.SpecGrpcRouteActionTargetVirtualServiceProperty): any;
export declare function awsAppmeshGatewayRouteSpecGrpcRouteActionTargetPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecGrpcRouteActionTargetPropertyOutputReference | AwsAppmeshGatewayRoute.SpecGrpcRouteActionTargetProperty): any;
export declare function awsAppmeshGatewayRouteSpecGrpcRouteActionTargetPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecGrpcRouteActionTargetPropertyOutputReference | AwsAppmeshGatewayRoute.SpecGrpcRouteActionTargetProperty): any;
export declare function awsAppmeshGatewayRouteSpecGrpcRouteActionPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecGrpcRouteActionPropertyOutputReference | AwsAppmeshGatewayRoute.SpecGrpcRouteActionProperty): any;
export declare function awsAppmeshGatewayRouteSpecGrpcRouteActionPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecGrpcRouteActionPropertyOutputReference | AwsAppmeshGatewayRoute.SpecGrpcRouteActionProperty): any;
export declare function awsAppmeshGatewayRouteSpecGrpcRouteMatchPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecGrpcRouteMatchPropertyOutputReference | AwsAppmeshGatewayRoute.SpecGrpcRouteMatchProperty): any;
export declare function awsAppmeshGatewayRouteSpecGrpcRouteMatchPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecGrpcRouteMatchPropertyOutputReference | AwsAppmeshGatewayRoute.SpecGrpcRouteMatchProperty): any;
export declare function awsAppmeshGatewayRouteGrpcRoutePropertyToTerraform(struct?: AwsAppmeshGatewayRoute.GrpcRoutePropertyOutputReference | AwsAppmeshGatewayRoute.GrpcRouteProperty): any;
export declare function awsAppmeshGatewayRouteGrpcRoutePropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.GrpcRoutePropertyOutputReference | AwsAppmeshGatewayRoute.GrpcRouteProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteActionRewriteHostnamePropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteActionRewriteHostnamePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteActionRewriteHostnameProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteActionRewriteHostnamePropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteActionRewriteHostnamePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteActionRewriteHostnameProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteActionRewritePathPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteActionRewritePathPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteActionRewritePathProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteActionRewritePathPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteActionRewritePathPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteActionRewritePathProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteActionRewritePrefixPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteActionRewritePrefixPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteActionRewritePrefixProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteActionRewritePrefixPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteActionRewritePrefixPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteActionRewritePrefixProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteActionRewritePropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteActionRewritePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteActionRewriteProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteActionRewritePropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteActionRewritePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteActionRewriteProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteActionTargetVirtualServicePropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteActionTargetVirtualServicePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteActionTargetVirtualServiceProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteActionTargetVirtualServicePropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteActionTargetVirtualServicePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteActionTargetVirtualServiceProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteActionTargetPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteActionTargetPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteActionTargetProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteActionTargetPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteActionTargetPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteActionTargetProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteActionPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteActionPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteActionProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteActionPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteActionPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteActionProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteMatchHeaderMatchRangePropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteMatchHeaderMatchRangeProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteMatchHeaderMatchRangePropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteMatchHeaderMatchRangeProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteMatchHeaderMatchPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteMatchHeaderMatchPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteMatchHeaderMatchProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteMatchHeaderMatchPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteMatchHeaderMatchPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteMatchHeaderMatchProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteMatchHeaderPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteMatchHeaderProperty | cdktn.IResolvable): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteMatchHeaderPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteMatchHeaderProperty | cdktn.IResolvable): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteMatchHostnamePropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteMatchHostnamePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteMatchHostnameProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteMatchHostnamePropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteMatchHostnamePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteMatchHostnameProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteMatchPathPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteMatchPathPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteMatchPathProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteMatchPathPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteMatchPathPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteMatchPathProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteMatchQueryParameterMatchPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteMatchQueryParameterMatchProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteMatchQueryParameterMatchPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteMatchQueryParameterMatchProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteMatchQueryParameterPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteMatchQueryParameterProperty | cdktn.IResolvable): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteMatchQueryParameterPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteMatchQueryParameterProperty | cdktn.IResolvable): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteMatchPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteMatchPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteMatchProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttp2RouteMatchPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttp2RouteMatchPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttp2RouteMatchProperty): any;
export declare function awsAppmeshGatewayRouteHttp2RoutePropertyToTerraform(struct?: AwsAppmeshGatewayRoute.Http2RoutePropertyOutputReference | AwsAppmeshGatewayRoute.Http2RouteProperty): any;
export declare function awsAppmeshGatewayRouteHttp2RoutePropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.Http2RoutePropertyOutputReference | AwsAppmeshGatewayRoute.Http2RouteProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteActionRewriteHostnamePropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteActionRewriteHostnamePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteActionRewriteHostnameProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteActionRewriteHostnamePropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteActionRewriteHostnamePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteActionRewriteHostnameProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteActionRewritePathPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteActionRewritePathPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteActionRewritePathProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteActionRewritePathPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteActionRewritePathPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteActionRewritePathProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteActionRewritePrefixPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteActionRewritePrefixPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteActionRewritePrefixProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteActionRewritePrefixPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteActionRewritePrefixPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteActionRewritePrefixProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteActionRewritePropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteActionRewritePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteActionRewriteProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteActionRewritePropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteActionRewritePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteActionRewriteProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteActionTargetVirtualServicePropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteActionTargetVirtualServicePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteActionTargetVirtualServiceProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteActionTargetVirtualServicePropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteActionTargetVirtualServicePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteActionTargetVirtualServiceProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteActionTargetPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteActionTargetPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteActionTargetProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteActionTargetPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteActionTargetPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteActionTargetProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteActionPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteActionPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteActionProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteActionPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteActionPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteActionProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteMatchHeaderMatchRangePropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteMatchHeaderMatchRangeProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteMatchHeaderMatchRangePropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteMatchHeaderMatchRangeProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteMatchHeaderMatchPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteMatchHeaderMatchPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteMatchHeaderMatchProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteMatchHeaderMatchPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteMatchHeaderMatchPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteMatchHeaderMatchProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteMatchHeaderPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteMatchHeaderProperty | cdktn.IResolvable): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteMatchHeaderPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteMatchHeaderProperty | cdktn.IResolvable): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteMatchHostnamePropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteMatchHostnamePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteMatchHostnameProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteMatchHostnamePropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteMatchHostnamePropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteMatchHostnameProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteMatchPathPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteMatchPathPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteMatchPathProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteMatchPathPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteMatchPathPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteMatchPathProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteMatchQueryParameterMatchPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteMatchQueryParameterMatchProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteMatchQueryParameterMatchPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteMatchQueryParameterMatchProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteMatchQueryParameterPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteMatchQueryParameterProperty | cdktn.IResolvable): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteMatchQueryParameterPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteMatchQueryParameterProperty | cdktn.IResolvable): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteMatchPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteMatchPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteMatchProperty): any;
export declare function awsAppmeshGatewayRouteSpecHttpRouteMatchPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecHttpRouteMatchPropertyOutputReference | AwsAppmeshGatewayRoute.SpecHttpRouteMatchProperty): any;
export declare function awsAppmeshGatewayRouteHttpRoutePropertyToTerraform(struct?: AwsAppmeshGatewayRoute.HttpRoutePropertyOutputReference | AwsAppmeshGatewayRoute.HttpRouteProperty): any;
export declare function awsAppmeshGatewayRouteHttpRoutePropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.HttpRoutePropertyOutputReference | AwsAppmeshGatewayRoute.HttpRouteProperty): any;
export declare function awsAppmeshGatewayRouteSpecPropertyToTerraform(struct?: AwsAppmeshGatewayRoute.SpecPropertyOutputReference | AwsAppmeshGatewayRoute.SpecProperty): any;
export declare function awsAppmeshGatewayRouteSpecPropertyToHclTerraform(struct?: AwsAppmeshGatewayRoute.SpecPropertyOutputReference | AwsAppmeshGatewayRoute.SpecProperty): any;
export declare namespace AwsAppmeshGatewayRoute {
    interface SpecGrpcRouteActionTargetVirtualServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#virtual_service_name AwsAppmeshGatewayRoute#virtual_service_name}
        */
        readonly virtualServiceName: string;
    }
    class SpecGrpcRouteActionTargetVirtualServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteActionTargetVirtualServiceProperty | undefined;
        set internalValue(value: SpecGrpcRouteActionTargetVirtualServiceProperty | undefined);
        private _virtualServiceName?;
        get virtualServiceName(): string;
        set virtualServiceName(value: string);
        get virtualServiceNameInput(): string | undefined;
    }
    interface SpecGrpcRouteActionTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#port AwsAppmeshGatewayRoute#port}
        */
        readonly port?: number;
        /**
        * virtual_service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#virtual_service AwsAppmeshGatewayRoute#virtual_service}
        */
        readonly virtualService: SpecGrpcRouteActionTargetVirtualServiceProperty;
    }
    class SpecGrpcRouteActionTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteActionTargetProperty | undefined;
        set internalValue(value: SpecGrpcRouteActionTargetProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _virtualService;
        get virtualService(): SpecGrpcRouteActionTargetVirtualServicePropertyOutputReference;
        putVirtualService(value: SpecGrpcRouteActionTargetVirtualServiceProperty): void;
        get virtualServiceInput(): SpecGrpcRouteActionTargetVirtualServiceProperty | undefined;
    }
    interface SpecGrpcRouteActionProperty {
        /**
        * target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#target AwsAppmeshGatewayRoute#target}
        */
        readonly target: SpecGrpcRouteActionTargetProperty;
    }
    class SpecGrpcRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteActionProperty | undefined;
        set internalValue(value: SpecGrpcRouteActionProperty | undefined);
        private _target;
        get target(): SpecGrpcRouteActionTargetPropertyOutputReference;
        putTarget(value: SpecGrpcRouteActionTargetProperty): void;
        get targetInput(): SpecGrpcRouteActionTargetProperty | undefined;
    }
    interface SpecGrpcRouteMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#port AwsAppmeshGatewayRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#service_name AwsAppmeshGatewayRoute#service_name}
        */
        readonly serviceName: string;
    }
    class SpecGrpcRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteMatchProperty | undefined;
        set internalValue(value: SpecGrpcRouteMatchProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _serviceName?;
        get serviceName(): string;
        set serviceName(value: string);
        get serviceNameInput(): string | undefined;
    }
    interface GrpcRouteProperty {
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#action AwsAppmeshGatewayRoute#action}
        */
        readonly action: SpecGrpcRouteActionProperty;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#match AwsAppmeshGatewayRoute#match}
        */
        readonly match: SpecGrpcRouteMatchProperty;
    }
    class GrpcRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GrpcRouteProperty | undefined;
        set internalValue(value: GrpcRouteProperty | undefined);
        private _action;
        get action(): SpecGrpcRouteActionPropertyOutputReference;
        putAction(value: SpecGrpcRouteActionProperty): void;
        get actionInput(): SpecGrpcRouteActionProperty | undefined;
        private _match;
        get match(): SpecGrpcRouteMatchPropertyOutputReference;
        putMatch(value: SpecGrpcRouteMatchProperty): void;
        get matchInput(): SpecGrpcRouteMatchProperty | undefined;
    }
    interface SpecHttp2RouteActionRewriteHostnameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#default_target_hostname AwsAppmeshGatewayRoute#default_target_hostname}
        */
        readonly defaultTargetHostname: string;
    }
    class SpecHttp2RouteActionRewriteHostnamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteActionRewriteHostnameProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionRewriteHostnameProperty | undefined);
        private _defaultTargetHostname?;
        get defaultTargetHostname(): string;
        set defaultTargetHostname(value: string);
        get defaultTargetHostnameInput(): string | undefined;
    }
    interface SpecHttp2RouteActionRewritePathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsAppmeshGatewayRoute#exact}
        */
        readonly exact: string;
    }
    class SpecHttp2RouteActionRewritePathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteActionRewritePathProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionRewritePathProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        get exactInput(): string | undefined;
    }
    interface SpecHttp2RouteActionRewritePrefixProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#default_prefix AwsAppmeshGatewayRoute#default_prefix}
        */
        readonly defaultPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#value AwsAppmeshGatewayRoute#value}
        */
        readonly value?: string;
    }
    class SpecHttp2RouteActionRewritePrefixPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteActionRewritePrefixProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionRewritePrefixProperty | undefined);
        private _defaultPrefix?;
        get defaultPrefix(): string;
        set defaultPrefix(value: string);
        resetDefaultPrefix(): void;
        get defaultPrefixInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    interface SpecHttp2RouteActionRewriteProperty {
        /**
        * hostname block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#hostname AwsAppmeshGatewayRoute#hostname}
        */
        readonly hostname?: SpecHttp2RouteActionRewriteHostnameProperty;
        /**
        * path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#path AwsAppmeshGatewayRoute#path}
        */
        readonly path?: SpecHttp2RouteActionRewritePathProperty;
        /**
        * prefix block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#prefix AwsAppmeshGatewayRoute#prefix}
        */
        readonly prefix?: SpecHttp2RouteActionRewritePrefixProperty;
    }
    class SpecHttp2RouteActionRewritePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteActionRewriteProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionRewriteProperty | undefined);
        private _hostname;
        get hostname(): SpecHttp2RouteActionRewriteHostnamePropertyOutputReference;
        putHostname(value: SpecHttp2RouteActionRewriteHostnameProperty): void;
        resetHostname(): void;
        get hostnameInput(): SpecHttp2RouteActionRewriteHostnameProperty | undefined;
        private _path;
        get path(): SpecHttp2RouteActionRewritePathPropertyOutputReference;
        putPath(value: SpecHttp2RouteActionRewritePathProperty): void;
        resetPath(): void;
        get pathInput(): SpecHttp2RouteActionRewritePathProperty | undefined;
        private _prefix;
        get prefix(): SpecHttp2RouteActionRewritePrefixPropertyOutputReference;
        putPrefix(value: SpecHttp2RouteActionRewritePrefixProperty): void;
        resetPrefix(): void;
        get prefixInput(): SpecHttp2RouteActionRewritePrefixProperty | undefined;
    }
    interface SpecHttp2RouteActionTargetVirtualServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#virtual_service_name AwsAppmeshGatewayRoute#virtual_service_name}
        */
        readonly virtualServiceName: string;
    }
    class SpecHttp2RouteActionTargetVirtualServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteActionTargetVirtualServiceProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionTargetVirtualServiceProperty | undefined);
        private _virtualServiceName?;
        get virtualServiceName(): string;
        set virtualServiceName(value: string);
        get virtualServiceNameInput(): string | undefined;
    }
    interface SpecHttp2RouteActionTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#port AwsAppmeshGatewayRoute#port}
        */
        readonly port?: number;
        /**
        * virtual_service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#virtual_service AwsAppmeshGatewayRoute#virtual_service}
        */
        readonly virtualService: SpecHttp2RouteActionTargetVirtualServiceProperty;
    }
    class SpecHttp2RouteActionTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteActionTargetProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionTargetProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _virtualService;
        get virtualService(): SpecHttp2RouteActionTargetVirtualServicePropertyOutputReference;
        putVirtualService(value: SpecHttp2RouteActionTargetVirtualServiceProperty): void;
        get virtualServiceInput(): SpecHttp2RouteActionTargetVirtualServiceProperty | undefined;
    }
    interface SpecHttp2RouteActionProperty {
        /**
        * rewrite block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#rewrite AwsAppmeshGatewayRoute#rewrite}
        */
        readonly rewrite?: SpecHttp2RouteActionRewriteProperty;
        /**
        * target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#target AwsAppmeshGatewayRoute#target}
        */
        readonly target: SpecHttp2RouteActionTargetProperty;
    }
    class SpecHttp2RouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteActionProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionProperty | undefined);
        private _rewrite;
        get rewrite(): SpecHttp2RouteActionRewritePropertyOutputReference;
        putRewrite(value: SpecHttp2RouteActionRewriteProperty): void;
        resetRewrite(): void;
        get rewriteInput(): SpecHttp2RouteActionRewriteProperty | undefined;
        private _target;
        get target(): SpecHttp2RouteActionTargetPropertyOutputReference;
        putTarget(value: SpecHttp2RouteActionTargetProperty): void;
        get targetInput(): SpecHttp2RouteActionTargetProperty | undefined;
    }
    interface SpecHttp2RouteMatchHeaderMatchRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#end AwsAppmeshGatewayRoute#end}
        */
        readonly end: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#start AwsAppmeshGatewayRoute#start}
        */
        readonly start: number;
    }
    class SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined);
        private _end?;
        get end(): number;
        set end(value: number);
        get endInput(): number | undefined;
        private _start?;
        get start(): number;
        set start(value: number);
        get startInput(): number | undefined;
    }
    interface SpecHttp2RouteMatchHeaderMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsAppmeshGatewayRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#prefix AwsAppmeshGatewayRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#regex AwsAppmeshGatewayRoute#regex}
        */
        readonly regex?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#suffix AwsAppmeshGatewayRoute#suffix}
        */
        readonly suffix?: string;
        /**
        * range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#range AwsAppmeshGatewayRoute#range}
        */
        readonly range?: SpecHttp2RouteMatchHeaderMatchRangeProperty;
    }
    class SpecHttp2RouteMatchHeaderMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchHeaderMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
        private _suffix?;
        get suffix(): string;
        set suffix(value: string);
        resetSuffix(): void;
        get suffixInput(): string | undefined;
        private _range;
        get range(): SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference;
        putRange(value: SpecHttp2RouteMatchHeaderMatchRangeProperty): void;
        resetRange(): void;
        get rangeInput(): SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined;
    }
    interface SpecHttp2RouteMatchHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#invert AwsAppmeshGatewayRoute#invert}
        */
        readonly invert?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#name AwsAppmeshGatewayRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#match AwsAppmeshGatewayRoute#match}
        */
        readonly match?: SpecHttp2RouteMatchHeaderMatchProperty;
    }
    class SpecHttp2RouteMatchHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderProperty | cdktn.IResolvable | undefined);
        private _invert?;
        get invert(): boolean | cdktn.IResolvable;
        set invert(value: boolean | cdktn.IResolvable);
        resetInvert(): void;
        get invertInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecHttp2RouteMatchHeaderMatchPropertyOutputReference;
        putMatch(value: SpecHttp2RouteMatchHeaderMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecHttp2RouteMatchHeaderMatchProperty | undefined;
    }
    class SpecHttp2RouteMatchHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttp2RouteMatchHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchHeaderPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchHostnameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsAppmeshGatewayRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#suffix AwsAppmeshGatewayRoute#suffix}
        */
        readonly suffix?: string;
    }
    class SpecHttp2RouteMatchHostnamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchHostnameProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHostnameProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _suffix?;
        get suffix(): string;
        set suffix(value: string);
        resetSuffix(): void;
        get suffixInput(): string | undefined;
    }
    interface SpecHttp2RouteMatchPathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsAppmeshGatewayRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#regex AwsAppmeshGatewayRoute#regex}
        */
        readonly regex?: string;
    }
    class SpecHttp2RouteMatchPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchPathProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchPathProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
    }
    interface SpecHttp2RouteMatchQueryParameterMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsAppmeshGatewayRoute#exact}
        */
        readonly exact?: string;
    }
    class SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchQueryParameterMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchQueryParameterMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
    }
    interface SpecHttp2RouteMatchQueryParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#name AwsAppmeshGatewayRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#match AwsAppmeshGatewayRoute#match}
        */
        readonly match?: SpecHttp2RouteMatchQueryParameterMatchProperty;
    }
    class SpecHttp2RouteMatchQueryParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchQueryParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttp2RouteMatchQueryParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference;
        putMatch(value: SpecHttp2RouteMatchQueryParameterMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecHttp2RouteMatchQueryParameterMatchProperty | undefined;
    }
    class SpecHttp2RouteMatchQueryParameterPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttp2RouteMatchQueryParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchQueryParameterPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#port AwsAppmeshGatewayRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#prefix AwsAppmeshGatewayRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#header AwsAppmeshGatewayRoute#header}
        */
        readonly header?: SpecHttp2RouteMatchHeaderProperty[] | cdktn.IResolvable;
        /**
        * hostname block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#hostname AwsAppmeshGatewayRoute#hostname}
        */
        readonly hostname?: SpecHttp2RouteMatchHostnameProperty;
        /**
        * path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#path AwsAppmeshGatewayRoute#path}
        */
        readonly path?: SpecHttp2RouteMatchPathProperty;
        /**
        * query_parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#query_parameter AwsAppmeshGatewayRoute#query_parameter}
        */
        readonly queryParameter?: SpecHttp2RouteMatchQueryParameterProperty[] | cdktn.IResolvable;
    }
    class SpecHttp2RouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _header;
        get header(): SpecHttp2RouteMatchHeaderPropertyList;
        putHeader(value: SpecHttp2RouteMatchHeaderProperty[] | cdktn.IResolvable): void;
        resetHeader(): void;
        get headerInput(): cdktn.IResolvable | SpecHttp2RouteMatchHeaderProperty[] | undefined;
        private _hostname;
        get hostname(): SpecHttp2RouteMatchHostnamePropertyOutputReference;
        putHostname(value: SpecHttp2RouteMatchHostnameProperty): void;
        resetHostname(): void;
        get hostnameInput(): SpecHttp2RouteMatchHostnameProperty | undefined;
        private _path;
        get path(): SpecHttp2RouteMatchPathPropertyOutputReference;
        putPath(value: SpecHttp2RouteMatchPathProperty): void;
        resetPath(): void;
        get pathInput(): SpecHttp2RouteMatchPathProperty | undefined;
        private _queryParameter;
        get queryParameter(): SpecHttp2RouteMatchQueryParameterPropertyList;
        putQueryParameter(value: SpecHttp2RouteMatchQueryParameterProperty[] | cdktn.IResolvable): void;
        resetQueryParameter(): void;
        get queryParameterInput(): cdktn.IResolvable | SpecHttp2RouteMatchQueryParameterProperty[] | undefined;
    }
    interface Http2RouteProperty {
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#action AwsAppmeshGatewayRoute#action}
        */
        readonly action: SpecHttp2RouteActionProperty;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#match AwsAppmeshGatewayRoute#match}
        */
        readonly match: SpecHttp2RouteMatchProperty;
    }
    class Http2RoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Http2RouteProperty | undefined;
        set internalValue(value: Http2RouteProperty | undefined);
        private _action;
        get action(): SpecHttp2RouteActionPropertyOutputReference;
        putAction(value: SpecHttp2RouteActionProperty): void;
        get actionInput(): SpecHttp2RouteActionProperty | undefined;
        private _match;
        get match(): SpecHttp2RouteMatchPropertyOutputReference;
        putMatch(value: SpecHttp2RouteMatchProperty): void;
        get matchInput(): SpecHttp2RouteMatchProperty | undefined;
    }
    interface SpecHttpRouteActionRewriteHostnameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#default_target_hostname AwsAppmeshGatewayRoute#default_target_hostname}
        */
        readonly defaultTargetHostname: string;
    }
    class SpecHttpRouteActionRewriteHostnamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteActionRewriteHostnameProperty | undefined;
        set internalValue(value: SpecHttpRouteActionRewriteHostnameProperty | undefined);
        private _defaultTargetHostname?;
        get defaultTargetHostname(): string;
        set defaultTargetHostname(value: string);
        get defaultTargetHostnameInput(): string | undefined;
    }
    interface SpecHttpRouteActionRewritePathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsAppmeshGatewayRoute#exact}
        */
        readonly exact: string;
    }
    class SpecHttpRouteActionRewritePathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteActionRewritePathProperty | undefined;
        set internalValue(value: SpecHttpRouteActionRewritePathProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        get exactInput(): string | undefined;
    }
    interface SpecHttpRouteActionRewritePrefixProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#default_prefix AwsAppmeshGatewayRoute#default_prefix}
        */
        readonly defaultPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#value AwsAppmeshGatewayRoute#value}
        */
        readonly value?: string;
    }
    class SpecHttpRouteActionRewritePrefixPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteActionRewritePrefixProperty | undefined;
        set internalValue(value: SpecHttpRouteActionRewritePrefixProperty | undefined);
        private _defaultPrefix?;
        get defaultPrefix(): string;
        set defaultPrefix(value: string);
        resetDefaultPrefix(): void;
        get defaultPrefixInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    interface SpecHttpRouteActionRewriteProperty {
        /**
        * hostname block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#hostname AwsAppmeshGatewayRoute#hostname}
        */
        readonly hostname?: SpecHttpRouteActionRewriteHostnameProperty;
        /**
        * path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#path AwsAppmeshGatewayRoute#path}
        */
        readonly path?: SpecHttpRouteActionRewritePathProperty;
        /**
        * prefix block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#prefix AwsAppmeshGatewayRoute#prefix}
        */
        readonly prefix?: SpecHttpRouteActionRewritePrefixProperty;
    }
    class SpecHttpRouteActionRewritePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteActionRewriteProperty | undefined;
        set internalValue(value: SpecHttpRouteActionRewriteProperty | undefined);
        private _hostname;
        get hostname(): SpecHttpRouteActionRewriteHostnamePropertyOutputReference;
        putHostname(value: SpecHttpRouteActionRewriteHostnameProperty): void;
        resetHostname(): void;
        get hostnameInput(): SpecHttpRouteActionRewriteHostnameProperty | undefined;
        private _path;
        get path(): SpecHttpRouteActionRewritePathPropertyOutputReference;
        putPath(value: SpecHttpRouteActionRewritePathProperty): void;
        resetPath(): void;
        get pathInput(): SpecHttpRouteActionRewritePathProperty | undefined;
        private _prefix;
        get prefix(): SpecHttpRouteActionRewritePrefixPropertyOutputReference;
        putPrefix(value: SpecHttpRouteActionRewritePrefixProperty): void;
        resetPrefix(): void;
        get prefixInput(): SpecHttpRouteActionRewritePrefixProperty | undefined;
    }
    interface SpecHttpRouteActionTargetVirtualServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#virtual_service_name AwsAppmeshGatewayRoute#virtual_service_name}
        */
        readonly virtualServiceName: string;
    }
    class SpecHttpRouteActionTargetVirtualServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteActionTargetVirtualServiceProperty | undefined;
        set internalValue(value: SpecHttpRouteActionTargetVirtualServiceProperty | undefined);
        private _virtualServiceName?;
        get virtualServiceName(): string;
        set virtualServiceName(value: string);
        get virtualServiceNameInput(): string | undefined;
    }
    interface SpecHttpRouteActionTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#port AwsAppmeshGatewayRoute#port}
        */
        readonly port?: number;
        /**
        * virtual_service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#virtual_service AwsAppmeshGatewayRoute#virtual_service}
        */
        readonly virtualService: SpecHttpRouteActionTargetVirtualServiceProperty;
    }
    class SpecHttpRouteActionTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteActionTargetProperty | undefined;
        set internalValue(value: SpecHttpRouteActionTargetProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _virtualService;
        get virtualService(): SpecHttpRouteActionTargetVirtualServicePropertyOutputReference;
        putVirtualService(value: SpecHttpRouteActionTargetVirtualServiceProperty): void;
        get virtualServiceInput(): SpecHttpRouteActionTargetVirtualServiceProperty | undefined;
    }
    interface SpecHttpRouteActionProperty {
        /**
        * rewrite block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#rewrite AwsAppmeshGatewayRoute#rewrite}
        */
        readonly rewrite?: SpecHttpRouteActionRewriteProperty;
        /**
        * target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#target AwsAppmeshGatewayRoute#target}
        */
        readonly target: SpecHttpRouteActionTargetProperty;
    }
    class SpecHttpRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteActionProperty | undefined;
        set internalValue(value: SpecHttpRouteActionProperty | undefined);
        private _rewrite;
        get rewrite(): SpecHttpRouteActionRewritePropertyOutputReference;
        putRewrite(value: SpecHttpRouteActionRewriteProperty): void;
        resetRewrite(): void;
        get rewriteInput(): SpecHttpRouteActionRewriteProperty | undefined;
        private _target;
        get target(): SpecHttpRouteActionTargetPropertyOutputReference;
        putTarget(value: SpecHttpRouteActionTargetProperty): void;
        get targetInput(): SpecHttpRouteActionTargetProperty | undefined;
    }
    interface SpecHttpRouteMatchHeaderMatchRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#end AwsAppmeshGatewayRoute#end}
        */
        readonly end: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#start AwsAppmeshGatewayRoute#start}
        */
        readonly start: number;
    }
    class SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchHeaderMatchRangeProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderMatchRangeProperty | undefined);
        private _end?;
        get end(): number;
        set end(value: number);
        get endInput(): number | undefined;
        private _start?;
        get start(): number;
        set start(value: number);
        get startInput(): number | undefined;
    }
    interface SpecHttpRouteMatchHeaderMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsAppmeshGatewayRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#prefix AwsAppmeshGatewayRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#regex AwsAppmeshGatewayRoute#regex}
        */
        readonly regex?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#suffix AwsAppmeshGatewayRoute#suffix}
        */
        readonly suffix?: string;
        /**
        * range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#range AwsAppmeshGatewayRoute#range}
        */
        readonly range?: SpecHttpRouteMatchHeaderMatchRangeProperty;
    }
    class SpecHttpRouteMatchHeaderMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchHeaderMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
        private _suffix?;
        get suffix(): string;
        set suffix(value: string);
        resetSuffix(): void;
        get suffixInput(): string | undefined;
        private _range;
        get range(): SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference;
        putRange(value: SpecHttpRouteMatchHeaderMatchRangeProperty): void;
        resetRange(): void;
        get rangeInput(): SpecHttpRouteMatchHeaderMatchRangeProperty | undefined;
    }
    interface SpecHttpRouteMatchHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#invert AwsAppmeshGatewayRoute#invert}
        */
        readonly invert?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#name AwsAppmeshGatewayRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#match AwsAppmeshGatewayRoute#match}
        */
        readonly match?: SpecHttpRouteMatchHeaderMatchProperty;
    }
    class SpecHttpRouteMatchHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderProperty | cdktn.IResolvable | undefined);
        private _invert?;
        get invert(): boolean | cdktn.IResolvable;
        set invert(value: boolean | cdktn.IResolvable);
        resetInvert(): void;
        get invertInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecHttpRouteMatchHeaderMatchPropertyOutputReference;
        putMatch(value: SpecHttpRouteMatchHeaderMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecHttpRouteMatchHeaderMatchProperty | undefined;
    }
    class SpecHttpRouteMatchHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttpRouteMatchHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchHeaderPropertyOutputReference;
    }
    interface SpecHttpRouteMatchHostnameProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsAppmeshGatewayRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#suffix AwsAppmeshGatewayRoute#suffix}
        */
        readonly suffix?: string;
    }
    class SpecHttpRouteMatchHostnamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchHostnameProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHostnameProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _suffix?;
        get suffix(): string;
        set suffix(value: string);
        resetSuffix(): void;
        get suffixInput(): string | undefined;
    }
    interface SpecHttpRouteMatchPathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsAppmeshGatewayRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#regex AwsAppmeshGatewayRoute#regex}
        */
        readonly regex?: string;
    }
    class SpecHttpRouteMatchPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchPathProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchPathProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
    }
    interface SpecHttpRouteMatchQueryParameterMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#exact AwsAppmeshGatewayRoute#exact}
        */
        readonly exact?: string;
    }
    class SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchQueryParameterMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchQueryParameterMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
    }
    interface SpecHttpRouteMatchQueryParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#name AwsAppmeshGatewayRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#match AwsAppmeshGatewayRoute#match}
        */
        readonly match?: SpecHttpRouteMatchQueryParameterMatchProperty;
    }
    class SpecHttpRouteMatchQueryParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchQueryParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttpRouteMatchQueryParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference;
        putMatch(value: SpecHttpRouteMatchQueryParameterMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecHttpRouteMatchQueryParameterMatchProperty | undefined;
    }
    class SpecHttpRouteMatchQueryParameterPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttpRouteMatchQueryParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchQueryParameterPropertyOutputReference;
    }
    interface SpecHttpRouteMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#port AwsAppmeshGatewayRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#prefix AwsAppmeshGatewayRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#header AwsAppmeshGatewayRoute#header}
        */
        readonly header?: SpecHttpRouteMatchHeaderProperty[] | cdktn.IResolvable;
        /**
        * hostname block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#hostname AwsAppmeshGatewayRoute#hostname}
        */
        readonly hostname?: SpecHttpRouteMatchHostnameProperty;
        /**
        * path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#path AwsAppmeshGatewayRoute#path}
        */
        readonly path?: SpecHttpRouteMatchPathProperty;
        /**
        * query_parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#query_parameter AwsAppmeshGatewayRoute#query_parameter}
        */
        readonly queryParameter?: SpecHttpRouteMatchQueryParameterProperty[] | cdktn.IResolvable;
    }
    class SpecHttpRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _header;
        get header(): SpecHttpRouteMatchHeaderPropertyList;
        putHeader(value: SpecHttpRouteMatchHeaderProperty[] | cdktn.IResolvable): void;
        resetHeader(): void;
        get headerInput(): cdktn.IResolvable | SpecHttpRouteMatchHeaderProperty[] | undefined;
        private _hostname;
        get hostname(): SpecHttpRouteMatchHostnamePropertyOutputReference;
        putHostname(value: SpecHttpRouteMatchHostnameProperty): void;
        resetHostname(): void;
        get hostnameInput(): SpecHttpRouteMatchHostnameProperty | undefined;
        private _path;
        get path(): SpecHttpRouteMatchPathPropertyOutputReference;
        putPath(value: SpecHttpRouteMatchPathProperty): void;
        resetPath(): void;
        get pathInput(): SpecHttpRouteMatchPathProperty | undefined;
        private _queryParameter;
        get queryParameter(): SpecHttpRouteMatchQueryParameterPropertyList;
        putQueryParameter(value: SpecHttpRouteMatchQueryParameterProperty[] | cdktn.IResolvable): void;
        resetQueryParameter(): void;
        get queryParameterInput(): cdktn.IResolvable | SpecHttpRouteMatchQueryParameterProperty[] | undefined;
    }
    interface HttpRouteProperty {
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#action AwsAppmeshGatewayRoute#action}
        */
        readonly action: SpecHttpRouteActionProperty;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#match AwsAppmeshGatewayRoute#match}
        */
        readonly match: SpecHttpRouteMatchProperty;
    }
    class HttpRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpRouteProperty | undefined;
        set internalValue(value: HttpRouteProperty | undefined);
        private _action;
        get action(): SpecHttpRouteActionPropertyOutputReference;
        putAction(value: SpecHttpRouteActionProperty): void;
        get actionInput(): SpecHttpRouteActionProperty | undefined;
        private _match;
        get match(): SpecHttpRouteMatchPropertyOutputReference;
        putMatch(value: SpecHttpRouteMatchProperty): void;
        get matchInput(): SpecHttpRouteMatchProperty | undefined;
    }
    interface SpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#priority AwsAppmeshGatewayRoute#priority}
        */
        readonly priority?: number;
        /**
        * grpc_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#grpc_route AwsAppmeshGatewayRoute#grpc_route}
        */
        readonly grpcRoute?: GrpcRouteProperty;
        /**
        * http2_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#http2_route AwsAppmeshGatewayRoute#http2_route}
        */
        readonly http2Route?: Http2RouteProperty;
        /**
        * http_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_gateway_route#http_route AwsAppmeshGatewayRoute#http_route}
        */
        readonly httpRoute?: HttpRouteProperty;
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _priority?;
        get priority(): number;
        set priority(value: number);
        resetPriority(): void;
        get priorityInput(): number | undefined;
        private _grpcRoute;
        get grpcRoute(): GrpcRoutePropertyOutputReference;
        putGrpcRoute(value: GrpcRouteProperty): void;
        resetGrpcRoute(): void;
        get grpcRouteInput(): GrpcRouteProperty | undefined;
        private _http2Route;
        get http2Route(): Http2RoutePropertyOutputReference;
        putHttp2Route(value: Http2RouteProperty): void;
        resetHttp2Route(): void;
        get http2RouteInput(): Http2RouteProperty | undefined;
        private _httpRoute;
        get httpRoute(): HttpRoutePropertyOutputReference;
        putHttpRoute(value: HttpRouteProperty): void;
        resetHttpRoute(): void;
        get httpRouteInput(): HttpRouteProperty | undefined;
    }
}
