import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppmeshMeshConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#id AwsAppmeshMesh#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#name AwsAppmeshMesh#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#region AwsAppmeshMesh#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#tags AwsAppmeshMesh#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#tags_all AwsAppmeshMesh#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#spec AwsAppmeshMesh#spec}
    */
    readonly spec?: AwsAppmeshMesh.SpecProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh aws_appmesh_mesh}
*/
export declare class AwsAppmeshMesh extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appmesh_mesh";
    /**
    * Generates CDKTN code for importing a AwsAppmeshMesh resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppmeshMesh to import
    * @param importFromId The id of the existing AwsAppmeshMesh that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppmeshMesh to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh aws_appmesh_mesh} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppmeshMeshConfig
    */
    constructor(scope: Construct, id: string, config: AwsAppmeshMeshConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    get meshOwner(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _spec;
    get spec(): AwsAppmeshMesh.SpecPropertyOutputReference;
    putSpec(value: AwsAppmeshMesh.SpecProperty): void;
    resetSpec(): void;
    get specInput(): AwsAppmeshMesh.SpecProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppmeshMeshEgressFilterPropertyToTerraform(struct?: AwsAppmeshMesh.EgressFilterPropertyOutputReference | AwsAppmeshMesh.EgressFilterProperty): any;
export declare function awsAppmeshMeshEgressFilterPropertyToHclTerraform(struct?: AwsAppmeshMesh.EgressFilterPropertyOutputReference | AwsAppmeshMesh.EgressFilterProperty): any;
export declare function awsAppmeshMeshServiceDiscoveryPropertyToTerraform(struct?: AwsAppmeshMesh.ServiceDiscoveryPropertyOutputReference | AwsAppmeshMesh.ServiceDiscoveryProperty): any;
export declare function awsAppmeshMeshServiceDiscoveryPropertyToHclTerraform(struct?: AwsAppmeshMesh.ServiceDiscoveryPropertyOutputReference | AwsAppmeshMesh.ServiceDiscoveryProperty): any;
export declare function awsAppmeshMeshSpecPropertyToTerraform(struct?: AwsAppmeshMesh.SpecPropertyOutputReference | AwsAppmeshMesh.SpecProperty): any;
export declare function awsAppmeshMeshSpecPropertyToHclTerraform(struct?: AwsAppmeshMesh.SpecPropertyOutputReference | AwsAppmeshMesh.SpecProperty): any;
export declare namespace AwsAppmeshMesh {
    interface EgressFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#type AwsAppmeshMesh#type}
        */
        readonly type?: string;
    }
    class EgressFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EgressFilterProperty | undefined;
        set internalValue(value: EgressFilterProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface ServiceDiscoveryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#ip_preference AwsAppmeshMesh#ip_preference}
        */
        readonly ipPreference?: string;
    }
    class ServiceDiscoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceDiscoveryProperty | undefined;
        set internalValue(value: ServiceDiscoveryProperty | undefined);
        private _ipPreference?;
        get ipPreference(): string;
        set ipPreference(value: string);
        resetIpPreference(): void;
        get ipPreferenceInput(): string | undefined;
    }
    interface SpecProperty {
        /**
        * egress_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#egress_filter AwsAppmeshMesh#egress_filter}
        */
        readonly egressFilter?: EgressFilterProperty;
        /**
        * service_discovery block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#service_discovery AwsAppmeshMesh#service_discovery}
        */
        readonly serviceDiscovery?: ServiceDiscoveryProperty;
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _egressFilter;
        get egressFilter(): EgressFilterPropertyOutputReference;
        putEgressFilter(value: EgressFilterProperty): void;
        resetEgressFilter(): void;
        get egressFilterInput(): EgressFilterProperty | undefined;
        private _serviceDiscovery;
        get serviceDiscovery(): ServiceDiscoveryPropertyOutputReference;
        putServiceDiscovery(value: ServiceDiscoveryProperty): void;
        resetServiceDiscovery(): void;
        get serviceDiscoveryInput(): ServiceDiscoveryProperty | undefined;
    }
}
