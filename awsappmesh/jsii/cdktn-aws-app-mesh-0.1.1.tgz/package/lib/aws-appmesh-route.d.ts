import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppmeshRouteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#id AwsAppmeshRoute#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#mesh_name AwsAppmeshRoute#mesh_name}
    */
    readonly meshName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#mesh_owner AwsAppmeshRoute#mesh_owner}
    */
    readonly meshOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#name AwsAppmeshRoute#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#region AwsAppmeshRoute#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#tags AwsAppmeshRoute#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#tags_all AwsAppmeshRoute#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#virtual_router_name AwsAppmeshRoute#virtual_router_name}
    */
    readonly virtualRouterName: string;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#spec AwsAppmeshRoute#spec}
    */
    readonly spec: AwsAppmeshRoute.SpecProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route aws_appmesh_route}
*/
export declare class AwsAppmeshRoute extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appmesh_route";
    /**
    * Generates CDKTN code for importing a AwsAppmeshRoute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppmeshRoute to import
    * @param importFromId The id of the existing AwsAppmeshRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppmeshRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route aws_appmesh_route} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppmeshRouteConfig
    */
    constructor(scope: Construct, id: string, config: AwsAppmeshRouteConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _meshName?;
    get meshName(): string;
    set meshName(value: string);
    get meshNameInput(): string | undefined;
    private _meshOwner?;
    get meshOwner(): string;
    set meshOwner(value: string);
    resetMeshOwner(): void;
    get meshOwnerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _virtualRouterName?;
    get virtualRouterName(): string;
    set virtualRouterName(value: string);
    get virtualRouterNameInput(): string | undefined;
    private _spec;
    get spec(): AwsAppmeshRoute.SpecPropertyOutputReference;
    putSpec(value: AwsAppmeshRoute.SpecProperty): void;
    get specInput(): AwsAppmeshRoute.SpecProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppmeshRouteSpecGrpcRouteActionWeightedTargetPropertyToTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteActionWeightedTargetProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecGrpcRouteActionWeightedTargetPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteActionWeightedTargetProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecGrpcRouteActionPropertyToTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteActionPropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteActionProperty): any;
export declare function awsAppmeshRouteSpecGrpcRouteActionPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteActionPropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteActionProperty): any;
export declare function awsAppmeshRouteSpecGrpcRouteMatchMetadataMatchRangePropertyToTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteMatchMetadataMatchRangePropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteMatchMetadataMatchRangeProperty): any;
export declare function awsAppmeshRouteSpecGrpcRouteMatchMetadataMatchRangePropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteMatchMetadataMatchRangePropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteMatchMetadataMatchRangeProperty): any;
export declare function awsAppmeshRouteSpecGrpcRouteMatchMetadataMatchPropertyToTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteMatchMetadataMatchPropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteMatchMetadataMatchProperty): any;
export declare function awsAppmeshRouteSpecGrpcRouteMatchMetadataMatchPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteMatchMetadataMatchPropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteMatchMetadataMatchProperty): any;
export declare function awsAppmeshRouteMetadataPropertyToTerraform(struct?: AwsAppmeshRoute.MetadataProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteMetadataPropertyToHclTerraform(struct?: AwsAppmeshRoute.MetadataProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecGrpcRouteMatchPropertyToTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteMatchPropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteMatchProperty): any;
export declare function awsAppmeshRouteSpecGrpcRouteMatchPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteMatchPropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteMatchProperty): any;
export declare function awsAppmeshRouteSpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyToTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function awsAppmeshRouteSpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function awsAppmeshRouteSpecGrpcRouteRetryPolicyPropertyToTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteRetryPolicyPropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteRetryPolicyProperty): any;
export declare function awsAppmeshRouteSpecGrpcRouteRetryPolicyPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteRetryPolicyPropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteRetryPolicyProperty): any;
export declare function awsAppmeshRouteSpecGrpcRouteTimeoutIdlePropertyToTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteTimeoutIdlePropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteTimeoutIdleProperty): any;
export declare function awsAppmeshRouteSpecGrpcRouteTimeoutIdlePropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteTimeoutIdlePropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteTimeoutIdleProperty): any;
export declare function awsAppmeshRouteSpecGrpcRouteTimeoutPerRequestPropertyToTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteTimeoutPerRequestPropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteTimeoutPerRequestProperty): any;
export declare function awsAppmeshRouteSpecGrpcRouteTimeoutPerRequestPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteTimeoutPerRequestPropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteTimeoutPerRequestProperty): any;
export declare function awsAppmeshRouteSpecGrpcRouteTimeoutPropertyToTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteTimeoutPropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteTimeoutProperty): any;
export declare function awsAppmeshRouteSpecGrpcRouteTimeoutPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecGrpcRouteTimeoutPropertyOutputReference | AwsAppmeshRoute.SpecGrpcRouteTimeoutProperty): any;
export declare function awsAppmeshRouteGrpcRoutePropertyToTerraform(struct?: AwsAppmeshRoute.GrpcRoutePropertyOutputReference | AwsAppmeshRoute.GrpcRouteProperty): any;
export declare function awsAppmeshRouteGrpcRoutePropertyToHclTerraform(struct?: AwsAppmeshRoute.GrpcRoutePropertyOutputReference | AwsAppmeshRoute.GrpcRouteProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteActionWeightedTargetPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteActionWeightedTargetProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecHttp2RouteActionWeightedTargetPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteActionWeightedTargetProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecHttp2RouteActionPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteActionPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteActionProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteActionPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteActionPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteActionProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteMatchHeaderMatchRangePropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteMatchHeaderMatchRangeProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteMatchHeaderMatchRangePropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteMatchHeaderMatchRangeProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteMatchHeaderMatchPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteMatchHeaderMatchPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteMatchHeaderMatchProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteMatchHeaderMatchPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteMatchHeaderMatchPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteMatchHeaderMatchProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteMatchHeaderPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteMatchHeaderProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecHttp2RouteMatchHeaderPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteMatchHeaderProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecHttp2RouteMatchPathPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteMatchPathPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteMatchPathProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteMatchPathPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteMatchPathPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteMatchPathProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteMatchQueryParameterMatchPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteMatchQueryParameterMatchProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteMatchQueryParameterMatchPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteMatchQueryParameterMatchProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteMatchQueryParameterPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteMatchQueryParameterProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecHttp2RouteMatchQueryParameterPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteMatchQueryParameterProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecHttp2RouteMatchPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteMatchPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteMatchProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteMatchPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteMatchPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteMatchProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteRetryPolicyPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteRetryPolicyPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteRetryPolicyProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteRetryPolicyPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteRetryPolicyPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteRetryPolicyProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteTimeoutIdlePropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteTimeoutIdlePropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteTimeoutIdleProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteTimeoutIdlePropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteTimeoutIdlePropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteTimeoutIdleProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteTimeoutPerRequestPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteTimeoutPerRequestPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteTimeoutPerRequestProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteTimeoutPerRequestPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteTimeoutPerRequestPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteTimeoutPerRequestProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteTimeoutPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteTimeoutPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteTimeoutProperty): any;
export declare function awsAppmeshRouteSpecHttp2RouteTimeoutPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttp2RouteTimeoutPropertyOutputReference | AwsAppmeshRoute.SpecHttp2RouteTimeoutProperty): any;
export declare function awsAppmeshRouteHttp2RoutePropertyToTerraform(struct?: AwsAppmeshRoute.Http2RoutePropertyOutputReference | AwsAppmeshRoute.Http2RouteProperty): any;
export declare function awsAppmeshRouteHttp2RoutePropertyToHclTerraform(struct?: AwsAppmeshRoute.Http2RoutePropertyOutputReference | AwsAppmeshRoute.Http2RouteProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteActionWeightedTargetPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteActionWeightedTargetProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecHttpRouteActionWeightedTargetPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteActionWeightedTargetProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecHttpRouteActionPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteActionPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteActionProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteActionPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteActionPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteActionProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteMatchHeaderMatchRangePropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteMatchHeaderMatchRangeProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteMatchHeaderMatchRangePropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteMatchHeaderMatchRangeProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteMatchHeaderMatchPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteMatchHeaderMatchPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteMatchHeaderMatchProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteMatchHeaderMatchPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteMatchHeaderMatchPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteMatchHeaderMatchProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteMatchHeaderPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteMatchHeaderProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecHttpRouteMatchHeaderPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteMatchHeaderProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecHttpRouteMatchPathPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteMatchPathPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteMatchPathProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteMatchPathPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteMatchPathPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteMatchPathProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteMatchQueryParameterMatchPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteMatchQueryParameterMatchProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteMatchQueryParameterMatchPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteMatchQueryParameterMatchProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteMatchQueryParameterPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteMatchQueryParameterProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecHttpRouteMatchQueryParameterPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteMatchQueryParameterProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecHttpRouteMatchPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteMatchPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteMatchProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteMatchPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteMatchPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteMatchProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteRetryPolicyPerRetryTimeoutPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteRetryPolicyPerRetryTimeoutPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteRetryPolicyPerRetryTimeoutPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteRetryPolicyPerRetryTimeoutPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteRetryPolicyPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteRetryPolicyPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteRetryPolicyProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteRetryPolicyPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteRetryPolicyPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteRetryPolicyProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteTimeoutIdlePropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteTimeoutIdlePropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteTimeoutIdleProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteTimeoutIdlePropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteTimeoutIdlePropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteTimeoutIdleProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteTimeoutPerRequestPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteTimeoutPerRequestPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteTimeoutPerRequestProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteTimeoutPerRequestPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteTimeoutPerRequestPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteTimeoutPerRequestProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteTimeoutPropertyToTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteTimeoutPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteTimeoutProperty): any;
export declare function awsAppmeshRouteSpecHttpRouteTimeoutPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecHttpRouteTimeoutPropertyOutputReference | AwsAppmeshRoute.SpecHttpRouteTimeoutProperty): any;
export declare function awsAppmeshRouteHttpRoutePropertyToTerraform(struct?: AwsAppmeshRoute.HttpRoutePropertyOutputReference | AwsAppmeshRoute.HttpRouteProperty): any;
export declare function awsAppmeshRouteHttpRoutePropertyToHclTerraform(struct?: AwsAppmeshRoute.HttpRoutePropertyOutputReference | AwsAppmeshRoute.HttpRouteProperty): any;
export declare function awsAppmeshRouteSpecTcpRouteActionWeightedTargetPropertyToTerraform(struct?: AwsAppmeshRoute.SpecTcpRouteActionWeightedTargetProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecTcpRouteActionWeightedTargetPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecTcpRouteActionWeightedTargetProperty | cdktn.IResolvable): any;
export declare function awsAppmeshRouteSpecTcpRouteActionPropertyToTerraform(struct?: AwsAppmeshRoute.SpecTcpRouteActionPropertyOutputReference | AwsAppmeshRoute.SpecTcpRouteActionProperty): any;
export declare function awsAppmeshRouteSpecTcpRouteActionPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecTcpRouteActionPropertyOutputReference | AwsAppmeshRoute.SpecTcpRouteActionProperty): any;
export declare function awsAppmeshRouteSpecTcpRouteMatchPropertyToTerraform(struct?: AwsAppmeshRoute.SpecTcpRouteMatchPropertyOutputReference | AwsAppmeshRoute.SpecTcpRouteMatchProperty): any;
export declare function awsAppmeshRouteSpecTcpRouteMatchPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecTcpRouteMatchPropertyOutputReference | AwsAppmeshRoute.SpecTcpRouteMatchProperty): any;
export declare function awsAppmeshRouteSpecTcpRouteTimeoutIdlePropertyToTerraform(struct?: AwsAppmeshRoute.SpecTcpRouteTimeoutIdlePropertyOutputReference | AwsAppmeshRoute.SpecTcpRouteTimeoutIdleProperty): any;
export declare function awsAppmeshRouteSpecTcpRouteTimeoutIdlePropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecTcpRouteTimeoutIdlePropertyOutputReference | AwsAppmeshRoute.SpecTcpRouteTimeoutIdleProperty): any;
export declare function awsAppmeshRouteSpecTcpRouteTimeoutPropertyToTerraform(struct?: AwsAppmeshRoute.SpecTcpRouteTimeoutPropertyOutputReference | AwsAppmeshRoute.SpecTcpRouteTimeoutProperty): any;
export declare function awsAppmeshRouteSpecTcpRouteTimeoutPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecTcpRouteTimeoutPropertyOutputReference | AwsAppmeshRoute.SpecTcpRouteTimeoutProperty): any;
export declare function awsAppmeshRouteTcpRoutePropertyToTerraform(struct?: AwsAppmeshRoute.TcpRoutePropertyOutputReference | AwsAppmeshRoute.TcpRouteProperty): any;
export declare function awsAppmeshRouteTcpRoutePropertyToHclTerraform(struct?: AwsAppmeshRoute.TcpRoutePropertyOutputReference | AwsAppmeshRoute.TcpRouteProperty): any;
export declare function awsAppmeshRouteSpecPropertyToTerraform(struct?: AwsAppmeshRoute.SpecPropertyOutputReference | AwsAppmeshRoute.SpecProperty): any;
export declare function awsAppmeshRouteSpecPropertyToHclTerraform(struct?: AwsAppmeshRoute.SpecPropertyOutputReference | AwsAppmeshRoute.SpecProperty): any;
export declare namespace AwsAppmeshRoute {
    interface SpecGrpcRouteActionWeightedTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#port AwsAppmeshRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#virtual_node AwsAppmeshRoute#virtual_node}
        */
        readonly virtualNode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#weight AwsAppmeshRoute#weight}
        */
        readonly weight: number;
    }
    class SpecGrpcRouteActionWeightedTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteActionWeightedTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecGrpcRouteActionWeightedTargetProperty | cdktn.IResolvable | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _virtualNode?;
        get virtualNode(): string;
        set virtualNode(value: string);
        get virtualNodeInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        get weightInput(): number | undefined;
    }
    class SpecGrpcRouteActionWeightedTargetPropertyList extends cdktn.ComplexList {
        internalValue?: SpecGrpcRouteActionWeightedTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteActionWeightedTargetPropertyOutputReference;
    }
    interface SpecGrpcRouteActionProperty {
        /**
        * weighted_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#weighted_target AwsAppmeshRoute#weighted_target}
        */
        readonly weightedTarget: SpecGrpcRouteActionWeightedTargetProperty[] | cdktn.IResolvable;
    }
    class SpecGrpcRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteActionProperty | undefined;
        set internalValue(value: SpecGrpcRouteActionProperty | undefined);
        private _weightedTarget;
        get weightedTarget(): SpecGrpcRouteActionWeightedTargetPropertyList;
        putWeightedTarget(value: SpecGrpcRouteActionWeightedTargetProperty[] | cdktn.IResolvable): void;
        get weightedTargetInput(): cdktn.IResolvable | SpecGrpcRouteActionWeightedTargetProperty[] | undefined;
    }
    interface SpecGrpcRouteMatchMetadataMatchRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#end AwsAppmeshRoute#end}
        */
        readonly end: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#start AwsAppmeshRoute#start}
        */
        readonly start: number;
    }
    class SpecGrpcRouteMatchMetadataMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteMatchMetadataMatchRangeProperty | undefined;
        set internalValue(value: SpecGrpcRouteMatchMetadataMatchRangeProperty | undefined);
        private _end?;
        get end(): number;
        set end(value: number);
        get endInput(): number | undefined;
        private _start?;
        get start(): number;
        set start(value: number);
        get startInput(): number | undefined;
    }
    interface SpecGrpcRouteMatchMetadataMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#exact AwsAppmeshRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#prefix AwsAppmeshRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#regex AwsAppmeshRoute#regex}
        */
        readonly regex?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#suffix AwsAppmeshRoute#suffix}
        */
        readonly suffix?: string;
        /**
        * range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#range AwsAppmeshRoute#range}
        */
        readonly range?: SpecGrpcRouteMatchMetadataMatchRangeProperty;
    }
    class SpecGrpcRouteMatchMetadataMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteMatchMetadataMatchProperty | undefined;
        set internalValue(value: SpecGrpcRouteMatchMetadataMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
        private _suffix?;
        get suffix(): string;
        set suffix(value: string);
        resetSuffix(): void;
        get suffixInput(): string | undefined;
        private _range;
        get range(): SpecGrpcRouteMatchMetadataMatchRangePropertyOutputReference;
        putRange(value: SpecGrpcRouteMatchMetadataMatchRangeProperty): void;
        resetRange(): void;
        get rangeInput(): SpecGrpcRouteMatchMetadataMatchRangeProperty | undefined;
    }
    interface MetadataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#invert AwsAppmeshRoute#invert}
        */
        readonly invert?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#name AwsAppmeshRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match AwsAppmeshRoute#match}
        */
        readonly match?: SpecGrpcRouteMatchMetadataMatchProperty;
    }
    class MetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetadataProperty | cdktn.IResolvable | undefined);
        private _invert?;
        get invert(): boolean | cdktn.IResolvable;
        set invert(value: boolean | cdktn.IResolvable);
        resetInvert(): void;
        get invertInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecGrpcRouteMatchMetadataMatchPropertyOutputReference;
        putMatch(value: SpecGrpcRouteMatchMetadataMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecGrpcRouteMatchMetadataMatchProperty | undefined;
    }
    class MetadataPropertyList extends cdktn.ComplexList {
        internalValue?: MetadataProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataPropertyOutputReference;
    }
    interface SpecGrpcRouteMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#method_name AwsAppmeshRoute#method_name}
        */
        readonly methodName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#port AwsAppmeshRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#prefix AwsAppmeshRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#service_name AwsAppmeshRoute#service_name}
        */
        readonly serviceName?: string;
        /**
        * metadata block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#metadata AwsAppmeshRoute#metadata}
        */
        readonly metadata?: MetadataProperty[] | cdktn.IResolvable;
    }
    class SpecGrpcRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteMatchProperty | undefined;
        set internalValue(value: SpecGrpcRouteMatchProperty | undefined);
        private _methodName?;
        get methodName(): string;
        set methodName(value: string);
        resetMethodName(): void;
        get methodNameInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _serviceName?;
        get serviceName(): string;
        set serviceName(value: string);
        resetServiceName(): void;
        get serviceNameInput(): string | undefined;
        private _metadata;
        get metadata(): MetadataPropertyList;
        putMetadata(value: MetadataProperty[] | cdktn.IResolvable): void;
        resetMetadata(): void;
        get metadataInput(): cdktn.IResolvable | MetadataProperty[] | undefined;
    }
    interface SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit AwsAppmeshRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value AwsAppmeshRoute#value}
        */
        readonly value: number;
    }
    class SpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty | undefined;
        set internalValue(value: SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecGrpcRouteRetryPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#grpc_retry_events AwsAppmeshRoute#grpc_retry_events}
        */
        readonly grpcRetryEvents?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#http_retry_events AwsAppmeshRoute#http_retry_events}
        */
        readonly httpRetryEvents?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#max_retries AwsAppmeshRoute#max_retries}
        */
        readonly maxRetries: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#tcp_retry_events AwsAppmeshRoute#tcp_retry_events}
        */
        readonly tcpRetryEvents?: string[];
        /**
        * per_retry_timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#per_retry_timeout AwsAppmeshRoute#per_retry_timeout}
        */
        readonly perRetryTimeout: SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty;
    }
    class SpecGrpcRouteRetryPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteRetryPolicyProperty | undefined;
        set internalValue(value: SpecGrpcRouteRetryPolicyProperty | undefined);
        private _grpcRetryEvents?;
        get grpcRetryEvents(): string[];
        set grpcRetryEvents(value: string[]);
        resetGrpcRetryEvents(): void;
        get grpcRetryEventsInput(): string[] | undefined;
        private _httpRetryEvents?;
        get httpRetryEvents(): string[];
        set httpRetryEvents(value: string[]);
        resetHttpRetryEvents(): void;
        get httpRetryEventsInput(): string[] | undefined;
        private _maxRetries?;
        get maxRetries(): number;
        set maxRetries(value: number);
        get maxRetriesInput(): number | undefined;
        private _tcpRetryEvents?;
        get tcpRetryEvents(): string[];
        set tcpRetryEvents(value: string[]);
        resetTcpRetryEvents(): void;
        get tcpRetryEventsInput(): string[] | undefined;
        private _perRetryTimeout;
        get perRetryTimeout(): SpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyOutputReference;
        putPerRetryTimeout(value: SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty): void;
        get perRetryTimeoutInput(): SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty | undefined;
    }
    interface SpecGrpcRouteTimeoutIdleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit AwsAppmeshRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value AwsAppmeshRoute#value}
        */
        readonly value: number;
    }
    class SpecGrpcRouteTimeoutIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteTimeoutIdleProperty | undefined;
        set internalValue(value: SpecGrpcRouteTimeoutIdleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecGrpcRouteTimeoutPerRequestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit AwsAppmeshRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value AwsAppmeshRoute#value}
        */
        readonly value: number;
    }
    class SpecGrpcRouteTimeoutPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteTimeoutPerRequestProperty | undefined;
        set internalValue(value: SpecGrpcRouteTimeoutPerRequestProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecGrpcRouteTimeoutProperty {
        /**
        * idle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#idle AwsAppmeshRoute#idle}
        */
        readonly idle?: SpecGrpcRouteTimeoutIdleProperty;
        /**
        * per_request block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#per_request AwsAppmeshRoute#per_request}
        */
        readonly perRequest?: SpecGrpcRouteTimeoutPerRequestProperty;
    }
    class SpecGrpcRouteTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteTimeoutProperty | undefined;
        set internalValue(value: SpecGrpcRouteTimeoutProperty | undefined);
        private _idle;
        get idle(): SpecGrpcRouteTimeoutIdlePropertyOutputReference;
        putIdle(value: SpecGrpcRouteTimeoutIdleProperty): void;
        resetIdle(): void;
        get idleInput(): SpecGrpcRouteTimeoutIdleProperty | undefined;
        private _perRequest;
        get perRequest(): SpecGrpcRouteTimeoutPerRequestPropertyOutputReference;
        putPerRequest(value: SpecGrpcRouteTimeoutPerRequestProperty): void;
        resetPerRequest(): void;
        get perRequestInput(): SpecGrpcRouteTimeoutPerRequestProperty | undefined;
    }
    interface GrpcRouteProperty {
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#action AwsAppmeshRoute#action}
        */
        readonly action: SpecGrpcRouteActionProperty;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match AwsAppmeshRoute#match}
        */
        readonly match?: SpecGrpcRouteMatchProperty;
        /**
        * retry_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#retry_policy AwsAppmeshRoute#retry_policy}
        */
        readonly retryPolicy?: SpecGrpcRouteRetryPolicyProperty;
        /**
        * timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#timeout AwsAppmeshRoute#timeout}
        */
        readonly timeout?: SpecGrpcRouteTimeoutProperty;
    }
    class GrpcRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GrpcRouteProperty | undefined;
        set internalValue(value: GrpcRouteProperty | undefined);
        private _action;
        get action(): SpecGrpcRouteActionPropertyOutputReference;
        putAction(value: SpecGrpcRouteActionProperty): void;
        get actionInput(): SpecGrpcRouteActionProperty | undefined;
        private _match;
        get match(): SpecGrpcRouteMatchPropertyOutputReference;
        putMatch(value: SpecGrpcRouteMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecGrpcRouteMatchProperty | undefined;
        private _retryPolicy;
        get retryPolicy(): SpecGrpcRouteRetryPolicyPropertyOutputReference;
        putRetryPolicy(value: SpecGrpcRouteRetryPolicyProperty): void;
        resetRetryPolicy(): void;
        get retryPolicyInput(): SpecGrpcRouteRetryPolicyProperty | undefined;
        private _timeout;
        get timeout(): SpecGrpcRouteTimeoutPropertyOutputReference;
        putTimeout(value: SpecGrpcRouteTimeoutProperty): void;
        resetTimeout(): void;
        get timeoutInput(): SpecGrpcRouteTimeoutProperty | undefined;
    }
    interface SpecHttp2RouteActionWeightedTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#port AwsAppmeshRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#virtual_node AwsAppmeshRoute#virtual_node}
        */
        readonly virtualNode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#weight AwsAppmeshRoute#weight}
        */
        readonly weight: number;
    }
    class SpecHttp2RouteActionWeightedTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionWeightedTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttp2RouteActionWeightedTargetProperty | cdktn.IResolvable | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _virtualNode?;
        get virtualNode(): string;
        set virtualNode(value: string);
        get virtualNodeInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        get weightInput(): number | undefined;
    }
    class SpecHttp2RouteActionWeightedTargetPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttp2RouteActionWeightedTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionWeightedTargetPropertyOutputReference;
    }
    interface SpecHttp2RouteActionProperty {
        /**
        * weighted_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#weighted_target AwsAppmeshRoute#weighted_target}
        */
        readonly weightedTarget: SpecHttp2RouteActionWeightedTargetProperty[] | cdktn.IResolvable;
    }
    class SpecHttp2RouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteActionProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionProperty | undefined);
        private _weightedTarget;
        get weightedTarget(): SpecHttp2RouteActionWeightedTargetPropertyList;
        putWeightedTarget(value: SpecHttp2RouteActionWeightedTargetProperty[] | cdktn.IResolvable): void;
        get weightedTargetInput(): cdktn.IResolvable | SpecHttp2RouteActionWeightedTargetProperty[] | undefined;
    }
    interface SpecHttp2RouteMatchHeaderMatchRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#end AwsAppmeshRoute#end}
        */
        readonly end: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#start AwsAppmeshRoute#start}
        */
        readonly start: number;
    }
    class SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined);
        private _end?;
        get end(): number;
        set end(value: number);
        get endInput(): number | undefined;
        private _start?;
        get start(): number;
        set start(value: number);
        get startInput(): number | undefined;
    }
    interface SpecHttp2RouteMatchHeaderMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#exact AwsAppmeshRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#prefix AwsAppmeshRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#regex AwsAppmeshRoute#regex}
        */
        readonly regex?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#suffix AwsAppmeshRoute#suffix}
        */
        readonly suffix?: string;
        /**
        * range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#range AwsAppmeshRoute#range}
        */
        readonly range?: SpecHttp2RouteMatchHeaderMatchRangeProperty;
    }
    class SpecHttp2RouteMatchHeaderMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchHeaderMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
        private _suffix?;
        get suffix(): string;
        set suffix(value: string);
        resetSuffix(): void;
        get suffixInput(): string | undefined;
        private _range;
        get range(): SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference;
        putRange(value: SpecHttp2RouteMatchHeaderMatchRangeProperty): void;
        resetRange(): void;
        get rangeInput(): SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined;
    }
    interface SpecHttp2RouteMatchHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#invert AwsAppmeshRoute#invert}
        */
        readonly invert?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#name AwsAppmeshRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match AwsAppmeshRoute#match}
        */
        readonly match?: SpecHttp2RouteMatchHeaderMatchProperty;
    }
    class SpecHttp2RouteMatchHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderProperty | cdktn.IResolvable | undefined);
        private _invert?;
        get invert(): boolean | cdktn.IResolvable;
        set invert(value: boolean | cdktn.IResolvable);
        resetInvert(): void;
        get invertInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecHttp2RouteMatchHeaderMatchPropertyOutputReference;
        putMatch(value: SpecHttp2RouteMatchHeaderMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecHttp2RouteMatchHeaderMatchProperty | undefined;
    }
    class SpecHttp2RouteMatchHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttp2RouteMatchHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchHeaderPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchPathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#exact AwsAppmeshRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#regex AwsAppmeshRoute#regex}
        */
        readonly regex?: string;
    }
    class SpecHttp2RouteMatchPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchPathProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchPathProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
    }
    interface SpecHttp2RouteMatchQueryParameterMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#exact AwsAppmeshRoute#exact}
        */
        readonly exact?: string;
    }
    class SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchQueryParameterMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchQueryParameterMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
    }
    interface SpecHttp2RouteMatchQueryParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#name AwsAppmeshRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match AwsAppmeshRoute#match}
        */
        readonly match?: SpecHttp2RouteMatchQueryParameterMatchProperty;
    }
    class SpecHttp2RouteMatchQueryParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchQueryParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttp2RouteMatchQueryParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference;
        putMatch(value: SpecHttp2RouteMatchQueryParameterMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecHttp2RouteMatchQueryParameterMatchProperty | undefined;
    }
    class SpecHttp2RouteMatchQueryParameterPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttp2RouteMatchQueryParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchQueryParameterPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#method AwsAppmeshRoute#method}
        */
        readonly method?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#port AwsAppmeshRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#prefix AwsAppmeshRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#scheme AwsAppmeshRoute#scheme}
        */
        readonly scheme?: string;
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#header AwsAppmeshRoute#header}
        */
        readonly header?: SpecHttp2RouteMatchHeaderProperty[] | cdktn.IResolvable;
        /**
        * path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#path AwsAppmeshRoute#path}
        */
        readonly path?: SpecHttp2RouteMatchPathProperty;
        /**
        * query_parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#query_parameter AwsAppmeshRoute#query_parameter}
        */
        readonly queryParameter?: SpecHttp2RouteMatchQueryParameterProperty[] | cdktn.IResolvable;
    }
    class SpecHttp2RouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchProperty | undefined);
        private _method?;
        get method(): string;
        set method(value: string);
        resetMethod(): void;
        get methodInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _scheme?;
        get scheme(): string;
        set scheme(value: string);
        resetScheme(): void;
        get schemeInput(): string | undefined;
        private _header;
        get header(): SpecHttp2RouteMatchHeaderPropertyList;
        putHeader(value: SpecHttp2RouteMatchHeaderProperty[] | cdktn.IResolvable): void;
        resetHeader(): void;
        get headerInput(): cdktn.IResolvable | SpecHttp2RouteMatchHeaderProperty[] | undefined;
        private _path;
        get path(): SpecHttp2RouteMatchPathPropertyOutputReference;
        putPath(value: SpecHttp2RouteMatchPathProperty): void;
        resetPath(): void;
        get pathInput(): SpecHttp2RouteMatchPathProperty | undefined;
        private _queryParameter;
        get queryParameter(): SpecHttp2RouteMatchQueryParameterPropertyList;
        putQueryParameter(value: SpecHttp2RouteMatchQueryParameterProperty[] | cdktn.IResolvable): void;
        resetQueryParameter(): void;
        get queryParameterInput(): cdktn.IResolvable | SpecHttp2RouteMatchQueryParameterProperty[] | undefined;
    }
    interface SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit AwsAppmeshRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value AwsAppmeshRoute#value}
        */
        readonly value: number;
    }
    class SpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty | undefined;
        set internalValue(value: SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecHttp2RouteRetryPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#http_retry_events AwsAppmeshRoute#http_retry_events}
        */
        readonly httpRetryEvents?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#max_retries AwsAppmeshRoute#max_retries}
        */
        readonly maxRetries: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#tcp_retry_events AwsAppmeshRoute#tcp_retry_events}
        */
        readonly tcpRetryEvents?: string[];
        /**
        * per_retry_timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#per_retry_timeout AwsAppmeshRoute#per_retry_timeout}
        */
        readonly perRetryTimeout: SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty;
    }
    class SpecHttp2RouteRetryPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteRetryPolicyProperty | undefined;
        set internalValue(value: SpecHttp2RouteRetryPolicyProperty | undefined);
        private _httpRetryEvents?;
        get httpRetryEvents(): string[];
        set httpRetryEvents(value: string[]);
        resetHttpRetryEvents(): void;
        get httpRetryEventsInput(): string[] | undefined;
        private _maxRetries?;
        get maxRetries(): number;
        set maxRetries(value: number);
        get maxRetriesInput(): number | undefined;
        private _tcpRetryEvents?;
        get tcpRetryEvents(): string[];
        set tcpRetryEvents(value: string[]);
        resetTcpRetryEvents(): void;
        get tcpRetryEventsInput(): string[] | undefined;
        private _perRetryTimeout;
        get perRetryTimeout(): SpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyOutputReference;
        putPerRetryTimeout(value: SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty): void;
        get perRetryTimeoutInput(): SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty | undefined;
    }
    interface SpecHttp2RouteTimeoutIdleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit AwsAppmeshRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value AwsAppmeshRoute#value}
        */
        readonly value: number;
    }
    class SpecHttp2RouteTimeoutIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteTimeoutIdleProperty | undefined;
        set internalValue(value: SpecHttp2RouteTimeoutIdleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecHttp2RouteTimeoutPerRequestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit AwsAppmeshRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value AwsAppmeshRoute#value}
        */
        readonly value: number;
    }
    class SpecHttp2RouteTimeoutPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteTimeoutPerRequestProperty | undefined;
        set internalValue(value: SpecHttp2RouteTimeoutPerRequestProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecHttp2RouteTimeoutProperty {
        /**
        * idle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#idle AwsAppmeshRoute#idle}
        */
        readonly idle?: SpecHttp2RouteTimeoutIdleProperty;
        /**
        * per_request block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#per_request AwsAppmeshRoute#per_request}
        */
        readonly perRequest?: SpecHttp2RouteTimeoutPerRequestProperty;
    }
    class SpecHttp2RouteTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteTimeoutProperty | undefined;
        set internalValue(value: SpecHttp2RouteTimeoutProperty | undefined);
        private _idle;
        get idle(): SpecHttp2RouteTimeoutIdlePropertyOutputReference;
        putIdle(value: SpecHttp2RouteTimeoutIdleProperty): void;
        resetIdle(): void;
        get idleInput(): SpecHttp2RouteTimeoutIdleProperty | undefined;
        private _perRequest;
        get perRequest(): SpecHttp2RouteTimeoutPerRequestPropertyOutputReference;
        putPerRequest(value: SpecHttp2RouteTimeoutPerRequestProperty): void;
        resetPerRequest(): void;
        get perRequestInput(): SpecHttp2RouteTimeoutPerRequestProperty | undefined;
    }
    interface Http2RouteProperty {
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#action AwsAppmeshRoute#action}
        */
        readonly action: SpecHttp2RouteActionProperty;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match AwsAppmeshRoute#match}
        */
        readonly match: SpecHttp2RouteMatchProperty;
        /**
        * retry_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#retry_policy AwsAppmeshRoute#retry_policy}
        */
        readonly retryPolicy?: SpecHttp2RouteRetryPolicyProperty;
        /**
        * timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#timeout AwsAppmeshRoute#timeout}
        */
        readonly timeout?: SpecHttp2RouteTimeoutProperty;
    }
    class Http2RoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Http2RouteProperty | undefined;
        set internalValue(value: Http2RouteProperty | undefined);
        private _action;
        get action(): SpecHttp2RouteActionPropertyOutputReference;
        putAction(value: SpecHttp2RouteActionProperty): void;
        get actionInput(): SpecHttp2RouteActionProperty | undefined;
        private _match;
        get match(): SpecHttp2RouteMatchPropertyOutputReference;
        putMatch(value: SpecHttp2RouteMatchProperty): void;
        get matchInput(): SpecHttp2RouteMatchProperty | undefined;
        private _retryPolicy;
        get retryPolicy(): SpecHttp2RouteRetryPolicyPropertyOutputReference;
        putRetryPolicy(value: SpecHttp2RouteRetryPolicyProperty): void;
        resetRetryPolicy(): void;
        get retryPolicyInput(): SpecHttp2RouteRetryPolicyProperty | undefined;
        private _timeout;
        get timeout(): SpecHttp2RouteTimeoutPropertyOutputReference;
        putTimeout(value: SpecHttp2RouteTimeoutProperty): void;
        resetTimeout(): void;
        get timeoutInput(): SpecHttp2RouteTimeoutProperty | undefined;
    }
    interface SpecHttpRouteActionWeightedTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#port AwsAppmeshRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#virtual_node AwsAppmeshRoute#virtual_node}
        */
        readonly virtualNode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#weight AwsAppmeshRoute#weight}
        */
        readonly weight: number;
    }
    class SpecHttpRouteActionWeightedTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionWeightedTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttpRouteActionWeightedTargetProperty | cdktn.IResolvable | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _virtualNode?;
        get virtualNode(): string;
        set virtualNode(value: string);
        get virtualNodeInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        get weightInput(): number | undefined;
    }
    class SpecHttpRouteActionWeightedTargetPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttpRouteActionWeightedTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionWeightedTargetPropertyOutputReference;
    }
    interface SpecHttpRouteActionProperty {
        /**
        * weighted_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#weighted_target AwsAppmeshRoute#weighted_target}
        */
        readonly weightedTarget: SpecHttpRouteActionWeightedTargetProperty[] | cdktn.IResolvable;
    }
    class SpecHttpRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteActionProperty | undefined;
        set internalValue(value: SpecHttpRouteActionProperty | undefined);
        private _weightedTarget;
        get weightedTarget(): SpecHttpRouteActionWeightedTargetPropertyList;
        putWeightedTarget(value: SpecHttpRouteActionWeightedTargetProperty[] | cdktn.IResolvable): void;
        get weightedTargetInput(): cdktn.IResolvable | SpecHttpRouteActionWeightedTargetProperty[] | undefined;
    }
    interface SpecHttpRouteMatchHeaderMatchRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#end AwsAppmeshRoute#end}
        */
        readonly end: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#start AwsAppmeshRoute#start}
        */
        readonly start: number;
    }
    class SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchHeaderMatchRangeProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderMatchRangeProperty | undefined);
        private _end?;
        get end(): number;
        set end(value: number);
        get endInput(): number | undefined;
        private _start?;
        get start(): number;
        set start(value: number);
        get startInput(): number | undefined;
    }
    interface SpecHttpRouteMatchHeaderMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#exact AwsAppmeshRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#prefix AwsAppmeshRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#regex AwsAppmeshRoute#regex}
        */
        readonly regex?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#suffix AwsAppmeshRoute#suffix}
        */
        readonly suffix?: string;
        /**
        * range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#range AwsAppmeshRoute#range}
        */
        readonly range?: SpecHttpRouteMatchHeaderMatchRangeProperty;
    }
    class SpecHttpRouteMatchHeaderMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchHeaderMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
        private _suffix?;
        get suffix(): string;
        set suffix(value: string);
        resetSuffix(): void;
        get suffixInput(): string | undefined;
        private _range;
        get range(): SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference;
        putRange(value: SpecHttpRouteMatchHeaderMatchRangeProperty): void;
        resetRange(): void;
        get rangeInput(): SpecHttpRouteMatchHeaderMatchRangeProperty | undefined;
    }
    interface SpecHttpRouteMatchHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#invert AwsAppmeshRoute#invert}
        */
        readonly invert?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#name AwsAppmeshRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match AwsAppmeshRoute#match}
        */
        readonly match?: SpecHttpRouteMatchHeaderMatchProperty;
    }
    class SpecHttpRouteMatchHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderProperty | cdktn.IResolvable | undefined);
        private _invert?;
        get invert(): boolean | cdktn.IResolvable;
        set invert(value: boolean | cdktn.IResolvable);
        resetInvert(): void;
        get invertInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecHttpRouteMatchHeaderMatchPropertyOutputReference;
        putMatch(value: SpecHttpRouteMatchHeaderMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecHttpRouteMatchHeaderMatchProperty | undefined;
    }
    class SpecHttpRouteMatchHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttpRouteMatchHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchHeaderPropertyOutputReference;
    }
    interface SpecHttpRouteMatchPathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#exact AwsAppmeshRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#regex AwsAppmeshRoute#regex}
        */
        readonly regex?: string;
    }
    class SpecHttpRouteMatchPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchPathProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchPathProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
    }
    interface SpecHttpRouteMatchQueryParameterMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#exact AwsAppmeshRoute#exact}
        */
        readonly exact?: string;
    }
    class SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchQueryParameterMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchQueryParameterMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
    }
    interface SpecHttpRouteMatchQueryParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#name AwsAppmeshRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match AwsAppmeshRoute#match}
        */
        readonly match?: SpecHttpRouteMatchQueryParameterMatchProperty;
    }
    class SpecHttpRouteMatchQueryParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchQueryParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttpRouteMatchQueryParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference;
        putMatch(value: SpecHttpRouteMatchQueryParameterMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecHttpRouteMatchQueryParameterMatchProperty | undefined;
    }
    class SpecHttpRouteMatchQueryParameterPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttpRouteMatchQueryParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchQueryParameterPropertyOutputReference;
    }
    interface SpecHttpRouteMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#method AwsAppmeshRoute#method}
        */
        readonly method?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#port AwsAppmeshRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#prefix AwsAppmeshRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#scheme AwsAppmeshRoute#scheme}
        */
        readonly scheme?: string;
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#header AwsAppmeshRoute#header}
        */
        readonly header?: SpecHttpRouteMatchHeaderProperty[] | cdktn.IResolvable;
        /**
        * path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#path AwsAppmeshRoute#path}
        */
        readonly path?: SpecHttpRouteMatchPathProperty;
        /**
        * query_parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#query_parameter AwsAppmeshRoute#query_parameter}
        */
        readonly queryParameter?: SpecHttpRouteMatchQueryParameterProperty[] | cdktn.IResolvable;
    }
    class SpecHttpRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchProperty | undefined);
        private _method?;
        get method(): string;
        set method(value: string);
        resetMethod(): void;
        get methodInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _scheme?;
        get scheme(): string;
        set scheme(value: string);
        resetScheme(): void;
        get schemeInput(): string | undefined;
        private _header;
        get header(): SpecHttpRouteMatchHeaderPropertyList;
        putHeader(value: SpecHttpRouteMatchHeaderProperty[] | cdktn.IResolvable): void;
        resetHeader(): void;
        get headerInput(): cdktn.IResolvable | SpecHttpRouteMatchHeaderProperty[] | undefined;
        private _path;
        get path(): SpecHttpRouteMatchPathPropertyOutputReference;
        putPath(value: SpecHttpRouteMatchPathProperty): void;
        resetPath(): void;
        get pathInput(): SpecHttpRouteMatchPathProperty | undefined;
        private _queryParameter;
        get queryParameter(): SpecHttpRouteMatchQueryParameterPropertyList;
        putQueryParameter(value: SpecHttpRouteMatchQueryParameterProperty[] | cdktn.IResolvable): void;
        resetQueryParameter(): void;
        get queryParameterInput(): cdktn.IResolvable | SpecHttpRouteMatchQueryParameterProperty[] | undefined;
    }
    interface SpecHttpRouteRetryPolicyPerRetryTimeoutProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit AwsAppmeshRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value AwsAppmeshRoute#value}
        */
        readonly value: number;
    }
    class SpecHttpRouteRetryPolicyPerRetryTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteRetryPolicyPerRetryTimeoutProperty | undefined;
        set internalValue(value: SpecHttpRouteRetryPolicyPerRetryTimeoutProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecHttpRouteRetryPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#http_retry_events AwsAppmeshRoute#http_retry_events}
        */
        readonly httpRetryEvents?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#max_retries AwsAppmeshRoute#max_retries}
        */
        readonly maxRetries: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#tcp_retry_events AwsAppmeshRoute#tcp_retry_events}
        */
        readonly tcpRetryEvents?: string[];
        /**
        * per_retry_timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#per_retry_timeout AwsAppmeshRoute#per_retry_timeout}
        */
        readonly perRetryTimeout: SpecHttpRouteRetryPolicyPerRetryTimeoutProperty;
    }
    class SpecHttpRouteRetryPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteRetryPolicyProperty | undefined;
        set internalValue(value: SpecHttpRouteRetryPolicyProperty | undefined);
        private _httpRetryEvents?;
        get httpRetryEvents(): string[];
        set httpRetryEvents(value: string[]);
        resetHttpRetryEvents(): void;
        get httpRetryEventsInput(): string[] | undefined;
        private _maxRetries?;
        get maxRetries(): number;
        set maxRetries(value: number);
        get maxRetriesInput(): number | undefined;
        private _tcpRetryEvents?;
        get tcpRetryEvents(): string[];
        set tcpRetryEvents(value: string[]);
        resetTcpRetryEvents(): void;
        get tcpRetryEventsInput(): string[] | undefined;
        private _perRetryTimeout;
        get perRetryTimeout(): SpecHttpRouteRetryPolicyPerRetryTimeoutPropertyOutputReference;
        putPerRetryTimeout(value: SpecHttpRouteRetryPolicyPerRetryTimeoutProperty): void;
        get perRetryTimeoutInput(): SpecHttpRouteRetryPolicyPerRetryTimeoutProperty | undefined;
    }
    interface SpecHttpRouteTimeoutIdleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit AwsAppmeshRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value AwsAppmeshRoute#value}
        */
        readonly value: number;
    }
    class SpecHttpRouteTimeoutIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteTimeoutIdleProperty | undefined;
        set internalValue(value: SpecHttpRouteTimeoutIdleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecHttpRouteTimeoutPerRequestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit AwsAppmeshRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value AwsAppmeshRoute#value}
        */
        readonly value: number;
    }
    class SpecHttpRouteTimeoutPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteTimeoutPerRequestProperty | undefined;
        set internalValue(value: SpecHttpRouteTimeoutPerRequestProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecHttpRouteTimeoutProperty {
        /**
        * idle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#idle AwsAppmeshRoute#idle}
        */
        readonly idle?: SpecHttpRouteTimeoutIdleProperty;
        /**
        * per_request block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#per_request AwsAppmeshRoute#per_request}
        */
        readonly perRequest?: SpecHttpRouteTimeoutPerRequestProperty;
    }
    class SpecHttpRouteTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteTimeoutProperty | undefined;
        set internalValue(value: SpecHttpRouteTimeoutProperty | undefined);
        private _idle;
        get idle(): SpecHttpRouteTimeoutIdlePropertyOutputReference;
        putIdle(value: SpecHttpRouteTimeoutIdleProperty): void;
        resetIdle(): void;
        get idleInput(): SpecHttpRouteTimeoutIdleProperty | undefined;
        private _perRequest;
        get perRequest(): SpecHttpRouteTimeoutPerRequestPropertyOutputReference;
        putPerRequest(value: SpecHttpRouteTimeoutPerRequestProperty): void;
        resetPerRequest(): void;
        get perRequestInput(): SpecHttpRouteTimeoutPerRequestProperty | undefined;
    }
    interface HttpRouteProperty {
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#action AwsAppmeshRoute#action}
        */
        readonly action: SpecHttpRouteActionProperty;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match AwsAppmeshRoute#match}
        */
        readonly match: SpecHttpRouteMatchProperty;
        /**
        * retry_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#retry_policy AwsAppmeshRoute#retry_policy}
        */
        readonly retryPolicy?: SpecHttpRouteRetryPolicyProperty;
        /**
        * timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#timeout AwsAppmeshRoute#timeout}
        */
        readonly timeout?: SpecHttpRouteTimeoutProperty;
    }
    class HttpRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpRouteProperty | undefined;
        set internalValue(value: HttpRouteProperty | undefined);
        private _action;
        get action(): SpecHttpRouteActionPropertyOutputReference;
        putAction(value: SpecHttpRouteActionProperty): void;
        get actionInput(): SpecHttpRouteActionProperty | undefined;
        private _match;
        get match(): SpecHttpRouteMatchPropertyOutputReference;
        putMatch(value: SpecHttpRouteMatchProperty): void;
        get matchInput(): SpecHttpRouteMatchProperty | undefined;
        private _retryPolicy;
        get retryPolicy(): SpecHttpRouteRetryPolicyPropertyOutputReference;
        putRetryPolicy(value: SpecHttpRouteRetryPolicyProperty): void;
        resetRetryPolicy(): void;
        get retryPolicyInput(): SpecHttpRouteRetryPolicyProperty | undefined;
        private _timeout;
        get timeout(): SpecHttpRouteTimeoutPropertyOutputReference;
        putTimeout(value: SpecHttpRouteTimeoutProperty): void;
        resetTimeout(): void;
        get timeoutInput(): SpecHttpRouteTimeoutProperty | undefined;
    }
    interface SpecTcpRouteActionWeightedTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#port AwsAppmeshRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#virtual_node AwsAppmeshRoute#virtual_node}
        */
        readonly virtualNode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#weight AwsAppmeshRoute#weight}
        */
        readonly weight: number;
    }
    class SpecTcpRouteActionWeightedTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecTcpRouteActionWeightedTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecTcpRouteActionWeightedTargetProperty | cdktn.IResolvable | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _virtualNode?;
        get virtualNode(): string;
        set virtualNode(value: string);
        get virtualNodeInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        get weightInput(): number | undefined;
    }
    class SpecTcpRouteActionWeightedTargetPropertyList extends cdktn.ComplexList {
        internalValue?: SpecTcpRouteActionWeightedTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecTcpRouteActionWeightedTargetPropertyOutputReference;
    }
    interface SpecTcpRouteActionProperty {
        /**
        * weighted_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#weighted_target AwsAppmeshRoute#weighted_target}
        */
        readonly weightedTarget: SpecTcpRouteActionWeightedTargetProperty[] | cdktn.IResolvable;
    }
    class SpecTcpRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecTcpRouteActionProperty | undefined;
        set internalValue(value: SpecTcpRouteActionProperty | undefined);
        private _weightedTarget;
        get weightedTarget(): SpecTcpRouteActionWeightedTargetPropertyList;
        putWeightedTarget(value: SpecTcpRouteActionWeightedTargetProperty[] | cdktn.IResolvable): void;
        get weightedTargetInput(): cdktn.IResolvable | SpecTcpRouteActionWeightedTargetProperty[] | undefined;
    }
    interface SpecTcpRouteMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#port AwsAppmeshRoute#port}
        */
        readonly port?: number;
    }
    class SpecTcpRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecTcpRouteMatchProperty | undefined;
        set internalValue(value: SpecTcpRouteMatchProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
    }
    interface SpecTcpRouteTimeoutIdleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit AwsAppmeshRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value AwsAppmeshRoute#value}
        */
        readonly value: number;
    }
    class SpecTcpRouteTimeoutIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecTcpRouteTimeoutIdleProperty | undefined;
        set internalValue(value: SpecTcpRouteTimeoutIdleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecTcpRouteTimeoutProperty {
        /**
        * idle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#idle AwsAppmeshRoute#idle}
        */
        readonly idle?: SpecTcpRouteTimeoutIdleProperty;
    }
    class SpecTcpRouteTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecTcpRouteTimeoutProperty | undefined;
        set internalValue(value: SpecTcpRouteTimeoutProperty | undefined);
        private _idle;
        get idle(): SpecTcpRouteTimeoutIdlePropertyOutputReference;
        putIdle(value: SpecTcpRouteTimeoutIdleProperty): void;
        resetIdle(): void;
        get idleInput(): SpecTcpRouteTimeoutIdleProperty | undefined;
    }
    interface TcpRouteProperty {
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#action AwsAppmeshRoute#action}
        */
        readonly action: SpecTcpRouteActionProperty;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match AwsAppmeshRoute#match}
        */
        readonly match?: SpecTcpRouteMatchProperty;
        /**
        * timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#timeout AwsAppmeshRoute#timeout}
        */
        readonly timeout?: SpecTcpRouteTimeoutProperty;
    }
    class TcpRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TcpRouteProperty | undefined;
        set internalValue(value: TcpRouteProperty | undefined);
        private _action;
        get action(): SpecTcpRouteActionPropertyOutputReference;
        putAction(value: SpecTcpRouteActionProperty): void;
        get actionInput(): SpecTcpRouteActionProperty | undefined;
        private _match;
        get match(): SpecTcpRouteMatchPropertyOutputReference;
        putMatch(value: SpecTcpRouteMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecTcpRouteMatchProperty | undefined;
        private _timeout;
        get timeout(): SpecTcpRouteTimeoutPropertyOutputReference;
        putTimeout(value: SpecTcpRouteTimeoutProperty): void;
        resetTimeout(): void;
        get timeoutInput(): SpecTcpRouteTimeoutProperty | undefined;
    }
    interface SpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#priority AwsAppmeshRoute#priority}
        */
        readonly priority?: number;
        /**
        * grpc_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#grpc_route AwsAppmeshRoute#grpc_route}
        */
        readonly grpcRoute?: GrpcRouteProperty;
        /**
        * http2_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#http2_route AwsAppmeshRoute#http2_route}
        */
        readonly http2Route?: Http2RouteProperty;
        /**
        * http_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#http_route AwsAppmeshRoute#http_route}
        */
        readonly httpRoute?: HttpRouteProperty;
        /**
        * tcp_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#tcp_route AwsAppmeshRoute#tcp_route}
        */
        readonly tcpRoute?: TcpRouteProperty;
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _priority?;
        get priority(): number;
        set priority(value: number);
        resetPriority(): void;
        get priorityInput(): number | undefined;
        private _grpcRoute;
        get grpcRoute(): GrpcRoutePropertyOutputReference;
        putGrpcRoute(value: GrpcRouteProperty): void;
        resetGrpcRoute(): void;
        get grpcRouteInput(): GrpcRouteProperty | undefined;
        private _http2Route;
        get http2Route(): Http2RoutePropertyOutputReference;
        putHttp2Route(value: Http2RouteProperty): void;
        resetHttp2Route(): void;
        get http2RouteInput(): Http2RouteProperty | undefined;
        private _httpRoute;
        get httpRoute(): HttpRoutePropertyOutputReference;
        putHttpRoute(value: HttpRouteProperty): void;
        resetHttpRoute(): void;
        get httpRouteInput(): HttpRouteProperty | undefined;
        private _tcpRoute;
        get tcpRoute(): TcpRoutePropertyOutputReference;
        putTcpRoute(value: TcpRouteProperty): void;
        resetTcpRoute(): void;
        get tcpRouteInput(): TcpRouteProperty | undefined;
    }
}
