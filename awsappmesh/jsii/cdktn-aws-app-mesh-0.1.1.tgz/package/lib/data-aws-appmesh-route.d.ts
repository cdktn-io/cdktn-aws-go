import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsAppmeshRouteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_route#id DataAwsAppmeshRoute#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_route#mesh_name DataAwsAppmeshRoute#mesh_name}
    */
    readonly meshName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_route#mesh_owner DataAwsAppmeshRoute#mesh_owner}
    */
    readonly meshOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_route#name DataAwsAppmeshRoute#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_route#region DataAwsAppmeshRoute#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_route#tags DataAwsAppmeshRoute#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_route#virtual_router_name DataAwsAppmeshRoute#virtual_router_name}
    */
    readonly virtualRouterName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_route aws_appmesh_route}
*/
export declare class DataAwsAppmeshRoute extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_appmesh_route";
    /**
    * Generates CDKTN code for importing a DataAwsAppmeshRoute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsAppmeshRoute to import
    * @param importFromId The id of the existing DataAwsAppmeshRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsAppmeshRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_route aws_appmesh_route} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsAppmeshRouteConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsAppmeshRouteConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _meshName?;
    get meshName(): string;
    set meshName(value: string);
    get meshNameInput(): string | undefined;
    private _meshOwner?;
    get meshOwner(): string;
    set meshOwner(value: string);
    resetMeshOwner(): void;
    get meshOwnerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _spec;
    get spec(): DataAwsAppmeshRoute.SpecPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _virtualRouterName?;
    get virtualRouterName(): string;
    set virtualRouterName(value: string);
    get virtualRouterNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsAppmeshRouteSpecGrpcRouteActionWeightedTargetPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteActionWeightedTargetProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteActionWeightedTargetPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteActionWeightedTargetProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteActionPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteActionProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteActionPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteActionProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteMatchMetadataMatchRangePropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteMatchMetadataMatchRangeProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteMatchMetadataMatchRangePropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteMatchMetadataMatchRangeProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteMatchMetadataMatchPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteMatchMetadataMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteMatchMetadataMatchPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteMatchMetadataMatchProperty): any;
export declare function dataAwsAppmeshRouteMetadataPropertyToTerraform(struct?: DataAwsAppmeshRoute.MetadataProperty): any;
export declare function dataAwsAppmeshRouteMetadataPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.MetadataProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteMatchPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteMatchPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteRetryPolicyPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteRetryPolicyProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteRetryPolicyPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteRetryPolicyProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteTimeoutIdlePropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteTimeoutIdleProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteTimeoutIdlePropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteTimeoutIdleProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteTimeoutPerRequestPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteTimeoutPerRequestProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteTimeoutPerRequestPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteTimeoutPerRequestProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteTimeoutPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteTimeoutProperty): any;
export declare function dataAwsAppmeshRouteSpecGrpcRouteTimeoutPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecGrpcRouteTimeoutProperty): any;
export declare function dataAwsAppmeshRouteGrpcRoutePropertyToTerraform(struct?: DataAwsAppmeshRoute.GrpcRouteProperty): any;
export declare function dataAwsAppmeshRouteGrpcRoutePropertyToHclTerraform(struct?: DataAwsAppmeshRoute.GrpcRouteProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteActionWeightedTargetPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteActionWeightedTargetProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteActionWeightedTargetPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteActionWeightedTargetProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteActionPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteActionProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteActionPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteActionProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteMatchHeaderMatchRangePropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteMatchHeaderMatchRangeProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteMatchHeaderMatchRangePropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteMatchHeaderMatchRangeProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteMatchHeaderMatchPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteMatchHeaderMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteMatchHeaderMatchPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteMatchHeaderMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteMatchHeaderPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteMatchHeaderProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteMatchHeaderPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteMatchHeaderProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteMatchPathPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteMatchPathProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteMatchPathPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteMatchPathProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteMatchQueryParameterMatchPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteMatchQueryParameterMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteMatchQueryParameterMatchPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteMatchQueryParameterMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteMatchQueryParameterPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteMatchQueryParameterProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteMatchQueryParameterPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteMatchQueryParameterProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteMatchPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteMatchPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteRetryPolicyPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteRetryPolicyProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteRetryPolicyPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteRetryPolicyProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteTimeoutIdlePropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteTimeoutIdleProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteTimeoutIdlePropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteTimeoutIdleProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteTimeoutPerRequestPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteTimeoutPerRequestProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteTimeoutPerRequestPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteTimeoutPerRequestProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteTimeoutPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteTimeoutProperty): any;
export declare function dataAwsAppmeshRouteSpecHttp2RouteTimeoutPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttp2RouteTimeoutProperty): any;
export declare function dataAwsAppmeshRouteHttp2RoutePropertyToTerraform(struct?: DataAwsAppmeshRoute.Http2RouteProperty): any;
export declare function dataAwsAppmeshRouteHttp2RoutePropertyToHclTerraform(struct?: DataAwsAppmeshRoute.Http2RouteProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteActionWeightedTargetPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteActionWeightedTargetProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteActionWeightedTargetPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteActionWeightedTargetProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteActionPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteActionProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteActionPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteActionProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteMatchHeaderMatchRangePropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteMatchHeaderMatchRangeProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteMatchHeaderMatchRangePropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteMatchHeaderMatchRangeProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteMatchHeaderMatchPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteMatchHeaderMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteMatchHeaderMatchPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteMatchHeaderMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteMatchHeaderPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteMatchHeaderProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteMatchHeaderPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteMatchHeaderProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteMatchPathPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteMatchPathProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteMatchPathPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteMatchPathProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteMatchQueryParameterMatchPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteMatchQueryParameterMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteMatchQueryParameterMatchPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteMatchQueryParameterMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteMatchQueryParameterPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteMatchQueryParameterProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteMatchQueryParameterPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteMatchQueryParameterProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteMatchPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteMatchPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteRetryPolicyPerRetryTimeoutPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteRetryPolicyPerRetryTimeoutPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteRetryPolicyPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteRetryPolicyProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteRetryPolicyPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteRetryPolicyProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteTimeoutIdlePropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteTimeoutIdleProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteTimeoutIdlePropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteTimeoutIdleProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteTimeoutPerRequestPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteTimeoutPerRequestProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteTimeoutPerRequestPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteTimeoutPerRequestProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteTimeoutPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteTimeoutProperty): any;
export declare function dataAwsAppmeshRouteSpecHttpRouteTimeoutPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecHttpRouteTimeoutProperty): any;
export declare function dataAwsAppmeshRouteHttpRoutePropertyToTerraform(struct?: DataAwsAppmeshRoute.HttpRouteProperty): any;
export declare function dataAwsAppmeshRouteHttpRoutePropertyToHclTerraform(struct?: DataAwsAppmeshRoute.HttpRouteProperty): any;
export declare function dataAwsAppmeshRouteSpecTcpRouteActionWeightedTargetPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecTcpRouteActionWeightedTargetProperty): any;
export declare function dataAwsAppmeshRouteSpecTcpRouteActionWeightedTargetPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecTcpRouteActionWeightedTargetProperty): any;
export declare function dataAwsAppmeshRouteSpecTcpRouteActionPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecTcpRouteActionProperty): any;
export declare function dataAwsAppmeshRouteSpecTcpRouteActionPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecTcpRouteActionProperty): any;
export declare function dataAwsAppmeshRouteSpecTcpRouteMatchPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecTcpRouteMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecTcpRouteMatchPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecTcpRouteMatchProperty): any;
export declare function dataAwsAppmeshRouteSpecTcpRouteTimeoutIdlePropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecTcpRouteTimeoutIdleProperty): any;
export declare function dataAwsAppmeshRouteSpecTcpRouteTimeoutIdlePropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecTcpRouteTimeoutIdleProperty): any;
export declare function dataAwsAppmeshRouteSpecTcpRouteTimeoutPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecTcpRouteTimeoutProperty): any;
export declare function dataAwsAppmeshRouteSpecTcpRouteTimeoutPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecTcpRouteTimeoutProperty): any;
export declare function dataAwsAppmeshRouteTcpRoutePropertyToTerraform(struct?: DataAwsAppmeshRoute.TcpRouteProperty): any;
export declare function dataAwsAppmeshRouteTcpRoutePropertyToHclTerraform(struct?: DataAwsAppmeshRoute.TcpRouteProperty): any;
export declare function dataAwsAppmeshRouteSpecPropertyToTerraform(struct?: DataAwsAppmeshRoute.SpecProperty): any;
export declare function dataAwsAppmeshRouteSpecPropertyToHclTerraform(struct?: DataAwsAppmeshRoute.SpecProperty): any;
export declare namespace DataAwsAppmeshRoute {
    interface SpecGrpcRouteActionWeightedTargetProperty {
    }
    class SpecGrpcRouteActionWeightedTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteActionWeightedTargetProperty | undefined;
        set internalValue(value: SpecGrpcRouteActionWeightedTargetProperty | undefined);
        get port(): number;
        get virtualNode(): string;
        get weight(): number;
    }
    class SpecGrpcRouteActionWeightedTargetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteActionWeightedTargetPropertyOutputReference;
    }
    interface SpecGrpcRouteActionProperty {
    }
    class SpecGrpcRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteActionProperty | undefined;
        set internalValue(value: SpecGrpcRouteActionProperty | undefined);
        private _weightedTarget;
        get weightedTarget(): SpecGrpcRouteActionWeightedTargetPropertyList;
    }
    class SpecGrpcRouteActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteActionPropertyOutputReference;
    }
    interface SpecGrpcRouteMatchMetadataMatchRangeProperty {
    }
    class SpecGrpcRouteMatchMetadataMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteMatchMetadataMatchRangeProperty | undefined;
        set internalValue(value: SpecGrpcRouteMatchMetadataMatchRangeProperty | undefined);
        get end(): number;
        get start(): number;
    }
    class SpecGrpcRouteMatchMetadataMatchRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteMatchMetadataMatchRangePropertyOutputReference;
    }
    interface SpecGrpcRouteMatchMetadataMatchProperty {
    }
    class SpecGrpcRouteMatchMetadataMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteMatchMetadataMatchProperty | undefined;
        set internalValue(value: SpecGrpcRouteMatchMetadataMatchProperty | undefined);
        get exact(): string;
        get prefix(): string;
        private _range;
        get range(): SpecGrpcRouteMatchMetadataMatchRangePropertyList;
        get regex(): string;
        get suffix(): string;
    }
    class SpecGrpcRouteMatchMetadataMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteMatchMetadataMatchPropertyOutputReference;
    }
    interface MetadataProperty {
    }
    class MetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataProperty | undefined;
        set internalValue(value: MetadataProperty | undefined);
        get invert(): cdktn.IResolvable;
        private _match;
        get match(): SpecGrpcRouteMatchMetadataMatchPropertyList;
        get name(): string;
    }
    class MetadataPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataPropertyOutputReference;
    }
    interface SpecGrpcRouteMatchProperty {
    }
    class SpecGrpcRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteMatchProperty | undefined;
        set internalValue(value: SpecGrpcRouteMatchProperty | undefined);
        private _metadata;
        get metadata(): MetadataPropertyList;
        get methodName(): string;
        get port(): number;
        get prefix(): string;
        get serviceName(): string;
    }
    class SpecGrpcRouteMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteMatchPropertyOutputReference;
    }
    interface SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty {
    }
    class SpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty | undefined;
        set internalValue(value: SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyOutputReference;
    }
    interface SpecGrpcRouteRetryPolicyProperty {
    }
    class SpecGrpcRouteRetryPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteRetryPolicyProperty | undefined;
        set internalValue(value: SpecGrpcRouteRetryPolicyProperty | undefined);
        get grpcRetryEvents(): string[];
        get httpRetryEvents(): string[];
        get maxRetries(): number;
        private _perRetryTimeout;
        get perRetryTimeout(): SpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyList;
        get tcpRetryEvents(): string[];
    }
    class SpecGrpcRouteRetryPolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteRetryPolicyPropertyOutputReference;
    }
    interface SpecGrpcRouteTimeoutIdleProperty {
    }
    class SpecGrpcRouteTimeoutIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteTimeoutIdleProperty | undefined;
        set internalValue(value: SpecGrpcRouteTimeoutIdleProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecGrpcRouteTimeoutIdlePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteTimeoutIdlePropertyOutputReference;
    }
    interface SpecGrpcRouteTimeoutPerRequestProperty {
    }
    class SpecGrpcRouteTimeoutPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteTimeoutPerRequestProperty | undefined;
        set internalValue(value: SpecGrpcRouteTimeoutPerRequestProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecGrpcRouteTimeoutPerRequestPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteTimeoutPerRequestPropertyOutputReference;
    }
    interface SpecGrpcRouteTimeoutProperty {
    }
    class SpecGrpcRouteTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteTimeoutProperty | undefined;
        set internalValue(value: SpecGrpcRouteTimeoutProperty | undefined);
        private _idle;
        get idle(): SpecGrpcRouteTimeoutIdlePropertyList;
        private _perRequest;
        get perRequest(): SpecGrpcRouteTimeoutPerRequestPropertyList;
    }
    class SpecGrpcRouteTimeoutPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteTimeoutPropertyOutputReference;
    }
    interface GrpcRouteProperty {
    }
    class GrpcRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GrpcRouteProperty | undefined;
        set internalValue(value: GrpcRouteProperty | undefined);
        private _action;
        get action(): SpecGrpcRouteActionPropertyList;
        private _match;
        get match(): SpecGrpcRouteMatchPropertyList;
        private _retryPolicy;
        get retryPolicy(): SpecGrpcRouteRetryPolicyPropertyList;
        private _timeout;
        get timeout(): SpecGrpcRouteTimeoutPropertyList;
    }
    class GrpcRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GrpcRoutePropertyOutputReference;
    }
    interface SpecHttp2RouteActionWeightedTargetProperty {
    }
    class SpecHttp2RouteActionWeightedTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionWeightedTargetProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionWeightedTargetProperty | undefined);
        get port(): number;
        get virtualNode(): string;
        get weight(): number;
    }
    class SpecHttp2RouteActionWeightedTargetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionWeightedTargetPropertyOutputReference;
    }
    interface SpecHttp2RouteActionProperty {
    }
    class SpecHttp2RouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionProperty | undefined);
        private _weightedTarget;
        get weightedTarget(): SpecHttp2RouteActionWeightedTargetPropertyList;
    }
    class SpecHttp2RouteActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchHeaderMatchRangeProperty {
    }
    class SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined);
        get end(): number;
        get start(): number;
    }
    class SpecHttp2RouteMatchHeaderMatchRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference;
    }
    interface SpecHttp2RouteMatchHeaderMatchProperty {
    }
    class SpecHttp2RouteMatchHeaderMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchHeaderMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderMatchProperty | undefined);
        get exact(): string;
        get prefix(): string;
        private _range;
        get range(): SpecHttp2RouteMatchHeaderMatchRangePropertyList;
        get regex(): string;
        get suffix(): string;
    }
    class SpecHttp2RouteMatchHeaderMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchHeaderMatchPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchHeaderProperty {
    }
    class SpecHttp2RouteMatchHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchHeaderProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderProperty | undefined);
        get invert(): cdktn.IResolvable;
        private _match;
        get match(): SpecHttp2RouteMatchHeaderMatchPropertyList;
        get name(): string;
    }
    class SpecHttp2RouteMatchHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchHeaderPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchPathProperty {
    }
    class SpecHttp2RouteMatchPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchPathProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchPathProperty | undefined);
        get exact(): string;
        get regex(): string;
    }
    class SpecHttp2RouteMatchPathPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchPathPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchQueryParameterMatchProperty {
    }
    class SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchQueryParameterMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchQueryParameterMatchProperty | undefined);
        get exact(): string;
    }
    class SpecHttp2RouteMatchQueryParameterMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchQueryParameterProperty {
    }
    class SpecHttp2RouteMatchQueryParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchQueryParameterProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchQueryParameterProperty | undefined);
        private _match;
        get match(): SpecHttp2RouteMatchQueryParameterMatchPropertyList;
        get name(): string;
    }
    class SpecHttp2RouteMatchQueryParameterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchQueryParameterPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchProperty {
    }
    class SpecHttp2RouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchProperty | undefined);
        private _header;
        get header(): SpecHttp2RouteMatchHeaderPropertyList;
        get method(): string;
        private _path;
        get path(): SpecHttp2RouteMatchPathPropertyList;
        get port(): number;
        get prefix(): string;
        private _queryParameter;
        get queryParameter(): SpecHttp2RouteMatchQueryParameterPropertyList;
        get scheme(): string;
    }
    class SpecHttp2RouteMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchPropertyOutputReference;
    }
    interface SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty {
    }
    class SpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty | undefined;
        set internalValue(value: SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyOutputReference;
    }
    interface SpecHttp2RouteRetryPolicyProperty {
    }
    class SpecHttp2RouteRetryPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteRetryPolicyProperty | undefined;
        set internalValue(value: SpecHttp2RouteRetryPolicyProperty | undefined);
        get httpRetryEvents(): string[];
        get maxRetries(): number;
        private _perRetryTimeout;
        get perRetryTimeout(): SpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyList;
        get tcpRetryEvents(): string[];
    }
    class SpecHttp2RouteRetryPolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteRetryPolicyPropertyOutputReference;
    }
    interface SpecHttp2RouteTimeoutIdleProperty {
    }
    class SpecHttp2RouteTimeoutIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteTimeoutIdleProperty | undefined;
        set internalValue(value: SpecHttp2RouteTimeoutIdleProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecHttp2RouteTimeoutIdlePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteTimeoutIdlePropertyOutputReference;
    }
    interface SpecHttp2RouteTimeoutPerRequestProperty {
    }
    class SpecHttp2RouteTimeoutPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteTimeoutPerRequestProperty | undefined;
        set internalValue(value: SpecHttp2RouteTimeoutPerRequestProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecHttp2RouteTimeoutPerRequestPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteTimeoutPerRequestPropertyOutputReference;
    }
    interface SpecHttp2RouteTimeoutProperty {
    }
    class SpecHttp2RouteTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteTimeoutProperty | undefined;
        set internalValue(value: SpecHttp2RouteTimeoutProperty | undefined);
        private _idle;
        get idle(): SpecHttp2RouteTimeoutIdlePropertyList;
        private _perRequest;
        get perRequest(): SpecHttp2RouteTimeoutPerRequestPropertyList;
    }
    class SpecHttp2RouteTimeoutPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteTimeoutPropertyOutputReference;
    }
    interface Http2RouteProperty {
    }
    class Http2RoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Http2RouteProperty | undefined;
        set internalValue(value: Http2RouteProperty | undefined);
        private _action;
        get action(): SpecHttp2RouteActionPropertyList;
        private _match;
        get match(): SpecHttp2RouteMatchPropertyList;
        private _retryPolicy;
        get retryPolicy(): SpecHttp2RouteRetryPolicyPropertyList;
        private _timeout;
        get timeout(): SpecHttp2RouteTimeoutPropertyList;
    }
    class Http2RoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Http2RoutePropertyOutputReference;
    }
    interface SpecHttpRouteActionWeightedTargetProperty {
    }
    class SpecHttpRouteActionWeightedTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionWeightedTargetProperty | undefined;
        set internalValue(value: SpecHttpRouteActionWeightedTargetProperty | undefined);
        get port(): number;
        get virtualNode(): string;
        get weight(): number;
    }
    class SpecHttpRouteActionWeightedTargetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionWeightedTargetPropertyOutputReference;
    }
    interface SpecHttpRouteActionProperty {
    }
    class SpecHttpRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionProperty | undefined;
        set internalValue(value: SpecHttpRouteActionProperty | undefined);
        private _weightedTarget;
        get weightedTarget(): SpecHttpRouteActionWeightedTargetPropertyList;
    }
    class SpecHttpRouteActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionPropertyOutputReference;
    }
    interface SpecHttpRouteMatchHeaderMatchRangeProperty {
    }
    class SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchHeaderMatchRangeProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderMatchRangeProperty | undefined);
        get end(): number;
        get start(): number;
    }
    class SpecHttpRouteMatchHeaderMatchRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference;
    }
    interface SpecHttpRouteMatchHeaderMatchProperty {
    }
    class SpecHttpRouteMatchHeaderMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchHeaderMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderMatchProperty | undefined);
        get exact(): string;
        get prefix(): string;
        private _range;
        get range(): SpecHttpRouteMatchHeaderMatchRangePropertyList;
        get regex(): string;
        get suffix(): string;
    }
    class SpecHttpRouteMatchHeaderMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchHeaderMatchPropertyOutputReference;
    }
    interface SpecHttpRouteMatchHeaderProperty {
    }
    class SpecHttpRouteMatchHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchHeaderProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderProperty | undefined);
        get invert(): cdktn.IResolvable;
        private _match;
        get match(): SpecHttpRouteMatchHeaderMatchPropertyList;
        get name(): string;
    }
    class SpecHttpRouteMatchHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchHeaderPropertyOutputReference;
    }
    interface SpecHttpRouteMatchPathProperty {
    }
    class SpecHttpRouteMatchPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchPathProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchPathProperty | undefined);
        get exact(): string;
        get regex(): string;
    }
    class SpecHttpRouteMatchPathPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchPathPropertyOutputReference;
    }
    interface SpecHttpRouteMatchQueryParameterMatchProperty {
    }
    class SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchQueryParameterMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchQueryParameterMatchProperty | undefined);
        get exact(): string;
    }
    class SpecHttpRouteMatchQueryParameterMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference;
    }
    interface SpecHttpRouteMatchQueryParameterProperty {
    }
    class SpecHttpRouteMatchQueryParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchQueryParameterProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchQueryParameterProperty | undefined);
        private _match;
        get match(): SpecHttpRouteMatchQueryParameterMatchPropertyList;
        get name(): string;
    }
    class SpecHttpRouteMatchQueryParameterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchQueryParameterPropertyOutputReference;
    }
    interface SpecHttpRouteMatchProperty {
    }
    class SpecHttpRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchProperty | undefined);
        private _header;
        get header(): SpecHttpRouteMatchHeaderPropertyList;
        get method(): string;
        private _path;
        get path(): SpecHttpRouteMatchPathPropertyList;
        get port(): number;
        get prefix(): string;
        private _queryParameter;
        get queryParameter(): SpecHttpRouteMatchQueryParameterPropertyList;
        get scheme(): string;
    }
    class SpecHttpRouteMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchPropertyOutputReference;
    }
    interface SpecHttpRouteRetryPolicyPerRetryTimeoutProperty {
    }
    class SpecHttpRouteRetryPolicyPerRetryTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteRetryPolicyPerRetryTimeoutProperty | undefined;
        set internalValue(value: SpecHttpRouteRetryPolicyPerRetryTimeoutProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecHttpRouteRetryPolicyPerRetryTimeoutPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteRetryPolicyPerRetryTimeoutPropertyOutputReference;
    }
    interface SpecHttpRouteRetryPolicyProperty {
    }
    class SpecHttpRouteRetryPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteRetryPolicyProperty | undefined;
        set internalValue(value: SpecHttpRouteRetryPolicyProperty | undefined);
        get httpRetryEvents(): string[];
        get maxRetries(): number;
        private _perRetryTimeout;
        get perRetryTimeout(): SpecHttpRouteRetryPolicyPerRetryTimeoutPropertyList;
        get tcpRetryEvents(): string[];
    }
    class SpecHttpRouteRetryPolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteRetryPolicyPropertyOutputReference;
    }
    interface SpecHttpRouteTimeoutIdleProperty {
    }
    class SpecHttpRouteTimeoutIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteTimeoutIdleProperty | undefined;
        set internalValue(value: SpecHttpRouteTimeoutIdleProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecHttpRouteTimeoutIdlePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteTimeoutIdlePropertyOutputReference;
    }
    interface SpecHttpRouteTimeoutPerRequestProperty {
    }
    class SpecHttpRouteTimeoutPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteTimeoutPerRequestProperty | undefined;
        set internalValue(value: SpecHttpRouteTimeoutPerRequestProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecHttpRouteTimeoutPerRequestPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteTimeoutPerRequestPropertyOutputReference;
    }
    interface SpecHttpRouteTimeoutProperty {
    }
    class SpecHttpRouteTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteTimeoutProperty | undefined;
        set internalValue(value: SpecHttpRouteTimeoutProperty | undefined);
        private _idle;
        get idle(): SpecHttpRouteTimeoutIdlePropertyList;
        private _perRequest;
        get perRequest(): SpecHttpRouteTimeoutPerRequestPropertyList;
    }
    class SpecHttpRouteTimeoutPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteTimeoutPropertyOutputReference;
    }
    interface HttpRouteProperty {
    }
    class HttpRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HttpRouteProperty | undefined;
        set internalValue(value: HttpRouteProperty | undefined);
        private _action;
        get action(): SpecHttpRouteActionPropertyList;
        private _match;
        get match(): SpecHttpRouteMatchPropertyList;
        private _retryPolicy;
        get retryPolicy(): SpecHttpRouteRetryPolicyPropertyList;
        private _timeout;
        get timeout(): SpecHttpRouteTimeoutPropertyList;
    }
    class HttpRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HttpRoutePropertyOutputReference;
    }
    interface SpecTcpRouteActionWeightedTargetProperty {
    }
    class SpecTcpRouteActionWeightedTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecTcpRouteActionWeightedTargetProperty | undefined;
        set internalValue(value: SpecTcpRouteActionWeightedTargetProperty | undefined);
        get port(): number;
        get virtualNode(): string;
        get weight(): number;
    }
    class SpecTcpRouteActionWeightedTargetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecTcpRouteActionWeightedTargetPropertyOutputReference;
    }
    interface SpecTcpRouteActionProperty {
    }
    class SpecTcpRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecTcpRouteActionProperty | undefined;
        set internalValue(value: SpecTcpRouteActionProperty | undefined);
        private _weightedTarget;
        get weightedTarget(): SpecTcpRouteActionWeightedTargetPropertyList;
    }
    class SpecTcpRouteActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecTcpRouteActionPropertyOutputReference;
    }
    interface SpecTcpRouteMatchProperty {
    }
    class SpecTcpRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecTcpRouteMatchProperty | undefined;
        set internalValue(value: SpecTcpRouteMatchProperty | undefined);
        get port(): number;
    }
    class SpecTcpRouteMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecTcpRouteMatchPropertyOutputReference;
    }
    interface SpecTcpRouteTimeoutIdleProperty {
    }
    class SpecTcpRouteTimeoutIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecTcpRouteTimeoutIdleProperty | undefined;
        set internalValue(value: SpecTcpRouteTimeoutIdleProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecTcpRouteTimeoutIdlePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecTcpRouteTimeoutIdlePropertyOutputReference;
    }
    interface SpecTcpRouteTimeoutProperty {
    }
    class SpecTcpRouteTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecTcpRouteTimeoutProperty | undefined;
        set internalValue(value: SpecTcpRouteTimeoutProperty | undefined);
        private _idle;
        get idle(): SpecTcpRouteTimeoutIdlePropertyList;
    }
    class SpecTcpRouteTimeoutPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecTcpRouteTimeoutPropertyOutputReference;
    }
    interface TcpRouteProperty {
    }
    class TcpRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TcpRouteProperty | undefined;
        set internalValue(value: TcpRouteProperty | undefined);
        private _action;
        get action(): SpecTcpRouteActionPropertyList;
        private _match;
        get match(): SpecTcpRouteMatchPropertyList;
        private _timeout;
        get timeout(): SpecTcpRouteTimeoutPropertyList;
    }
    class TcpRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TcpRoutePropertyOutputReference;
    }
    interface SpecProperty {
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _grpcRoute;
        get grpcRoute(): GrpcRoutePropertyList;
        private _http2Route;
        get http2Route(): Http2RoutePropertyList;
        private _httpRoute;
        get httpRoute(): HttpRoutePropertyList;
        get priority(): number;
        private _tcpRoute;
        get tcpRoute(): TcpRoutePropertyList;
    }
    class SpecPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecPropertyOutputReference;
    }
}
