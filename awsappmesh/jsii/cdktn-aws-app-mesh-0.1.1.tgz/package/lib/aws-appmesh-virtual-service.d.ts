import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppmeshVirtualServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_service#id AwsAppmeshVirtualService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_service#mesh_name AwsAppmeshVirtualService#mesh_name}
    */
    readonly meshName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_service#mesh_owner AwsAppmeshVirtualService#mesh_owner}
    */
    readonly meshOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_service#name AwsAppmeshVirtualService#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_service#region AwsAppmeshVirtualService#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_service#tags AwsAppmeshVirtualService#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_service#tags_all AwsAppmeshVirtualService#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_service#spec AwsAppmeshVirtualService#spec}
    */
    readonly spec: AwsAppmeshVirtualService.SpecProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_service aws_appmesh_virtual_service}
*/
export declare class AwsAppmeshVirtualService extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appmesh_virtual_service";
    /**
    * Generates CDKTN code for importing a AwsAppmeshVirtualService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppmeshVirtualService to import
    * @param importFromId The id of the existing AwsAppmeshVirtualService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppmeshVirtualService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_service aws_appmesh_virtual_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppmeshVirtualServiceConfig
    */
    constructor(scope: Construct, id: string, config: AwsAppmeshVirtualServiceConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _meshName?;
    get meshName(): string;
    set meshName(value: string);
    get meshNameInput(): string | undefined;
    private _meshOwner?;
    get meshOwner(): string;
    set meshOwner(value: string);
    resetMeshOwner(): void;
    get meshOwnerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _spec;
    get spec(): AwsAppmeshVirtualService.SpecPropertyOutputReference;
    putSpec(value: AwsAppmeshVirtualService.SpecProperty): void;
    get specInput(): AwsAppmeshVirtualService.SpecProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppmeshVirtualServiceVirtualNodePropertyToTerraform(struct?: AwsAppmeshVirtualService.VirtualNodePropertyOutputReference | AwsAppmeshVirtualService.VirtualNodeProperty): any;
export declare function awsAppmeshVirtualServiceVirtualNodePropertyToHclTerraform(struct?: AwsAppmeshVirtualService.VirtualNodePropertyOutputReference | AwsAppmeshVirtualService.VirtualNodeProperty): any;
export declare function awsAppmeshVirtualServiceVirtualRouterPropertyToTerraform(struct?: AwsAppmeshVirtualService.VirtualRouterPropertyOutputReference | AwsAppmeshVirtualService.VirtualRouterProperty): any;
export declare function awsAppmeshVirtualServiceVirtualRouterPropertyToHclTerraform(struct?: AwsAppmeshVirtualService.VirtualRouterPropertyOutputReference | AwsAppmeshVirtualService.VirtualRouterProperty): any;
export declare function awsAppmeshVirtualServiceProviderPropertyToTerraform(struct?: AwsAppmeshVirtualService.ProviderPropertyOutputReference | AwsAppmeshVirtualService.ProviderProperty): any;
export declare function awsAppmeshVirtualServiceProviderPropertyToHclTerraform(struct?: AwsAppmeshVirtualService.ProviderPropertyOutputReference | AwsAppmeshVirtualService.ProviderProperty): any;
export declare function awsAppmeshVirtualServiceSpecPropertyToTerraform(struct?: AwsAppmeshVirtualService.SpecPropertyOutputReference | AwsAppmeshVirtualService.SpecProperty): any;
export declare function awsAppmeshVirtualServiceSpecPropertyToHclTerraform(struct?: AwsAppmeshVirtualService.SpecPropertyOutputReference | AwsAppmeshVirtualService.SpecProperty): any;
export declare namespace AwsAppmeshVirtualService {
    interface VirtualNodeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_service#virtual_node_name AwsAppmeshVirtualService#virtual_node_name}
        */
        readonly virtualNodeName: string;
    }
    class VirtualNodePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VirtualNodeProperty | undefined;
        set internalValue(value: VirtualNodeProperty | undefined);
        private _virtualNodeName?;
        get virtualNodeName(): string;
        set virtualNodeName(value: string);
        get virtualNodeNameInput(): string | undefined;
    }
    interface VirtualRouterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_service#virtual_router_name AwsAppmeshVirtualService#virtual_router_name}
        */
        readonly virtualRouterName: string;
    }
    class VirtualRouterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VirtualRouterProperty | undefined;
        set internalValue(value: VirtualRouterProperty | undefined);
        private _virtualRouterName?;
        get virtualRouterName(): string;
        set virtualRouterName(value: string);
        get virtualRouterNameInput(): string | undefined;
    }
    interface ProviderProperty {
        /**
        * virtual_node block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_service#virtual_node AwsAppmeshVirtualService#virtual_node}
        */
        readonly virtualNode?: VirtualNodeProperty;
        /**
        * virtual_router block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_service#virtual_router AwsAppmeshVirtualService#virtual_router}
        */
        readonly virtualRouter?: VirtualRouterProperty;
    }
    class ProviderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProviderProperty | undefined;
        set internalValue(value: ProviderProperty | undefined);
        private _virtualNode;
        get virtualNode(): VirtualNodePropertyOutputReference;
        putVirtualNode(value: VirtualNodeProperty): void;
        resetVirtualNode(): void;
        get virtualNodeInput(): VirtualNodeProperty | undefined;
        private _virtualRouter;
        get virtualRouter(): VirtualRouterPropertyOutputReference;
        putVirtualRouter(value: VirtualRouterProperty): void;
        resetVirtualRouter(): void;
        get virtualRouterInput(): VirtualRouterProperty | undefined;
    }
    interface SpecProperty {
        /**
        * provider block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_service#provider AwsAppmeshVirtualService#provider}
        */
        readonly provider?: ProviderProperty;
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _provider;
        get provider(): ProviderPropertyOutputReference;
        putProvider(value: ProviderProperty): void;
        resetProvider(): void;
        get providerInput(): ProviderProperty | undefined;
    }
}
