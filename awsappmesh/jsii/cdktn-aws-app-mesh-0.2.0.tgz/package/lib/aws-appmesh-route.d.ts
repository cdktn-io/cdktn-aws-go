import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfRouteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#id TfRoute#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#mesh_name TfRoute#mesh_name}
    */
    readonly meshName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#mesh_owner TfRoute#mesh_owner}
    */
    readonly meshOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#name TfRoute#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#region TfRoute#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#tags TfRoute#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#tags_all TfRoute#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#virtual_router_name TfRoute#virtual_router_name}
    */
    readonly virtualRouterName: string;
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#spec TfRoute#spec}
    */
    readonly spec: TfRoute.SpecProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route aws_appmesh_route}
*/
export declare class TfRoute extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appmesh_route";
    /**
    * Generates CDKTN code for importing a TfRoute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfRoute to import
    * @param importFromId The id of the existing TfRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route aws_appmesh_route} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfRouteConfig
    */
    constructor(scope: Construct, id: string, config: TfRouteConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _meshName?;
    get meshName(): string;
    set meshName(value: string);
    get meshNameInput(): string | undefined;
    private _meshOwner?;
    get meshOwner(): string;
    set meshOwner(value: string);
    resetMeshOwner(): void;
    get meshOwnerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _virtualRouterName?;
    get virtualRouterName(): string;
    set virtualRouterName(value: string);
    get virtualRouterNameInput(): string | undefined;
    private _spec;
    get spec(): TfRoute.SpecPropertyOutputReference;
    putSpec(value: TfRoute.SpecProperty): void;
    get specInput(): TfRoute.SpecProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfRouteSpecGrpcRouteActionWeightedTargetPropertyToTerraform(struct?: TfRoute.SpecGrpcRouteActionWeightedTargetProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecGrpcRouteActionWeightedTargetPropertyToHclTerraform(struct?: TfRoute.SpecGrpcRouteActionWeightedTargetProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecGrpcRouteActionPropertyToTerraform(struct?: TfRoute.SpecGrpcRouteActionPropertyOutputReference | TfRoute.SpecGrpcRouteActionProperty): any;
export declare function tfRouteSpecGrpcRouteActionPropertyToHclTerraform(struct?: TfRoute.SpecGrpcRouteActionPropertyOutputReference | TfRoute.SpecGrpcRouteActionProperty): any;
export declare function tfRouteSpecGrpcRouteMatchMetadataMatchRangePropertyToTerraform(struct?: TfRoute.SpecGrpcRouteMatchMetadataMatchRangePropertyOutputReference | TfRoute.SpecGrpcRouteMatchMetadataMatchRangeProperty): any;
export declare function tfRouteSpecGrpcRouteMatchMetadataMatchRangePropertyToHclTerraform(struct?: TfRoute.SpecGrpcRouteMatchMetadataMatchRangePropertyOutputReference | TfRoute.SpecGrpcRouteMatchMetadataMatchRangeProperty): any;
export declare function tfRouteSpecGrpcRouteMatchMetadataMatchPropertyToTerraform(struct?: TfRoute.SpecGrpcRouteMatchMetadataMatchPropertyOutputReference | TfRoute.SpecGrpcRouteMatchMetadataMatchProperty): any;
export declare function tfRouteSpecGrpcRouteMatchMetadataMatchPropertyToHclTerraform(struct?: TfRoute.SpecGrpcRouteMatchMetadataMatchPropertyOutputReference | TfRoute.SpecGrpcRouteMatchMetadataMatchProperty): any;
export declare function tfRouteMetadataPropertyToTerraform(struct?: TfRoute.MetadataProperty | cdktn.IResolvable): any;
export declare function tfRouteMetadataPropertyToHclTerraform(struct?: TfRoute.MetadataProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecGrpcRouteMatchPropertyToTerraform(struct?: TfRoute.SpecGrpcRouteMatchPropertyOutputReference | TfRoute.SpecGrpcRouteMatchProperty): any;
export declare function tfRouteSpecGrpcRouteMatchPropertyToHclTerraform(struct?: TfRoute.SpecGrpcRouteMatchPropertyOutputReference | TfRoute.SpecGrpcRouteMatchProperty): any;
export declare function tfRouteSpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyToTerraform(struct?: TfRoute.SpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyOutputReference | TfRoute.SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function tfRouteSpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyToHclTerraform(struct?: TfRoute.SpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyOutputReference | TfRoute.SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function tfRouteSpecGrpcRouteRetryPolicyPropertyToTerraform(struct?: TfRoute.SpecGrpcRouteRetryPolicyPropertyOutputReference | TfRoute.SpecGrpcRouteRetryPolicyProperty): any;
export declare function tfRouteSpecGrpcRouteRetryPolicyPropertyToHclTerraform(struct?: TfRoute.SpecGrpcRouteRetryPolicyPropertyOutputReference | TfRoute.SpecGrpcRouteRetryPolicyProperty): any;
export declare function tfRouteSpecGrpcRouteTimeoutIdlePropertyToTerraform(struct?: TfRoute.SpecGrpcRouteTimeoutIdlePropertyOutputReference | TfRoute.SpecGrpcRouteTimeoutIdleProperty): any;
export declare function tfRouteSpecGrpcRouteTimeoutIdlePropertyToHclTerraform(struct?: TfRoute.SpecGrpcRouteTimeoutIdlePropertyOutputReference | TfRoute.SpecGrpcRouteTimeoutIdleProperty): any;
export declare function tfRouteSpecGrpcRouteTimeoutPerRequestPropertyToTerraform(struct?: TfRoute.SpecGrpcRouteTimeoutPerRequestPropertyOutputReference | TfRoute.SpecGrpcRouteTimeoutPerRequestProperty): any;
export declare function tfRouteSpecGrpcRouteTimeoutPerRequestPropertyToHclTerraform(struct?: TfRoute.SpecGrpcRouteTimeoutPerRequestPropertyOutputReference | TfRoute.SpecGrpcRouteTimeoutPerRequestProperty): any;
export declare function tfRouteSpecGrpcRouteTimeoutPropertyToTerraform(struct?: TfRoute.SpecGrpcRouteTimeoutPropertyOutputReference | TfRoute.SpecGrpcRouteTimeoutProperty): any;
export declare function tfRouteSpecGrpcRouteTimeoutPropertyToHclTerraform(struct?: TfRoute.SpecGrpcRouteTimeoutPropertyOutputReference | TfRoute.SpecGrpcRouteTimeoutProperty): any;
export declare function tfRouteGrpcRoutePropertyToTerraform(struct?: TfRoute.GrpcRoutePropertyOutputReference | TfRoute.GrpcRouteProperty): any;
export declare function tfRouteGrpcRoutePropertyToHclTerraform(struct?: TfRoute.GrpcRoutePropertyOutputReference | TfRoute.GrpcRouteProperty): any;
export declare function tfRouteSpecHttp2RouteActionWeightedTargetPropertyToTerraform(struct?: TfRoute.SpecHttp2RouteActionWeightedTargetProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecHttp2RouteActionWeightedTargetPropertyToHclTerraform(struct?: TfRoute.SpecHttp2RouteActionWeightedTargetProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecHttp2RouteActionPropertyToTerraform(struct?: TfRoute.SpecHttp2RouteActionPropertyOutputReference | TfRoute.SpecHttp2RouteActionProperty): any;
export declare function tfRouteSpecHttp2RouteActionPropertyToHclTerraform(struct?: TfRoute.SpecHttp2RouteActionPropertyOutputReference | TfRoute.SpecHttp2RouteActionProperty): any;
export declare function tfRouteSpecHttp2RouteMatchHeaderMatchRangePropertyToTerraform(struct?: TfRoute.SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference | TfRoute.SpecHttp2RouteMatchHeaderMatchRangeProperty): any;
export declare function tfRouteSpecHttp2RouteMatchHeaderMatchRangePropertyToHclTerraform(struct?: TfRoute.SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference | TfRoute.SpecHttp2RouteMatchHeaderMatchRangeProperty): any;
export declare function tfRouteSpecHttp2RouteMatchHeaderMatchPropertyToTerraform(struct?: TfRoute.SpecHttp2RouteMatchHeaderMatchPropertyOutputReference | TfRoute.SpecHttp2RouteMatchHeaderMatchProperty): any;
export declare function tfRouteSpecHttp2RouteMatchHeaderMatchPropertyToHclTerraform(struct?: TfRoute.SpecHttp2RouteMatchHeaderMatchPropertyOutputReference | TfRoute.SpecHttp2RouteMatchHeaderMatchProperty): any;
export declare function tfRouteSpecHttp2RouteMatchHeaderPropertyToTerraform(struct?: TfRoute.SpecHttp2RouteMatchHeaderProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecHttp2RouteMatchHeaderPropertyToHclTerraform(struct?: TfRoute.SpecHttp2RouteMatchHeaderProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecHttp2RouteMatchPathPropertyToTerraform(struct?: TfRoute.SpecHttp2RouteMatchPathPropertyOutputReference | TfRoute.SpecHttp2RouteMatchPathProperty): any;
export declare function tfRouteSpecHttp2RouteMatchPathPropertyToHclTerraform(struct?: TfRoute.SpecHttp2RouteMatchPathPropertyOutputReference | TfRoute.SpecHttp2RouteMatchPathProperty): any;
export declare function tfRouteSpecHttp2RouteMatchQueryParameterMatchPropertyToTerraform(struct?: TfRoute.SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference | TfRoute.SpecHttp2RouteMatchQueryParameterMatchProperty): any;
export declare function tfRouteSpecHttp2RouteMatchQueryParameterMatchPropertyToHclTerraform(struct?: TfRoute.SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference | TfRoute.SpecHttp2RouteMatchQueryParameterMatchProperty): any;
export declare function tfRouteSpecHttp2RouteMatchQueryParameterPropertyToTerraform(struct?: TfRoute.SpecHttp2RouteMatchQueryParameterProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecHttp2RouteMatchQueryParameterPropertyToHclTerraform(struct?: TfRoute.SpecHttp2RouteMatchQueryParameterProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecHttp2RouteMatchPropertyToTerraform(struct?: TfRoute.SpecHttp2RouteMatchPropertyOutputReference | TfRoute.SpecHttp2RouteMatchProperty): any;
export declare function tfRouteSpecHttp2RouteMatchPropertyToHclTerraform(struct?: TfRoute.SpecHttp2RouteMatchPropertyOutputReference | TfRoute.SpecHttp2RouteMatchProperty): any;
export declare function tfRouteSpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyToTerraform(struct?: TfRoute.SpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyOutputReference | TfRoute.SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function tfRouteSpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyToHclTerraform(struct?: TfRoute.SpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyOutputReference | TfRoute.SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function tfRouteSpecHttp2RouteRetryPolicyPropertyToTerraform(struct?: TfRoute.SpecHttp2RouteRetryPolicyPropertyOutputReference | TfRoute.SpecHttp2RouteRetryPolicyProperty): any;
export declare function tfRouteSpecHttp2RouteRetryPolicyPropertyToHclTerraform(struct?: TfRoute.SpecHttp2RouteRetryPolicyPropertyOutputReference | TfRoute.SpecHttp2RouteRetryPolicyProperty): any;
export declare function tfRouteSpecHttp2RouteTimeoutIdlePropertyToTerraform(struct?: TfRoute.SpecHttp2RouteTimeoutIdlePropertyOutputReference | TfRoute.SpecHttp2RouteTimeoutIdleProperty): any;
export declare function tfRouteSpecHttp2RouteTimeoutIdlePropertyToHclTerraform(struct?: TfRoute.SpecHttp2RouteTimeoutIdlePropertyOutputReference | TfRoute.SpecHttp2RouteTimeoutIdleProperty): any;
export declare function tfRouteSpecHttp2RouteTimeoutPerRequestPropertyToTerraform(struct?: TfRoute.SpecHttp2RouteTimeoutPerRequestPropertyOutputReference | TfRoute.SpecHttp2RouteTimeoutPerRequestProperty): any;
export declare function tfRouteSpecHttp2RouteTimeoutPerRequestPropertyToHclTerraform(struct?: TfRoute.SpecHttp2RouteTimeoutPerRequestPropertyOutputReference | TfRoute.SpecHttp2RouteTimeoutPerRequestProperty): any;
export declare function tfRouteSpecHttp2RouteTimeoutPropertyToTerraform(struct?: TfRoute.SpecHttp2RouteTimeoutPropertyOutputReference | TfRoute.SpecHttp2RouteTimeoutProperty): any;
export declare function tfRouteSpecHttp2RouteTimeoutPropertyToHclTerraform(struct?: TfRoute.SpecHttp2RouteTimeoutPropertyOutputReference | TfRoute.SpecHttp2RouteTimeoutProperty): any;
export declare function tfRouteHttp2RoutePropertyToTerraform(struct?: TfRoute.Http2RoutePropertyOutputReference | TfRoute.Http2RouteProperty): any;
export declare function tfRouteHttp2RoutePropertyToHclTerraform(struct?: TfRoute.Http2RoutePropertyOutputReference | TfRoute.Http2RouteProperty): any;
export declare function tfRouteSpecHttpRouteActionWeightedTargetPropertyToTerraform(struct?: TfRoute.SpecHttpRouteActionWeightedTargetProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecHttpRouteActionWeightedTargetPropertyToHclTerraform(struct?: TfRoute.SpecHttpRouteActionWeightedTargetProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecHttpRouteActionPropertyToTerraform(struct?: TfRoute.SpecHttpRouteActionPropertyOutputReference | TfRoute.SpecHttpRouteActionProperty): any;
export declare function tfRouteSpecHttpRouteActionPropertyToHclTerraform(struct?: TfRoute.SpecHttpRouteActionPropertyOutputReference | TfRoute.SpecHttpRouteActionProperty): any;
export declare function tfRouteSpecHttpRouteMatchHeaderMatchRangePropertyToTerraform(struct?: TfRoute.SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference | TfRoute.SpecHttpRouteMatchHeaderMatchRangeProperty): any;
export declare function tfRouteSpecHttpRouteMatchHeaderMatchRangePropertyToHclTerraform(struct?: TfRoute.SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference | TfRoute.SpecHttpRouteMatchHeaderMatchRangeProperty): any;
export declare function tfRouteSpecHttpRouteMatchHeaderMatchPropertyToTerraform(struct?: TfRoute.SpecHttpRouteMatchHeaderMatchPropertyOutputReference | TfRoute.SpecHttpRouteMatchHeaderMatchProperty): any;
export declare function tfRouteSpecHttpRouteMatchHeaderMatchPropertyToHclTerraform(struct?: TfRoute.SpecHttpRouteMatchHeaderMatchPropertyOutputReference | TfRoute.SpecHttpRouteMatchHeaderMatchProperty): any;
export declare function tfRouteSpecHttpRouteMatchHeaderPropertyToTerraform(struct?: TfRoute.SpecHttpRouteMatchHeaderProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecHttpRouteMatchHeaderPropertyToHclTerraform(struct?: TfRoute.SpecHttpRouteMatchHeaderProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecHttpRouteMatchPathPropertyToTerraform(struct?: TfRoute.SpecHttpRouteMatchPathPropertyOutputReference | TfRoute.SpecHttpRouteMatchPathProperty): any;
export declare function tfRouteSpecHttpRouteMatchPathPropertyToHclTerraform(struct?: TfRoute.SpecHttpRouteMatchPathPropertyOutputReference | TfRoute.SpecHttpRouteMatchPathProperty): any;
export declare function tfRouteSpecHttpRouteMatchQueryParameterMatchPropertyToTerraform(struct?: TfRoute.SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference | TfRoute.SpecHttpRouteMatchQueryParameterMatchProperty): any;
export declare function tfRouteSpecHttpRouteMatchQueryParameterMatchPropertyToHclTerraform(struct?: TfRoute.SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference | TfRoute.SpecHttpRouteMatchQueryParameterMatchProperty): any;
export declare function tfRouteSpecHttpRouteMatchQueryParameterPropertyToTerraform(struct?: TfRoute.SpecHttpRouteMatchQueryParameterProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecHttpRouteMatchQueryParameterPropertyToHclTerraform(struct?: TfRoute.SpecHttpRouteMatchQueryParameterProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecHttpRouteMatchPropertyToTerraform(struct?: TfRoute.SpecHttpRouteMatchPropertyOutputReference | TfRoute.SpecHttpRouteMatchProperty): any;
export declare function tfRouteSpecHttpRouteMatchPropertyToHclTerraform(struct?: TfRoute.SpecHttpRouteMatchPropertyOutputReference | TfRoute.SpecHttpRouteMatchProperty): any;
export declare function tfRouteSpecHttpRouteRetryPolicyPerRetryTimeoutPropertyToTerraform(struct?: TfRoute.SpecHttpRouteRetryPolicyPerRetryTimeoutPropertyOutputReference | TfRoute.SpecHttpRouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function tfRouteSpecHttpRouteRetryPolicyPerRetryTimeoutPropertyToHclTerraform(struct?: TfRoute.SpecHttpRouteRetryPolicyPerRetryTimeoutPropertyOutputReference | TfRoute.SpecHttpRouteRetryPolicyPerRetryTimeoutProperty): any;
export declare function tfRouteSpecHttpRouteRetryPolicyPropertyToTerraform(struct?: TfRoute.SpecHttpRouteRetryPolicyPropertyOutputReference | TfRoute.SpecHttpRouteRetryPolicyProperty): any;
export declare function tfRouteSpecHttpRouteRetryPolicyPropertyToHclTerraform(struct?: TfRoute.SpecHttpRouteRetryPolicyPropertyOutputReference | TfRoute.SpecHttpRouteRetryPolicyProperty): any;
export declare function tfRouteSpecHttpRouteTimeoutIdlePropertyToTerraform(struct?: TfRoute.SpecHttpRouteTimeoutIdlePropertyOutputReference | TfRoute.SpecHttpRouteTimeoutIdleProperty): any;
export declare function tfRouteSpecHttpRouteTimeoutIdlePropertyToHclTerraform(struct?: TfRoute.SpecHttpRouteTimeoutIdlePropertyOutputReference | TfRoute.SpecHttpRouteTimeoutIdleProperty): any;
export declare function tfRouteSpecHttpRouteTimeoutPerRequestPropertyToTerraform(struct?: TfRoute.SpecHttpRouteTimeoutPerRequestPropertyOutputReference | TfRoute.SpecHttpRouteTimeoutPerRequestProperty): any;
export declare function tfRouteSpecHttpRouteTimeoutPerRequestPropertyToHclTerraform(struct?: TfRoute.SpecHttpRouteTimeoutPerRequestPropertyOutputReference | TfRoute.SpecHttpRouteTimeoutPerRequestProperty): any;
export declare function tfRouteSpecHttpRouteTimeoutPropertyToTerraform(struct?: TfRoute.SpecHttpRouteTimeoutPropertyOutputReference | TfRoute.SpecHttpRouteTimeoutProperty): any;
export declare function tfRouteSpecHttpRouteTimeoutPropertyToHclTerraform(struct?: TfRoute.SpecHttpRouteTimeoutPropertyOutputReference | TfRoute.SpecHttpRouteTimeoutProperty): any;
export declare function tfRouteHttpRoutePropertyToTerraform(struct?: TfRoute.HttpRoutePropertyOutputReference | TfRoute.HttpRouteProperty): any;
export declare function tfRouteHttpRoutePropertyToHclTerraform(struct?: TfRoute.HttpRoutePropertyOutputReference | TfRoute.HttpRouteProperty): any;
export declare function tfRouteSpecTcpRouteActionWeightedTargetPropertyToTerraform(struct?: TfRoute.SpecTcpRouteActionWeightedTargetProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecTcpRouteActionWeightedTargetPropertyToHclTerraform(struct?: TfRoute.SpecTcpRouteActionWeightedTargetProperty | cdktn.IResolvable): any;
export declare function tfRouteSpecTcpRouteActionPropertyToTerraform(struct?: TfRoute.SpecTcpRouteActionPropertyOutputReference | TfRoute.SpecTcpRouteActionProperty): any;
export declare function tfRouteSpecTcpRouteActionPropertyToHclTerraform(struct?: TfRoute.SpecTcpRouteActionPropertyOutputReference | TfRoute.SpecTcpRouteActionProperty): any;
export declare function tfRouteSpecTcpRouteMatchPropertyToTerraform(struct?: TfRoute.SpecTcpRouteMatchPropertyOutputReference | TfRoute.SpecTcpRouteMatchProperty): any;
export declare function tfRouteSpecTcpRouteMatchPropertyToHclTerraform(struct?: TfRoute.SpecTcpRouteMatchPropertyOutputReference | TfRoute.SpecTcpRouteMatchProperty): any;
export declare function tfRouteSpecTcpRouteTimeoutIdlePropertyToTerraform(struct?: TfRoute.SpecTcpRouteTimeoutIdlePropertyOutputReference | TfRoute.SpecTcpRouteTimeoutIdleProperty): any;
export declare function tfRouteSpecTcpRouteTimeoutIdlePropertyToHclTerraform(struct?: TfRoute.SpecTcpRouteTimeoutIdlePropertyOutputReference | TfRoute.SpecTcpRouteTimeoutIdleProperty): any;
export declare function tfRouteSpecTcpRouteTimeoutPropertyToTerraform(struct?: TfRoute.SpecTcpRouteTimeoutPropertyOutputReference | TfRoute.SpecTcpRouteTimeoutProperty): any;
export declare function tfRouteSpecTcpRouteTimeoutPropertyToHclTerraform(struct?: TfRoute.SpecTcpRouteTimeoutPropertyOutputReference | TfRoute.SpecTcpRouteTimeoutProperty): any;
export declare function tfRouteTcpRoutePropertyToTerraform(struct?: TfRoute.TcpRoutePropertyOutputReference | TfRoute.TcpRouteProperty): any;
export declare function tfRouteTcpRoutePropertyToHclTerraform(struct?: TfRoute.TcpRoutePropertyOutputReference | TfRoute.TcpRouteProperty): any;
export declare function tfRouteSpecPropertyToTerraform(struct?: TfRoute.SpecPropertyOutputReference | TfRoute.SpecProperty): any;
export declare function tfRouteSpecPropertyToHclTerraform(struct?: TfRoute.SpecPropertyOutputReference | TfRoute.SpecProperty): any;
export declare namespace TfRoute {
    interface SpecGrpcRouteActionWeightedTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#port TfRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#virtual_node TfRoute#virtual_node}
        */
        readonly virtualNode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#weight TfRoute#weight}
        */
        readonly weight: number;
    }
    class SpecGrpcRouteActionWeightedTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteActionWeightedTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecGrpcRouteActionWeightedTargetProperty | cdktn.IResolvable | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _virtualNode?;
        get virtualNode(): string;
        set virtualNode(value: string);
        get virtualNodeInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        get weightInput(): number | undefined;
    }
    class SpecGrpcRouteActionWeightedTargetPropertyList extends cdktn.ComplexList {
        internalValue?: SpecGrpcRouteActionWeightedTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteActionWeightedTargetPropertyOutputReference;
    }
    interface SpecGrpcRouteActionProperty {
        /**
        * weighted_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#weighted_target TfRoute#weighted_target}
        */
        readonly weightedTarget: SpecGrpcRouteActionWeightedTargetProperty[] | cdktn.IResolvable;
    }
    class SpecGrpcRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteActionProperty | undefined;
        set internalValue(value: SpecGrpcRouteActionProperty | undefined);
        private _weightedTarget;
        get weightedTarget(): SpecGrpcRouteActionWeightedTargetPropertyList;
        putWeightedTarget(value: SpecGrpcRouteActionWeightedTargetProperty[] | cdktn.IResolvable): void;
        get weightedTargetInput(): cdktn.IResolvable | SpecGrpcRouteActionWeightedTargetProperty[] | undefined;
    }
    interface SpecGrpcRouteMatchMetadataMatchRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#end TfRoute#end}
        */
        readonly end: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#start TfRoute#start}
        */
        readonly start: number;
    }
    class SpecGrpcRouteMatchMetadataMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteMatchMetadataMatchRangeProperty | undefined;
        set internalValue(value: SpecGrpcRouteMatchMetadataMatchRangeProperty | undefined);
        private _end?;
        get end(): number;
        set end(value: number);
        get endInput(): number | undefined;
        private _start?;
        get start(): number;
        set start(value: number);
        get startInput(): number | undefined;
    }
    interface SpecGrpcRouteMatchMetadataMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#exact TfRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#prefix TfRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#regex TfRoute#regex}
        */
        readonly regex?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#suffix TfRoute#suffix}
        */
        readonly suffix?: string;
        /**
        * range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#range TfRoute#range}
        */
        readonly range?: SpecGrpcRouteMatchMetadataMatchRangeProperty;
    }
    class SpecGrpcRouteMatchMetadataMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteMatchMetadataMatchProperty | undefined;
        set internalValue(value: SpecGrpcRouteMatchMetadataMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
        private _suffix?;
        get suffix(): string;
        set suffix(value: string);
        resetSuffix(): void;
        get suffixInput(): string | undefined;
        private _range;
        get range(): SpecGrpcRouteMatchMetadataMatchRangePropertyOutputReference;
        putRange(value: SpecGrpcRouteMatchMetadataMatchRangeProperty): void;
        resetRange(): void;
        get rangeInput(): SpecGrpcRouteMatchMetadataMatchRangeProperty | undefined;
    }
    interface MetadataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#invert TfRoute#invert}
        */
        readonly invert?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#name TfRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match TfRoute#match}
        */
        readonly match?: SpecGrpcRouteMatchMetadataMatchProperty;
    }
    class MetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetadataProperty | cdktn.IResolvable | undefined);
        private _invert?;
        get invert(): boolean | cdktn.IResolvable;
        set invert(value: boolean | cdktn.IResolvable);
        resetInvert(): void;
        get invertInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecGrpcRouteMatchMetadataMatchPropertyOutputReference;
        putMatch(value: SpecGrpcRouteMatchMetadataMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecGrpcRouteMatchMetadataMatchProperty | undefined;
    }
    class MetadataPropertyList extends cdktn.ComplexList {
        internalValue?: MetadataProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataPropertyOutputReference;
    }
    interface SpecGrpcRouteMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#method_name TfRoute#method_name}
        */
        readonly methodName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#port TfRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#prefix TfRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#service_name TfRoute#service_name}
        */
        readonly serviceName?: string;
        /**
        * metadata block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#metadata TfRoute#metadata}
        */
        readonly metadata?: MetadataProperty[] | cdktn.IResolvable;
    }
    class SpecGrpcRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteMatchProperty | undefined;
        set internalValue(value: SpecGrpcRouteMatchProperty | undefined);
        private _methodName?;
        get methodName(): string;
        set methodName(value: string);
        resetMethodName(): void;
        get methodNameInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _serviceName?;
        get serviceName(): string;
        set serviceName(value: string);
        resetServiceName(): void;
        get serviceNameInput(): string | undefined;
        private _metadata;
        get metadata(): MetadataPropertyList;
        putMetadata(value: MetadataProperty[] | cdktn.IResolvable): void;
        resetMetadata(): void;
        get metadataInput(): cdktn.IResolvable | MetadataProperty[] | undefined;
    }
    interface SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit TfRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value TfRoute#value}
        */
        readonly value: number;
    }
    class SpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty | undefined;
        set internalValue(value: SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecGrpcRouteRetryPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#grpc_retry_events TfRoute#grpc_retry_events}
        */
        readonly grpcRetryEvents?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#http_retry_events TfRoute#http_retry_events}
        */
        readonly httpRetryEvents?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#max_retries TfRoute#max_retries}
        */
        readonly maxRetries: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#tcp_retry_events TfRoute#tcp_retry_events}
        */
        readonly tcpRetryEvents?: string[];
        /**
        * per_retry_timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#per_retry_timeout TfRoute#per_retry_timeout}
        */
        readonly perRetryTimeout: SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty;
    }
    class SpecGrpcRouteRetryPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteRetryPolicyProperty | undefined;
        set internalValue(value: SpecGrpcRouteRetryPolicyProperty | undefined);
        private _grpcRetryEvents?;
        get grpcRetryEvents(): string[];
        set grpcRetryEvents(value: string[]);
        resetGrpcRetryEvents(): void;
        get grpcRetryEventsInput(): string[] | undefined;
        private _httpRetryEvents?;
        get httpRetryEvents(): string[];
        set httpRetryEvents(value: string[]);
        resetHttpRetryEvents(): void;
        get httpRetryEventsInput(): string[] | undefined;
        private _maxRetries?;
        get maxRetries(): number;
        set maxRetries(value: number);
        get maxRetriesInput(): number | undefined;
        private _tcpRetryEvents?;
        get tcpRetryEvents(): string[];
        set tcpRetryEvents(value: string[]);
        resetTcpRetryEvents(): void;
        get tcpRetryEventsInput(): string[] | undefined;
        private _perRetryTimeout;
        get perRetryTimeout(): SpecGrpcRouteRetryPolicyPerRetryTimeoutPropertyOutputReference;
        putPerRetryTimeout(value: SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty): void;
        get perRetryTimeoutInput(): SpecGrpcRouteRetryPolicyPerRetryTimeoutProperty | undefined;
    }
    interface SpecGrpcRouteTimeoutIdleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit TfRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value TfRoute#value}
        */
        readonly value: number;
    }
    class SpecGrpcRouteTimeoutIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteTimeoutIdleProperty | undefined;
        set internalValue(value: SpecGrpcRouteTimeoutIdleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecGrpcRouteTimeoutPerRequestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit TfRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value TfRoute#value}
        */
        readonly value: number;
    }
    class SpecGrpcRouteTimeoutPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteTimeoutPerRequestProperty | undefined;
        set internalValue(value: SpecGrpcRouteTimeoutPerRequestProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecGrpcRouteTimeoutProperty {
        /**
        * idle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#idle TfRoute#idle}
        */
        readonly idle?: SpecGrpcRouteTimeoutIdleProperty;
        /**
        * per_request block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#per_request TfRoute#per_request}
        */
        readonly perRequest?: SpecGrpcRouteTimeoutPerRequestProperty;
    }
    class SpecGrpcRouteTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecGrpcRouteTimeoutProperty | undefined;
        set internalValue(value: SpecGrpcRouteTimeoutProperty | undefined);
        private _idle;
        get idle(): SpecGrpcRouteTimeoutIdlePropertyOutputReference;
        putIdle(value: SpecGrpcRouteTimeoutIdleProperty): void;
        resetIdle(): void;
        get idleInput(): SpecGrpcRouteTimeoutIdleProperty | undefined;
        private _perRequest;
        get perRequest(): SpecGrpcRouteTimeoutPerRequestPropertyOutputReference;
        putPerRequest(value: SpecGrpcRouteTimeoutPerRequestProperty): void;
        resetPerRequest(): void;
        get perRequestInput(): SpecGrpcRouteTimeoutPerRequestProperty | undefined;
    }
    interface GrpcRouteProperty {
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#action TfRoute#action}
        */
        readonly action: SpecGrpcRouteActionProperty;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match TfRoute#match}
        */
        readonly match?: SpecGrpcRouteMatchProperty;
        /**
        * retry_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#retry_policy TfRoute#retry_policy}
        */
        readonly retryPolicy?: SpecGrpcRouteRetryPolicyProperty;
        /**
        * timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#timeout TfRoute#timeout}
        */
        readonly timeout?: SpecGrpcRouteTimeoutProperty;
    }
    class GrpcRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GrpcRouteProperty | undefined;
        set internalValue(value: GrpcRouteProperty | undefined);
        private _action;
        get action(): SpecGrpcRouteActionPropertyOutputReference;
        putAction(value: SpecGrpcRouteActionProperty): void;
        get actionInput(): SpecGrpcRouteActionProperty | undefined;
        private _match;
        get match(): SpecGrpcRouteMatchPropertyOutputReference;
        putMatch(value: SpecGrpcRouteMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecGrpcRouteMatchProperty | undefined;
        private _retryPolicy;
        get retryPolicy(): SpecGrpcRouteRetryPolicyPropertyOutputReference;
        putRetryPolicy(value: SpecGrpcRouteRetryPolicyProperty): void;
        resetRetryPolicy(): void;
        get retryPolicyInput(): SpecGrpcRouteRetryPolicyProperty | undefined;
        private _timeout;
        get timeout(): SpecGrpcRouteTimeoutPropertyOutputReference;
        putTimeout(value: SpecGrpcRouteTimeoutProperty): void;
        resetTimeout(): void;
        get timeoutInput(): SpecGrpcRouteTimeoutProperty | undefined;
    }
    interface SpecHttp2RouteActionWeightedTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#port TfRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#virtual_node TfRoute#virtual_node}
        */
        readonly virtualNode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#weight TfRoute#weight}
        */
        readonly weight: number;
    }
    class SpecHttp2RouteActionWeightedTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionWeightedTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttp2RouteActionWeightedTargetProperty | cdktn.IResolvable | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _virtualNode?;
        get virtualNode(): string;
        set virtualNode(value: string);
        get virtualNodeInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        get weightInput(): number | undefined;
    }
    class SpecHttp2RouteActionWeightedTargetPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttp2RouteActionWeightedTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionWeightedTargetPropertyOutputReference;
    }
    interface SpecHttp2RouteActionProperty {
        /**
        * weighted_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#weighted_target TfRoute#weighted_target}
        */
        readonly weightedTarget: SpecHttp2RouteActionWeightedTargetProperty[] | cdktn.IResolvable;
    }
    class SpecHttp2RouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteActionProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionProperty | undefined);
        private _weightedTarget;
        get weightedTarget(): SpecHttp2RouteActionWeightedTargetPropertyList;
        putWeightedTarget(value: SpecHttp2RouteActionWeightedTargetProperty[] | cdktn.IResolvable): void;
        get weightedTargetInput(): cdktn.IResolvable | SpecHttp2RouteActionWeightedTargetProperty[] | undefined;
    }
    interface SpecHttp2RouteMatchHeaderMatchRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#end TfRoute#end}
        */
        readonly end: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#start TfRoute#start}
        */
        readonly start: number;
    }
    class SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined);
        private _end?;
        get end(): number;
        set end(value: number);
        get endInput(): number | undefined;
        private _start?;
        get start(): number;
        set start(value: number);
        get startInput(): number | undefined;
    }
    interface SpecHttp2RouteMatchHeaderMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#exact TfRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#prefix TfRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#regex TfRoute#regex}
        */
        readonly regex?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#suffix TfRoute#suffix}
        */
        readonly suffix?: string;
        /**
        * range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#range TfRoute#range}
        */
        readonly range?: SpecHttp2RouteMatchHeaderMatchRangeProperty;
    }
    class SpecHttp2RouteMatchHeaderMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchHeaderMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
        private _suffix?;
        get suffix(): string;
        set suffix(value: string);
        resetSuffix(): void;
        get suffixInput(): string | undefined;
        private _range;
        get range(): SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference;
        putRange(value: SpecHttp2RouteMatchHeaderMatchRangeProperty): void;
        resetRange(): void;
        get rangeInput(): SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined;
    }
    interface SpecHttp2RouteMatchHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#invert TfRoute#invert}
        */
        readonly invert?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#name TfRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match TfRoute#match}
        */
        readonly match?: SpecHttp2RouteMatchHeaderMatchProperty;
    }
    class SpecHttp2RouteMatchHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderProperty | cdktn.IResolvable | undefined);
        private _invert?;
        get invert(): boolean | cdktn.IResolvable;
        set invert(value: boolean | cdktn.IResolvable);
        resetInvert(): void;
        get invertInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecHttp2RouteMatchHeaderMatchPropertyOutputReference;
        putMatch(value: SpecHttp2RouteMatchHeaderMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecHttp2RouteMatchHeaderMatchProperty | undefined;
    }
    class SpecHttp2RouteMatchHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttp2RouteMatchHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchHeaderPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchPathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#exact TfRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#regex TfRoute#regex}
        */
        readonly regex?: string;
    }
    class SpecHttp2RouteMatchPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchPathProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchPathProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
    }
    interface SpecHttp2RouteMatchQueryParameterMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#exact TfRoute#exact}
        */
        readonly exact?: string;
    }
    class SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchQueryParameterMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchQueryParameterMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
    }
    interface SpecHttp2RouteMatchQueryParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#name TfRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match TfRoute#match}
        */
        readonly match?: SpecHttp2RouteMatchQueryParameterMatchProperty;
    }
    class SpecHttp2RouteMatchQueryParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchQueryParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttp2RouteMatchQueryParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference;
        putMatch(value: SpecHttp2RouteMatchQueryParameterMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecHttp2RouteMatchQueryParameterMatchProperty | undefined;
    }
    class SpecHttp2RouteMatchQueryParameterPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttp2RouteMatchQueryParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchQueryParameterPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#method TfRoute#method}
        */
        readonly method?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#port TfRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#prefix TfRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#scheme TfRoute#scheme}
        */
        readonly scheme?: string;
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#header TfRoute#header}
        */
        readonly header?: SpecHttp2RouteMatchHeaderProperty[] | cdktn.IResolvable;
        /**
        * path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#path TfRoute#path}
        */
        readonly path?: SpecHttp2RouteMatchPathProperty;
        /**
        * query_parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#query_parameter TfRoute#query_parameter}
        */
        readonly queryParameter?: SpecHttp2RouteMatchQueryParameterProperty[] | cdktn.IResolvable;
    }
    class SpecHttp2RouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchProperty | undefined);
        private _method?;
        get method(): string;
        set method(value: string);
        resetMethod(): void;
        get methodInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _scheme?;
        get scheme(): string;
        set scheme(value: string);
        resetScheme(): void;
        get schemeInput(): string | undefined;
        private _header;
        get header(): SpecHttp2RouteMatchHeaderPropertyList;
        putHeader(value: SpecHttp2RouteMatchHeaderProperty[] | cdktn.IResolvable): void;
        resetHeader(): void;
        get headerInput(): cdktn.IResolvable | SpecHttp2RouteMatchHeaderProperty[] | undefined;
        private _path;
        get path(): SpecHttp2RouteMatchPathPropertyOutputReference;
        putPath(value: SpecHttp2RouteMatchPathProperty): void;
        resetPath(): void;
        get pathInput(): SpecHttp2RouteMatchPathProperty | undefined;
        private _queryParameter;
        get queryParameter(): SpecHttp2RouteMatchQueryParameterPropertyList;
        putQueryParameter(value: SpecHttp2RouteMatchQueryParameterProperty[] | cdktn.IResolvable): void;
        resetQueryParameter(): void;
        get queryParameterInput(): cdktn.IResolvable | SpecHttp2RouteMatchQueryParameterProperty[] | undefined;
    }
    interface SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit TfRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value TfRoute#value}
        */
        readonly value: number;
    }
    class SpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty | undefined;
        set internalValue(value: SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecHttp2RouteRetryPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#http_retry_events TfRoute#http_retry_events}
        */
        readonly httpRetryEvents?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#max_retries TfRoute#max_retries}
        */
        readonly maxRetries: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#tcp_retry_events TfRoute#tcp_retry_events}
        */
        readonly tcpRetryEvents?: string[];
        /**
        * per_retry_timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#per_retry_timeout TfRoute#per_retry_timeout}
        */
        readonly perRetryTimeout: SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty;
    }
    class SpecHttp2RouteRetryPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteRetryPolicyProperty | undefined;
        set internalValue(value: SpecHttp2RouteRetryPolicyProperty | undefined);
        private _httpRetryEvents?;
        get httpRetryEvents(): string[];
        set httpRetryEvents(value: string[]);
        resetHttpRetryEvents(): void;
        get httpRetryEventsInput(): string[] | undefined;
        private _maxRetries?;
        get maxRetries(): number;
        set maxRetries(value: number);
        get maxRetriesInput(): number | undefined;
        private _tcpRetryEvents?;
        get tcpRetryEvents(): string[];
        set tcpRetryEvents(value: string[]);
        resetTcpRetryEvents(): void;
        get tcpRetryEventsInput(): string[] | undefined;
        private _perRetryTimeout;
        get perRetryTimeout(): SpecHttp2RouteRetryPolicyPerRetryTimeoutPropertyOutputReference;
        putPerRetryTimeout(value: SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty): void;
        get perRetryTimeoutInput(): SpecHttp2RouteRetryPolicyPerRetryTimeoutProperty | undefined;
    }
    interface SpecHttp2RouteTimeoutIdleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit TfRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value TfRoute#value}
        */
        readonly value: number;
    }
    class SpecHttp2RouteTimeoutIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteTimeoutIdleProperty | undefined;
        set internalValue(value: SpecHttp2RouteTimeoutIdleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecHttp2RouteTimeoutPerRequestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit TfRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value TfRoute#value}
        */
        readonly value: number;
    }
    class SpecHttp2RouteTimeoutPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteTimeoutPerRequestProperty | undefined;
        set internalValue(value: SpecHttp2RouteTimeoutPerRequestProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecHttp2RouteTimeoutProperty {
        /**
        * idle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#idle TfRoute#idle}
        */
        readonly idle?: SpecHttp2RouteTimeoutIdleProperty;
        /**
        * per_request block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#per_request TfRoute#per_request}
        */
        readonly perRequest?: SpecHttp2RouteTimeoutPerRequestProperty;
    }
    class SpecHttp2RouteTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttp2RouteTimeoutProperty | undefined;
        set internalValue(value: SpecHttp2RouteTimeoutProperty | undefined);
        private _idle;
        get idle(): SpecHttp2RouteTimeoutIdlePropertyOutputReference;
        putIdle(value: SpecHttp2RouteTimeoutIdleProperty): void;
        resetIdle(): void;
        get idleInput(): SpecHttp2RouteTimeoutIdleProperty | undefined;
        private _perRequest;
        get perRequest(): SpecHttp2RouteTimeoutPerRequestPropertyOutputReference;
        putPerRequest(value: SpecHttp2RouteTimeoutPerRequestProperty): void;
        resetPerRequest(): void;
        get perRequestInput(): SpecHttp2RouteTimeoutPerRequestProperty | undefined;
    }
    interface Http2RouteProperty {
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#action TfRoute#action}
        */
        readonly action: SpecHttp2RouteActionProperty;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match TfRoute#match}
        */
        readonly match: SpecHttp2RouteMatchProperty;
        /**
        * retry_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#retry_policy TfRoute#retry_policy}
        */
        readonly retryPolicy?: SpecHttp2RouteRetryPolicyProperty;
        /**
        * timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#timeout TfRoute#timeout}
        */
        readonly timeout?: SpecHttp2RouteTimeoutProperty;
    }
    class Http2RoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Http2RouteProperty | undefined;
        set internalValue(value: Http2RouteProperty | undefined);
        private _action;
        get action(): SpecHttp2RouteActionPropertyOutputReference;
        putAction(value: SpecHttp2RouteActionProperty): void;
        get actionInput(): SpecHttp2RouteActionProperty | undefined;
        private _match;
        get match(): SpecHttp2RouteMatchPropertyOutputReference;
        putMatch(value: SpecHttp2RouteMatchProperty): void;
        get matchInput(): SpecHttp2RouteMatchProperty | undefined;
        private _retryPolicy;
        get retryPolicy(): SpecHttp2RouteRetryPolicyPropertyOutputReference;
        putRetryPolicy(value: SpecHttp2RouteRetryPolicyProperty): void;
        resetRetryPolicy(): void;
        get retryPolicyInput(): SpecHttp2RouteRetryPolicyProperty | undefined;
        private _timeout;
        get timeout(): SpecHttp2RouteTimeoutPropertyOutputReference;
        putTimeout(value: SpecHttp2RouteTimeoutProperty): void;
        resetTimeout(): void;
        get timeoutInput(): SpecHttp2RouteTimeoutProperty | undefined;
    }
    interface SpecHttpRouteActionWeightedTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#port TfRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#virtual_node TfRoute#virtual_node}
        */
        readonly virtualNode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#weight TfRoute#weight}
        */
        readonly weight: number;
    }
    class SpecHttpRouteActionWeightedTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionWeightedTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttpRouteActionWeightedTargetProperty | cdktn.IResolvable | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _virtualNode?;
        get virtualNode(): string;
        set virtualNode(value: string);
        get virtualNodeInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        get weightInput(): number | undefined;
    }
    class SpecHttpRouteActionWeightedTargetPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttpRouteActionWeightedTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionWeightedTargetPropertyOutputReference;
    }
    interface SpecHttpRouteActionProperty {
        /**
        * weighted_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#weighted_target TfRoute#weighted_target}
        */
        readonly weightedTarget: SpecHttpRouteActionWeightedTargetProperty[] | cdktn.IResolvable;
    }
    class SpecHttpRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteActionProperty | undefined;
        set internalValue(value: SpecHttpRouteActionProperty | undefined);
        private _weightedTarget;
        get weightedTarget(): SpecHttpRouteActionWeightedTargetPropertyList;
        putWeightedTarget(value: SpecHttpRouteActionWeightedTargetProperty[] | cdktn.IResolvable): void;
        get weightedTargetInput(): cdktn.IResolvable | SpecHttpRouteActionWeightedTargetProperty[] | undefined;
    }
    interface SpecHttpRouteMatchHeaderMatchRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#end TfRoute#end}
        */
        readonly end: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#start TfRoute#start}
        */
        readonly start: number;
    }
    class SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchHeaderMatchRangeProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderMatchRangeProperty | undefined);
        private _end?;
        get end(): number;
        set end(value: number);
        get endInput(): number | undefined;
        private _start?;
        get start(): number;
        set start(value: number);
        get startInput(): number | undefined;
    }
    interface SpecHttpRouteMatchHeaderMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#exact TfRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#prefix TfRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#regex TfRoute#regex}
        */
        readonly regex?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#suffix TfRoute#suffix}
        */
        readonly suffix?: string;
        /**
        * range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#range TfRoute#range}
        */
        readonly range?: SpecHttpRouteMatchHeaderMatchRangeProperty;
    }
    class SpecHttpRouteMatchHeaderMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchHeaderMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
        private _suffix?;
        get suffix(): string;
        set suffix(value: string);
        resetSuffix(): void;
        get suffixInput(): string | undefined;
        private _range;
        get range(): SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference;
        putRange(value: SpecHttpRouteMatchHeaderMatchRangeProperty): void;
        resetRange(): void;
        get rangeInput(): SpecHttpRouteMatchHeaderMatchRangeProperty | undefined;
    }
    interface SpecHttpRouteMatchHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#invert TfRoute#invert}
        */
        readonly invert?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#name TfRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match TfRoute#match}
        */
        readonly match?: SpecHttpRouteMatchHeaderMatchProperty;
    }
    class SpecHttpRouteMatchHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderProperty | cdktn.IResolvable | undefined);
        private _invert?;
        get invert(): boolean | cdktn.IResolvable;
        set invert(value: boolean | cdktn.IResolvable);
        resetInvert(): void;
        get invertInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecHttpRouteMatchHeaderMatchPropertyOutputReference;
        putMatch(value: SpecHttpRouteMatchHeaderMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecHttpRouteMatchHeaderMatchProperty | undefined;
    }
    class SpecHttpRouteMatchHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttpRouteMatchHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchHeaderPropertyOutputReference;
    }
    interface SpecHttpRouteMatchPathProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#exact TfRoute#exact}
        */
        readonly exact?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#regex TfRoute#regex}
        */
        readonly regex?: string;
    }
    class SpecHttpRouteMatchPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchPathProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchPathProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
        private _regex?;
        get regex(): string;
        set regex(value: string);
        resetRegex(): void;
        get regexInput(): string | undefined;
    }
    interface SpecHttpRouteMatchQueryParameterMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#exact TfRoute#exact}
        */
        readonly exact?: string;
    }
    class SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchQueryParameterMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchQueryParameterMatchProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        resetExact(): void;
        get exactInput(): string | undefined;
    }
    interface SpecHttpRouteMatchQueryParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#name TfRoute#name}
        */
        readonly name: string;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match TfRoute#match}
        */
        readonly match?: SpecHttpRouteMatchQueryParameterMatchProperty;
    }
    class SpecHttpRouteMatchQueryParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchQueryParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecHttpRouteMatchQueryParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _match;
        get match(): SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference;
        putMatch(value: SpecHttpRouteMatchQueryParameterMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecHttpRouteMatchQueryParameterMatchProperty | undefined;
    }
    class SpecHttpRouteMatchQueryParameterPropertyList extends cdktn.ComplexList {
        internalValue?: SpecHttpRouteMatchQueryParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchQueryParameterPropertyOutputReference;
    }
    interface SpecHttpRouteMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#method TfRoute#method}
        */
        readonly method?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#port TfRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#prefix TfRoute#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#scheme TfRoute#scheme}
        */
        readonly scheme?: string;
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#header TfRoute#header}
        */
        readonly header?: SpecHttpRouteMatchHeaderProperty[] | cdktn.IResolvable;
        /**
        * path block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#path TfRoute#path}
        */
        readonly path?: SpecHttpRouteMatchPathProperty;
        /**
        * query_parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#query_parameter TfRoute#query_parameter}
        */
        readonly queryParameter?: SpecHttpRouteMatchQueryParameterProperty[] | cdktn.IResolvable;
    }
    class SpecHttpRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchProperty | undefined);
        private _method?;
        get method(): string;
        set method(value: string);
        resetMethod(): void;
        get methodInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _scheme?;
        get scheme(): string;
        set scheme(value: string);
        resetScheme(): void;
        get schemeInput(): string | undefined;
        private _header;
        get header(): SpecHttpRouteMatchHeaderPropertyList;
        putHeader(value: SpecHttpRouteMatchHeaderProperty[] | cdktn.IResolvable): void;
        resetHeader(): void;
        get headerInput(): cdktn.IResolvable | SpecHttpRouteMatchHeaderProperty[] | undefined;
        private _path;
        get path(): SpecHttpRouteMatchPathPropertyOutputReference;
        putPath(value: SpecHttpRouteMatchPathProperty): void;
        resetPath(): void;
        get pathInput(): SpecHttpRouteMatchPathProperty | undefined;
        private _queryParameter;
        get queryParameter(): SpecHttpRouteMatchQueryParameterPropertyList;
        putQueryParameter(value: SpecHttpRouteMatchQueryParameterProperty[] | cdktn.IResolvable): void;
        resetQueryParameter(): void;
        get queryParameterInput(): cdktn.IResolvable | SpecHttpRouteMatchQueryParameterProperty[] | undefined;
    }
    interface SpecHttpRouteRetryPolicyPerRetryTimeoutProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit TfRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value TfRoute#value}
        */
        readonly value: number;
    }
    class SpecHttpRouteRetryPolicyPerRetryTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteRetryPolicyPerRetryTimeoutProperty | undefined;
        set internalValue(value: SpecHttpRouteRetryPolicyPerRetryTimeoutProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecHttpRouteRetryPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#http_retry_events TfRoute#http_retry_events}
        */
        readonly httpRetryEvents?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#max_retries TfRoute#max_retries}
        */
        readonly maxRetries: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#tcp_retry_events TfRoute#tcp_retry_events}
        */
        readonly tcpRetryEvents?: string[];
        /**
        * per_retry_timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#per_retry_timeout TfRoute#per_retry_timeout}
        */
        readonly perRetryTimeout: SpecHttpRouteRetryPolicyPerRetryTimeoutProperty;
    }
    class SpecHttpRouteRetryPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteRetryPolicyProperty | undefined;
        set internalValue(value: SpecHttpRouteRetryPolicyProperty | undefined);
        private _httpRetryEvents?;
        get httpRetryEvents(): string[];
        set httpRetryEvents(value: string[]);
        resetHttpRetryEvents(): void;
        get httpRetryEventsInput(): string[] | undefined;
        private _maxRetries?;
        get maxRetries(): number;
        set maxRetries(value: number);
        get maxRetriesInput(): number | undefined;
        private _tcpRetryEvents?;
        get tcpRetryEvents(): string[];
        set tcpRetryEvents(value: string[]);
        resetTcpRetryEvents(): void;
        get tcpRetryEventsInput(): string[] | undefined;
        private _perRetryTimeout;
        get perRetryTimeout(): SpecHttpRouteRetryPolicyPerRetryTimeoutPropertyOutputReference;
        putPerRetryTimeout(value: SpecHttpRouteRetryPolicyPerRetryTimeoutProperty): void;
        get perRetryTimeoutInput(): SpecHttpRouteRetryPolicyPerRetryTimeoutProperty | undefined;
    }
    interface SpecHttpRouteTimeoutIdleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit TfRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value TfRoute#value}
        */
        readonly value: number;
    }
    class SpecHttpRouteTimeoutIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteTimeoutIdleProperty | undefined;
        set internalValue(value: SpecHttpRouteTimeoutIdleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecHttpRouteTimeoutPerRequestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit TfRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value TfRoute#value}
        */
        readonly value: number;
    }
    class SpecHttpRouteTimeoutPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteTimeoutPerRequestProperty | undefined;
        set internalValue(value: SpecHttpRouteTimeoutPerRequestProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecHttpRouteTimeoutProperty {
        /**
        * idle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#idle TfRoute#idle}
        */
        readonly idle?: SpecHttpRouteTimeoutIdleProperty;
        /**
        * per_request block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#per_request TfRoute#per_request}
        */
        readonly perRequest?: SpecHttpRouteTimeoutPerRequestProperty;
    }
    class SpecHttpRouteTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecHttpRouteTimeoutProperty | undefined;
        set internalValue(value: SpecHttpRouteTimeoutProperty | undefined);
        private _idle;
        get idle(): SpecHttpRouteTimeoutIdlePropertyOutputReference;
        putIdle(value: SpecHttpRouteTimeoutIdleProperty): void;
        resetIdle(): void;
        get idleInput(): SpecHttpRouteTimeoutIdleProperty | undefined;
        private _perRequest;
        get perRequest(): SpecHttpRouteTimeoutPerRequestPropertyOutputReference;
        putPerRequest(value: SpecHttpRouteTimeoutPerRequestProperty): void;
        resetPerRequest(): void;
        get perRequestInput(): SpecHttpRouteTimeoutPerRequestProperty | undefined;
    }
    interface HttpRouteProperty {
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#action TfRoute#action}
        */
        readonly action: SpecHttpRouteActionProperty;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match TfRoute#match}
        */
        readonly match: SpecHttpRouteMatchProperty;
        /**
        * retry_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#retry_policy TfRoute#retry_policy}
        */
        readonly retryPolicy?: SpecHttpRouteRetryPolicyProperty;
        /**
        * timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#timeout TfRoute#timeout}
        */
        readonly timeout?: SpecHttpRouteTimeoutProperty;
    }
    class HttpRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpRouteProperty | undefined;
        set internalValue(value: HttpRouteProperty | undefined);
        private _action;
        get action(): SpecHttpRouteActionPropertyOutputReference;
        putAction(value: SpecHttpRouteActionProperty): void;
        get actionInput(): SpecHttpRouteActionProperty | undefined;
        private _match;
        get match(): SpecHttpRouteMatchPropertyOutputReference;
        putMatch(value: SpecHttpRouteMatchProperty): void;
        get matchInput(): SpecHttpRouteMatchProperty | undefined;
        private _retryPolicy;
        get retryPolicy(): SpecHttpRouteRetryPolicyPropertyOutputReference;
        putRetryPolicy(value: SpecHttpRouteRetryPolicyProperty): void;
        resetRetryPolicy(): void;
        get retryPolicyInput(): SpecHttpRouteRetryPolicyProperty | undefined;
        private _timeout;
        get timeout(): SpecHttpRouteTimeoutPropertyOutputReference;
        putTimeout(value: SpecHttpRouteTimeoutProperty): void;
        resetTimeout(): void;
        get timeoutInput(): SpecHttpRouteTimeoutProperty | undefined;
    }
    interface SpecTcpRouteActionWeightedTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#port TfRoute#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#virtual_node TfRoute#virtual_node}
        */
        readonly virtualNode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#weight TfRoute#weight}
        */
        readonly weight: number;
    }
    class SpecTcpRouteActionWeightedTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecTcpRouteActionWeightedTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecTcpRouteActionWeightedTargetProperty | cdktn.IResolvable | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _virtualNode?;
        get virtualNode(): string;
        set virtualNode(value: string);
        get virtualNodeInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        get weightInput(): number | undefined;
    }
    class SpecTcpRouteActionWeightedTargetPropertyList extends cdktn.ComplexList {
        internalValue?: SpecTcpRouteActionWeightedTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecTcpRouteActionWeightedTargetPropertyOutputReference;
    }
    interface SpecTcpRouteActionProperty {
        /**
        * weighted_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#weighted_target TfRoute#weighted_target}
        */
        readonly weightedTarget: SpecTcpRouteActionWeightedTargetProperty[] | cdktn.IResolvable;
    }
    class SpecTcpRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecTcpRouteActionProperty | undefined;
        set internalValue(value: SpecTcpRouteActionProperty | undefined);
        private _weightedTarget;
        get weightedTarget(): SpecTcpRouteActionWeightedTargetPropertyList;
        putWeightedTarget(value: SpecTcpRouteActionWeightedTargetProperty[] | cdktn.IResolvable): void;
        get weightedTargetInput(): cdktn.IResolvable | SpecTcpRouteActionWeightedTargetProperty[] | undefined;
    }
    interface SpecTcpRouteMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#port TfRoute#port}
        */
        readonly port?: number;
    }
    class SpecTcpRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecTcpRouteMatchProperty | undefined;
        set internalValue(value: SpecTcpRouteMatchProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
    }
    interface SpecTcpRouteTimeoutIdleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#unit TfRoute#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#value TfRoute#value}
        */
        readonly value: number;
    }
    class SpecTcpRouteTimeoutIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecTcpRouteTimeoutIdleProperty | undefined;
        set internalValue(value: SpecTcpRouteTimeoutIdleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecTcpRouteTimeoutProperty {
        /**
        * idle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#idle TfRoute#idle}
        */
        readonly idle?: SpecTcpRouteTimeoutIdleProperty;
    }
    class SpecTcpRouteTimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecTcpRouteTimeoutProperty | undefined;
        set internalValue(value: SpecTcpRouteTimeoutProperty | undefined);
        private _idle;
        get idle(): SpecTcpRouteTimeoutIdlePropertyOutputReference;
        putIdle(value: SpecTcpRouteTimeoutIdleProperty): void;
        resetIdle(): void;
        get idleInput(): SpecTcpRouteTimeoutIdleProperty | undefined;
    }
    interface TcpRouteProperty {
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#action TfRoute#action}
        */
        readonly action: SpecTcpRouteActionProperty;
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#match TfRoute#match}
        */
        readonly match?: SpecTcpRouteMatchProperty;
        /**
        * timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#timeout TfRoute#timeout}
        */
        readonly timeout?: SpecTcpRouteTimeoutProperty;
    }
    class TcpRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TcpRouteProperty | undefined;
        set internalValue(value: TcpRouteProperty | undefined);
        private _action;
        get action(): SpecTcpRouteActionPropertyOutputReference;
        putAction(value: SpecTcpRouteActionProperty): void;
        get actionInput(): SpecTcpRouteActionProperty | undefined;
        private _match;
        get match(): SpecTcpRouteMatchPropertyOutputReference;
        putMatch(value: SpecTcpRouteMatchProperty): void;
        resetMatch(): void;
        get matchInput(): SpecTcpRouteMatchProperty | undefined;
        private _timeout;
        get timeout(): SpecTcpRouteTimeoutPropertyOutputReference;
        putTimeout(value: SpecTcpRouteTimeoutProperty): void;
        resetTimeout(): void;
        get timeoutInput(): SpecTcpRouteTimeoutProperty | undefined;
    }
    interface SpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#priority TfRoute#priority}
        */
        readonly priority?: number;
        /**
        * grpc_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#grpc_route TfRoute#grpc_route}
        */
        readonly grpcRoute?: GrpcRouteProperty;
        /**
        * http2_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#http2_route TfRoute#http2_route}
        */
        readonly http2Route?: Http2RouteProperty;
        /**
        * http_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#http_route TfRoute#http_route}
        */
        readonly httpRoute?: HttpRouteProperty;
        /**
        * tcp_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_route#tcp_route TfRoute#tcp_route}
        */
        readonly tcpRoute?: TcpRouteProperty;
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _priority?;
        get priority(): number;
        set priority(value: number);
        resetPriority(): void;
        get priorityInput(): number | undefined;
        private _grpcRoute;
        get grpcRoute(): GrpcRoutePropertyOutputReference;
        putGrpcRoute(value: GrpcRouteProperty): void;
        resetGrpcRoute(): void;
        get grpcRouteInput(): GrpcRouteProperty | undefined;
        private _http2Route;
        get http2Route(): Http2RoutePropertyOutputReference;
        putHttp2Route(value: Http2RouteProperty): void;
        resetHttp2Route(): void;
        get http2RouteInput(): Http2RouteProperty | undefined;
        private _httpRoute;
        get httpRoute(): HttpRoutePropertyOutputReference;
        putHttpRoute(value: HttpRouteProperty): void;
        resetHttpRoute(): void;
        get httpRouteInput(): HttpRouteProperty | undefined;
        private _tcpRoute;
        get tcpRoute(): TcpRoutePropertyOutputReference;
        putTcpRoute(value: TcpRouteProperty): void;
        resetTcpRoute(): void;
        get tcpRouteInput(): TcpRouteProperty | undefined;
    }
}
