import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfMeshConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#id TfMesh#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#name TfMesh#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#region TfMesh#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#tags TfMesh#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#tags_all TfMesh#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#spec TfMesh#spec}
    */
    readonly spec?: TfMesh.SpecProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh aws_appmesh_mesh}
*/
export declare class TfMesh extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appmesh_mesh";
    /**
    * Generates CDKTN code for importing a TfMesh resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfMesh to import
    * @param importFromId The id of the existing TfMesh that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfMesh to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh aws_appmesh_mesh} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfMeshConfig
    */
    constructor(scope: Construct, id: string, config: TfMeshConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    get meshOwner(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _spec;
    get spec(): TfMesh.SpecPropertyOutputReference;
    putSpec(value: TfMesh.SpecProperty): void;
    resetSpec(): void;
    get specInput(): TfMesh.SpecProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfMeshEgressFilterPropertyToTerraform(struct?: TfMesh.EgressFilterPropertyOutputReference | TfMesh.EgressFilterProperty): any;
export declare function tfMeshEgressFilterPropertyToHclTerraform(struct?: TfMesh.EgressFilterPropertyOutputReference | TfMesh.EgressFilterProperty): any;
export declare function tfMeshServiceDiscoveryPropertyToTerraform(struct?: TfMesh.ServiceDiscoveryPropertyOutputReference | TfMesh.ServiceDiscoveryProperty): any;
export declare function tfMeshServiceDiscoveryPropertyToHclTerraform(struct?: TfMesh.ServiceDiscoveryPropertyOutputReference | TfMesh.ServiceDiscoveryProperty): any;
export declare function tfMeshSpecPropertyToTerraform(struct?: TfMesh.SpecPropertyOutputReference | TfMesh.SpecProperty): any;
export declare function tfMeshSpecPropertyToHclTerraform(struct?: TfMesh.SpecPropertyOutputReference | TfMesh.SpecProperty): any;
export declare namespace TfMesh {
    interface EgressFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#type TfMesh#type}
        */
        readonly type?: string;
    }
    class EgressFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EgressFilterProperty | undefined;
        set internalValue(value: EgressFilterProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface ServiceDiscoveryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#ip_preference TfMesh#ip_preference}
        */
        readonly ipPreference?: string;
    }
    class ServiceDiscoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceDiscoveryProperty | undefined;
        set internalValue(value: ServiceDiscoveryProperty | undefined);
        private _ipPreference?;
        get ipPreference(): string;
        set ipPreference(value: string);
        resetIpPreference(): void;
        get ipPreferenceInput(): string | undefined;
    }
    interface SpecProperty {
        /**
        * egress_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#egress_filter TfMesh#egress_filter}
        */
        readonly egressFilter?: EgressFilterProperty;
        /**
        * service_discovery block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_mesh#service_discovery TfMesh#service_discovery}
        */
        readonly serviceDiscovery?: ServiceDiscoveryProperty;
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _egressFilter;
        get egressFilter(): EgressFilterPropertyOutputReference;
        putEgressFilter(value: EgressFilterProperty): void;
        resetEgressFilter(): void;
        get egressFilterInput(): EgressFilterProperty | undefined;
        private _serviceDiscovery;
        get serviceDiscovery(): ServiceDiscoveryPropertyOutputReference;
        putServiceDiscovery(value: ServiceDiscoveryProperty): void;
        resetServiceDiscovery(): void;
        get serviceDiscoveryInput(): ServiceDiscoveryProperty | undefined;
    }
}
