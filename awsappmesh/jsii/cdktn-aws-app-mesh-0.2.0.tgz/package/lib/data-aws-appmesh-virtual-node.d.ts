import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfVirtualNodeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node#id DataTfVirtualNode#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node#mesh_name DataTfVirtualNode#mesh_name}
    */
    readonly meshName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node#mesh_owner DataTfVirtualNode#mesh_owner}
    */
    readonly meshOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node#name DataTfVirtualNode#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node#region DataTfVirtualNode#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node#tags DataTfVirtualNode#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node aws_appmesh_virtual_node}
*/
export declare class DataTfVirtualNode extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_appmesh_virtual_node";
    /**
    * Generates CDKTN code for importing a DataTfVirtualNode resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfVirtualNode to import
    * @param importFromId The id of the existing DataTfVirtualNode that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfVirtualNode to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_virtual_node aws_appmesh_virtual_node} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfVirtualNodeConfig
    */
    constructor(scope: Construct, id: string, config: DataTfVirtualNodeConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _meshName?;
    get meshName(): string;
    set meshName(value: string);
    get meshNameInput(): string | undefined;
    private _meshOwner?;
    get meshOwner(): string;
    set meshOwner(value: string);
    resetMeshOwner(): void;
    get meshOwnerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _spec;
    get spec(): DataTfVirtualNode.SpecPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificatePropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificatePropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyProperty): any;
export declare function dataTfVirtualNodeSpecBackendVirtualServiceClientPolicyPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendVirtualServiceClientPolicyProperty): any;
export declare function dataTfVirtualNodeVirtualServicePropertyToTerraform(struct?: DataTfVirtualNode.VirtualServiceProperty): any;
export declare function dataTfVirtualNodeVirtualServicePropertyToHclTerraform(struct?: DataTfVirtualNode.VirtualServiceProperty): any;
export declare function dataTfVirtualNodeBackendPropertyToTerraform(struct?: DataTfVirtualNode.BackendProperty): any;
export declare function dataTfVirtualNodeBackendPropertyToHclTerraform(struct?: DataTfVirtualNode.BackendProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificateFilePropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateFileProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificateFilePropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateFileProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificatePropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificatePropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyTlsPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyTlsProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyPropertyToTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyProperty): any;
export declare function dataTfVirtualNodeSpecBackendDefaultsClientPolicyPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecBackendDefaultsClientPolicyProperty): any;
export declare function dataTfVirtualNodeBackendDefaultsPropertyToTerraform(struct?: DataTfVirtualNode.BackendDefaultsProperty): any;
export declare function dataTfVirtualNodeBackendDefaultsPropertyToHclTerraform(struct?: DataTfVirtualNode.BackendDefaultsProperty): any;
export declare function dataTfVirtualNodeSpecListenerConnectionPoolGrpcPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerConnectionPoolGrpcProperty): any;
export declare function dataTfVirtualNodeSpecListenerConnectionPoolGrpcPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerConnectionPoolGrpcProperty): any;
export declare function dataTfVirtualNodeSpecListenerConnectionPoolHttpPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerConnectionPoolHttpProperty): any;
export declare function dataTfVirtualNodeSpecListenerConnectionPoolHttpPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerConnectionPoolHttpProperty): any;
export declare function dataTfVirtualNodeSpecListenerConnectionPoolHttp2PropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerConnectionPoolHttp2Property): any;
export declare function dataTfVirtualNodeSpecListenerConnectionPoolHttp2PropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerConnectionPoolHttp2Property): any;
export declare function dataTfVirtualNodeSpecListenerConnectionPoolTcpPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerConnectionPoolTcpProperty): any;
export declare function dataTfVirtualNodeSpecListenerConnectionPoolTcpPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerConnectionPoolTcpProperty): any;
export declare function dataTfVirtualNodeConnectionPoolPropertyToTerraform(struct?: DataTfVirtualNode.ConnectionPoolProperty): any;
export declare function dataTfVirtualNodeConnectionPoolPropertyToHclTerraform(struct?: DataTfVirtualNode.ConnectionPoolProperty): any;
export declare function dataTfVirtualNodeHealthCheckPropertyToTerraform(struct?: DataTfVirtualNode.HealthCheckProperty): any;
export declare function dataTfVirtualNodeHealthCheckPropertyToHclTerraform(struct?: DataTfVirtualNode.HealthCheckProperty): any;
export declare function dataTfVirtualNodeBaseEjectionDurationPropertyToTerraform(struct?: DataTfVirtualNode.BaseEjectionDurationProperty): any;
export declare function dataTfVirtualNodeBaseEjectionDurationPropertyToHclTerraform(struct?: DataTfVirtualNode.BaseEjectionDurationProperty): any;
export declare function dataTfVirtualNodeIntervalPropertyToTerraform(struct?: DataTfVirtualNode.IntervalProperty): any;
export declare function dataTfVirtualNodeIntervalPropertyToHclTerraform(struct?: DataTfVirtualNode.IntervalProperty): any;
export declare function dataTfVirtualNodeOutlierDetectionPropertyToTerraform(struct?: DataTfVirtualNode.OutlierDetectionProperty): any;
export declare function dataTfVirtualNodeOutlierDetectionPropertyToHclTerraform(struct?: DataTfVirtualNode.OutlierDetectionProperty): any;
export declare function dataTfVirtualNodePortMappingPropertyToTerraform(struct?: DataTfVirtualNode.PortMappingProperty): any;
export declare function dataTfVirtualNodePortMappingPropertyToHclTerraform(struct?: DataTfVirtualNode.PortMappingProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutGrpcIdlePropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutGrpcIdleProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutGrpcIdlePropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutGrpcIdleProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutGrpcPerRequestPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutGrpcPerRequestProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutGrpcPerRequestPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutGrpcPerRequestProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutGrpcPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutGrpcProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutGrpcPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutGrpcProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutHttpIdlePropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutHttpIdleProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutHttpIdlePropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutHttpIdleProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutHttpPerRequestPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutHttpPerRequestProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutHttpPerRequestPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutHttpPerRequestProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutHttpPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutHttpProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutHttpPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutHttpProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutHttp2IdlePropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutHttp2IdleProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutHttp2IdlePropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutHttp2IdleProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutHttp2PerRequestPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutHttp2PerRequestProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutHttp2PerRequestPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutHttp2PerRequestProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutHttp2PropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutHttp2Property): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutHttp2PropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutHttp2Property): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutTcpIdlePropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutTcpIdleProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutTcpIdlePropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutTcpIdleProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutTcpPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutTcpProperty): any;
export declare function dataTfVirtualNodeSpecListenerTimeoutTcpPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTimeoutTcpProperty): any;
export declare function dataTfVirtualNodeTimeoutPropertyToTerraform(struct?: DataTfVirtualNode.TimeoutProperty): any;
export declare function dataTfVirtualNodeTimeoutPropertyToHclTerraform(struct?: DataTfVirtualNode.TimeoutProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsCertificateAcmPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTlsCertificateAcmProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsCertificateAcmPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTlsCertificateAcmProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsCertificateFilePropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTlsCertificateFileProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsCertificateFilePropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTlsCertificateFileProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsCertificateSdsPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTlsCertificateSdsProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsCertificateSdsPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTlsCertificateSdsProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsCertificatePropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTlsCertificateProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsCertificatePropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTlsCertificateProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsValidationSubjectAlternativeNamesPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsValidationSubjectAlternativeNamesPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsValidationTrustFilePropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTlsValidationTrustFileProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsValidationTrustFilePropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTlsValidationTrustFileProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsValidationTrustSdsPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTlsValidationTrustSdsProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsValidationTrustSdsPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTlsValidationTrustSdsProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsValidationTrustPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTlsValidationTrustProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsValidationTrustPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTlsValidationTrustProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsValidationPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTlsValidationProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsValidationPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTlsValidationProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsPropertyToTerraform(struct?: DataTfVirtualNode.SpecListenerTlsProperty): any;
export declare function dataTfVirtualNodeSpecListenerTlsPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecListenerTlsProperty): any;
export declare function dataTfVirtualNodeListenerPropertyToTerraform(struct?: DataTfVirtualNode.ListenerProperty): any;
export declare function dataTfVirtualNodeListenerPropertyToHclTerraform(struct?: DataTfVirtualNode.ListenerProperty): any;
export declare function dataTfVirtualNodeJsonPropertyToTerraform(struct?: DataTfVirtualNode.JsonProperty): any;
export declare function dataTfVirtualNodeJsonPropertyToHclTerraform(struct?: DataTfVirtualNode.JsonProperty): any;
export declare function dataTfVirtualNodeFormatPropertyToTerraform(struct?: DataTfVirtualNode.FormatProperty): any;
export declare function dataTfVirtualNodeFormatPropertyToHclTerraform(struct?: DataTfVirtualNode.FormatProperty): any;
export declare function dataTfVirtualNodeSpecLoggingAccessLogFilePropertyToTerraform(struct?: DataTfVirtualNode.SpecLoggingAccessLogFileProperty): any;
export declare function dataTfVirtualNodeSpecLoggingAccessLogFilePropertyToHclTerraform(struct?: DataTfVirtualNode.SpecLoggingAccessLogFileProperty): any;
export declare function dataTfVirtualNodeAccessLogPropertyToTerraform(struct?: DataTfVirtualNode.AccessLogProperty): any;
export declare function dataTfVirtualNodeAccessLogPropertyToHclTerraform(struct?: DataTfVirtualNode.AccessLogProperty): any;
export declare function dataTfVirtualNodeLoggingPropertyToTerraform(struct?: DataTfVirtualNode.LoggingProperty): any;
export declare function dataTfVirtualNodeLoggingPropertyToHclTerraform(struct?: DataTfVirtualNode.LoggingProperty): any;
export declare function dataTfVirtualNodeAwsCloudMapPropertyToTerraform(struct?: DataTfVirtualNode.AwsCloudMapProperty): any;
export declare function dataTfVirtualNodeAwsCloudMapPropertyToHclTerraform(struct?: DataTfVirtualNode.AwsCloudMapProperty): any;
export declare function dataTfVirtualNodeDnsPropertyToTerraform(struct?: DataTfVirtualNode.DnsProperty): any;
export declare function dataTfVirtualNodeDnsPropertyToHclTerraform(struct?: DataTfVirtualNode.DnsProperty): any;
export declare function dataTfVirtualNodeServiceDiscoveryPropertyToTerraform(struct?: DataTfVirtualNode.ServiceDiscoveryProperty): any;
export declare function dataTfVirtualNodeServiceDiscoveryPropertyToHclTerraform(struct?: DataTfVirtualNode.ServiceDiscoveryProperty): any;
export declare function dataTfVirtualNodeSpecPropertyToTerraform(struct?: DataTfVirtualNode.SpecProperty): any;
export declare function dataTfVirtualNodeSpecPropertyToHclTerraform(struct?: DataTfVirtualNode.SpecProperty): any;
export declare namespace DataTfVirtualNode {
    interface SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty | undefined);
        get certificateChain(): string;
        get privateKey(): string;
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty | undefined);
        get secretName(): string;
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsCertificateProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsCertificateProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsCertificateProperty | undefined);
        private _file;
        get file(): SpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyList;
        private _sds;
        get sds(): SpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyList;
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsCertificatePropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined);
        get exact(): string[];
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined);
        private _match;
        get match(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyList;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty | undefined);
        get certificateAuthorityArns(): string[];
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty | undefined);
        get certificateChain(): string;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty | undefined);
        get secretName(): string;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty | undefined);
        private _acm;
        get acm(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyList;
        private _file;
        get file(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyList;
        private _sds;
        get sds(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyList;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationProperty | undefined);
        private _subjectAlternativeNames;
        get subjectAlternativeNames(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyList;
        private _trust;
        get trust(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyList;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsValidationPropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsProperty {
    }
    class SpecBackendVirtualServiceClientPolicyTlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsProperty | undefined);
        private _certificate;
        get certificate(): SpecBackendVirtualServiceClientPolicyTlsCertificatePropertyList;
        get enforce(): cdktn.IResolvable;
        get ports(): number[];
        private _validation;
        get validation(): SpecBackendVirtualServiceClientPolicyTlsValidationPropertyList;
    }
    class SpecBackendVirtualServiceClientPolicyTlsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyTlsPropertyOutputReference;
    }
    interface SpecBackendVirtualServiceClientPolicyProperty {
    }
    class SpecBackendVirtualServiceClientPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendVirtualServiceClientPolicyProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyProperty | undefined);
        private _tls;
        get tls(): SpecBackendVirtualServiceClientPolicyTlsPropertyList;
    }
    class SpecBackendVirtualServiceClientPolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendVirtualServiceClientPolicyPropertyOutputReference;
    }
    interface VirtualServiceProperty {
    }
    class VirtualServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VirtualServiceProperty | undefined;
        set internalValue(value: VirtualServiceProperty | undefined);
        private _clientPolicy;
        get clientPolicy(): SpecBackendVirtualServiceClientPolicyPropertyList;
        get virtualServiceName(): string;
    }
    class VirtualServicePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VirtualServicePropertyOutputReference;
    }
    interface BackendProperty {
    }
    class BackendPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BackendProperty | undefined;
        set internalValue(value: BackendProperty | undefined);
        private _virtualService;
        get virtualService(): VirtualServicePropertyList;
    }
    class BackendPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BackendPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsCertificateFileProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateFileProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateFileProperty | undefined);
        get certificateChain(): string;
        get privateKey(): string;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty | undefined);
        get secretName(): string;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsCertificateProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateProperty | undefined);
        private _file;
        get file(): SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyList;
        private _sds;
        get sds(): SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyList;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined);
        get exact(): string[];
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined);
        private _match;
        get match(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyList;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty | undefined);
        get certificateAuthorityArns(): string[];
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty | undefined);
        get certificateChain(): string;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty | undefined);
        get secretName(): string;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustProperty | undefined);
        private _acm;
        get acm(): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyList;
        private _file;
        get file(): SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyList;
        private _sds;
        get sds(): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyList;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationProperty | undefined);
        private _subjectAlternativeNames;
        get subjectAlternativeNames(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyList;
        private _trust;
        get trust(): SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyList;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsProperty {
    }
    class SpecBackendDefaultsClientPolicyTlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsProperty | undefined);
        private _certificate;
        get certificate(): SpecBackendDefaultsClientPolicyTlsCertificatePropertyList;
        get enforce(): cdktn.IResolvable;
        get ports(): number[];
        private _validation;
        get validation(): SpecBackendDefaultsClientPolicyTlsValidationPropertyList;
    }
    class SpecBackendDefaultsClientPolicyTlsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyTlsPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyProperty {
    }
    class SpecBackendDefaultsClientPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecBackendDefaultsClientPolicyProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyProperty | undefined);
        private _tls;
        get tls(): SpecBackendDefaultsClientPolicyTlsPropertyList;
    }
    class SpecBackendDefaultsClientPolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecBackendDefaultsClientPolicyPropertyOutputReference;
    }
    interface BackendDefaultsProperty {
    }
    class BackendDefaultsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BackendDefaultsProperty | undefined;
        set internalValue(value: BackendDefaultsProperty | undefined);
        private _clientPolicy;
        get clientPolicy(): SpecBackendDefaultsClientPolicyPropertyList;
    }
    class BackendDefaultsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BackendDefaultsPropertyOutputReference;
    }
    interface SpecListenerConnectionPoolGrpcProperty {
    }
    class SpecListenerConnectionPoolGrpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerConnectionPoolGrpcProperty | undefined;
        set internalValue(value: SpecListenerConnectionPoolGrpcProperty | undefined);
        get maxRequests(): number;
    }
    class SpecListenerConnectionPoolGrpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerConnectionPoolGrpcPropertyOutputReference;
    }
    interface SpecListenerConnectionPoolHttpProperty {
    }
    class SpecListenerConnectionPoolHttpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerConnectionPoolHttpProperty | undefined;
        set internalValue(value: SpecListenerConnectionPoolHttpProperty | undefined);
        get maxConnections(): number;
        get maxPendingRequests(): number;
    }
    class SpecListenerConnectionPoolHttpPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerConnectionPoolHttpPropertyOutputReference;
    }
    interface SpecListenerConnectionPoolHttp2Property {
    }
    class SpecListenerConnectionPoolHttp2PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerConnectionPoolHttp2Property | undefined;
        set internalValue(value: SpecListenerConnectionPoolHttp2Property | undefined);
        get maxRequests(): number;
    }
    class SpecListenerConnectionPoolHttp2PropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerConnectionPoolHttp2PropertyOutputReference;
    }
    interface SpecListenerConnectionPoolTcpProperty {
    }
    class SpecListenerConnectionPoolTcpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerConnectionPoolTcpProperty | undefined;
        set internalValue(value: SpecListenerConnectionPoolTcpProperty | undefined);
        get maxConnections(): number;
    }
    class SpecListenerConnectionPoolTcpPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerConnectionPoolTcpPropertyOutputReference;
    }
    interface ConnectionPoolProperty {
    }
    class ConnectionPoolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectionPoolProperty | undefined;
        set internalValue(value: ConnectionPoolProperty | undefined);
        private _grpc;
        get grpc(): SpecListenerConnectionPoolGrpcPropertyList;
        private _http;
        get http(): SpecListenerConnectionPoolHttpPropertyList;
        private _http2;
        get http2(): SpecListenerConnectionPoolHttp2PropertyList;
        private _tcp;
        get tcp(): SpecListenerConnectionPoolTcpPropertyList;
    }
    class ConnectionPoolPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectionPoolPropertyOutputReference;
    }
    interface HealthCheckProperty {
    }
    class HealthCheckPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HealthCheckProperty | undefined;
        set internalValue(value: HealthCheckProperty | undefined);
        get healthyThreshold(): number;
        get intervalMillis(): number;
        get path(): string;
        get port(): number;
        get protocol(): string;
        get timeoutMillis(): number;
        get unhealthyThreshold(): number;
    }
    class HealthCheckPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HealthCheckPropertyOutputReference;
    }
    interface BaseEjectionDurationProperty {
    }
    class BaseEjectionDurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BaseEjectionDurationProperty | undefined;
        set internalValue(value: BaseEjectionDurationProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class BaseEjectionDurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BaseEjectionDurationPropertyOutputReference;
    }
    interface IntervalProperty {
    }
    class IntervalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IntervalProperty | undefined;
        set internalValue(value: IntervalProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class IntervalPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IntervalPropertyOutputReference;
    }
    interface OutlierDetectionProperty {
    }
    class OutlierDetectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutlierDetectionProperty | undefined;
        set internalValue(value: OutlierDetectionProperty | undefined);
        private _baseEjectionDuration;
        get baseEjectionDuration(): BaseEjectionDurationPropertyList;
        private _interval;
        get interval(): IntervalPropertyList;
        get maxEjectionPercent(): number;
        get maxServerErrors(): number;
    }
    class OutlierDetectionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutlierDetectionPropertyOutputReference;
    }
    interface PortMappingProperty {
    }
    class PortMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PortMappingProperty | undefined;
        set internalValue(value: PortMappingProperty | undefined);
        get port(): number;
        get protocol(): string;
    }
    class PortMappingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PortMappingPropertyOutputReference;
    }
    interface SpecListenerTimeoutGrpcIdleProperty {
    }
    class SpecListenerTimeoutGrpcIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutGrpcIdleProperty | undefined;
        set internalValue(value: SpecListenerTimeoutGrpcIdleProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecListenerTimeoutGrpcIdlePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutGrpcIdlePropertyOutputReference;
    }
    interface SpecListenerTimeoutGrpcPerRequestProperty {
    }
    class SpecListenerTimeoutGrpcPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutGrpcPerRequestProperty | undefined;
        set internalValue(value: SpecListenerTimeoutGrpcPerRequestProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecListenerTimeoutGrpcPerRequestPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutGrpcPerRequestPropertyOutputReference;
    }
    interface SpecListenerTimeoutGrpcProperty {
    }
    class SpecListenerTimeoutGrpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutGrpcProperty | undefined;
        set internalValue(value: SpecListenerTimeoutGrpcProperty | undefined);
        private _idle;
        get idle(): SpecListenerTimeoutGrpcIdlePropertyList;
        private _perRequest;
        get perRequest(): SpecListenerTimeoutGrpcPerRequestPropertyList;
    }
    class SpecListenerTimeoutGrpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutGrpcPropertyOutputReference;
    }
    interface SpecListenerTimeoutHttpIdleProperty {
    }
    class SpecListenerTimeoutHttpIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutHttpIdleProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttpIdleProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecListenerTimeoutHttpIdlePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutHttpIdlePropertyOutputReference;
    }
    interface SpecListenerTimeoutHttpPerRequestProperty {
    }
    class SpecListenerTimeoutHttpPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutHttpPerRequestProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttpPerRequestProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecListenerTimeoutHttpPerRequestPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutHttpPerRequestPropertyOutputReference;
    }
    interface SpecListenerTimeoutHttpProperty {
    }
    class SpecListenerTimeoutHttpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutHttpProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttpProperty | undefined);
        private _idle;
        get idle(): SpecListenerTimeoutHttpIdlePropertyList;
        private _perRequest;
        get perRequest(): SpecListenerTimeoutHttpPerRequestPropertyList;
    }
    class SpecListenerTimeoutHttpPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutHttpPropertyOutputReference;
    }
    interface SpecListenerTimeoutHttp2IdleProperty {
    }
    class SpecListenerTimeoutHttp2IdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutHttp2IdleProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttp2IdleProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecListenerTimeoutHttp2IdlePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutHttp2IdlePropertyOutputReference;
    }
    interface SpecListenerTimeoutHttp2PerRequestProperty {
    }
    class SpecListenerTimeoutHttp2PerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutHttp2PerRequestProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttp2PerRequestProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecListenerTimeoutHttp2PerRequestPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutHttp2PerRequestPropertyOutputReference;
    }
    interface SpecListenerTimeoutHttp2Property {
    }
    class SpecListenerTimeoutHttp2PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutHttp2Property | undefined;
        set internalValue(value: SpecListenerTimeoutHttp2Property | undefined);
        private _idle;
        get idle(): SpecListenerTimeoutHttp2IdlePropertyList;
        private _perRequest;
        get perRequest(): SpecListenerTimeoutHttp2PerRequestPropertyList;
    }
    class SpecListenerTimeoutHttp2PropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutHttp2PropertyOutputReference;
    }
    interface SpecListenerTimeoutTcpIdleProperty {
    }
    class SpecListenerTimeoutTcpIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutTcpIdleProperty | undefined;
        set internalValue(value: SpecListenerTimeoutTcpIdleProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class SpecListenerTimeoutTcpIdlePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutTcpIdlePropertyOutputReference;
    }
    interface SpecListenerTimeoutTcpProperty {
    }
    class SpecListenerTimeoutTcpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTimeoutTcpProperty | undefined;
        set internalValue(value: SpecListenerTimeoutTcpProperty | undefined);
        private _idle;
        get idle(): SpecListenerTimeoutTcpIdlePropertyList;
    }
    class SpecListenerTimeoutTcpPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTimeoutTcpPropertyOutputReference;
    }
    interface TimeoutProperty {
    }
    class TimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TimeoutProperty | undefined;
        set internalValue(value: TimeoutProperty | undefined);
        private _grpc;
        get grpc(): SpecListenerTimeoutGrpcPropertyList;
        private _http;
        get http(): SpecListenerTimeoutHttpPropertyList;
        private _http2;
        get http2(): SpecListenerTimeoutHttp2PropertyList;
        private _tcp;
        get tcp(): SpecListenerTimeoutTcpPropertyList;
    }
    class TimeoutPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TimeoutPropertyOutputReference;
    }
    interface SpecListenerTlsCertificateAcmProperty {
    }
    class SpecListenerTlsCertificateAcmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsCertificateAcmProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateAcmProperty | undefined);
        get certificateArn(): string;
    }
    class SpecListenerTlsCertificateAcmPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsCertificateAcmPropertyOutputReference;
    }
    interface SpecListenerTlsCertificateFileProperty {
    }
    class SpecListenerTlsCertificateFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsCertificateFileProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateFileProperty | undefined);
        get certificateChain(): string;
        get privateKey(): string;
    }
    class SpecListenerTlsCertificateFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsCertificateFilePropertyOutputReference;
    }
    interface SpecListenerTlsCertificateSdsProperty {
    }
    class SpecListenerTlsCertificateSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsCertificateSdsProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateSdsProperty | undefined);
        get secretName(): string;
    }
    class SpecListenerTlsCertificateSdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsCertificateSdsPropertyOutputReference;
    }
    interface SpecListenerTlsCertificateProperty {
    }
    class SpecListenerTlsCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsCertificateProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateProperty | undefined);
        private _acm;
        get acm(): SpecListenerTlsCertificateAcmPropertyList;
        private _file;
        get file(): SpecListenerTlsCertificateFilePropertyList;
        private _sds;
        get sds(): SpecListenerTlsCertificateSdsPropertyList;
    }
    class SpecListenerTlsCertificatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsCertificatePropertyOutputReference;
    }
    interface SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty {
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty | undefined);
        get exact(): string[];
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference;
    }
    interface SpecListenerTlsValidationSubjectAlternativeNamesProperty {
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationSubjectAlternativeNamesProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationSubjectAlternativeNamesProperty | undefined);
        private _match;
        get match(): SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyList;
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference;
    }
    interface SpecListenerTlsValidationTrustFileProperty {
    }
    class SpecListenerTlsValidationTrustFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationTrustFileProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustFileProperty | undefined);
        get certificateChain(): string;
    }
    class SpecListenerTlsValidationTrustFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationTrustFilePropertyOutputReference;
    }
    interface SpecListenerTlsValidationTrustSdsProperty {
    }
    class SpecListenerTlsValidationTrustSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationTrustSdsProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustSdsProperty | undefined);
        get secretName(): string;
    }
    class SpecListenerTlsValidationTrustSdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationTrustSdsPropertyOutputReference;
    }
    interface SpecListenerTlsValidationTrustProperty {
    }
    class SpecListenerTlsValidationTrustPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationTrustProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustProperty | undefined);
        private _file;
        get file(): SpecListenerTlsValidationTrustFilePropertyList;
        private _sds;
        get sds(): SpecListenerTlsValidationTrustSdsPropertyList;
    }
    class SpecListenerTlsValidationTrustPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationTrustPropertyOutputReference;
    }
    interface SpecListenerTlsValidationProperty {
    }
    class SpecListenerTlsValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsValidationProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationProperty | undefined);
        private _subjectAlternativeNames;
        get subjectAlternativeNames(): SpecListenerTlsValidationSubjectAlternativeNamesPropertyList;
        private _trust;
        get trust(): SpecListenerTlsValidationTrustPropertyList;
    }
    class SpecListenerTlsValidationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsValidationPropertyOutputReference;
    }
    interface SpecListenerTlsProperty {
    }
    class SpecListenerTlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerTlsProperty | undefined;
        set internalValue(value: SpecListenerTlsProperty | undefined);
        private _certificate;
        get certificate(): SpecListenerTlsCertificatePropertyList;
        get mode(): string;
        private _validation;
        get validation(): SpecListenerTlsValidationPropertyList;
    }
    class SpecListenerTlsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerTlsPropertyOutputReference;
    }
    interface ListenerProperty {
    }
    class ListenerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ListenerProperty | undefined;
        set internalValue(value: ListenerProperty | undefined);
        private _connectionPool;
        get connectionPool(): ConnectionPoolPropertyList;
        private _healthCheck;
        get healthCheck(): HealthCheckPropertyList;
        private _outlierDetection;
        get outlierDetection(): OutlierDetectionPropertyList;
        private _portMapping;
        get portMapping(): PortMappingPropertyList;
        private _timeout;
        get timeout(): TimeoutPropertyList;
        private _tls;
        get tls(): SpecListenerTlsPropertyList;
    }
    class ListenerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ListenerPropertyOutputReference;
    }
    interface JsonProperty {
    }
    class JsonPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JsonProperty | undefined;
        set internalValue(value: JsonProperty | undefined);
        get key(): string;
        get value(): string;
    }
    class JsonPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JsonPropertyOutputReference;
    }
    interface FormatProperty {
    }
    class FormatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FormatProperty | undefined;
        set internalValue(value: FormatProperty | undefined);
        private _json;
        get json(): JsonPropertyList;
        get text(): string;
    }
    class FormatPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FormatPropertyOutputReference;
    }
    interface SpecLoggingAccessLogFileProperty {
    }
    class SpecLoggingAccessLogFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecLoggingAccessLogFileProperty | undefined;
        set internalValue(value: SpecLoggingAccessLogFileProperty | undefined);
        private _format;
        get format(): FormatPropertyList;
        get path(): string;
    }
    class SpecLoggingAccessLogFilePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecLoggingAccessLogFilePropertyOutputReference;
    }
    interface AccessLogProperty {
    }
    class AccessLogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessLogProperty | undefined;
        set internalValue(value: AccessLogProperty | undefined);
        private _file;
        get file(): SpecLoggingAccessLogFilePropertyList;
    }
    class AccessLogPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessLogPropertyOutputReference;
    }
    interface LoggingProperty {
    }
    class LoggingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoggingProperty | undefined;
        set internalValue(value: LoggingProperty | undefined);
        private _accessLog;
        get accessLog(): AccessLogPropertyList;
    }
    class LoggingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoggingPropertyOutputReference;
    }
    interface AwsCloudMapProperty {
    }
    class AwsCloudMapPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AwsCloudMapProperty | undefined;
        set internalValue(value: AwsCloudMapProperty | undefined);
        private _attributes;
        get attributes(): cdktn.StringMap;
        get namespaceName(): string;
        get serviceName(): string;
    }
    class AwsCloudMapPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AwsCloudMapPropertyOutputReference;
    }
    interface DnsProperty {
    }
    class DnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DnsProperty | undefined;
        set internalValue(value: DnsProperty | undefined);
        get hostname(): string;
        get ipPreference(): string;
        get responseType(): string;
    }
    class DnsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DnsPropertyOutputReference;
    }
    interface ServiceDiscoveryProperty {
    }
    class ServiceDiscoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServiceDiscoveryProperty | undefined;
        set internalValue(value: ServiceDiscoveryProperty | undefined);
        private _awsCloudMap;
        get awsCloudMap(): AwsCloudMapPropertyList;
        private _dns;
        get dns(): DnsPropertyList;
    }
    class ServiceDiscoveryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServiceDiscoveryPropertyOutputReference;
    }
    interface SpecProperty {
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _backend;
        get backend(): BackendPropertyList;
        private _backendDefaults;
        get backendDefaults(): BackendDefaultsPropertyList;
        private _listener;
        get listener(): ListenerPropertyList;
        private _logging;
        get logging(): LoggingPropertyList;
        private _serviceDiscovery;
        get serviceDiscovery(): ServiceDiscoveryPropertyList;
    }
    class SpecPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecPropertyOutputReference;
    }
}
