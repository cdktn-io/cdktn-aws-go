import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfVirtualNodeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#id TfVirtualNode#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#mesh_name TfVirtualNode#mesh_name}
    */
    readonly meshName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#mesh_owner TfVirtualNode#mesh_owner}
    */
    readonly meshOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#name TfVirtualNode#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#region TfVirtualNode#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#tags TfVirtualNode#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#tags_all TfVirtualNode#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * spec block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#spec TfVirtualNode#spec}
    */
    readonly spec: TfVirtualNode.SpecProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node aws_appmesh_virtual_node}
*/
export declare class TfVirtualNode extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appmesh_virtual_node";
    /**
    * Generates CDKTN code for importing a TfVirtualNode resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfVirtualNode to import
    * @param importFromId The id of the existing TfVirtualNode that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfVirtualNode to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node aws_appmesh_virtual_node} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfVirtualNodeConfig
    */
    constructor(scope: Construct, id: string, config: TfVirtualNodeConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _meshName?;
    get meshName(): string;
    set meshName(value: string);
    get meshNameInput(): string | undefined;
    private _meshOwner?;
    get meshOwner(): string;
    set meshOwner(value: string);
    resetMeshOwner(): void;
    get meshOwnerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _spec;
    get spec(): TfVirtualNode.SpecPropertyOutputReference;
    putSpec(value: TfVirtualNode.SpecProperty): void;
    get specInput(): TfVirtualNode.SpecProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyToTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyToTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificatePropertyToTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificatePropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsCertificatePropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificatePropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsCertificateProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyToTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyToTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyToTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyToTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyToTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationPropertyToTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsValidationPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsValidationProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsPropertyToTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyTlsPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyTlsProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyPropertyToTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyProperty): any;
export declare function tfVirtualNodeSpecBackendVirtualServiceClientPolicyPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendVirtualServiceClientPolicyPropertyOutputReference | TfVirtualNode.SpecBackendVirtualServiceClientPolicyProperty): any;
export declare function tfVirtualNodeVirtualServicePropertyToTerraform(struct?: TfVirtualNode.VirtualServicePropertyOutputReference | TfVirtualNode.VirtualServiceProperty): any;
export declare function tfVirtualNodeVirtualServicePropertyToHclTerraform(struct?: TfVirtualNode.VirtualServicePropertyOutputReference | TfVirtualNode.VirtualServiceProperty): any;
export declare function tfVirtualNodeBackendPropertyToTerraform(struct?: TfVirtualNode.BackendProperty | cdktn.IResolvable): any;
export declare function tfVirtualNodeBackendPropertyToHclTerraform(struct?: TfVirtualNode.BackendProperty | cdktn.IResolvable): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificateFilePropertyToTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateFileProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificateFilePropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateFileProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyToTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificatePropertyToTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsCertificatePropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsCertificateProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyToTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyToTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyToTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyToTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustPropertyToTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationTrustPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationTrustProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationPropertyToTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsValidationPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsValidationProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsPropertyToTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyTlsPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyTlsPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyTlsProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyPropertyToTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyProperty): any;
export declare function tfVirtualNodeSpecBackendDefaultsClientPolicyPropertyToHclTerraform(struct?: TfVirtualNode.SpecBackendDefaultsClientPolicyPropertyOutputReference | TfVirtualNode.SpecBackendDefaultsClientPolicyProperty): any;
export declare function tfVirtualNodeBackendDefaultsPropertyToTerraform(struct?: TfVirtualNode.BackendDefaultsPropertyOutputReference | TfVirtualNode.BackendDefaultsProperty): any;
export declare function tfVirtualNodeBackendDefaultsPropertyToHclTerraform(struct?: TfVirtualNode.BackendDefaultsPropertyOutputReference | TfVirtualNode.BackendDefaultsProperty): any;
export declare function tfVirtualNodeSpecListenerConnectionPoolGrpcPropertyToTerraform(struct?: TfVirtualNode.SpecListenerConnectionPoolGrpcPropertyOutputReference | TfVirtualNode.SpecListenerConnectionPoolGrpcProperty): any;
export declare function tfVirtualNodeSpecListenerConnectionPoolGrpcPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerConnectionPoolGrpcPropertyOutputReference | TfVirtualNode.SpecListenerConnectionPoolGrpcProperty): any;
export declare function tfVirtualNodeSpecListenerConnectionPoolHttpPropertyToTerraform(struct?: TfVirtualNode.SpecListenerConnectionPoolHttpProperty | cdktn.IResolvable): any;
export declare function tfVirtualNodeSpecListenerConnectionPoolHttpPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerConnectionPoolHttpProperty | cdktn.IResolvable): any;
export declare function tfVirtualNodeSpecListenerConnectionPoolHttp2PropertyToTerraform(struct?: TfVirtualNode.SpecListenerConnectionPoolHttp2Property | cdktn.IResolvable): any;
export declare function tfVirtualNodeSpecListenerConnectionPoolHttp2PropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerConnectionPoolHttp2Property | cdktn.IResolvable): any;
export declare function tfVirtualNodeSpecListenerConnectionPoolTcpPropertyToTerraform(struct?: TfVirtualNode.SpecListenerConnectionPoolTcpProperty | cdktn.IResolvable): any;
export declare function tfVirtualNodeSpecListenerConnectionPoolTcpPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerConnectionPoolTcpProperty | cdktn.IResolvable): any;
export declare function tfVirtualNodeConnectionPoolPropertyToTerraform(struct?: TfVirtualNode.ConnectionPoolPropertyOutputReference | TfVirtualNode.ConnectionPoolProperty): any;
export declare function tfVirtualNodeConnectionPoolPropertyToHclTerraform(struct?: TfVirtualNode.ConnectionPoolPropertyOutputReference | TfVirtualNode.ConnectionPoolProperty): any;
export declare function tfVirtualNodeHealthCheckPropertyToTerraform(struct?: TfVirtualNode.HealthCheckPropertyOutputReference | TfVirtualNode.HealthCheckProperty): any;
export declare function tfVirtualNodeHealthCheckPropertyToHclTerraform(struct?: TfVirtualNode.HealthCheckPropertyOutputReference | TfVirtualNode.HealthCheckProperty): any;
export declare function tfVirtualNodeBaseEjectionDurationPropertyToTerraform(struct?: TfVirtualNode.BaseEjectionDurationPropertyOutputReference | TfVirtualNode.BaseEjectionDurationProperty): any;
export declare function tfVirtualNodeBaseEjectionDurationPropertyToHclTerraform(struct?: TfVirtualNode.BaseEjectionDurationPropertyOutputReference | TfVirtualNode.BaseEjectionDurationProperty): any;
export declare function tfVirtualNodeIntervalPropertyToTerraform(struct?: TfVirtualNode.IntervalPropertyOutputReference | TfVirtualNode.IntervalProperty): any;
export declare function tfVirtualNodeIntervalPropertyToHclTerraform(struct?: TfVirtualNode.IntervalPropertyOutputReference | TfVirtualNode.IntervalProperty): any;
export declare function tfVirtualNodeOutlierDetectionPropertyToTerraform(struct?: TfVirtualNode.OutlierDetectionPropertyOutputReference | TfVirtualNode.OutlierDetectionProperty): any;
export declare function tfVirtualNodeOutlierDetectionPropertyToHclTerraform(struct?: TfVirtualNode.OutlierDetectionPropertyOutputReference | TfVirtualNode.OutlierDetectionProperty): any;
export declare function tfVirtualNodePortMappingPropertyToTerraform(struct?: TfVirtualNode.PortMappingPropertyOutputReference | TfVirtualNode.PortMappingProperty): any;
export declare function tfVirtualNodePortMappingPropertyToHclTerraform(struct?: TfVirtualNode.PortMappingPropertyOutputReference | TfVirtualNode.PortMappingProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutGrpcIdlePropertyToTerraform(struct?: TfVirtualNode.SpecListenerTimeoutGrpcIdlePropertyOutputReference | TfVirtualNode.SpecListenerTimeoutGrpcIdleProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutGrpcIdlePropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTimeoutGrpcIdlePropertyOutputReference | TfVirtualNode.SpecListenerTimeoutGrpcIdleProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutGrpcPerRequestPropertyToTerraform(struct?: TfVirtualNode.SpecListenerTimeoutGrpcPerRequestPropertyOutputReference | TfVirtualNode.SpecListenerTimeoutGrpcPerRequestProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutGrpcPerRequestPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTimeoutGrpcPerRequestPropertyOutputReference | TfVirtualNode.SpecListenerTimeoutGrpcPerRequestProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutGrpcPropertyToTerraform(struct?: TfVirtualNode.SpecListenerTimeoutGrpcPropertyOutputReference | TfVirtualNode.SpecListenerTimeoutGrpcProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutGrpcPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTimeoutGrpcPropertyOutputReference | TfVirtualNode.SpecListenerTimeoutGrpcProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutHttpIdlePropertyToTerraform(struct?: TfVirtualNode.SpecListenerTimeoutHttpIdlePropertyOutputReference | TfVirtualNode.SpecListenerTimeoutHttpIdleProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutHttpIdlePropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTimeoutHttpIdlePropertyOutputReference | TfVirtualNode.SpecListenerTimeoutHttpIdleProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutHttpPerRequestPropertyToTerraform(struct?: TfVirtualNode.SpecListenerTimeoutHttpPerRequestPropertyOutputReference | TfVirtualNode.SpecListenerTimeoutHttpPerRequestProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutHttpPerRequestPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTimeoutHttpPerRequestPropertyOutputReference | TfVirtualNode.SpecListenerTimeoutHttpPerRequestProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutHttpPropertyToTerraform(struct?: TfVirtualNode.SpecListenerTimeoutHttpPropertyOutputReference | TfVirtualNode.SpecListenerTimeoutHttpProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutHttpPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTimeoutHttpPropertyOutputReference | TfVirtualNode.SpecListenerTimeoutHttpProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutHttp2IdlePropertyToTerraform(struct?: TfVirtualNode.SpecListenerTimeoutHttp2IdlePropertyOutputReference | TfVirtualNode.SpecListenerTimeoutHttp2IdleProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutHttp2IdlePropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTimeoutHttp2IdlePropertyOutputReference | TfVirtualNode.SpecListenerTimeoutHttp2IdleProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutHttp2PerRequestPropertyToTerraform(struct?: TfVirtualNode.SpecListenerTimeoutHttp2PerRequestPropertyOutputReference | TfVirtualNode.SpecListenerTimeoutHttp2PerRequestProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutHttp2PerRequestPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTimeoutHttp2PerRequestPropertyOutputReference | TfVirtualNode.SpecListenerTimeoutHttp2PerRequestProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutHttp2PropertyToTerraform(struct?: TfVirtualNode.SpecListenerTimeoutHttp2PropertyOutputReference | TfVirtualNode.SpecListenerTimeoutHttp2Property): any;
export declare function tfVirtualNodeSpecListenerTimeoutHttp2PropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTimeoutHttp2PropertyOutputReference | TfVirtualNode.SpecListenerTimeoutHttp2Property): any;
export declare function tfVirtualNodeSpecListenerTimeoutTcpIdlePropertyToTerraform(struct?: TfVirtualNode.SpecListenerTimeoutTcpIdlePropertyOutputReference | TfVirtualNode.SpecListenerTimeoutTcpIdleProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutTcpIdlePropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTimeoutTcpIdlePropertyOutputReference | TfVirtualNode.SpecListenerTimeoutTcpIdleProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutTcpPropertyToTerraform(struct?: TfVirtualNode.SpecListenerTimeoutTcpPropertyOutputReference | TfVirtualNode.SpecListenerTimeoutTcpProperty): any;
export declare function tfVirtualNodeSpecListenerTimeoutTcpPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTimeoutTcpPropertyOutputReference | TfVirtualNode.SpecListenerTimeoutTcpProperty): any;
export declare function tfVirtualNodeTimeoutPropertyToTerraform(struct?: TfVirtualNode.TimeoutPropertyOutputReference | TfVirtualNode.TimeoutProperty): any;
export declare function tfVirtualNodeTimeoutPropertyToHclTerraform(struct?: TfVirtualNode.TimeoutPropertyOutputReference | TfVirtualNode.TimeoutProperty): any;
export declare function tfVirtualNodeSpecListenerTlsCertificateAcmPropertyToTerraform(struct?: TfVirtualNode.SpecListenerTlsCertificateAcmPropertyOutputReference | TfVirtualNode.SpecListenerTlsCertificateAcmProperty): any;
export declare function tfVirtualNodeSpecListenerTlsCertificateAcmPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTlsCertificateAcmPropertyOutputReference | TfVirtualNode.SpecListenerTlsCertificateAcmProperty): any;
export declare function tfVirtualNodeSpecListenerTlsCertificateFilePropertyToTerraform(struct?: TfVirtualNode.SpecListenerTlsCertificateFilePropertyOutputReference | TfVirtualNode.SpecListenerTlsCertificateFileProperty): any;
export declare function tfVirtualNodeSpecListenerTlsCertificateFilePropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTlsCertificateFilePropertyOutputReference | TfVirtualNode.SpecListenerTlsCertificateFileProperty): any;
export declare function tfVirtualNodeSpecListenerTlsCertificateSdsPropertyToTerraform(struct?: TfVirtualNode.SpecListenerTlsCertificateSdsPropertyOutputReference | TfVirtualNode.SpecListenerTlsCertificateSdsProperty): any;
export declare function tfVirtualNodeSpecListenerTlsCertificateSdsPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTlsCertificateSdsPropertyOutputReference | TfVirtualNode.SpecListenerTlsCertificateSdsProperty): any;
export declare function tfVirtualNodeSpecListenerTlsCertificatePropertyToTerraform(struct?: TfVirtualNode.SpecListenerTlsCertificatePropertyOutputReference | TfVirtualNode.SpecListenerTlsCertificateProperty): any;
export declare function tfVirtualNodeSpecListenerTlsCertificatePropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTlsCertificatePropertyOutputReference | TfVirtualNode.SpecListenerTlsCertificateProperty): any;
export declare function tfVirtualNodeSpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyToTerraform(struct?: TfVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference | TfVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function tfVirtualNodeSpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference | TfVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty): any;
export declare function tfVirtualNodeSpecListenerTlsValidationSubjectAlternativeNamesPropertyToTerraform(struct?: TfVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference | TfVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesProperty): any;
export declare function tfVirtualNodeSpecListenerTlsValidationSubjectAlternativeNamesPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference | TfVirtualNode.SpecListenerTlsValidationSubjectAlternativeNamesProperty): any;
export declare function tfVirtualNodeSpecListenerTlsValidationTrustFilePropertyToTerraform(struct?: TfVirtualNode.SpecListenerTlsValidationTrustFilePropertyOutputReference | TfVirtualNode.SpecListenerTlsValidationTrustFileProperty): any;
export declare function tfVirtualNodeSpecListenerTlsValidationTrustFilePropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTlsValidationTrustFilePropertyOutputReference | TfVirtualNode.SpecListenerTlsValidationTrustFileProperty): any;
export declare function tfVirtualNodeSpecListenerTlsValidationTrustSdsPropertyToTerraform(struct?: TfVirtualNode.SpecListenerTlsValidationTrustSdsPropertyOutputReference | TfVirtualNode.SpecListenerTlsValidationTrustSdsProperty): any;
export declare function tfVirtualNodeSpecListenerTlsValidationTrustSdsPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTlsValidationTrustSdsPropertyOutputReference | TfVirtualNode.SpecListenerTlsValidationTrustSdsProperty): any;
export declare function tfVirtualNodeSpecListenerTlsValidationTrustPropertyToTerraform(struct?: TfVirtualNode.SpecListenerTlsValidationTrustPropertyOutputReference | TfVirtualNode.SpecListenerTlsValidationTrustProperty): any;
export declare function tfVirtualNodeSpecListenerTlsValidationTrustPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTlsValidationTrustPropertyOutputReference | TfVirtualNode.SpecListenerTlsValidationTrustProperty): any;
export declare function tfVirtualNodeSpecListenerTlsValidationPropertyToTerraform(struct?: TfVirtualNode.SpecListenerTlsValidationPropertyOutputReference | TfVirtualNode.SpecListenerTlsValidationProperty): any;
export declare function tfVirtualNodeSpecListenerTlsValidationPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTlsValidationPropertyOutputReference | TfVirtualNode.SpecListenerTlsValidationProperty): any;
export declare function tfVirtualNodeSpecListenerTlsPropertyToTerraform(struct?: TfVirtualNode.SpecListenerTlsPropertyOutputReference | TfVirtualNode.SpecListenerTlsProperty): any;
export declare function tfVirtualNodeSpecListenerTlsPropertyToHclTerraform(struct?: TfVirtualNode.SpecListenerTlsPropertyOutputReference | TfVirtualNode.SpecListenerTlsProperty): any;
export declare function tfVirtualNodeListenerPropertyToTerraform(struct?: TfVirtualNode.ListenerProperty | cdktn.IResolvable): any;
export declare function tfVirtualNodeListenerPropertyToHclTerraform(struct?: TfVirtualNode.ListenerProperty | cdktn.IResolvable): any;
export declare function tfVirtualNodeJsonPropertyToTerraform(struct?: TfVirtualNode.JsonProperty | cdktn.IResolvable): any;
export declare function tfVirtualNodeJsonPropertyToHclTerraform(struct?: TfVirtualNode.JsonProperty | cdktn.IResolvable): any;
export declare function tfVirtualNodeFormatPropertyToTerraform(struct?: TfVirtualNode.FormatPropertyOutputReference | TfVirtualNode.FormatProperty): any;
export declare function tfVirtualNodeFormatPropertyToHclTerraform(struct?: TfVirtualNode.FormatPropertyOutputReference | TfVirtualNode.FormatProperty): any;
export declare function tfVirtualNodeSpecLoggingAccessLogFilePropertyToTerraform(struct?: TfVirtualNode.SpecLoggingAccessLogFilePropertyOutputReference | TfVirtualNode.SpecLoggingAccessLogFileProperty): any;
export declare function tfVirtualNodeSpecLoggingAccessLogFilePropertyToHclTerraform(struct?: TfVirtualNode.SpecLoggingAccessLogFilePropertyOutputReference | TfVirtualNode.SpecLoggingAccessLogFileProperty): any;
export declare function tfVirtualNodeAccessLogPropertyToTerraform(struct?: TfVirtualNode.AccessLogPropertyOutputReference | TfVirtualNode.AccessLogProperty): any;
export declare function tfVirtualNodeAccessLogPropertyToHclTerraform(struct?: TfVirtualNode.AccessLogPropertyOutputReference | TfVirtualNode.AccessLogProperty): any;
export declare function tfVirtualNodeLoggingPropertyToTerraform(struct?: TfVirtualNode.LoggingPropertyOutputReference | TfVirtualNode.LoggingProperty): any;
export declare function tfVirtualNodeLoggingPropertyToHclTerraform(struct?: TfVirtualNode.LoggingPropertyOutputReference | TfVirtualNode.LoggingProperty): any;
export declare function tfVirtualNodeAwsCloudMapPropertyToTerraform(struct?: TfVirtualNode.AwsCloudMapPropertyOutputReference | TfVirtualNode.AwsCloudMapProperty): any;
export declare function tfVirtualNodeAwsCloudMapPropertyToHclTerraform(struct?: TfVirtualNode.AwsCloudMapPropertyOutputReference | TfVirtualNode.AwsCloudMapProperty): any;
export declare function tfVirtualNodeDnsPropertyToTerraform(struct?: TfVirtualNode.DnsPropertyOutputReference | TfVirtualNode.DnsProperty): any;
export declare function tfVirtualNodeDnsPropertyToHclTerraform(struct?: TfVirtualNode.DnsPropertyOutputReference | TfVirtualNode.DnsProperty): any;
export declare function tfVirtualNodeServiceDiscoveryPropertyToTerraform(struct?: TfVirtualNode.ServiceDiscoveryPropertyOutputReference | TfVirtualNode.ServiceDiscoveryProperty): any;
export declare function tfVirtualNodeServiceDiscoveryPropertyToHclTerraform(struct?: TfVirtualNode.ServiceDiscoveryPropertyOutputReference | TfVirtualNode.ServiceDiscoveryProperty): any;
export declare function tfVirtualNodeSpecPropertyToTerraform(struct?: TfVirtualNode.SpecPropertyOutputReference | TfVirtualNode.SpecProperty): any;
export declare function tfVirtualNodeSpecPropertyToHclTerraform(struct?: TfVirtualNode.SpecPropertyOutputReference | TfVirtualNode.SpecProperty): any;
export declare namespace TfVirtualNode {
    interface SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_chain TfVirtualNode#certificate_chain}
        */
        readonly certificateChain: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#private_key TfVirtualNode#private_key}
        */
        readonly privateKey: string;
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty | undefined);
        private _certificateChain?;
        get certificateChain(): string;
        set certificateChain(value: string);
        get certificateChainInput(): string | undefined;
        private _privateKey?;
        get privateKey(): string;
        set privateKey(value: string);
        get privateKeyInput(): string | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#secret_name TfVirtualNode#secret_name}
        */
        readonly secretName: string;
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty | undefined);
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsCertificateProperty {
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#file TfVirtualNode#file}
        */
        readonly file?: SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty;
        /**
        * sds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#sds TfVirtualNode#sds}
        */
        readonly sds?: SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty;
    }
    class SpecBackendVirtualServiceClientPolicyTlsCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsCertificateProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsCertificateProperty | undefined);
        private _file;
        get file(): SpecBackendVirtualServiceClientPolicyTlsCertificateFilePropertyOutputReference;
        putFile(value: SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecBackendVirtualServiceClientPolicyTlsCertificateFileProperty | undefined;
        private _sds;
        get sds(): SpecBackendVirtualServiceClientPolicyTlsCertificateSdsPropertyOutputReference;
        putSds(value: SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty): void;
        resetSds(): void;
        get sdsInput(): SpecBackendVirtualServiceClientPolicyTlsCertificateSdsProperty | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#exact TfVirtualNode#exact}
        */
        readonly exact: string[];
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined);
        private _exact?;
        get exact(): string[];
        set exact(value: string[]);
        get exactInput(): string[] | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty {
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#match TfVirtualNode#match}
        */
        readonly match: SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined);
        private _match;
        get match(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference;
        putMatch(value: SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): void;
        get matchInput(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_authority_arns TfVirtualNode#certificate_authority_arns}
        */
        readonly certificateAuthorityArns: string[];
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty | undefined);
        private _certificateAuthorityArns?;
        get certificateAuthorityArns(): string[];
        set certificateAuthorityArns(value: string[]);
        get certificateAuthorityArnsInput(): string[] | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_chain TfVirtualNode#certificate_chain}
        */
        readonly certificateChain: string;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty | undefined);
        private _certificateChain?;
        get certificateChain(): string;
        set certificateChain(value: string);
        get certificateChainInput(): string | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#secret_name TfVirtualNode#secret_name}
        */
        readonly secretName: string;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty | undefined);
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty {
        /**
        * acm block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#acm TfVirtualNode#acm}
        */
        readonly acm?: SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty;
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#file TfVirtualNode#file}
        */
        readonly file?: SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty;
        /**
        * sds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#sds TfVirtualNode#sds}
        */
        readonly sds?: SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty | undefined);
        private _acm;
        get acm(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmPropertyOutputReference;
        putAcm(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty): void;
        resetAcm(): void;
        get acmInput(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustAcmProperty | undefined;
        private _file;
        get file(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustFilePropertyOutputReference;
        putFile(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustFileProperty | undefined;
        private _sds;
        get sds(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsPropertyOutputReference;
        putSds(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty): void;
        resetSds(): void;
        get sdsInput(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustSdsProperty | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsValidationProperty {
        /**
        * subject_alternative_names block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#subject_alternative_names TfVirtualNode#subject_alternative_names}
        */
        readonly subjectAlternativeNames?: SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty;
        /**
        * trust block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#trust TfVirtualNode#trust}
        */
        readonly trust: SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty;
    }
    class SpecBackendVirtualServiceClientPolicyTlsValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsValidationProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsValidationProperty | undefined);
        private _subjectAlternativeNames;
        get subjectAlternativeNames(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference;
        putSubjectAlternativeNames(value: SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty): void;
        resetSubjectAlternativeNames(): void;
        get subjectAlternativeNamesInput(): SpecBackendVirtualServiceClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined;
        private _trust;
        get trust(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustPropertyOutputReference;
        putTrust(value: SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty): void;
        get trustInput(): SpecBackendVirtualServiceClientPolicyTlsValidationTrustProperty | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyTlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#enforce TfVirtualNode#enforce}
        */
        readonly enforce?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#ports TfVirtualNode#ports}
        */
        readonly ports?: number[];
        /**
        * certificate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate TfVirtualNode#certificate}
        */
        readonly certificate?: SpecBackendVirtualServiceClientPolicyTlsCertificateProperty;
        /**
        * validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#validation TfVirtualNode#validation}
        */
        readonly validation: SpecBackendVirtualServiceClientPolicyTlsValidationProperty;
    }
    class SpecBackendVirtualServiceClientPolicyTlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyTlsProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyTlsProperty | undefined);
        private _enforce?;
        get enforce(): boolean | cdktn.IResolvable;
        set enforce(value: boolean | cdktn.IResolvable);
        resetEnforce(): void;
        get enforceInput(): boolean | cdktn.IResolvable | undefined;
        private _ports?;
        get ports(): number[];
        set ports(value: number[]);
        resetPorts(): void;
        get portsInput(): number[] | undefined;
        private _certificate;
        get certificate(): SpecBackendVirtualServiceClientPolicyTlsCertificatePropertyOutputReference;
        putCertificate(value: SpecBackendVirtualServiceClientPolicyTlsCertificateProperty): void;
        resetCertificate(): void;
        get certificateInput(): SpecBackendVirtualServiceClientPolicyTlsCertificateProperty | undefined;
        private _validation;
        get validation(): SpecBackendVirtualServiceClientPolicyTlsValidationPropertyOutputReference;
        putValidation(value: SpecBackendVirtualServiceClientPolicyTlsValidationProperty): void;
        get validationInput(): SpecBackendVirtualServiceClientPolicyTlsValidationProperty | undefined;
    }
    interface SpecBackendVirtualServiceClientPolicyProperty {
        /**
        * tls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#tls TfVirtualNode#tls}
        */
        readonly tls?: SpecBackendVirtualServiceClientPolicyTlsProperty;
    }
    class SpecBackendVirtualServiceClientPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendVirtualServiceClientPolicyProperty | undefined;
        set internalValue(value: SpecBackendVirtualServiceClientPolicyProperty | undefined);
        private _tls;
        get tls(): SpecBackendVirtualServiceClientPolicyTlsPropertyOutputReference;
        putTls(value: SpecBackendVirtualServiceClientPolicyTlsProperty): void;
        resetTls(): void;
        get tlsInput(): SpecBackendVirtualServiceClientPolicyTlsProperty | undefined;
    }
    interface VirtualServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#virtual_service_name TfVirtualNode#virtual_service_name}
        */
        readonly virtualServiceName: string;
        /**
        * client_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#client_policy TfVirtualNode#client_policy}
        */
        readonly clientPolicy?: SpecBackendVirtualServiceClientPolicyProperty;
    }
    class VirtualServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VirtualServiceProperty | undefined;
        set internalValue(value: VirtualServiceProperty | undefined);
        private _virtualServiceName?;
        get virtualServiceName(): string;
        set virtualServiceName(value: string);
        get virtualServiceNameInput(): string | undefined;
        private _clientPolicy;
        get clientPolicy(): SpecBackendVirtualServiceClientPolicyPropertyOutputReference;
        putClientPolicy(value: SpecBackendVirtualServiceClientPolicyProperty): void;
        resetClientPolicy(): void;
        get clientPolicyInput(): SpecBackendVirtualServiceClientPolicyProperty | undefined;
    }
    interface BackendProperty {
        /**
        * virtual_service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#virtual_service TfVirtualNode#virtual_service}
        */
        readonly virtualService: VirtualServiceProperty;
    }
    class BackendPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BackendProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BackendProperty | cdktn.IResolvable | undefined);
        private _virtualService;
        get virtualService(): VirtualServicePropertyOutputReference;
        putVirtualService(value: VirtualServiceProperty): void;
        get virtualServiceInput(): VirtualServiceProperty | undefined;
    }
    class BackendPropertyList extends cdktn.ComplexList {
        internalValue?: BackendProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BackendPropertyOutputReference;
    }
    interface SpecBackendDefaultsClientPolicyTlsCertificateFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_chain TfVirtualNode#certificate_chain}
        */
        readonly certificateChain: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#private_key TfVirtualNode#private_key}
        */
        readonly privateKey: string;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateFileProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateFileProperty | undefined);
        private _certificateChain?;
        get certificateChain(): string;
        set certificateChain(value: string);
        get certificateChainInput(): string | undefined;
        private _privateKey?;
        get privateKey(): string;
        set privateKey(value: string);
        get privateKeyInput(): string | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#secret_name TfVirtualNode#secret_name}
        */
        readonly secretName: string;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty | undefined);
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsCertificateProperty {
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#file TfVirtualNode#file}
        */
        readonly file?: SpecBackendDefaultsClientPolicyTlsCertificateFileProperty;
        /**
        * sds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#sds TfVirtualNode#sds}
        */
        readonly sds?: SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty;
    }
    class SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsCertificateProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsCertificateProperty | undefined);
        private _file;
        get file(): SpecBackendDefaultsClientPolicyTlsCertificateFilePropertyOutputReference;
        putFile(value: SpecBackendDefaultsClientPolicyTlsCertificateFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecBackendDefaultsClientPolicyTlsCertificateFileProperty | undefined;
        private _sds;
        get sds(): SpecBackendDefaultsClientPolicyTlsCertificateSdsPropertyOutputReference;
        putSds(value: SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty): void;
        resetSds(): void;
        get sdsInput(): SpecBackendDefaultsClientPolicyTlsCertificateSdsProperty | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#exact TfVirtualNode#exact}
        */
        readonly exact: string[];
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined);
        private _exact?;
        get exact(): string[];
        set exact(value: string[]);
        get exactInput(): string[] | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty {
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#match TfVirtualNode#match}
        */
        readonly match: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined);
        private _match;
        get match(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference;
        putMatch(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty): void;
        get matchInput(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_authority_arns TfVirtualNode#certificate_authority_arns}
        */
        readonly certificateAuthorityArns: string[];
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty | undefined);
        private _certificateAuthorityArns?;
        get certificateAuthorityArns(): string[];
        set certificateAuthorityArns(value: string[]);
        get certificateAuthorityArnsInput(): string[] | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_chain TfVirtualNode#certificate_chain}
        */
        readonly certificateChain: string;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty | undefined);
        private _certificateChain?;
        get certificateChain(): string;
        set certificateChain(value: string);
        get certificateChainInput(): string | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#secret_name TfVirtualNode#secret_name}
        */
        readonly secretName: string;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty | undefined);
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationTrustProperty {
        /**
        * acm block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#acm TfVirtualNode#acm}
        */
        readonly acm?: SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty;
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#file TfVirtualNode#file}
        */
        readonly file?: SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty;
        /**
        * sds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#sds TfVirtualNode#sds}
        */
        readonly sds?: SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationTrustProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationTrustProperty | undefined);
        private _acm;
        get acm(): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmPropertyOutputReference;
        putAcm(value: SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty): void;
        resetAcm(): void;
        get acmInput(): SpecBackendDefaultsClientPolicyTlsValidationTrustAcmProperty | undefined;
        private _file;
        get file(): SpecBackendDefaultsClientPolicyTlsValidationTrustFilePropertyOutputReference;
        putFile(value: SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecBackendDefaultsClientPolicyTlsValidationTrustFileProperty | undefined;
        private _sds;
        get sds(): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsPropertyOutputReference;
        putSds(value: SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty): void;
        resetSds(): void;
        get sdsInput(): SpecBackendDefaultsClientPolicyTlsValidationTrustSdsProperty | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsValidationProperty {
        /**
        * subject_alternative_names block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#subject_alternative_names TfVirtualNode#subject_alternative_names}
        */
        readonly subjectAlternativeNames?: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty;
        /**
        * trust block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#trust TfVirtualNode#trust}
        */
        readonly trust: SpecBackendDefaultsClientPolicyTlsValidationTrustProperty;
    }
    class SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsValidationProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsValidationProperty | undefined);
        private _subjectAlternativeNames;
        get subjectAlternativeNames(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesPropertyOutputReference;
        putSubjectAlternativeNames(value: SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty): void;
        resetSubjectAlternativeNames(): void;
        get subjectAlternativeNamesInput(): SpecBackendDefaultsClientPolicyTlsValidationSubjectAlternativeNamesProperty | undefined;
        private _trust;
        get trust(): SpecBackendDefaultsClientPolicyTlsValidationTrustPropertyOutputReference;
        putTrust(value: SpecBackendDefaultsClientPolicyTlsValidationTrustProperty): void;
        get trustInput(): SpecBackendDefaultsClientPolicyTlsValidationTrustProperty | undefined;
    }
    interface SpecBackendDefaultsClientPolicyTlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#enforce TfVirtualNode#enforce}
        */
        readonly enforce?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#ports TfVirtualNode#ports}
        */
        readonly ports?: number[];
        /**
        * certificate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate TfVirtualNode#certificate}
        */
        readonly certificate?: SpecBackendDefaultsClientPolicyTlsCertificateProperty;
        /**
        * validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#validation TfVirtualNode#validation}
        */
        readonly validation: SpecBackendDefaultsClientPolicyTlsValidationProperty;
    }
    class SpecBackendDefaultsClientPolicyTlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyTlsProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyTlsProperty | undefined);
        private _enforce?;
        get enforce(): boolean | cdktn.IResolvable;
        set enforce(value: boolean | cdktn.IResolvable);
        resetEnforce(): void;
        get enforceInput(): boolean | cdktn.IResolvable | undefined;
        private _ports?;
        get ports(): number[];
        set ports(value: number[]);
        resetPorts(): void;
        get portsInput(): number[] | undefined;
        private _certificate;
        get certificate(): SpecBackendDefaultsClientPolicyTlsCertificatePropertyOutputReference;
        putCertificate(value: SpecBackendDefaultsClientPolicyTlsCertificateProperty): void;
        resetCertificate(): void;
        get certificateInput(): SpecBackendDefaultsClientPolicyTlsCertificateProperty | undefined;
        private _validation;
        get validation(): SpecBackendDefaultsClientPolicyTlsValidationPropertyOutputReference;
        putValidation(value: SpecBackendDefaultsClientPolicyTlsValidationProperty): void;
        get validationInput(): SpecBackendDefaultsClientPolicyTlsValidationProperty | undefined;
    }
    interface SpecBackendDefaultsClientPolicyProperty {
        /**
        * tls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#tls TfVirtualNode#tls}
        */
        readonly tls?: SpecBackendDefaultsClientPolicyTlsProperty;
    }
    class SpecBackendDefaultsClientPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecBackendDefaultsClientPolicyProperty | undefined;
        set internalValue(value: SpecBackendDefaultsClientPolicyProperty | undefined);
        private _tls;
        get tls(): SpecBackendDefaultsClientPolicyTlsPropertyOutputReference;
        putTls(value: SpecBackendDefaultsClientPolicyTlsProperty): void;
        resetTls(): void;
        get tlsInput(): SpecBackendDefaultsClientPolicyTlsProperty | undefined;
    }
    interface BackendDefaultsProperty {
        /**
        * client_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#client_policy TfVirtualNode#client_policy}
        */
        readonly clientPolicy?: SpecBackendDefaultsClientPolicyProperty;
    }
    class BackendDefaultsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BackendDefaultsProperty | undefined;
        set internalValue(value: BackendDefaultsProperty | undefined);
        private _clientPolicy;
        get clientPolicy(): SpecBackendDefaultsClientPolicyPropertyOutputReference;
        putClientPolicy(value: SpecBackendDefaultsClientPolicyProperty): void;
        resetClientPolicy(): void;
        get clientPolicyInput(): SpecBackendDefaultsClientPolicyProperty | undefined;
    }
    interface SpecListenerConnectionPoolGrpcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#max_requests TfVirtualNode#max_requests}
        */
        readonly maxRequests: number;
    }
    class SpecListenerConnectionPoolGrpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerConnectionPoolGrpcProperty | undefined;
        set internalValue(value: SpecListenerConnectionPoolGrpcProperty | undefined);
        private _maxRequests?;
        get maxRequests(): number;
        set maxRequests(value: number);
        get maxRequestsInput(): number | undefined;
    }
    interface SpecListenerConnectionPoolHttpProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#max_connections TfVirtualNode#max_connections}
        */
        readonly maxConnections: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#max_pending_requests TfVirtualNode#max_pending_requests}
        */
        readonly maxPendingRequests?: number;
    }
    class SpecListenerConnectionPoolHttpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerConnectionPoolHttpProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecListenerConnectionPoolHttpProperty | cdktn.IResolvable | undefined);
        private _maxConnections?;
        get maxConnections(): number;
        set maxConnections(value: number);
        get maxConnectionsInput(): number | undefined;
        private _maxPendingRequests?;
        get maxPendingRequests(): number;
        set maxPendingRequests(value: number);
        resetMaxPendingRequests(): void;
        get maxPendingRequestsInput(): number | undefined;
    }
    class SpecListenerConnectionPoolHttpPropertyList extends cdktn.ComplexList {
        internalValue?: SpecListenerConnectionPoolHttpProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerConnectionPoolHttpPropertyOutputReference;
    }
    interface SpecListenerConnectionPoolHttp2Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#max_requests TfVirtualNode#max_requests}
        */
        readonly maxRequests: number;
    }
    class SpecListenerConnectionPoolHttp2PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerConnectionPoolHttp2Property | cdktn.IResolvable | undefined;
        set internalValue(value: SpecListenerConnectionPoolHttp2Property | cdktn.IResolvable | undefined);
        private _maxRequests?;
        get maxRequests(): number;
        set maxRequests(value: number);
        get maxRequestsInput(): number | undefined;
    }
    class SpecListenerConnectionPoolHttp2PropertyList extends cdktn.ComplexList {
        internalValue?: SpecListenerConnectionPoolHttp2Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerConnectionPoolHttp2PropertyOutputReference;
    }
    interface SpecListenerConnectionPoolTcpProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#max_connections TfVirtualNode#max_connections}
        */
        readonly maxConnections: number;
    }
    class SpecListenerConnectionPoolTcpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecListenerConnectionPoolTcpProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SpecListenerConnectionPoolTcpProperty | cdktn.IResolvable | undefined);
        private _maxConnections?;
        get maxConnections(): number;
        set maxConnections(value: number);
        get maxConnectionsInput(): number | undefined;
    }
    class SpecListenerConnectionPoolTcpPropertyList extends cdktn.ComplexList {
        internalValue?: SpecListenerConnectionPoolTcpProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecListenerConnectionPoolTcpPropertyOutputReference;
    }
    interface ConnectionPoolProperty {
        /**
        * grpc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#grpc TfVirtualNode#grpc}
        */
        readonly grpc?: SpecListenerConnectionPoolGrpcProperty;
        /**
        * http block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#http TfVirtualNode#http}
        */
        readonly http?: SpecListenerConnectionPoolHttpProperty[] | cdktn.IResolvable;
        /**
        * http2 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#http2 TfVirtualNode#http2}
        */
        readonly http2?: SpecListenerConnectionPoolHttp2Property[] | cdktn.IResolvable;
        /**
        * tcp block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#tcp TfVirtualNode#tcp}
        */
        readonly tcp?: SpecListenerConnectionPoolTcpProperty[] | cdktn.IResolvable;
    }
    class ConnectionPoolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectionPoolProperty | undefined;
        set internalValue(value: ConnectionPoolProperty | undefined);
        private _grpc;
        get grpc(): SpecListenerConnectionPoolGrpcPropertyOutputReference;
        putGrpc(value: SpecListenerConnectionPoolGrpcProperty): void;
        resetGrpc(): void;
        get grpcInput(): SpecListenerConnectionPoolGrpcProperty | undefined;
        private _http;
        get http(): SpecListenerConnectionPoolHttpPropertyList;
        putHttp(value: SpecListenerConnectionPoolHttpProperty[] | cdktn.IResolvable): void;
        resetHttp(): void;
        get httpInput(): cdktn.IResolvable | SpecListenerConnectionPoolHttpProperty[] | undefined;
        private _http2;
        get http2(): SpecListenerConnectionPoolHttp2PropertyList;
        putHttp2(value: SpecListenerConnectionPoolHttp2Property[] | cdktn.IResolvable): void;
        resetHttp2(): void;
        get http2Input(): cdktn.IResolvable | SpecListenerConnectionPoolHttp2Property[] | undefined;
        private _tcp;
        get tcp(): SpecListenerConnectionPoolTcpPropertyList;
        putTcp(value: SpecListenerConnectionPoolTcpProperty[] | cdktn.IResolvable): void;
        resetTcp(): void;
        get tcpInput(): cdktn.IResolvable | SpecListenerConnectionPoolTcpProperty[] | undefined;
    }
    interface HealthCheckProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#healthy_threshold TfVirtualNode#healthy_threshold}
        */
        readonly healthyThreshold: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#interval_millis TfVirtualNode#interval_millis}
        */
        readonly intervalMillis: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#path TfVirtualNode#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#port TfVirtualNode#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#protocol TfVirtualNode#protocol}
        */
        readonly protocol: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#timeout_millis TfVirtualNode#timeout_millis}
        */
        readonly timeoutMillis: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unhealthy_threshold TfVirtualNode#unhealthy_threshold}
        */
        readonly unhealthyThreshold: number;
    }
    class HealthCheckPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HealthCheckProperty | undefined;
        set internalValue(value: HealthCheckProperty | undefined);
        private _healthyThreshold?;
        get healthyThreshold(): number;
        set healthyThreshold(value: number);
        get healthyThresholdInput(): number | undefined;
        private _intervalMillis?;
        get intervalMillis(): number;
        set intervalMillis(value: number);
        get intervalMillisInput(): number | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        get protocolInput(): string | undefined;
        private _timeoutMillis?;
        get timeoutMillis(): number;
        set timeoutMillis(value: number);
        get timeoutMillisInput(): number | undefined;
        private _unhealthyThreshold?;
        get unhealthyThreshold(): number;
        set unhealthyThreshold(value: number);
        get unhealthyThresholdInput(): number | undefined;
    }
    interface BaseEjectionDurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit TfVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value TfVirtualNode#value}
        */
        readonly value: number;
    }
    class BaseEjectionDurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BaseEjectionDurationProperty | undefined;
        set internalValue(value: BaseEjectionDurationProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface IntervalProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit TfVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value TfVirtualNode#value}
        */
        readonly value: number;
    }
    class IntervalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IntervalProperty | undefined;
        set internalValue(value: IntervalProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface OutlierDetectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#max_ejection_percent TfVirtualNode#max_ejection_percent}
        */
        readonly maxEjectionPercent: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#max_server_errors TfVirtualNode#max_server_errors}
        */
        readonly maxServerErrors: number;
        /**
        * base_ejection_duration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#base_ejection_duration TfVirtualNode#base_ejection_duration}
        */
        readonly baseEjectionDuration: BaseEjectionDurationProperty;
        /**
        * interval block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#interval TfVirtualNode#interval}
        */
        readonly interval: IntervalProperty;
    }
    class OutlierDetectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutlierDetectionProperty | undefined;
        set internalValue(value: OutlierDetectionProperty | undefined);
        private _maxEjectionPercent?;
        get maxEjectionPercent(): number;
        set maxEjectionPercent(value: number);
        get maxEjectionPercentInput(): number | undefined;
        private _maxServerErrors?;
        get maxServerErrors(): number;
        set maxServerErrors(value: number);
        get maxServerErrorsInput(): number | undefined;
        private _baseEjectionDuration;
        get baseEjectionDuration(): BaseEjectionDurationPropertyOutputReference;
        putBaseEjectionDuration(value: BaseEjectionDurationProperty): void;
        get baseEjectionDurationInput(): BaseEjectionDurationProperty | undefined;
        private _interval;
        get interval(): IntervalPropertyOutputReference;
        putInterval(value: IntervalProperty): void;
        get intervalInput(): IntervalProperty | undefined;
    }
    interface PortMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#port TfVirtualNode#port}
        */
        readonly port: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#protocol TfVirtualNode#protocol}
        */
        readonly protocol: string;
    }
    class PortMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PortMappingProperty | undefined;
        set internalValue(value: PortMappingProperty | undefined);
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        get protocolInput(): string | undefined;
    }
    interface SpecListenerTimeoutGrpcIdleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit TfVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value TfVirtualNode#value}
        */
        readonly value: number;
    }
    class SpecListenerTimeoutGrpcIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutGrpcIdleProperty | undefined;
        set internalValue(value: SpecListenerTimeoutGrpcIdleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecListenerTimeoutGrpcPerRequestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit TfVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value TfVirtualNode#value}
        */
        readonly value: number;
    }
    class SpecListenerTimeoutGrpcPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutGrpcPerRequestProperty | undefined;
        set internalValue(value: SpecListenerTimeoutGrpcPerRequestProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecListenerTimeoutGrpcProperty {
        /**
        * idle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#idle TfVirtualNode#idle}
        */
        readonly idle?: SpecListenerTimeoutGrpcIdleProperty;
        /**
        * per_request block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#per_request TfVirtualNode#per_request}
        */
        readonly perRequest?: SpecListenerTimeoutGrpcPerRequestProperty;
    }
    class SpecListenerTimeoutGrpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutGrpcProperty | undefined;
        set internalValue(value: SpecListenerTimeoutGrpcProperty | undefined);
        private _idle;
        get idle(): SpecListenerTimeoutGrpcIdlePropertyOutputReference;
        putIdle(value: SpecListenerTimeoutGrpcIdleProperty): void;
        resetIdle(): void;
        get idleInput(): SpecListenerTimeoutGrpcIdleProperty | undefined;
        private _perRequest;
        get perRequest(): SpecListenerTimeoutGrpcPerRequestPropertyOutputReference;
        putPerRequest(value: SpecListenerTimeoutGrpcPerRequestProperty): void;
        resetPerRequest(): void;
        get perRequestInput(): SpecListenerTimeoutGrpcPerRequestProperty | undefined;
    }
    interface SpecListenerTimeoutHttpIdleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit TfVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value TfVirtualNode#value}
        */
        readonly value: number;
    }
    class SpecListenerTimeoutHttpIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutHttpIdleProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttpIdleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecListenerTimeoutHttpPerRequestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit TfVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value TfVirtualNode#value}
        */
        readonly value: number;
    }
    class SpecListenerTimeoutHttpPerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutHttpPerRequestProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttpPerRequestProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecListenerTimeoutHttpProperty {
        /**
        * idle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#idle TfVirtualNode#idle}
        */
        readonly idle?: SpecListenerTimeoutHttpIdleProperty;
        /**
        * per_request block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#per_request TfVirtualNode#per_request}
        */
        readonly perRequest?: SpecListenerTimeoutHttpPerRequestProperty;
    }
    class SpecListenerTimeoutHttpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutHttpProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttpProperty | undefined);
        private _idle;
        get idle(): SpecListenerTimeoutHttpIdlePropertyOutputReference;
        putIdle(value: SpecListenerTimeoutHttpIdleProperty): void;
        resetIdle(): void;
        get idleInput(): SpecListenerTimeoutHttpIdleProperty | undefined;
        private _perRequest;
        get perRequest(): SpecListenerTimeoutHttpPerRequestPropertyOutputReference;
        putPerRequest(value: SpecListenerTimeoutHttpPerRequestProperty): void;
        resetPerRequest(): void;
        get perRequestInput(): SpecListenerTimeoutHttpPerRequestProperty | undefined;
    }
    interface SpecListenerTimeoutHttp2IdleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit TfVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value TfVirtualNode#value}
        */
        readonly value: number;
    }
    class SpecListenerTimeoutHttp2IdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutHttp2IdleProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttp2IdleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecListenerTimeoutHttp2PerRequestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit TfVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value TfVirtualNode#value}
        */
        readonly value: number;
    }
    class SpecListenerTimeoutHttp2PerRequestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutHttp2PerRequestProperty | undefined;
        set internalValue(value: SpecListenerTimeoutHttp2PerRequestProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecListenerTimeoutHttp2Property {
        /**
        * idle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#idle TfVirtualNode#idle}
        */
        readonly idle?: SpecListenerTimeoutHttp2IdleProperty;
        /**
        * per_request block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#per_request TfVirtualNode#per_request}
        */
        readonly perRequest?: SpecListenerTimeoutHttp2PerRequestProperty;
    }
    class SpecListenerTimeoutHttp2PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutHttp2Property | undefined;
        set internalValue(value: SpecListenerTimeoutHttp2Property | undefined);
        private _idle;
        get idle(): SpecListenerTimeoutHttp2IdlePropertyOutputReference;
        putIdle(value: SpecListenerTimeoutHttp2IdleProperty): void;
        resetIdle(): void;
        get idleInput(): SpecListenerTimeoutHttp2IdleProperty | undefined;
        private _perRequest;
        get perRequest(): SpecListenerTimeoutHttp2PerRequestPropertyOutputReference;
        putPerRequest(value: SpecListenerTimeoutHttp2PerRequestProperty): void;
        resetPerRequest(): void;
        get perRequestInput(): SpecListenerTimeoutHttp2PerRequestProperty | undefined;
    }
    interface SpecListenerTimeoutTcpIdleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#unit TfVirtualNode#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value TfVirtualNode#value}
        */
        readonly value: number;
    }
    class SpecListenerTimeoutTcpIdlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutTcpIdleProperty | undefined;
        set internalValue(value: SpecListenerTimeoutTcpIdleProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SpecListenerTimeoutTcpProperty {
        /**
        * idle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#idle TfVirtualNode#idle}
        */
        readonly idle?: SpecListenerTimeoutTcpIdleProperty;
    }
    class SpecListenerTimeoutTcpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTimeoutTcpProperty | undefined;
        set internalValue(value: SpecListenerTimeoutTcpProperty | undefined);
        private _idle;
        get idle(): SpecListenerTimeoutTcpIdlePropertyOutputReference;
        putIdle(value: SpecListenerTimeoutTcpIdleProperty): void;
        resetIdle(): void;
        get idleInput(): SpecListenerTimeoutTcpIdleProperty | undefined;
    }
    interface TimeoutProperty {
        /**
        * grpc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#grpc TfVirtualNode#grpc}
        */
        readonly grpc?: SpecListenerTimeoutGrpcProperty;
        /**
        * http block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#http TfVirtualNode#http}
        */
        readonly http?: SpecListenerTimeoutHttpProperty;
        /**
        * http2 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#http2 TfVirtualNode#http2}
        */
        readonly http2?: SpecListenerTimeoutHttp2Property;
        /**
        * tcp block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#tcp TfVirtualNode#tcp}
        */
        readonly tcp?: SpecListenerTimeoutTcpProperty;
    }
    class TimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutProperty | undefined;
        set internalValue(value: TimeoutProperty | undefined);
        private _grpc;
        get grpc(): SpecListenerTimeoutGrpcPropertyOutputReference;
        putGrpc(value: SpecListenerTimeoutGrpcProperty): void;
        resetGrpc(): void;
        get grpcInput(): SpecListenerTimeoutGrpcProperty | undefined;
        private _http;
        get http(): SpecListenerTimeoutHttpPropertyOutputReference;
        putHttp(value: SpecListenerTimeoutHttpProperty): void;
        resetHttp(): void;
        get httpInput(): SpecListenerTimeoutHttpProperty | undefined;
        private _http2;
        get http2(): SpecListenerTimeoutHttp2PropertyOutputReference;
        putHttp2(value: SpecListenerTimeoutHttp2Property): void;
        resetHttp2(): void;
        get http2Input(): SpecListenerTimeoutHttp2Property | undefined;
        private _tcp;
        get tcp(): SpecListenerTimeoutTcpPropertyOutputReference;
        putTcp(value: SpecListenerTimeoutTcpProperty): void;
        resetTcp(): void;
        get tcpInput(): SpecListenerTimeoutTcpProperty | undefined;
    }
    interface SpecListenerTlsCertificateAcmProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_arn TfVirtualNode#certificate_arn}
        */
        readonly certificateArn: string;
    }
    class SpecListenerTlsCertificateAcmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsCertificateAcmProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateAcmProperty | undefined);
        private _certificateArn?;
        get certificateArn(): string;
        set certificateArn(value: string);
        get certificateArnInput(): string | undefined;
    }
    interface SpecListenerTlsCertificateFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_chain TfVirtualNode#certificate_chain}
        */
        readonly certificateChain: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#private_key TfVirtualNode#private_key}
        */
        readonly privateKey: string;
    }
    class SpecListenerTlsCertificateFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsCertificateFileProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateFileProperty | undefined);
        private _certificateChain?;
        get certificateChain(): string;
        set certificateChain(value: string);
        get certificateChainInput(): string | undefined;
        private _privateKey?;
        get privateKey(): string;
        set privateKey(value: string);
        get privateKeyInput(): string | undefined;
    }
    interface SpecListenerTlsCertificateSdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#secret_name TfVirtualNode#secret_name}
        */
        readonly secretName: string;
    }
    class SpecListenerTlsCertificateSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsCertificateSdsProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateSdsProperty | undefined);
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface SpecListenerTlsCertificateProperty {
        /**
        * acm block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#acm TfVirtualNode#acm}
        */
        readonly acm?: SpecListenerTlsCertificateAcmProperty;
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#file TfVirtualNode#file}
        */
        readonly file?: SpecListenerTlsCertificateFileProperty;
        /**
        * sds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#sds TfVirtualNode#sds}
        */
        readonly sds?: SpecListenerTlsCertificateSdsProperty;
    }
    class SpecListenerTlsCertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsCertificateProperty | undefined;
        set internalValue(value: SpecListenerTlsCertificateProperty | undefined);
        private _acm;
        get acm(): SpecListenerTlsCertificateAcmPropertyOutputReference;
        putAcm(value: SpecListenerTlsCertificateAcmProperty): void;
        resetAcm(): void;
        get acmInput(): SpecListenerTlsCertificateAcmProperty | undefined;
        private _file;
        get file(): SpecListenerTlsCertificateFilePropertyOutputReference;
        putFile(value: SpecListenerTlsCertificateFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecListenerTlsCertificateFileProperty | undefined;
        private _sds;
        get sds(): SpecListenerTlsCertificateSdsPropertyOutputReference;
        putSds(value: SpecListenerTlsCertificateSdsProperty): void;
        resetSds(): void;
        get sdsInput(): SpecListenerTlsCertificateSdsProperty | undefined;
    }
    interface SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#exact TfVirtualNode#exact}
        */
        readonly exact: string[];
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty | undefined);
        private _exact?;
        get exact(): string[];
        set exact(value: string[]);
        get exactInput(): string[] | undefined;
    }
    interface SpecListenerTlsValidationSubjectAlternativeNamesProperty {
        /**
        * match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#match TfVirtualNode#match}
        */
        readonly match: SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty;
    }
    class SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationSubjectAlternativeNamesProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationSubjectAlternativeNamesProperty | undefined);
        private _match;
        get match(): SpecListenerTlsValidationSubjectAlternativeNamesMatchPropertyOutputReference;
        putMatch(value: SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty): void;
        get matchInput(): SpecListenerTlsValidationSubjectAlternativeNamesMatchProperty | undefined;
    }
    interface SpecListenerTlsValidationTrustFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate_chain TfVirtualNode#certificate_chain}
        */
        readonly certificateChain: string;
    }
    class SpecListenerTlsValidationTrustFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationTrustFileProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustFileProperty | undefined);
        private _certificateChain?;
        get certificateChain(): string;
        set certificateChain(value: string);
        get certificateChainInput(): string | undefined;
    }
    interface SpecListenerTlsValidationTrustSdsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#secret_name TfVirtualNode#secret_name}
        */
        readonly secretName: string;
    }
    class SpecListenerTlsValidationTrustSdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationTrustSdsProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustSdsProperty | undefined);
        private _secretName?;
        get secretName(): string;
        set secretName(value: string);
        get secretNameInput(): string | undefined;
    }
    interface SpecListenerTlsValidationTrustProperty {
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#file TfVirtualNode#file}
        */
        readonly file?: SpecListenerTlsValidationTrustFileProperty;
        /**
        * sds block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#sds TfVirtualNode#sds}
        */
        readonly sds?: SpecListenerTlsValidationTrustSdsProperty;
    }
    class SpecListenerTlsValidationTrustPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationTrustProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationTrustProperty | undefined);
        private _file;
        get file(): SpecListenerTlsValidationTrustFilePropertyOutputReference;
        putFile(value: SpecListenerTlsValidationTrustFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecListenerTlsValidationTrustFileProperty | undefined;
        private _sds;
        get sds(): SpecListenerTlsValidationTrustSdsPropertyOutputReference;
        putSds(value: SpecListenerTlsValidationTrustSdsProperty): void;
        resetSds(): void;
        get sdsInput(): SpecListenerTlsValidationTrustSdsProperty | undefined;
    }
    interface SpecListenerTlsValidationProperty {
        /**
        * subject_alternative_names block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#subject_alternative_names TfVirtualNode#subject_alternative_names}
        */
        readonly subjectAlternativeNames?: SpecListenerTlsValidationSubjectAlternativeNamesProperty;
        /**
        * trust block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#trust TfVirtualNode#trust}
        */
        readonly trust: SpecListenerTlsValidationTrustProperty;
    }
    class SpecListenerTlsValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsValidationProperty | undefined;
        set internalValue(value: SpecListenerTlsValidationProperty | undefined);
        private _subjectAlternativeNames;
        get subjectAlternativeNames(): SpecListenerTlsValidationSubjectAlternativeNamesPropertyOutputReference;
        putSubjectAlternativeNames(value: SpecListenerTlsValidationSubjectAlternativeNamesProperty): void;
        resetSubjectAlternativeNames(): void;
        get subjectAlternativeNamesInput(): SpecListenerTlsValidationSubjectAlternativeNamesProperty | undefined;
        private _trust;
        get trust(): SpecListenerTlsValidationTrustPropertyOutputReference;
        putTrust(value: SpecListenerTlsValidationTrustProperty): void;
        get trustInput(): SpecListenerTlsValidationTrustProperty | undefined;
    }
    interface SpecListenerTlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#mode TfVirtualNode#mode}
        */
        readonly mode: string;
        /**
        * certificate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#certificate TfVirtualNode#certificate}
        */
        readonly certificate: SpecListenerTlsCertificateProperty;
        /**
        * validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#validation TfVirtualNode#validation}
        */
        readonly validation?: SpecListenerTlsValidationProperty;
    }
    class SpecListenerTlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecListenerTlsProperty | undefined;
        set internalValue(value: SpecListenerTlsProperty | undefined);
        private _mode?;
        get mode(): string;
        set mode(value: string);
        get modeInput(): string | undefined;
        private _certificate;
        get certificate(): SpecListenerTlsCertificatePropertyOutputReference;
        putCertificate(value: SpecListenerTlsCertificateProperty): void;
        get certificateInput(): SpecListenerTlsCertificateProperty | undefined;
        private _validation;
        get validation(): SpecListenerTlsValidationPropertyOutputReference;
        putValidation(value: SpecListenerTlsValidationProperty): void;
        resetValidation(): void;
        get validationInput(): SpecListenerTlsValidationProperty | undefined;
    }
    interface ListenerProperty {
        /**
        * connection_pool block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#connection_pool TfVirtualNode#connection_pool}
        */
        readonly connectionPool?: ConnectionPoolProperty;
        /**
        * health_check block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#health_check TfVirtualNode#health_check}
        */
        readonly healthCheck?: HealthCheckProperty;
        /**
        * outlier_detection block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#outlier_detection TfVirtualNode#outlier_detection}
        */
        readonly outlierDetection?: OutlierDetectionProperty;
        /**
        * port_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#port_mapping TfVirtualNode#port_mapping}
        */
        readonly portMapping: PortMappingProperty;
        /**
        * timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#timeout TfVirtualNode#timeout}
        */
        readonly timeout?: TimeoutProperty;
        /**
        * tls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#tls TfVirtualNode#tls}
        */
        readonly tls?: SpecListenerTlsProperty;
    }
    class ListenerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ListenerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ListenerProperty | cdktn.IResolvable | undefined);
        private _connectionPool;
        get connectionPool(): ConnectionPoolPropertyOutputReference;
        putConnectionPool(value: ConnectionPoolProperty): void;
        resetConnectionPool(): void;
        get connectionPoolInput(): ConnectionPoolProperty | undefined;
        private _healthCheck;
        get healthCheck(): HealthCheckPropertyOutputReference;
        putHealthCheck(value: HealthCheckProperty): void;
        resetHealthCheck(): void;
        get healthCheckInput(): HealthCheckProperty | undefined;
        private _outlierDetection;
        get outlierDetection(): OutlierDetectionPropertyOutputReference;
        putOutlierDetection(value: OutlierDetectionProperty): void;
        resetOutlierDetection(): void;
        get outlierDetectionInput(): OutlierDetectionProperty | undefined;
        private _portMapping;
        get portMapping(): PortMappingPropertyOutputReference;
        putPortMapping(value: PortMappingProperty): void;
        get portMappingInput(): PortMappingProperty | undefined;
        private _timeout;
        get timeout(): TimeoutPropertyOutputReference;
        putTimeout(value: TimeoutProperty): void;
        resetTimeout(): void;
        get timeoutInput(): TimeoutProperty | undefined;
        private _tls;
        get tls(): SpecListenerTlsPropertyOutputReference;
        putTls(value: SpecListenerTlsProperty): void;
        resetTls(): void;
        get tlsInput(): SpecListenerTlsProperty | undefined;
    }
    class ListenerPropertyList extends cdktn.ComplexList {
        internalValue?: ListenerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ListenerPropertyOutputReference;
    }
    interface JsonProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#key TfVirtualNode#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#value TfVirtualNode#value}
        */
        readonly value: string;
    }
    class JsonPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JsonProperty | cdktn.IResolvable | undefined;
        set internalValue(value: JsonProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class JsonPropertyList extends cdktn.ComplexList {
        internalValue?: JsonProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JsonPropertyOutputReference;
    }
    interface FormatProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#text TfVirtualNode#text}
        */
        readonly text?: string;
        /**
        * json block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#json TfVirtualNode#json}
        */
        readonly json?: JsonProperty[] | cdktn.IResolvable;
    }
    class FormatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FormatProperty | undefined;
        set internalValue(value: FormatProperty | undefined);
        private _text?;
        get text(): string;
        set text(value: string);
        resetText(): void;
        get textInput(): string | undefined;
        private _json;
        get json(): JsonPropertyList;
        putJson(value: JsonProperty[] | cdktn.IResolvable): void;
        resetJson(): void;
        get jsonInput(): cdktn.IResolvable | JsonProperty[] | undefined;
    }
    interface SpecLoggingAccessLogFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#path TfVirtualNode#path}
        */
        readonly path: string;
        /**
        * format block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#format TfVirtualNode#format}
        */
        readonly format?: FormatProperty;
    }
    class SpecLoggingAccessLogFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecLoggingAccessLogFileProperty | undefined;
        set internalValue(value: SpecLoggingAccessLogFileProperty | undefined);
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
        private _format;
        get format(): FormatPropertyOutputReference;
        putFormat(value: FormatProperty): void;
        resetFormat(): void;
        get formatInput(): FormatProperty | undefined;
    }
    interface AccessLogProperty {
        /**
        * file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#file TfVirtualNode#file}
        */
        readonly file?: SpecLoggingAccessLogFileProperty;
    }
    class AccessLogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessLogProperty | undefined;
        set internalValue(value: AccessLogProperty | undefined);
        private _file;
        get file(): SpecLoggingAccessLogFilePropertyOutputReference;
        putFile(value: SpecLoggingAccessLogFileProperty): void;
        resetFile(): void;
        get fileInput(): SpecLoggingAccessLogFileProperty | undefined;
    }
    interface LoggingProperty {
        /**
        * access_log block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#access_log TfVirtualNode#access_log}
        */
        readonly accessLog?: AccessLogProperty;
    }
    class LoggingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingProperty | undefined;
        set internalValue(value: LoggingProperty | undefined);
        private _accessLog;
        get accessLog(): AccessLogPropertyOutputReference;
        putAccessLog(value: AccessLogProperty): void;
        resetAccessLog(): void;
        get accessLogInput(): AccessLogProperty | undefined;
    }
    interface AwsCloudMapProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#attributes TfVirtualNode#attributes}
        */
        readonly attributes?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#namespace_name TfVirtualNode#namespace_name}
        */
        readonly namespaceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#service_name TfVirtualNode#service_name}
        */
        readonly serviceName: string;
    }
    class AwsCloudMapPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AwsCloudMapProperty | undefined;
        set internalValue(value: AwsCloudMapProperty | undefined);
        private _attributes?;
        get attributes(): {
            [key: string]: string;
        };
        set attributes(value: {
            [key: string]: string;
        });
        resetAttributes(): void;
        get attributesInput(): {
            [key: string]: string;
        } | undefined;
        private _namespaceName?;
        get namespaceName(): string;
        set namespaceName(value: string);
        get namespaceNameInput(): string | undefined;
        private _serviceName?;
        get serviceName(): string;
        set serviceName(value: string);
        get serviceNameInput(): string | undefined;
    }
    interface DnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#hostname TfVirtualNode#hostname}
        */
        readonly hostname: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#ip_preference TfVirtualNode#ip_preference}
        */
        readonly ipPreference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#response_type TfVirtualNode#response_type}
        */
        readonly responseType?: string;
    }
    class DnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DnsProperty | undefined;
        set internalValue(value: DnsProperty | undefined);
        private _hostname?;
        get hostname(): string;
        set hostname(value: string);
        get hostnameInput(): string | undefined;
        private _ipPreference?;
        get ipPreference(): string;
        set ipPreference(value: string);
        resetIpPreference(): void;
        get ipPreferenceInput(): string | undefined;
        private _responseType?;
        get responseType(): string;
        set responseType(value: string);
        resetResponseType(): void;
        get responseTypeInput(): string | undefined;
    }
    interface ServiceDiscoveryProperty {
        /**
        * aws_cloud_map block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#aws_cloud_map TfVirtualNode#aws_cloud_map}
        */
        readonly awsCloudMap?: AwsCloudMapProperty;
        /**
        * dns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#dns TfVirtualNode#dns}
        */
        readonly dns?: DnsProperty;
    }
    class ServiceDiscoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceDiscoveryProperty | undefined;
        set internalValue(value: ServiceDiscoveryProperty | undefined);
        private _awsCloudMap;
        get awsCloudMap(): AwsCloudMapPropertyOutputReference;
        putAwsCloudMap(value: AwsCloudMapProperty): void;
        resetAwsCloudMap(): void;
        get awsCloudMapInput(): AwsCloudMapProperty | undefined;
        private _dns;
        get dns(): DnsPropertyOutputReference;
        putDns(value: DnsProperty): void;
        resetDns(): void;
        get dnsInput(): DnsProperty | undefined;
    }
    interface SpecProperty {
        /**
        * backend block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#backend TfVirtualNode#backend}
        */
        readonly backend?: BackendProperty[] | cdktn.IResolvable;
        /**
        * backend_defaults block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#backend_defaults TfVirtualNode#backend_defaults}
        */
        readonly backendDefaults?: BackendDefaultsProperty;
        /**
        * listener block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#listener TfVirtualNode#listener}
        */
        readonly listener?: ListenerProperty[] | cdktn.IResolvable;
        /**
        * logging block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#logging TfVirtualNode#logging}
        */
        readonly logging?: LoggingProperty;
        /**
        * service_discovery block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appmesh_virtual_node#service_discovery TfVirtualNode#service_discovery}
        */
        readonly serviceDiscovery?: ServiceDiscoveryProperty;
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _backend;
        get backend(): BackendPropertyList;
        putBackend(value: BackendProperty[] | cdktn.IResolvable): void;
        resetBackend(): void;
        get backendInput(): cdktn.IResolvable | BackendProperty[] | undefined;
        private _backendDefaults;
        get backendDefaults(): BackendDefaultsPropertyOutputReference;
        putBackendDefaults(value: BackendDefaultsProperty): void;
        resetBackendDefaults(): void;
        get backendDefaultsInput(): BackendDefaultsProperty | undefined;
        private _listener;
        get listener(): ListenerPropertyList;
        putListener(value: ListenerProperty[] | cdktn.IResolvable): void;
        resetListener(): void;
        get listenerInput(): cdktn.IResolvable | ListenerProperty[] | undefined;
        private _logging;
        get logging(): LoggingPropertyOutputReference;
        putLogging(value: LoggingProperty): void;
        resetLogging(): void;
        get loggingInput(): LoggingProperty | undefined;
        private _serviceDiscovery;
        get serviceDiscovery(): ServiceDiscoveryPropertyOutputReference;
        putServiceDiscovery(value: ServiceDiscoveryProperty): void;
        resetServiceDiscovery(): void;
        get serviceDiscoveryInput(): ServiceDiscoveryProperty | undefined;
    }
}
