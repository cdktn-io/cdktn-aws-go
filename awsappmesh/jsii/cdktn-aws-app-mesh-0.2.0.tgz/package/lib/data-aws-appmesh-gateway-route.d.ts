import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfGatewayRouteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route#id DataTfGatewayRoute#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route#mesh_name DataTfGatewayRoute#mesh_name}
    */
    readonly meshName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route#mesh_owner DataTfGatewayRoute#mesh_owner}
    */
    readonly meshOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route#name DataTfGatewayRoute#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route#region DataTfGatewayRoute#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route#tags DataTfGatewayRoute#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route#virtual_gateway_name DataTfGatewayRoute#virtual_gateway_name}
    */
    readonly virtualGatewayName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route aws_appmesh_gateway_route}
*/
export declare class DataTfGatewayRoute extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_appmesh_gateway_route";
    /**
    * Generates CDKTN code for importing a DataTfGatewayRoute resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfGatewayRoute to import
    * @param importFromId The id of the existing DataTfGatewayRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfGatewayRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/appmesh_gateway_route aws_appmesh_gateway_route} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfGatewayRouteConfig
    */
    constructor(scope: Construct, id: string, config: DataTfGatewayRouteConfig);
    get arn(): string;
    get createdDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _meshName?;
    get meshName(): string;
    set meshName(value: string);
    get meshNameInput(): string | undefined;
    private _meshOwner?;
    get meshOwner(): string;
    set meshOwner(value: string);
    resetMeshOwner(): void;
    get meshOwnerInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceOwner(): string;
    private _spec;
    get spec(): DataTfGatewayRoute.SpecPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _virtualGatewayName?;
    get virtualGatewayName(): string;
    set virtualGatewayName(value: string);
    get virtualGatewayNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfGatewayRouteSpecGrpcRouteActionTargetVirtualServicePropertyToTerraform(struct?: DataTfGatewayRoute.SpecGrpcRouteActionTargetVirtualServiceProperty): any;
export declare function dataTfGatewayRouteSpecGrpcRouteActionTargetVirtualServicePropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecGrpcRouteActionTargetVirtualServiceProperty): any;
export declare function dataTfGatewayRouteSpecGrpcRouteActionTargetPropertyToTerraform(struct?: DataTfGatewayRoute.SpecGrpcRouteActionTargetProperty): any;
export declare function dataTfGatewayRouteSpecGrpcRouteActionTargetPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecGrpcRouteActionTargetProperty): any;
export declare function dataTfGatewayRouteSpecGrpcRouteActionPropertyToTerraform(struct?: DataTfGatewayRoute.SpecGrpcRouteActionProperty): any;
export declare function dataTfGatewayRouteSpecGrpcRouteActionPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecGrpcRouteActionProperty): any;
export declare function dataTfGatewayRouteSpecGrpcRouteMatchPropertyToTerraform(struct?: DataTfGatewayRoute.SpecGrpcRouteMatchProperty): any;
export declare function dataTfGatewayRouteSpecGrpcRouteMatchPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecGrpcRouteMatchProperty): any;
export declare function dataTfGatewayRouteGrpcRoutePropertyToTerraform(struct?: DataTfGatewayRoute.GrpcRouteProperty): any;
export declare function dataTfGatewayRouteGrpcRoutePropertyToHclTerraform(struct?: DataTfGatewayRoute.GrpcRouteProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteActionRewriteHostnamePropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteActionRewriteHostnameProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteActionRewriteHostnamePropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteActionRewriteHostnameProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteActionRewritePathPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteActionRewritePathProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteActionRewritePathPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteActionRewritePathProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteActionRewritePrefixPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteActionRewritePrefixProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteActionRewritePrefixPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteActionRewritePrefixProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteActionRewritePropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteActionRewriteProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteActionRewritePropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteActionRewriteProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteActionTargetVirtualServicePropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteActionTargetVirtualServiceProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteActionTargetVirtualServicePropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteActionTargetVirtualServiceProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteActionTargetPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteActionTargetProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteActionTargetPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteActionTargetProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteActionPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteActionProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteActionPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteActionProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteMatchHeaderMatchRangePropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteMatchHeaderMatchRangeProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteMatchHeaderMatchRangePropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteMatchHeaderMatchRangeProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteMatchHeaderMatchPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteMatchHeaderMatchProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteMatchHeaderMatchPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteMatchHeaderMatchProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteMatchHeaderPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteMatchHeaderProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteMatchHeaderPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteMatchHeaderProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteMatchHostnamePropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteMatchHostnameProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteMatchHostnamePropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteMatchHostnameProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteMatchPathPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteMatchPathProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteMatchPathPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteMatchPathProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteMatchQueryParameterMatchPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteMatchQueryParameterMatchProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteMatchQueryParameterMatchPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteMatchQueryParameterMatchProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteMatchQueryParameterPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteMatchQueryParameterProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteMatchQueryParameterPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteMatchQueryParameterProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteMatchPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteMatchProperty): any;
export declare function dataTfGatewayRouteSpecHttp2RouteMatchPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttp2RouteMatchProperty): any;
export declare function dataTfGatewayRouteHttp2RoutePropertyToTerraform(struct?: DataTfGatewayRoute.Http2RouteProperty): any;
export declare function dataTfGatewayRouteHttp2RoutePropertyToHclTerraform(struct?: DataTfGatewayRoute.Http2RouteProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteActionRewriteHostnamePropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteActionRewriteHostnameProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteActionRewriteHostnamePropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteActionRewriteHostnameProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteActionRewritePathPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteActionRewritePathProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteActionRewritePathPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteActionRewritePathProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteActionRewritePrefixPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteActionRewritePrefixProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteActionRewritePrefixPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteActionRewritePrefixProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteActionRewritePropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteActionRewriteProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteActionRewritePropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteActionRewriteProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteActionTargetVirtualServicePropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteActionTargetVirtualServiceProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteActionTargetVirtualServicePropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteActionTargetVirtualServiceProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteActionTargetPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteActionTargetProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteActionTargetPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteActionTargetProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteActionPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteActionProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteActionPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteActionProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteMatchHeaderMatchRangePropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteMatchHeaderMatchRangeProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteMatchHeaderMatchRangePropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteMatchHeaderMatchRangeProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteMatchHeaderMatchPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteMatchHeaderMatchProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteMatchHeaderMatchPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteMatchHeaderMatchProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteMatchHeaderPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteMatchHeaderProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteMatchHeaderPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteMatchHeaderProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteMatchHostnamePropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteMatchHostnameProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteMatchHostnamePropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteMatchHostnameProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteMatchPathPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteMatchPathProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteMatchPathPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteMatchPathProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteMatchQueryParameterMatchPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteMatchQueryParameterMatchProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteMatchQueryParameterMatchPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteMatchQueryParameterMatchProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteMatchQueryParameterPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteMatchQueryParameterProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteMatchQueryParameterPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteMatchQueryParameterProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteMatchPropertyToTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteMatchProperty): any;
export declare function dataTfGatewayRouteSpecHttpRouteMatchPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecHttpRouteMatchProperty): any;
export declare function dataTfGatewayRouteHttpRoutePropertyToTerraform(struct?: DataTfGatewayRoute.HttpRouteProperty): any;
export declare function dataTfGatewayRouteHttpRoutePropertyToHclTerraform(struct?: DataTfGatewayRoute.HttpRouteProperty): any;
export declare function dataTfGatewayRouteSpecPropertyToTerraform(struct?: DataTfGatewayRoute.SpecProperty): any;
export declare function dataTfGatewayRouteSpecPropertyToHclTerraform(struct?: DataTfGatewayRoute.SpecProperty): any;
export declare namespace DataTfGatewayRoute {
    interface SpecGrpcRouteActionTargetVirtualServiceProperty {
    }
    class SpecGrpcRouteActionTargetVirtualServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteActionTargetVirtualServiceProperty | undefined;
        set internalValue(value: SpecGrpcRouteActionTargetVirtualServiceProperty | undefined);
        get virtualServiceName(): string;
    }
    class SpecGrpcRouteActionTargetVirtualServicePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteActionTargetVirtualServicePropertyOutputReference;
    }
    interface SpecGrpcRouteActionTargetProperty {
    }
    class SpecGrpcRouteActionTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteActionTargetProperty | undefined;
        set internalValue(value: SpecGrpcRouteActionTargetProperty | undefined);
        get port(): number;
        private _virtualService;
        get virtualService(): SpecGrpcRouteActionTargetVirtualServicePropertyList;
    }
    class SpecGrpcRouteActionTargetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteActionTargetPropertyOutputReference;
    }
    interface SpecGrpcRouteActionProperty {
    }
    class SpecGrpcRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteActionProperty | undefined;
        set internalValue(value: SpecGrpcRouteActionProperty | undefined);
        private _target;
        get target(): SpecGrpcRouteActionTargetPropertyList;
    }
    class SpecGrpcRouteActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteActionPropertyOutputReference;
    }
    interface SpecGrpcRouteMatchProperty {
    }
    class SpecGrpcRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecGrpcRouteMatchProperty | undefined;
        set internalValue(value: SpecGrpcRouteMatchProperty | undefined);
        get port(): number;
        get serviceName(): string;
    }
    class SpecGrpcRouteMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecGrpcRouteMatchPropertyOutputReference;
    }
    interface GrpcRouteProperty {
    }
    class GrpcRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GrpcRouteProperty | undefined;
        set internalValue(value: GrpcRouteProperty | undefined);
        private _action;
        get action(): SpecGrpcRouteActionPropertyList;
        private _match;
        get match(): SpecGrpcRouteMatchPropertyList;
    }
    class GrpcRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GrpcRoutePropertyOutputReference;
    }
    interface SpecHttp2RouteActionRewriteHostnameProperty {
    }
    class SpecHttp2RouteActionRewriteHostnamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionRewriteHostnameProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionRewriteHostnameProperty | undefined);
        get defaultTargetHostname(): string;
    }
    class SpecHttp2RouteActionRewriteHostnamePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionRewriteHostnamePropertyOutputReference;
    }
    interface SpecHttp2RouteActionRewritePathProperty {
    }
    class SpecHttp2RouteActionRewritePathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionRewritePathProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionRewritePathProperty | undefined);
        get exact(): string;
    }
    class SpecHttp2RouteActionRewritePathPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionRewritePathPropertyOutputReference;
    }
    interface SpecHttp2RouteActionRewritePrefixProperty {
    }
    class SpecHttp2RouteActionRewritePrefixPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionRewritePrefixProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionRewritePrefixProperty | undefined);
        get defaultPrefix(): string;
        get value(): string;
    }
    class SpecHttp2RouteActionRewritePrefixPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionRewritePrefixPropertyOutputReference;
    }
    interface SpecHttp2RouteActionRewriteProperty {
    }
    class SpecHttp2RouteActionRewritePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionRewriteProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionRewriteProperty | undefined);
        private _hostname;
        get hostname(): SpecHttp2RouteActionRewriteHostnamePropertyList;
        private _path;
        get path(): SpecHttp2RouteActionRewritePathPropertyList;
        private _prefix;
        get prefix(): SpecHttp2RouteActionRewritePrefixPropertyList;
    }
    class SpecHttp2RouteActionRewritePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionRewritePropertyOutputReference;
    }
    interface SpecHttp2RouteActionTargetVirtualServiceProperty {
    }
    class SpecHttp2RouteActionTargetVirtualServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionTargetVirtualServiceProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionTargetVirtualServiceProperty | undefined);
        get virtualServiceName(): string;
    }
    class SpecHttp2RouteActionTargetVirtualServicePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionTargetVirtualServicePropertyOutputReference;
    }
    interface SpecHttp2RouteActionTargetProperty {
    }
    class SpecHttp2RouteActionTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionTargetProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionTargetProperty | undefined);
        get port(): number;
        private _virtualService;
        get virtualService(): SpecHttp2RouteActionTargetVirtualServicePropertyList;
    }
    class SpecHttp2RouteActionTargetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionTargetPropertyOutputReference;
    }
    interface SpecHttp2RouteActionProperty {
    }
    class SpecHttp2RouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteActionProperty | undefined;
        set internalValue(value: SpecHttp2RouteActionProperty | undefined);
        private _rewrite;
        get rewrite(): SpecHttp2RouteActionRewritePropertyList;
        private _target;
        get target(): SpecHttp2RouteActionTargetPropertyList;
    }
    class SpecHttp2RouteActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteActionPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchHeaderMatchRangeProperty {
    }
    class SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderMatchRangeProperty | undefined);
        get end(): number;
        get start(): number;
    }
    class SpecHttp2RouteMatchHeaderMatchRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchHeaderMatchRangePropertyOutputReference;
    }
    interface SpecHttp2RouteMatchHeaderMatchProperty {
    }
    class SpecHttp2RouteMatchHeaderMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchHeaderMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderMatchProperty | undefined);
        get exact(): string;
        get prefix(): string;
        private _range;
        get range(): SpecHttp2RouteMatchHeaderMatchRangePropertyList;
        get regex(): string;
        get suffix(): string;
    }
    class SpecHttp2RouteMatchHeaderMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchHeaderMatchPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchHeaderProperty {
    }
    class SpecHttp2RouteMatchHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchHeaderProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHeaderProperty | undefined);
        get invert(): cdktn.IResolvable;
        private _match;
        get match(): SpecHttp2RouteMatchHeaderMatchPropertyList;
        get name(): string;
    }
    class SpecHttp2RouteMatchHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchHeaderPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchHostnameProperty {
    }
    class SpecHttp2RouteMatchHostnamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchHostnameProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchHostnameProperty | undefined);
        get exact(): string;
        get suffix(): string;
    }
    class SpecHttp2RouteMatchHostnamePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchHostnamePropertyOutputReference;
    }
    interface SpecHttp2RouteMatchPathProperty {
    }
    class SpecHttp2RouteMatchPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchPathProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchPathProperty | undefined);
        get exact(): string;
        get regex(): string;
    }
    class SpecHttp2RouteMatchPathPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchPathPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchQueryParameterMatchProperty {
    }
    class SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchQueryParameterMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchQueryParameterMatchProperty | undefined);
        get exact(): string;
    }
    class SpecHttp2RouteMatchQueryParameterMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchQueryParameterMatchPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchQueryParameterProperty {
    }
    class SpecHttp2RouteMatchQueryParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchQueryParameterProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchQueryParameterProperty | undefined);
        private _match;
        get match(): SpecHttp2RouteMatchQueryParameterMatchPropertyList;
        get name(): string;
    }
    class SpecHttp2RouteMatchQueryParameterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchQueryParameterPropertyOutputReference;
    }
    interface SpecHttp2RouteMatchProperty {
    }
    class SpecHttp2RouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttp2RouteMatchProperty | undefined;
        set internalValue(value: SpecHttp2RouteMatchProperty | undefined);
        private _header;
        get header(): SpecHttp2RouteMatchHeaderPropertyList;
        private _hostname;
        get hostname(): SpecHttp2RouteMatchHostnamePropertyList;
        private _path;
        get path(): SpecHttp2RouteMatchPathPropertyList;
        get port(): number;
        get prefix(): string;
        private _queryParameter;
        get queryParameter(): SpecHttp2RouteMatchQueryParameterPropertyList;
    }
    class SpecHttp2RouteMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttp2RouteMatchPropertyOutputReference;
    }
    interface Http2RouteProperty {
    }
    class Http2RoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Http2RouteProperty | undefined;
        set internalValue(value: Http2RouteProperty | undefined);
        private _action;
        get action(): SpecHttp2RouteActionPropertyList;
        private _match;
        get match(): SpecHttp2RouteMatchPropertyList;
    }
    class Http2RoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Http2RoutePropertyOutputReference;
    }
    interface SpecHttpRouteActionRewriteHostnameProperty {
    }
    class SpecHttpRouteActionRewriteHostnamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionRewriteHostnameProperty | undefined;
        set internalValue(value: SpecHttpRouteActionRewriteHostnameProperty | undefined);
        get defaultTargetHostname(): string;
    }
    class SpecHttpRouteActionRewriteHostnamePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionRewriteHostnamePropertyOutputReference;
    }
    interface SpecHttpRouteActionRewritePathProperty {
    }
    class SpecHttpRouteActionRewritePathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionRewritePathProperty | undefined;
        set internalValue(value: SpecHttpRouteActionRewritePathProperty | undefined);
        get exact(): string;
    }
    class SpecHttpRouteActionRewritePathPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionRewritePathPropertyOutputReference;
    }
    interface SpecHttpRouteActionRewritePrefixProperty {
    }
    class SpecHttpRouteActionRewritePrefixPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionRewritePrefixProperty | undefined;
        set internalValue(value: SpecHttpRouteActionRewritePrefixProperty | undefined);
        get defaultPrefix(): string;
        get value(): string;
    }
    class SpecHttpRouteActionRewritePrefixPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionRewritePrefixPropertyOutputReference;
    }
    interface SpecHttpRouteActionRewriteProperty {
    }
    class SpecHttpRouteActionRewritePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionRewriteProperty | undefined;
        set internalValue(value: SpecHttpRouteActionRewriteProperty | undefined);
        private _hostname;
        get hostname(): SpecHttpRouteActionRewriteHostnamePropertyList;
        private _path;
        get path(): SpecHttpRouteActionRewritePathPropertyList;
        private _prefix;
        get prefix(): SpecHttpRouteActionRewritePrefixPropertyList;
    }
    class SpecHttpRouteActionRewritePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionRewritePropertyOutputReference;
    }
    interface SpecHttpRouteActionTargetVirtualServiceProperty {
    }
    class SpecHttpRouteActionTargetVirtualServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionTargetVirtualServiceProperty | undefined;
        set internalValue(value: SpecHttpRouteActionTargetVirtualServiceProperty | undefined);
        get virtualServiceName(): string;
    }
    class SpecHttpRouteActionTargetVirtualServicePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionTargetVirtualServicePropertyOutputReference;
    }
    interface SpecHttpRouteActionTargetProperty {
    }
    class SpecHttpRouteActionTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionTargetProperty | undefined;
        set internalValue(value: SpecHttpRouteActionTargetProperty | undefined);
        get port(): number;
        private _virtualService;
        get virtualService(): SpecHttpRouteActionTargetVirtualServicePropertyList;
    }
    class SpecHttpRouteActionTargetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionTargetPropertyOutputReference;
    }
    interface SpecHttpRouteActionProperty {
    }
    class SpecHttpRouteActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteActionProperty | undefined;
        set internalValue(value: SpecHttpRouteActionProperty | undefined);
        private _rewrite;
        get rewrite(): SpecHttpRouteActionRewritePropertyList;
        private _target;
        get target(): SpecHttpRouteActionTargetPropertyList;
    }
    class SpecHttpRouteActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteActionPropertyOutputReference;
    }
    interface SpecHttpRouteMatchHeaderMatchRangeProperty {
    }
    class SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchHeaderMatchRangeProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderMatchRangeProperty | undefined);
        get end(): number;
        get start(): number;
    }
    class SpecHttpRouteMatchHeaderMatchRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchHeaderMatchRangePropertyOutputReference;
    }
    interface SpecHttpRouteMatchHeaderMatchProperty {
    }
    class SpecHttpRouteMatchHeaderMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchHeaderMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderMatchProperty | undefined);
        get exact(): string;
        get prefix(): string;
        private _range;
        get range(): SpecHttpRouteMatchHeaderMatchRangePropertyList;
        get regex(): string;
        get suffix(): string;
    }
    class SpecHttpRouteMatchHeaderMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchHeaderMatchPropertyOutputReference;
    }
    interface SpecHttpRouteMatchHeaderProperty {
    }
    class SpecHttpRouteMatchHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchHeaderProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHeaderProperty | undefined);
        get invert(): cdktn.IResolvable;
        private _match;
        get match(): SpecHttpRouteMatchHeaderMatchPropertyList;
        get name(): string;
    }
    class SpecHttpRouteMatchHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchHeaderPropertyOutputReference;
    }
    interface SpecHttpRouteMatchHostnameProperty {
    }
    class SpecHttpRouteMatchHostnamePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchHostnameProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchHostnameProperty | undefined);
        get exact(): string;
        get suffix(): string;
    }
    class SpecHttpRouteMatchHostnamePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchHostnamePropertyOutputReference;
    }
    interface SpecHttpRouteMatchPathProperty {
    }
    class SpecHttpRouteMatchPathPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchPathProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchPathProperty | undefined);
        get exact(): string;
        get regex(): string;
    }
    class SpecHttpRouteMatchPathPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchPathPropertyOutputReference;
    }
    interface SpecHttpRouteMatchQueryParameterMatchProperty {
    }
    class SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchQueryParameterMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchQueryParameterMatchProperty | undefined);
        get exact(): string;
    }
    class SpecHttpRouteMatchQueryParameterMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchQueryParameterMatchPropertyOutputReference;
    }
    interface SpecHttpRouteMatchQueryParameterProperty {
    }
    class SpecHttpRouteMatchQueryParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchQueryParameterProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchQueryParameterProperty | undefined);
        private _match;
        get match(): SpecHttpRouteMatchQueryParameterMatchPropertyList;
        get name(): string;
    }
    class SpecHttpRouteMatchQueryParameterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchQueryParameterPropertyOutputReference;
    }
    interface SpecHttpRouteMatchProperty {
    }
    class SpecHttpRouteMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecHttpRouteMatchProperty | undefined;
        set internalValue(value: SpecHttpRouteMatchProperty | undefined);
        private _header;
        get header(): SpecHttpRouteMatchHeaderPropertyList;
        private _hostname;
        get hostname(): SpecHttpRouteMatchHostnamePropertyList;
        private _path;
        get path(): SpecHttpRouteMatchPathPropertyList;
        get port(): number;
        get prefix(): string;
        private _queryParameter;
        get queryParameter(): SpecHttpRouteMatchQueryParameterPropertyList;
    }
    class SpecHttpRouteMatchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecHttpRouteMatchPropertyOutputReference;
    }
    interface HttpRouteProperty {
    }
    class HttpRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HttpRouteProperty | undefined;
        set internalValue(value: HttpRouteProperty | undefined);
        private _action;
        get action(): SpecHttpRouteActionPropertyList;
        private _match;
        get match(): SpecHttpRouteMatchPropertyList;
    }
    class HttpRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HttpRoutePropertyOutputReference;
    }
    interface SpecProperty {
    }
    class SpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SpecProperty | undefined;
        set internalValue(value: SpecProperty | undefined);
        private _grpcRoute;
        get grpcRoute(): GrpcRoutePropertyList;
        private _http2Route;
        get http2Route(): Http2RoutePropertyList;
        private _httpRoute;
        get httpRoute(): HttpRoutePropertyList;
        get priority(): number;
    }
    class SpecPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SpecPropertyOutputReference;
    }
}
