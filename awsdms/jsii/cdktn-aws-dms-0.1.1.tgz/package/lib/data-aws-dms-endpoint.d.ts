import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsDmsEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dms_endpoint#endpoint_id DataAwsDmsEndpoint#endpoint_id}
    */
    readonly endpointId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dms_endpoint#id DataAwsDmsEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dms_endpoint#region DataAwsDmsEndpoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dms_endpoint#tags DataAwsDmsEndpoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dms_endpoint aws_dms_endpoint}
*/
export declare class DataAwsDmsEndpoint extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_dms_endpoint";
    /**
    * Generates CDKTN code for importing a DataAwsDmsEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsDmsEndpoint to import
    * @param importFromId The id of the existing DataAwsDmsEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dms_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsDmsEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/dms_endpoint aws_dms_endpoint} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsDmsEndpointConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsDmsEndpointConfig);
    get certificateArn(): string;
    get databaseName(): string;
    private _elasticsearchSettings;
    get elasticsearchSettings(): DataAwsDmsEndpoint.ElasticsearchSettingsPropertyList;
    get endpointArn(): string;
    private _endpointId?;
    get endpointId(): string;
    set endpointId(value: string);
    get endpointIdInput(): string | undefined;
    get endpointType(): string;
    get engineName(): string;
    get extraConnectionAttributes(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kafkaSettings;
    get kafkaSettings(): DataAwsDmsEndpoint.KafkaSettingsPropertyList;
    private _kinesisSettings;
    get kinesisSettings(): DataAwsDmsEndpoint.KinesisSettingsPropertyList;
    get kmsKeyArn(): string;
    private _mongodbSettings;
    get mongodbSettings(): DataAwsDmsEndpoint.MongodbSettingsPropertyList;
    private _mysqlSettings;
    get mysqlSettings(): DataAwsDmsEndpoint.MysqlSettingsPropertyList;
    get password(): string;
    get port(): number;
    private _postgresSettings;
    get postgresSettings(): DataAwsDmsEndpoint.PostgresSettingsPropertyList;
    private _redisSettings;
    get redisSettings(): DataAwsDmsEndpoint.RedisSettingsPropertyList;
    private _redshiftSettings;
    get redshiftSettings(): DataAwsDmsEndpoint.RedshiftSettingsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _s3Settings;
    get s3Settings(): DataAwsDmsEndpoint.S3SettingsPropertyList;
    get secretsManagerAccessRoleArn(): string;
    get secretsManagerArn(): string;
    get serverName(): string;
    get serviceAccessRole(): string;
    get sslMode(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsDmsEndpointElasticsearchSettingsPropertyToTerraform(struct?: DataAwsDmsEndpoint.ElasticsearchSettingsProperty): any;
export declare function dataAwsDmsEndpointElasticsearchSettingsPropertyToHclTerraform(struct?: DataAwsDmsEndpoint.ElasticsearchSettingsProperty): any;
export declare function dataAwsDmsEndpointKafkaSettingsPropertyToTerraform(struct?: DataAwsDmsEndpoint.KafkaSettingsProperty): any;
export declare function dataAwsDmsEndpointKafkaSettingsPropertyToHclTerraform(struct?: DataAwsDmsEndpoint.KafkaSettingsProperty): any;
export declare function dataAwsDmsEndpointKinesisSettingsPropertyToTerraform(struct?: DataAwsDmsEndpoint.KinesisSettingsProperty): any;
export declare function dataAwsDmsEndpointKinesisSettingsPropertyToHclTerraform(struct?: DataAwsDmsEndpoint.KinesisSettingsProperty): any;
export declare function dataAwsDmsEndpointMongodbSettingsPropertyToTerraform(struct?: DataAwsDmsEndpoint.MongodbSettingsProperty): any;
export declare function dataAwsDmsEndpointMongodbSettingsPropertyToHclTerraform(struct?: DataAwsDmsEndpoint.MongodbSettingsProperty): any;
export declare function dataAwsDmsEndpointMysqlSettingsPropertyToTerraform(struct?: DataAwsDmsEndpoint.MysqlSettingsProperty): any;
export declare function dataAwsDmsEndpointMysqlSettingsPropertyToHclTerraform(struct?: DataAwsDmsEndpoint.MysqlSettingsProperty): any;
export declare function dataAwsDmsEndpointPostgresSettingsPropertyToTerraform(struct?: DataAwsDmsEndpoint.PostgresSettingsProperty): any;
export declare function dataAwsDmsEndpointPostgresSettingsPropertyToHclTerraform(struct?: DataAwsDmsEndpoint.PostgresSettingsProperty): any;
export declare function dataAwsDmsEndpointRedisSettingsPropertyToTerraform(struct?: DataAwsDmsEndpoint.RedisSettingsProperty): any;
export declare function dataAwsDmsEndpointRedisSettingsPropertyToHclTerraform(struct?: DataAwsDmsEndpoint.RedisSettingsProperty): any;
export declare function dataAwsDmsEndpointRedshiftSettingsPropertyToTerraform(struct?: DataAwsDmsEndpoint.RedshiftSettingsProperty): any;
export declare function dataAwsDmsEndpointRedshiftSettingsPropertyToHclTerraform(struct?: DataAwsDmsEndpoint.RedshiftSettingsProperty): any;
export declare function dataAwsDmsEndpointS3SettingsPropertyToTerraform(struct?: DataAwsDmsEndpoint.S3SettingsProperty): any;
export declare function dataAwsDmsEndpointS3SettingsPropertyToHclTerraform(struct?: DataAwsDmsEndpoint.S3SettingsProperty): any;
export declare namespace DataAwsDmsEndpoint {
    interface ElasticsearchSettingsProperty {
    }
    class ElasticsearchSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ElasticsearchSettingsProperty | undefined;
        set internalValue(value: ElasticsearchSettingsProperty | undefined);
        get endpointUri(): string;
        get errorRetryDuration(): number;
        get fullLoadErrorPercentage(): number;
        get serviceAccessRoleArn(): string;
    }
    class ElasticsearchSettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ElasticsearchSettingsPropertyOutputReference;
    }
    interface KafkaSettingsProperty {
    }
    class KafkaSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KafkaSettingsProperty | undefined;
        set internalValue(value: KafkaSettingsProperty | undefined);
        get broker(): string;
        get includeControlDetails(): cdktn.IResolvable;
        get includeNullAndEmpty(): cdktn.IResolvable;
        get includePartitionValue(): cdktn.IResolvable;
        get includeTableAlterOperations(): cdktn.IResolvable;
        get includeTransactionDetails(): cdktn.IResolvable;
        get messageFormat(): string;
        get messageMaxBytes(): number;
        get noHexPrefix(): cdktn.IResolvable;
        get partitionIncludeSchemaTable(): cdktn.IResolvable;
        get saslMechanism(): string;
        get saslPassword(): string;
        get saslUsername(): string;
        get securityProtocol(): string;
        get sslCaCertificateArn(): string;
        get sslClientCertificateArn(): string;
        get sslClientKeyArn(): string;
        get sslClientKeyPassword(): string;
        get topic(): string;
    }
    class KafkaSettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KafkaSettingsPropertyOutputReference;
    }
    interface KinesisSettingsProperty {
    }
    class KinesisSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KinesisSettingsProperty | undefined;
        set internalValue(value: KinesisSettingsProperty | undefined);
        get includeControlDetails(): cdktn.IResolvable;
        get includeNullAndEmpty(): cdktn.IResolvable;
        get includePartitionValue(): cdktn.IResolvable;
        get includeTableAlterOperations(): cdktn.IResolvable;
        get includeTransactionDetails(): cdktn.IResolvable;
        get messageFormat(): string;
        get partitionIncludeSchemaTable(): cdktn.IResolvable;
        get serviceAccessRoleArn(): string;
        get streamArn(): string;
        get useLargeIntegerValue(): cdktn.IResolvable;
    }
    class KinesisSettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KinesisSettingsPropertyOutputReference;
    }
    interface MongodbSettingsProperty {
    }
    class MongodbSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MongodbSettingsProperty | undefined;
        set internalValue(value: MongodbSettingsProperty | undefined);
        get authMechanism(): string;
        get authSource(): string;
        get authType(): string;
        get docsToInvestigate(): string;
        get extractDocId(): string;
        get nestingLevel(): string;
        get useUpdateLookup(): cdktn.IResolvable;
    }
    class MongodbSettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MongodbSettingsPropertyOutputReference;
    }
    interface MysqlSettingsProperty {
    }
    class MysqlSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MysqlSettingsProperty | undefined;
        set internalValue(value: MysqlSettingsProperty | undefined);
        get afterConnectScript(): string;
        get authenticationMethod(): string;
        get cleanSourceMetadataOnMismatch(): cdktn.IResolvable;
        get eventsPollInterval(): number;
        get executeTimeout(): number;
        get maxFileSize(): number;
        get parallelLoadThreads(): number;
        get serverTimezone(): string;
        get serviceAccessRoleArn(): string;
        get targetDbType(): string;
    }
    class MysqlSettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MysqlSettingsPropertyOutputReference;
    }
    interface PostgresSettingsProperty {
    }
    class PostgresSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PostgresSettingsProperty | undefined;
        set internalValue(value: PostgresSettingsProperty | undefined);
        get afterConnectScript(): string;
        get authenticationMethod(): string;
        get babelfishDatabaseName(): string;
        get captureDdls(): cdktn.IResolvable;
        get databaseMode(): string;
        get ddlArtifactsSchema(): string;
        get executeTimeout(): number;
        get failTasksOnLobTruncation(): cdktn.IResolvable;
        get heartbeatEnable(): cdktn.IResolvable;
        get heartbeatFrequency(): number;
        get heartbeatSchema(): string;
        get mapBooleanAsBoolean(): cdktn.IResolvable;
        get mapJsonbAsClob(): cdktn.IResolvable;
        get mapLongVarcharAs(): string;
        get maxFileSize(): number;
        get pluginName(): string;
        get serviceAccessRoleArn(): string;
        get slotName(): string;
    }
    class PostgresSettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PostgresSettingsPropertyOutputReference;
    }
    interface RedisSettingsProperty {
    }
    class RedisSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RedisSettingsProperty | undefined;
        set internalValue(value: RedisSettingsProperty | undefined);
        get authPassword(): string;
        get authType(): string;
        get authUserName(): string;
        get port(): number;
        get serverName(): string;
        get sslCaCertificateArn(): string;
        get sslSecurityProtocol(): string;
    }
    class RedisSettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RedisSettingsPropertyOutputReference;
    }
    interface RedshiftSettingsProperty {
    }
    class RedshiftSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RedshiftSettingsProperty | undefined;
        set internalValue(value: RedshiftSettingsProperty | undefined);
        get bucketFolder(): string;
        get bucketName(): string;
        get encryptionMode(): string;
        get serverSideEncryptionKmsKeyId(): string;
        get serviceAccessRoleArn(): string;
    }
    class RedshiftSettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RedshiftSettingsPropertyOutputReference;
    }
    interface S3SettingsProperty {
    }
    class S3SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3SettingsProperty | undefined;
        set internalValue(value: S3SettingsProperty | undefined);
        get addColumnName(): cdktn.IResolvable;
        get bucketFolder(): string;
        get bucketName(): string;
        get cannedAclForObjects(): string;
        get cdcInsertsAndUpdates(): cdktn.IResolvable;
        get cdcInsertsOnly(): cdktn.IResolvable;
        get cdcMaxBatchInterval(): number;
        get cdcMinFileSize(): number;
        get cdcPath(): string;
        get compressionType(): string;
        get csvDelimiter(): string;
        get csvNoSupValue(): string;
        get csvNullValue(): string;
        get csvRowDelimiter(): string;
        get dataFormat(): string;
        get dataPageSize(): number;
        get datePartitionDelimiter(): string;
        get datePartitionEnabled(): cdktn.IResolvable;
        get datePartitionSequence(): string;
        get dictPageSizeLimit(): number;
        get enableStatistics(): cdktn.IResolvable;
        get encodingType(): string;
        get encryptionMode(): string;
        get externalTableDefinition(): string;
        get glueCatalogGeneration(): cdktn.IResolvable;
        get ignoreHeaderRows(): number;
        get ignoreHeadersRow(): number;
        get includeOpForFullLoad(): cdktn.IResolvable;
        get maxFileSize(): number;
        get parquetTimestampInMillisecond(): cdktn.IResolvable;
        get parquetVersion(): string;
        get preserveTransactions(): cdktn.IResolvable;
        get rfc4180(): cdktn.IResolvable;
        get rowGroupLength(): number;
        get serverSideEncryptionKmsKeyId(): string;
        get serviceAccessRoleArn(): string;
        get timestampColumnName(): string;
        get useCsvNoSupValue(): cdktn.IResolvable;
        get useTaskStartTimeForFullLoadTimestamp(): cdktn.IResolvable;
    }
    class S3SettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3SettingsPropertyOutputReference;
    }
}
