import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDmsReplicationConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#id AwsDmsReplicationConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#region AwsDmsReplicationConfig#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#replication_config_identifier AwsDmsReplicationConfig#replication_config_identifier}
    */
    readonly replicationConfigIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#replication_settings AwsDmsReplicationConfig#replication_settings}
    */
    readonly replicationSettings?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#replication_type AwsDmsReplicationConfig#replication_type}
    */
    readonly replicationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#resource_identifier AwsDmsReplicationConfig#resource_identifier}
    */
    readonly resourceIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#source_endpoint_arn AwsDmsReplicationConfig#source_endpoint_arn}
    */
    readonly sourceEndpointArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#start_replication AwsDmsReplicationConfig#start_replication}
    */
    readonly startReplication?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#supplemental_settings AwsDmsReplicationConfig#supplemental_settings}
    */
    readonly supplementalSettings?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#table_mappings AwsDmsReplicationConfig#table_mappings}
    */
    readonly tableMappings: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#tags AwsDmsReplicationConfig#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#tags_all AwsDmsReplicationConfig#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#target_endpoint_arn AwsDmsReplicationConfig#target_endpoint_arn}
    */
    readonly targetEndpointArn: string;
    /**
    * compute_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#compute_config AwsDmsReplicationConfig#compute_config}
    */
    readonly computeConfig: AwsDmsReplicationConfig.ComputeConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#timeouts AwsDmsReplicationConfig#timeouts}
    */
    readonly timeouts?: AwsDmsReplicationConfig.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config aws_dms_replication_config}
*/
export declare class AwsDmsReplicationConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dms_replication_config";
    /**
    * Generates CDKTN code for importing a AwsDmsReplicationConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDmsReplicationConfig to import
    * @param importFromId The id of the existing AwsDmsReplicationConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDmsReplicationConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config aws_dms_replication_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDmsReplicationConfigConfig
    */
    constructor(scope: Construct, id: string, config: AwsDmsReplicationConfigConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replicationConfigIdentifier?;
    get replicationConfigIdentifier(): string;
    set replicationConfigIdentifier(value: string);
    get replicationConfigIdentifierInput(): string | undefined;
    private _replicationSettings?;
    get replicationSettings(): string;
    set replicationSettings(value: string);
    resetReplicationSettings(): void;
    get replicationSettingsInput(): string | undefined;
    private _replicationType?;
    get replicationType(): string;
    set replicationType(value: string);
    get replicationTypeInput(): string | undefined;
    private _resourceIdentifier?;
    get resourceIdentifier(): string;
    set resourceIdentifier(value: string);
    resetResourceIdentifier(): void;
    get resourceIdentifierInput(): string | undefined;
    private _sourceEndpointArn?;
    get sourceEndpointArn(): string;
    set sourceEndpointArn(value: string);
    get sourceEndpointArnInput(): string | undefined;
    private _startReplication?;
    get startReplication(): boolean | cdktn.IResolvable;
    set startReplication(value: boolean | cdktn.IResolvable);
    resetStartReplication(): void;
    get startReplicationInput(): boolean | cdktn.IResolvable | undefined;
    private _supplementalSettings?;
    get supplementalSettings(): string;
    set supplementalSettings(value: string);
    resetSupplementalSettings(): void;
    get supplementalSettingsInput(): string | undefined;
    private _tableMappings?;
    get tableMappings(): string;
    set tableMappings(value: string);
    get tableMappingsInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _targetEndpointArn?;
    get targetEndpointArn(): string;
    set targetEndpointArn(value: string);
    get targetEndpointArnInput(): string | undefined;
    private _computeConfig;
    get computeConfig(): AwsDmsReplicationConfig.ComputeConfigPropertyOutputReference;
    putComputeConfig(value: AwsDmsReplicationConfig.ComputeConfigProperty): void;
    get computeConfigInput(): AwsDmsReplicationConfig.ComputeConfigProperty | undefined;
    private _timeouts;
    get timeouts(): AwsDmsReplicationConfig.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDmsReplicationConfig.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDmsReplicationConfig.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDmsReplicationConfigComputeConfigPropertyToTerraform(struct?: AwsDmsReplicationConfig.ComputeConfigPropertyOutputReference | AwsDmsReplicationConfig.ComputeConfigProperty): any;
export declare function awsDmsReplicationConfigComputeConfigPropertyToHclTerraform(struct?: AwsDmsReplicationConfig.ComputeConfigPropertyOutputReference | AwsDmsReplicationConfig.ComputeConfigProperty): any;
export declare function awsDmsReplicationConfigTimeoutsPropertyToTerraform(struct?: AwsDmsReplicationConfig.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDmsReplicationConfigTimeoutsPropertyToHclTerraform(struct?: AwsDmsReplicationConfig.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDmsReplicationConfig {
    interface ComputeConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#availability_zone AwsDmsReplicationConfig#availability_zone}
        */
        readonly availabilityZone?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#dns_name_servers AwsDmsReplicationConfig#dns_name_servers}
        */
        readonly dnsNameServers?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#kms_key_id AwsDmsReplicationConfig#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#max_capacity_units AwsDmsReplicationConfig#max_capacity_units}
        */
        readonly maxCapacityUnits?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#min_capacity_units AwsDmsReplicationConfig#min_capacity_units}
        */
        readonly minCapacityUnits?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#multi_az AwsDmsReplicationConfig#multi_az}
        */
        readonly multiAz?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#preferred_maintenance_window AwsDmsReplicationConfig#preferred_maintenance_window}
        */
        readonly preferredMaintenanceWindow?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#replication_subnet_group_id AwsDmsReplicationConfig#replication_subnet_group_id}
        */
        readonly replicationSubnetGroupId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#vpc_security_group_ids AwsDmsReplicationConfig#vpc_security_group_ids}
        */
        readonly vpcSecurityGroupIds?: string[];
    }
    class ComputeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ComputeConfigProperty | undefined;
        set internalValue(value: ComputeConfigProperty | undefined);
        private _availabilityZone?;
        get availabilityZone(): string;
        set availabilityZone(value: string);
        resetAvailabilityZone(): void;
        get availabilityZoneInput(): string | undefined;
        private _dnsNameServers?;
        get dnsNameServers(): string;
        set dnsNameServers(value: string);
        resetDnsNameServers(): void;
        get dnsNameServersInput(): string | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _maxCapacityUnits?;
        get maxCapacityUnits(): number;
        set maxCapacityUnits(value: number);
        resetMaxCapacityUnits(): void;
        get maxCapacityUnitsInput(): number | undefined;
        private _minCapacityUnits?;
        get minCapacityUnits(): number;
        set minCapacityUnits(value: number);
        resetMinCapacityUnits(): void;
        get minCapacityUnitsInput(): number | undefined;
        private _multiAz?;
        get multiAz(): boolean | cdktn.IResolvable;
        set multiAz(value: boolean | cdktn.IResolvable);
        resetMultiAz(): void;
        get multiAzInput(): boolean | cdktn.IResolvable | undefined;
        private _preferredMaintenanceWindow?;
        get preferredMaintenanceWindow(): string;
        set preferredMaintenanceWindow(value: string);
        resetPreferredMaintenanceWindow(): void;
        get preferredMaintenanceWindowInput(): string | undefined;
        private _replicationSubnetGroupId?;
        get replicationSubnetGroupId(): string;
        set replicationSubnetGroupId(value: string);
        get replicationSubnetGroupIdInput(): string | undefined;
        private _vpcSecurityGroupIds?;
        get vpcSecurityGroupIds(): string[];
        set vpcSecurityGroupIds(value: string[]);
        resetVpcSecurityGroupIds(): void;
        get vpcSecurityGroupIdsInput(): string[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#create AwsDmsReplicationConfig#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#delete AwsDmsReplicationConfig#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_replication_config#update AwsDmsReplicationConfig#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
