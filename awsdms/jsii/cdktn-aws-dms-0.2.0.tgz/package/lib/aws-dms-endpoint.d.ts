import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#certificate_arn TfEndpoint#certificate_arn}
    */
    readonly certificateArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#database_name TfEndpoint#database_name}
    */
    readonly databaseName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#endpoint_id TfEndpoint#endpoint_id}
    */
    readonly endpointId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#endpoint_type TfEndpoint#endpoint_type}
    */
    readonly endpointType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#engine_name TfEndpoint#engine_name}
    */
    readonly engineName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#extra_connection_attributes TfEndpoint#extra_connection_attributes}
    */
    readonly extraConnectionAttributes?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#id TfEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#kms_key_arn TfEndpoint#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#password TfEndpoint#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#pause_replication_tasks TfEndpoint#pause_replication_tasks}
    */
    readonly pauseReplicationTasks?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#port TfEndpoint#port}
    */
    readonly port?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#region TfEndpoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#secrets_manager_access_role_arn TfEndpoint#secrets_manager_access_role_arn}
    */
    readonly secretsManagerAccessRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#secrets_manager_arn TfEndpoint#secrets_manager_arn}
    */
    readonly secretsManagerArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#server_name TfEndpoint#server_name}
    */
    readonly serverName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#service_access_role TfEndpoint#service_access_role}
    */
    readonly serviceAccessRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#ssl_mode TfEndpoint#ssl_mode}
    */
    readonly sslMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#tags TfEndpoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#tags_all TfEndpoint#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#username TfEndpoint#username}
    */
    readonly username?: string;
    /**
    * elasticsearch_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#elasticsearch_settings TfEndpoint#elasticsearch_settings}
    */
    readonly elasticsearchSettings?: TfEndpoint.ElasticsearchSettingsProperty;
    /**
    * kafka_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#kafka_settings TfEndpoint#kafka_settings}
    */
    readonly kafkaSettings?: TfEndpoint.KafkaSettingsProperty;
    /**
    * kinesis_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#kinesis_settings TfEndpoint#kinesis_settings}
    */
    readonly kinesisSettings?: TfEndpoint.KinesisSettingsProperty;
    /**
    * mongodb_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#mongodb_settings TfEndpoint#mongodb_settings}
    */
    readonly mongodbSettings?: TfEndpoint.MongodbSettingsProperty;
    /**
    * mysql_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#mysql_settings TfEndpoint#mysql_settings}
    */
    readonly mysqlSettings?: TfEndpoint.MysqlSettingsProperty;
    /**
    * oracle_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#oracle_settings TfEndpoint#oracle_settings}
    */
    readonly oracleSettings?: TfEndpoint.OracleSettingsProperty;
    /**
    * postgres_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#postgres_settings TfEndpoint#postgres_settings}
    */
    readonly postgresSettings?: TfEndpoint.PostgresSettingsProperty;
    /**
    * redis_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#redis_settings TfEndpoint#redis_settings}
    */
    readonly redisSettings?: TfEndpoint.RedisSettingsProperty;
    /**
    * redshift_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#redshift_settings TfEndpoint#redshift_settings}
    */
    readonly redshiftSettings?: TfEndpoint.RedshiftSettingsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#timeouts TfEndpoint#timeouts}
    */
    readonly timeouts?: TfEndpoint.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint aws_dms_endpoint}
*/
export declare class TfEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_dms_endpoint";
    /**
    * Generates CDKTN code for importing a TfEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfEndpoint to import
    * @param importFromId The id of the existing TfEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint aws_dms_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfEndpointConfig
    */
    constructor(scope: Construct, id: string, config: TfEndpointConfig);
    private _certificateArn?;
    get certificateArn(): string;
    set certificateArn(value: string);
    resetCertificateArn(): void;
    get certificateArnInput(): string | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    resetDatabaseName(): void;
    get databaseNameInput(): string | undefined;
    get endpointArn(): string;
    private _endpointId?;
    get endpointId(): string;
    set endpointId(value: string);
    get endpointIdInput(): string | undefined;
    private _endpointType?;
    get endpointType(): string;
    set endpointType(value: string);
    get endpointTypeInput(): string | undefined;
    private _engineName?;
    get engineName(): string;
    set engineName(value: string);
    get engineNameInput(): string | undefined;
    private _extraConnectionAttributes?;
    get extraConnectionAttributes(): string;
    set extraConnectionAttributes(value: string);
    resetExtraConnectionAttributes(): void;
    get extraConnectionAttributesInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _pauseReplicationTasks?;
    get pauseReplicationTasks(): boolean | cdktn.IResolvable;
    set pauseReplicationTasks(value: boolean | cdktn.IResolvable);
    resetPauseReplicationTasks(): void;
    get pauseReplicationTasksInput(): boolean | cdktn.IResolvable | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _secretsManagerAccessRoleArn?;
    get secretsManagerAccessRoleArn(): string;
    set secretsManagerAccessRoleArn(value: string);
    resetSecretsManagerAccessRoleArn(): void;
    get secretsManagerAccessRoleArnInput(): string | undefined;
    private _secretsManagerArn?;
    get secretsManagerArn(): string;
    set secretsManagerArn(value: string);
    resetSecretsManagerArn(): void;
    get secretsManagerArnInput(): string | undefined;
    private _serverName?;
    get serverName(): string;
    set serverName(value: string);
    resetServerName(): void;
    get serverNameInput(): string | undefined;
    private _serviceAccessRole?;
    get serviceAccessRole(): string;
    set serviceAccessRole(value: string);
    resetServiceAccessRole(): void;
    get serviceAccessRoleInput(): string | undefined;
    private _sslMode?;
    get sslMode(): string;
    set sslMode(value: string);
    resetSslMode(): void;
    get sslModeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _elasticsearchSettings;
    get elasticsearchSettings(): TfEndpoint.ElasticsearchSettingsPropertyOutputReference;
    putElasticsearchSettings(value: TfEndpoint.ElasticsearchSettingsProperty): void;
    resetElasticsearchSettings(): void;
    get elasticsearchSettingsInput(): TfEndpoint.ElasticsearchSettingsProperty | undefined;
    private _kafkaSettings;
    get kafkaSettings(): TfEndpoint.KafkaSettingsPropertyOutputReference;
    putKafkaSettings(value: TfEndpoint.KafkaSettingsProperty): void;
    resetKafkaSettings(): void;
    get kafkaSettingsInput(): TfEndpoint.KafkaSettingsProperty | undefined;
    private _kinesisSettings;
    get kinesisSettings(): TfEndpoint.KinesisSettingsPropertyOutputReference;
    putKinesisSettings(value: TfEndpoint.KinesisSettingsProperty): void;
    resetKinesisSettings(): void;
    get kinesisSettingsInput(): TfEndpoint.KinesisSettingsProperty | undefined;
    private _mongodbSettings;
    get mongodbSettings(): TfEndpoint.MongodbSettingsPropertyOutputReference;
    putMongodbSettings(value: TfEndpoint.MongodbSettingsProperty): void;
    resetMongodbSettings(): void;
    get mongodbSettingsInput(): TfEndpoint.MongodbSettingsProperty | undefined;
    private _mysqlSettings;
    get mysqlSettings(): TfEndpoint.MysqlSettingsPropertyOutputReference;
    putMysqlSettings(value: TfEndpoint.MysqlSettingsProperty): void;
    resetMysqlSettings(): void;
    get mysqlSettingsInput(): TfEndpoint.MysqlSettingsProperty | undefined;
    private _oracleSettings;
    get oracleSettings(): TfEndpoint.OracleSettingsPropertyOutputReference;
    putOracleSettings(value: TfEndpoint.OracleSettingsProperty): void;
    resetOracleSettings(): void;
    get oracleSettingsInput(): TfEndpoint.OracleSettingsProperty | undefined;
    private _postgresSettings;
    get postgresSettings(): TfEndpoint.PostgresSettingsPropertyOutputReference;
    putPostgresSettings(value: TfEndpoint.PostgresSettingsProperty): void;
    resetPostgresSettings(): void;
    get postgresSettingsInput(): TfEndpoint.PostgresSettingsProperty | undefined;
    private _redisSettings;
    get redisSettings(): TfEndpoint.RedisSettingsPropertyOutputReference;
    putRedisSettings(value: TfEndpoint.RedisSettingsProperty): void;
    resetRedisSettings(): void;
    get redisSettingsInput(): TfEndpoint.RedisSettingsProperty | undefined;
    private _redshiftSettings;
    get redshiftSettings(): TfEndpoint.RedshiftSettingsPropertyOutputReference;
    putRedshiftSettings(value: TfEndpoint.RedshiftSettingsProperty): void;
    resetRedshiftSettings(): void;
    get redshiftSettingsInput(): TfEndpoint.RedshiftSettingsProperty | undefined;
    private _timeouts;
    get timeouts(): TfEndpoint.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfEndpoint.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfEndpoint.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfEndpointElasticsearchSettingsPropertyToTerraform(struct?: TfEndpoint.ElasticsearchSettingsPropertyOutputReference | TfEndpoint.ElasticsearchSettingsProperty): any;
export declare function tfEndpointElasticsearchSettingsPropertyToHclTerraform(struct?: TfEndpoint.ElasticsearchSettingsPropertyOutputReference | TfEndpoint.ElasticsearchSettingsProperty): any;
export declare function tfEndpointKafkaSettingsPropertyToTerraform(struct?: TfEndpoint.KafkaSettingsPropertyOutputReference | TfEndpoint.KafkaSettingsProperty): any;
export declare function tfEndpointKafkaSettingsPropertyToHclTerraform(struct?: TfEndpoint.KafkaSettingsPropertyOutputReference | TfEndpoint.KafkaSettingsProperty): any;
export declare function tfEndpointKinesisSettingsPropertyToTerraform(struct?: TfEndpoint.KinesisSettingsPropertyOutputReference | TfEndpoint.KinesisSettingsProperty): any;
export declare function tfEndpointKinesisSettingsPropertyToHclTerraform(struct?: TfEndpoint.KinesisSettingsPropertyOutputReference | TfEndpoint.KinesisSettingsProperty): any;
export declare function tfEndpointMongodbSettingsPropertyToTerraform(struct?: TfEndpoint.MongodbSettingsPropertyOutputReference | TfEndpoint.MongodbSettingsProperty): any;
export declare function tfEndpointMongodbSettingsPropertyToHclTerraform(struct?: TfEndpoint.MongodbSettingsPropertyOutputReference | TfEndpoint.MongodbSettingsProperty): any;
export declare function tfEndpointMysqlSettingsPropertyToTerraform(struct?: TfEndpoint.MysqlSettingsPropertyOutputReference | TfEndpoint.MysqlSettingsProperty): any;
export declare function tfEndpointMysqlSettingsPropertyToHclTerraform(struct?: TfEndpoint.MysqlSettingsPropertyOutputReference | TfEndpoint.MysqlSettingsProperty): any;
export declare function tfEndpointOracleSettingsPropertyToTerraform(struct?: TfEndpoint.OracleSettingsPropertyOutputReference | TfEndpoint.OracleSettingsProperty): any;
export declare function tfEndpointOracleSettingsPropertyToHclTerraform(struct?: TfEndpoint.OracleSettingsPropertyOutputReference | TfEndpoint.OracleSettingsProperty): any;
export declare function tfEndpointPostgresSettingsPropertyToTerraform(struct?: TfEndpoint.PostgresSettingsPropertyOutputReference | TfEndpoint.PostgresSettingsProperty): any;
export declare function tfEndpointPostgresSettingsPropertyToHclTerraform(struct?: TfEndpoint.PostgresSettingsPropertyOutputReference | TfEndpoint.PostgresSettingsProperty): any;
export declare function tfEndpointRedisSettingsPropertyToTerraform(struct?: TfEndpoint.RedisSettingsPropertyOutputReference | TfEndpoint.RedisSettingsProperty): any;
export declare function tfEndpointRedisSettingsPropertyToHclTerraform(struct?: TfEndpoint.RedisSettingsPropertyOutputReference | TfEndpoint.RedisSettingsProperty): any;
export declare function tfEndpointRedshiftSettingsPropertyToTerraform(struct?: TfEndpoint.RedshiftSettingsPropertyOutputReference | TfEndpoint.RedshiftSettingsProperty): any;
export declare function tfEndpointRedshiftSettingsPropertyToHclTerraform(struct?: TfEndpoint.RedshiftSettingsPropertyOutputReference | TfEndpoint.RedshiftSettingsProperty): any;
export declare function tfEndpointTimeoutsPropertyToTerraform(struct?: TfEndpoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfEndpointTimeoutsPropertyToHclTerraform(struct?: TfEndpoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfEndpoint {
    interface ElasticsearchSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#endpoint_uri TfEndpoint#endpoint_uri}
        */
        readonly endpointUri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#error_retry_duration TfEndpoint#error_retry_duration}
        */
        readonly errorRetryDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#full_load_error_percentage TfEndpoint#full_load_error_percentage}
        */
        readonly fullLoadErrorPercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#service_access_role_arn TfEndpoint#service_access_role_arn}
        */
        readonly serviceAccessRoleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#use_new_mapping_type TfEndpoint#use_new_mapping_type}
        */
        readonly useNewMappingType?: boolean | cdktn.IResolvable;
    }
    class ElasticsearchSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ElasticsearchSettingsProperty | undefined;
        set internalValue(value: ElasticsearchSettingsProperty | undefined);
        private _endpointUri?;
        get endpointUri(): string;
        set endpointUri(value: string);
        get endpointUriInput(): string | undefined;
        private _errorRetryDuration?;
        get errorRetryDuration(): number;
        set errorRetryDuration(value: number);
        resetErrorRetryDuration(): void;
        get errorRetryDurationInput(): number | undefined;
        private _fullLoadErrorPercentage?;
        get fullLoadErrorPercentage(): number;
        set fullLoadErrorPercentage(value: number);
        resetFullLoadErrorPercentage(): void;
        get fullLoadErrorPercentageInput(): number | undefined;
        private _serviceAccessRoleArn?;
        get serviceAccessRoleArn(): string;
        set serviceAccessRoleArn(value: string);
        get serviceAccessRoleArnInput(): string | undefined;
        private _useNewMappingType?;
        get useNewMappingType(): boolean | cdktn.IResolvable;
        set useNewMappingType(value: boolean | cdktn.IResolvable);
        resetUseNewMappingType(): void;
        get useNewMappingTypeInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface KafkaSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#broker TfEndpoint#broker}
        */
        readonly broker: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#include_control_details TfEndpoint#include_control_details}
        */
        readonly includeControlDetails?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#include_null_and_empty TfEndpoint#include_null_and_empty}
        */
        readonly includeNullAndEmpty?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#include_partition_value TfEndpoint#include_partition_value}
        */
        readonly includePartitionValue?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#include_table_alter_operations TfEndpoint#include_table_alter_operations}
        */
        readonly includeTableAlterOperations?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#include_transaction_details TfEndpoint#include_transaction_details}
        */
        readonly includeTransactionDetails?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#message_format TfEndpoint#message_format}
        */
        readonly messageFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#message_max_bytes TfEndpoint#message_max_bytes}
        */
        readonly messageMaxBytes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#no_hex_prefix TfEndpoint#no_hex_prefix}
        */
        readonly noHexPrefix?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#partition_include_schema_table TfEndpoint#partition_include_schema_table}
        */
        readonly partitionIncludeSchemaTable?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#sasl_mechanism TfEndpoint#sasl_mechanism}
        */
        readonly saslMechanism?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#sasl_password TfEndpoint#sasl_password}
        */
        readonly saslPassword?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#sasl_username TfEndpoint#sasl_username}
        */
        readonly saslUsername?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#security_protocol TfEndpoint#security_protocol}
        */
        readonly securityProtocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#ssl_ca_certificate_arn TfEndpoint#ssl_ca_certificate_arn}
        */
        readonly sslCaCertificateArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#ssl_client_certificate_arn TfEndpoint#ssl_client_certificate_arn}
        */
        readonly sslClientCertificateArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#ssl_client_key_arn TfEndpoint#ssl_client_key_arn}
        */
        readonly sslClientKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#ssl_client_key_password TfEndpoint#ssl_client_key_password}
        */
        readonly sslClientKeyPassword?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#topic TfEndpoint#topic}
        */
        readonly topic?: string;
    }
    class KafkaSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KafkaSettingsProperty | undefined;
        set internalValue(value: KafkaSettingsProperty | undefined);
        private _broker?;
        get broker(): string;
        set broker(value: string);
        get brokerInput(): string | undefined;
        private _includeControlDetails?;
        get includeControlDetails(): boolean | cdktn.IResolvable;
        set includeControlDetails(value: boolean | cdktn.IResolvable);
        resetIncludeControlDetails(): void;
        get includeControlDetailsInput(): boolean | cdktn.IResolvable | undefined;
        private _includeNullAndEmpty?;
        get includeNullAndEmpty(): boolean | cdktn.IResolvable;
        set includeNullAndEmpty(value: boolean | cdktn.IResolvable);
        resetIncludeNullAndEmpty(): void;
        get includeNullAndEmptyInput(): boolean | cdktn.IResolvable | undefined;
        private _includePartitionValue?;
        get includePartitionValue(): boolean | cdktn.IResolvable;
        set includePartitionValue(value: boolean | cdktn.IResolvable);
        resetIncludePartitionValue(): void;
        get includePartitionValueInput(): boolean | cdktn.IResolvable | undefined;
        private _includeTableAlterOperations?;
        get includeTableAlterOperations(): boolean | cdktn.IResolvable;
        set includeTableAlterOperations(value: boolean | cdktn.IResolvable);
        resetIncludeTableAlterOperations(): void;
        get includeTableAlterOperationsInput(): boolean | cdktn.IResolvable | undefined;
        private _includeTransactionDetails?;
        get includeTransactionDetails(): boolean | cdktn.IResolvable;
        set includeTransactionDetails(value: boolean | cdktn.IResolvable);
        resetIncludeTransactionDetails(): void;
        get includeTransactionDetailsInput(): boolean | cdktn.IResolvable | undefined;
        private _messageFormat?;
        get messageFormat(): string;
        set messageFormat(value: string);
        resetMessageFormat(): void;
        get messageFormatInput(): string | undefined;
        private _messageMaxBytes?;
        get messageMaxBytes(): number;
        set messageMaxBytes(value: number);
        resetMessageMaxBytes(): void;
        get messageMaxBytesInput(): number | undefined;
        private _noHexPrefix?;
        get noHexPrefix(): boolean | cdktn.IResolvable;
        set noHexPrefix(value: boolean | cdktn.IResolvable);
        resetNoHexPrefix(): void;
        get noHexPrefixInput(): boolean | cdktn.IResolvable | undefined;
        private _partitionIncludeSchemaTable?;
        get partitionIncludeSchemaTable(): boolean | cdktn.IResolvable;
        set partitionIncludeSchemaTable(value: boolean | cdktn.IResolvable);
        resetPartitionIncludeSchemaTable(): void;
        get partitionIncludeSchemaTableInput(): boolean | cdktn.IResolvable | undefined;
        private _saslMechanism?;
        get saslMechanism(): string;
        set saslMechanism(value: string);
        resetSaslMechanism(): void;
        get saslMechanismInput(): string | undefined;
        private _saslPassword?;
        get saslPassword(): string;
        set saslPassword(value: string);
        resetSaslPassword(): void;
        get saslPasswordInput(): string | undefined;
        private _saslUsername?;
        get saslUsername(): string;
        set saslUsername(value: string);
        resetSaslUsername(): void;
        get saslUsernameInput(): string | undefined;
        private _securityProtocol?;
        get securityProtocol(): string;
        set securityProtocol(value: string);
        resetSecurityProtocol(): void;
        get securityProtocolInput(): string | undefined;
        private _sslCaCertificateArn?;
        get sslCaCertificateArn(): string;
        set sslCaCertificateArn(value: string);
        resetSslCaCertificateArn(): void;
        get sslCaCertificateArnInput(): string | undefined;
        private _sslClientCertificateArn?;
        get sslClientCertificateArn(): string;
        set sslClientCertificateArn(value: string);
        resetSslClientCertificateArn(): void;
        get sslClientCertificateArnInput(): string | undefined;
        private _sslClientKeyArn?;
        get sslClientKeyArn(): string;
        set sslClientKeyArn(value: string);
        resetSslClientKeyArn(): void;
        get sslClientKeyArnInput(): string | undefined;
        private _sslClientKeyPassword?;
        get sslClientKeyPassword(): string;
        set sslClientKeyPassword(value: string);
        resetSslClientKeyPassword(): void;
        get sslClientKeyPasswordInput(): string | undefined;
        private _topic?;
        get topic(): string;
        set topic(value: string);
        resetTopic(): void;
        get topicInput(): string | undefined;
    }
    interface KinesisSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#include_control_details TfEndpoint#include_control_details}
        */
        readonly includeControlDetails?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#include_null_and_empty TfEndpoint#include_null_and_empty}
        */
        readonly includeNullAndEmpty?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#include_partition_value TfEndpoint#include_partition_value}
        */
        readonly includePartitionValue?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#include_table_alter_operations TfEndpoint#include_table_alter_operations}
        */
        readonly includeTableAlterOperations?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#include_transaction_details TfEndpoint#include_transaction_details}
        */
        readonly includeTransactionDetails?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#message_format TfEndpoint#message_format}
        */
        readonly messageFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#partition_include_schema_table TfEndpoint#partition_include_schema_table}
        */
        readonly partitionIncludeSchemaTable?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#service_access_role_arn TfEndpoint#service_access_role_arn}
        */
        readonly serviceAccessRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#stream_arn TfEndpoint#stream_arn}
        */
        readonly streamArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#use_large_integer_value TfEndpoint#use_large_integer_value}
        */
        readonly useLargeIntegerValue?: boolean | cdktn.IResolvable;
    }
    class KinesisSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisSettingsProperty | undefined;
        set internalValue(value: KinesisSettingsProperty | undefined);
        private _includeControlDetails?;
        get includeControlDetails(): boolean | cdktn.IResolvable;
        set includeControlDetails(value: boolean | cdktn.IResolvable);
        resetIncludeControlDetails(): void;
        get includeControlDetailsInput(): boolean | cdktn.IResolvable | undefined;
        private _includeNullAndEmpty?;
        get includeNullAndEmpty(): boolean | cdktn.IResolvable;
        set includeNullAndEmpty(value: boolean | cdktn.IResolvable);
        resetIncludeNullAndEmpty(): void;
        get includeNullAndEmptyInput(): boolean | cdktn.IResolvable | undefined;
        private _includePartitionValue?;
        get includePartitionValue(): boolean | cdktn.IResolvable;
        set includePartitionValue(value: boolean | cdktn.IResolvable);
        resetIncludePartitionValue(): void;
        get includePartitionValueInput(): boolean | cdktn.IResolvable | undefined;
        private _includeTableAlterOperations?;
        get includeTableAlterOperations(): boolean | cdktn.IResolvable;
        set includeTableAlterOperations(value: boolean | cdktn.IResolvable);
        resetIncludeTableAlterOperations(): void;
        get includeTableAlterOperationsInput(): boolean | cdktn.IResolvable | undefined;
        private _includeTransactionDetails?;
        get includeTransactionDetails(): boolean | cdktn.IResolvable;
        set includeTransactionDetails(value: boolean | cdktn.IResolvable);
        resetIncludeTransactionDetails(): void;
        get includeTransactionDetailsInput(): boolean | cdktn.IResolvable | undefined;
        private _messageFormat?;
        get messageFormat(): string;
        set messageFormat(value: string);
        resetMessageFormat(): void;
        get messageFormatInput(): string | undefined;
        private _partitionIncludeSchemaTable?;
        get partitionIncludeSchemaTable(): boolean | cdktn.IResolvable;
        set partitionIncludeSchemaTable(value: boolean | cdktn.IResolvable);
        resetPartitionIncludeSchemaTable(): void;
        get partitionIncludeSchemaTableInput(): boolean | cdktn.IResolvable | undefined;
        private _serviceAccessRoleArn?;
        get serviceAccessRoleArn(): string;
        set serviceAccessRoleArn(value: string);
        resetServiceAccessRoleArn(): void;
        get serviceAccessRoleArnInput(): string | undefined;
        private _streamArn?;
        get streamArn(): string;
        set streamArn(value: string);
        resetStreamArn(): void;
        get streamArnInput(): string | undefined;
        private _useLargeIntegerValue?;
        get useLargeIntegerValue(): boolean | cdktn.IResolvable;
        set useLargeIntegerValue(value: boolean | cdktn.IResolvable);
        resetUseLargeIntegerValue(): void;
        get useLargeIntegerValueInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface MongodbSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#auth_mechanism TfEndpoint#auth_mechanism}
        */
        readonly authMechanism?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#auth_source TfEndpoint#auth_source}
        */
        readonly authSource?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#auth_type TfEndpoint#auth_type}
        */
        readonly authType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#docs_to_investigate TfEndpoint#docs_to_investigate}
        */
        readonly docsToInvestigate?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#extract_doc_id TfEndpoint#extract_doc_id}
        */
        readonly extractDocId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#nesting_level TfEndpoint#nesting_level}
        */
        readonly nestingLevel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#use_update_lookup TfEndpoint#use_update_lookup}
        */
        readonly useUpdateLookup?: boolean | cdktn.IResolvable;
    }
    class MongodbSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MongodbSettingsProperty | undefined;
        set internalValue(value: MongodbSettingsProperty | undefined);
        private _authMechanism?;
        get authMechanism(): string;
        set authMechanism(value: string);
        resetAuthMechanism(): void;
        get authMechanismInput(): string | undefined;
        private _authSource?;
        get authSource(): string;
        set authSource(value: string);
        resetAuthSource(): void;
        get authSourceInput(): string | undefined;
        private _authType?;
        get authType(): string;
        set authType(value: string);
        resetAuthType(): void;
        get authTypeInput(): string | undefined;
        private _docsToInvestigate?;
        get docsToInvestigate(): string;
        set docsToInvestigate(value: string);
        resetDocsToInvestigate(): void;
        get docsToInvestigateInput(): string | undefined;
        private _extractDocId?;
        get extractDocId(): string;
        set extractDocId(value: string);
        resetExtractDocId(): void;
        get extractDocIdInput(): string | undefined;
        private _nestingLevel?;
        get nestingLevel(): string;
        set nestingLevel(value: string);
        resetNestingLevel(): void;
        get nestingLevelInput(): string | undefined;
        private _useUpdateLookup?;
        get useUpdateLookup(): boolean | cdktn.IResolvable;
        set useUpdateLookup(value: boolean | cdktn.IResolvable);
        resetUseUpdateLookup(): void;
        get useUpdateLookupInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface MysqlSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#after_connect_script TfEndpoint#after_connect_script}
        */
        readonly afterConnectScript?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#authentication_method TfEndpoint#authentication_method}
        */
        readonly authenticationMethod?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#clean_source_metadata_on_mismatch TfEndpoint#clean_source_metadata_on_mismatch}
        */
        readonly cleanSourceMetadataOnMismatch?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#events_poll_interval TfEndpoint#events_poll_interval}
        */
        readonly eventsPollInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#execute_timeout TfEndpoint#execute_timeout}
        */
        readonly executeTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#max_file_size TfEndpoint#max_file_size}
        */
        readonly maxFileSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#parallel_load_threads TfEndpoint#parallel_load_threads}
        */
        readonly parallelLoadThreads?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#server_timezone TfEndpoint#server_timezone}
        */
        readonly serverTimezone?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#service_access_role_arn TfEndpoint#service_access_role_arn}
        */
        readonly serviceAccessRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#target_db_type TfEndpoint#target_db_type}
        */
        readonly targetDbType?: string;
    }
    class MysqlSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MysqlSettingsProperty | undefined;
        set internalValue(value: MysqlSettingsProperty | undefined);
        private _afterConnectScript?;
        get afterConnectScript(): string;
        set afterConnectScript(value: string);
        resetAfterConnectScript(): void;
        get afterConnectScriptInput(): string | undefined;
        private _authenticationMethod?;
        get authenticationMethod(): string;
        set authenticationMethod(value: string);
        resetAuthenticationMethod(): void;
        get authenticationMethodInput(): string | undefined;
        private _cleanSourceMetadataOnMismatch?;
        get cleanSourceMetadataOnMismatch(): boolean | cdktn.IResolvable;
        set cleanSourceMetadataOnMismatch(value: boolean | cdktn.IResolvable);
        resetCleanSourceMetadataOnMismatch(): void;
        get cleanSourceMetadataOnMismatchInput(): boolean | cdktn.IResolvable | undefined;
        private _eventsPollInterval?;
        get eventsPollInterval(): number;
        set eventsPollInterval(value: number);
        resetEventsPollInterval(): void;
        get eventsPollIntervalInput(): number | undefined;
        private _executeTimeout?;
        get executeTimeout(): number;
        set executeTimeout(value: number);
        resetExecuteTimeout(): void;
        get executeTimeoutInput(): number | undefined;
        private _maxFileSize?;
        get maxFileSize(): number;
        set maxFileSize(value: number);
        resetMaxFileSize(): void;
        get maxFileSizeInput(): number | undefined;
        private _parallelLoadThreads?;
        get parallelLoadThreads(): number;
        set parallelLoadThreads(value: number);
        resetParallelLoadThreads(): void;
        get parallelLoadThreadsInput(): number | undefined;
        private _serverTimezone?;
        get serverTimezone(): string;
        set serverTimezone(value: string);
        resetServerTimezone(): void;
        get serverTimezoneInput(): string | undefined;
        private _serviceAccessRoleArn?;
        get serviceAccessRoleArn(): string;
        set serviceAccessRoleArn(value: string);
        resetServiceAccessRoleArn(): void;
        get serviceAccessRoleArnInput(): string | undefined;
        private _targetDbType?;
        get targetDbType(): string;
        set targetDbType(value: string);
        resetTargetDbType(): void;
        get targetDbTypeInput(): string | undefined;
    }
    interface OracleSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#access_alternate_directly TfEndpoint#access_alternate_directly}
        */
        readonly accessAlternateDirectly?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#add_supplemental_logging TfEndpoint#add_supplemental_logging}
        */
        readonly addSupplementalLogging?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#additional_archived_log_dest_id TfEndpoint#additional_archived_log_dest_id}
        */
        readonly additionalArchivedLogDestId?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#allow_selected_nested_tables TfEndpoint#allow_selected_nested_tables}
        */
        readonly allowSelectedNestedTables?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#archived_log_dest_id TfEndpoint#archived_log_dest_id}
        */
        readonly archivedLogDestId?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#archived_logs_only TfEndpoint#archived_logs_only}
        */
        readonly archivedLogsOnly?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#asm_password TfEndpoint#asm_password}
        */
        readonly asmPassword?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#asm_server TfEndpoint#asm_server}
        */
        readonly asmServer?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#asm_user TfEndpoint#asm_user}
        */
        readonly asmUser?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#authentication_method TfEndpoint#authentication_method}
        */
        readonly authenticationMethod?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#char_length_semantics TfEndpoint#char_length_semantics}
        */
        readonly charLengthSemantics?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#convert_timestamp_with_zone_to_utc TfEndpoint#convert_timestamp_with_zone_to_utc}
        */
        readonly convertTimestampWithZoneToUtc?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#direct_path_no_log TfEndpoint#direct_path_no_log}
        */
        readonly directPathNoLog?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#direct_path_parallel_load TfEndpoint#direct_path_parallel_load}
        */
        readonly directPathParallelLoad?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#enable_homogenous_tablespace TfEndpoint#enable_homogenous_tablespace}
        */
        readonly enableHomogenousTablespace?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#extra_archived_log_dest_ids TfEndpoint#extra_archived_log_dest_ids}
        */
        readonly extraArchivedLogDestIds?: number[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#fail_task_on_lob_truncation TfEndpoint#fail_task_on_lob_truncation}
        */
        readonly failTaskOnLobTruncation?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#number_datatype_scale TfEndpoint#number_datatype_scale}
        */
        readonly numberDatatypeScale?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#open_transaction_window TfEndpoint#open_transaction_window}
        */
        readonly openTransactionWindow?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#oracle_path_prefix TfEndpoint#oracle_path_prefix}
        */
        readonly oraclePathPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#parallel_asm_read_threads TfEndpoint#parallel_asm_read_threads}
        */
        readonly parallelAsmReadThreads?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#read_ahead_blocks TfEndpoint#read_ahead_blocks}
        */
        readonly readAheadBlocks?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#read_table_space_name TfEndpoint#read_table_space_name}
        */
        readonly readTableSpaceName?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#replace_path_prefix TfEndpoint#replace_path_prefix}
        */
        readonly replacePathPrefix?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#retry_interval TfEndpoint#retry_interval}
        */
        readonly retryInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#secrets_manager_oracle_asm_access_role_arn TfEndpoint#secrets_manager_oracle_asm_access_role_arn}
        */
        readonly secretsManagerOracleAsmAccessRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#secrets_manager_oracle_asm_secret_id TfEndpoint#secrets_manager_oracle_asm_secret_id}
        */
        readonly secretsManagerOracleAsmSecretId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#security_db_encryption TfEndpoint#security_db_encryption}
        */
        readonly securityDbEncryption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#security_db_encryption_name TfEndpoint#security_db_encryption_name}
        */
        readonly securityDbEncryptionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#spatial_data_option_to_geo_json_function_name TfEndpoint#spatial_data_option_to_geo_json_function_name}
        */
        readonly spatialDataOptionToGeoJsonFunctionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#standby_delay_time TfEndpoint#standby_delay_time}
        */
        readonly standbyDelayTime?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#trim_space_in_char TfEndpoint#trim_space_in_char}
        */
        readonly trimSpaceInChar?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#use_alternate_folder_for_online TfEndpoint#use_alternate_folder_for_online}
        */
        readonly useAlternateFolderForOnline?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#use_bfile TfEndpoint#use_bfile}
        */
        readonly useBfile?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#use_direct_path_full_load TfEndpoint#use_direct_path_full_load}
        */
        readonly useDirectPathFullLoad?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#use_logminer_reader TfEndpoint#use_logminer_reader}
        */
        readonly useLogminerReader?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#use_path_prefix TfEndpoint#use_path_prefix}
        */
        readonly usePathPrefix?: string;
    }
    class OracleSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OracleSettingsProperty | undefined;
        set internalValue(value: OracleSettingsProperty | undefined);
        private _accessAlternateDirectly?;
        get accessAlternateDirectly(): boolean | cdktn.IResolvable;
        set accessAlternateDirectly(value: boolean | cdktn.IResolvable);
        resetAccessAlternateDirectly(): void;
        get accessAlternateDirectlyInput(): boolean | cdktn.IResolvable | undefined;
        private _addSupplementalLogging?;
        get addSupplementalLogging(): boolean | cdktn.IResolvable;
        set addSupplementalLogging(value: boolean | cdktn.IResolvable);
        resetAddSupplementalLogging(): void;
        get addSupplementalLoggingInput(): boolean | cdktn.IResolvable | undefined;
        private _additionalArchivedLogDestId?;
        get additionalArchivedLogDestId(): number;
        set additionalArchivedLogDestId(value: number);
        resetAdditionalArchivedLogDestId(): void;
        get additionalArchivedLogDestIdInput(): number | undefined;
        private _allowSelectedNestedTables?;
        get allowSelectedNestedTables(): boolean | cdktn.IResolvable;
        set allowSelectedNestedTables(value: boolean | cdktn.IResolvable);
        resetAllowSelectedNestedTables(): void;
        get allowSelectedNestedTablesInput(): boolean | cdktn.IResolvable | undefined;
        private _archivedLogDestId?;
        get archivedLogDestId(): number;
        set archivedLogDestId(value: number);
        resetArchivedLogDestId(): void;
        get archivedLogDestIdInput(): number | undefined;
        private _archivedLogsOnly?;
        get archivedLogsOnly(): boolean | cdktn.IResolvable;
        set archivedLogsOnly(value: boolean | cdktn.IResolvable);
        resetArchivedLogsOnly(): void;
        get archivedLogsOnlyInput(): boolean | cdktn.IResolvable | undefined;
        private _asmPassword?;
        get asmPassword(): string;
        set asmPassword(value: string);
        resetAsmPassword(): void;
        get asmPasswordInput(): string | undefined;
        private _asmServer?;
        get asmServer(): string;
        set asmServer(value: string);
        resetAsmServer(): void;
        get asmServerInput(): string | undefined;
        private _asmUser?;
        get asmUser(): string;
        set asmUser(value: string);
        resetAsmUser(): void;
        get asmUserInput(): string | undefined;
        private _authenticationMethod?;
        get authenticationMethod(): string;
        set authenticationMethod(value: string);
        resetAuthenticationMethod(): void;
        get authenticationMethodInput(): string | undefined;
        private _charLengthSemantics?;
        get charLengthSemantics(): string;
        set charLengthSemantics(value: string);
        resetCharLengthSemantics(): void;
        get charLengthSemanticsInput(): string | undefined;
        private _convertTimestampWithZoneToUtc?;
        get convertTimestampWithZoneToUtc(): boolean | cdktn.IResolvable;
        set convertTimestampWithZoneToUtc(value: boolean | cdktn.IResolvable);
        resetConvertTimestampWithZoneToUtc(): void;
        get convertTimestampWithZoneToUtcInput(): boolean | cdktn.IResolvable | undefined;
        private _directPathNoLog?;
        get directPathNoLog(): boolean | cdktn.IResolvable;
        set directPathNoLog(value: boolean | cdktn.IResolvable);
        resetDirectPathNoLog(): void;
        get directPathNoLogInput(): boolean | cdktn.IResolvable | undefined;
        private _directPathParallelLoad?;
        get directPathParallelLoad(): boolean | cdktn.IResolvable;
        set directPathParallelLoad(value: boolean | cdktn.IResolvable);
        resetDirectPathParallelLoad(): void;
        get directPathParallelLoadInput(): boolean | cdktn.IResolvable | undefined;
        private _enableHomogenousTablespace?;
        get enableHomogenousTablespace(): boolean | cdktn.IResolvable;
        set enableHomogenousTablespace(value: boolean | cdktn.IResolvable);
        resetEnableHomogenousTablespace(): void;
        get enableHomogenousTablespaceInput(): boolean | cdktn.IResolvable | undefined;
        private _extraArchivedLogDestIds?;
        get extraArchivedLogDestIds(): number[];
        set extraArchivedLogDestIds(value: number[]);
        resetExtraArchivedLogDestIds(): void;
        get extraArchivedLogDestIdsInput(): number[] | undefined;
        private _failTaskOnLobTruncation?;
        get failTaskOnLobTruncation(): boolean | cdktn.IResolvable;
        set failTaskOnLobTruncation(value: boolean | cdktn.IResolvable);
        resetFailTaskOnLobTruncation(): void;
        get failTaskOnLobTruncationInput(): boolean | cdktn.IResolvable | undefined;
        private _numberDatatypeScale?;
        get numberDatatypeScale(): number;
        set numberDatatypeScale(value: number);
        resetNumberDatatypeScale(): void;
        get numberDatatypeScaleInput(): number | undefined;
        private _openTransactionWindow?;
        get openTransactionWindow(): number;
        set openTransactionWindow(value: number);
        resetOpenTransactionWindow(): void;
        get openTransactionWindowInput(): number | undefined;
        private _oraclePathPrefix?;
        get oraclePathPrefix(): string;
        set oraclePathPrefix(value: string);
        resetOraclePathPrefix(): void;
        get oraclePathPrefixInput(): string | undefined;
        private _parallelAsmReadThreads?;
        get parallelAsmReadThreads(): number;
        set parallelAsmReadThreads(value: number);
        resetParallelAsmReadThreads(): void;
        get parallelAsmReadThreadsInput(): number | undefined;
        private _readAheadBlocks?;
        get readAheadBlocks(): number;
        set readAheadBlocks(value: number);
        resetReadAheadBlocks(): void;
        get readAheadBlocksInput(): number | undefined;
        private _readTableSpaceName?;
        get readTableSpaceName(): boolean | cdktn.IResolvable;
        set readTableSpaceName(value: boolean | cdktn.IResolvable);
        resetReadTableSpaceName(): void;
        get readTableSpaceNameInput(): boolean | cdktn.IResolvable | undefined;
        private _replacePathPrefix?;
        get replacePathPrefix(): boolean | cdktn.IResolvable;
        set replacePathPrefix(value: boolean | cdktn.IResolvable);
        resetReplacePathPrefix(): void;
        get replacePathPrefixInput(): boolean | cdktn.IResolvable | undefined;
        private _retryInterval?;
        get retryInterval(): number;
        set retryInterval(value: number);
        resetRetryInterval(): void;
        get retryIntervalInput(): number | undefined;
        private _secretsManagerOracleAsmAccessRoleArn?;
        get secretsManagerOracleAsmAccessRoleArn(): string;
        set secretsManagerOracleAsmAccessRoleArn(value: string);
        resetSecretsManagerOracleAsmAccessRoleArn(): void;
        get secretsManagerOracleAsmAccessRoleArnInput(): string | undefined;
        private _secretsManagerOracleAsmSecretId?;
        get secretsManagerOracleAsmSecretId(): string;
        set secretsManagerOracleAsmSecretId(value: string);
        resetSecretsManagerOracleAsmSecretId(): void;
        get secretsManagerOracleAsmSecretIdInput(): string | undefined;
        private _securityDbEncryption?;
        get securityDbEncryption(): string;
        set securityDbEncryption(value: string);
        resetSecurityDbEncryption(): void;
        get securityDbEncryptionInput(): string | undefined;
        private _securityDbEncryptionName?;
        get securityDbEncryptionName(): string;
        set securityDbEncryptionName(value: string);
        resetSecurityDbEncryptionName(): void;
        get securityDbEncryptionNameInput(): string | undefined;
        private _spatialDataOptionToGeoJsonFunctionName?;
        get spatialDataOptionToGeoJsonFunctionName(): string;
        set spatialDataOptionToGeoJsonFunctionName(value: string);
        resetSpatialDataOptionToGeoJsonFunctionName(): void;
        get spatialDataOptionToGeoJsonFunctionNameInput(): string | undefined;
        private _standbyDelayTime?;
        get standbyDelayTime(): number;
        set standbyDelayTime(value: number);
        resetStandbyDelayTime(): void;
        get standbyDelayTimeInput(): number | undefined;
        private _trimSpaceInChar?;
        get trimSpaceInChar(): boolean | cdktn.IResolvable;
        set trimSpaceInChar(value: boolean | cdktn.IResolvable);
        resetTrimSpaceInChar(): void;
        get trimSpaceInCharInput(): boolean | cdktn.IResolvable | undefined;
        private _useAlternateFolderForOnline?;
        get useAlternateFolderForOnline(): boolean | cdktn.IResolvable;
        set useAlternateFolderForOnline(value: boolean | cdktn.IResolvable);
        resetUseAlternateFolderForOnline(): void;
        get useAlternateFolderForOnlineInput(): boolean | cdktn.IResolvable | undefined;
        private _useBfile?;
        get useBfile(): boolean | cdktn.IResolvable;
        set useBfile(value: boolean | cdktn.IResolvable);
        resetUseBfile(): void;
        get useBfileInput(): boolean | cdktn.IResolvable | undefined;
        private _useDirectPathFullLoad?;
        get useDirectPathFullLoad(): boolean | cdktn.IResolvable;
        set useDirectPathFullLoad(value: boolean | cdktn.IResolvable);
        resetUseDirectPathFullLoad(): void;
        get useDirectPathFullLoadInput(): boolean | cdktn.IResolvable | undefined;
        private _useLogminerReader?;
        get useLogminerReader(): boolean | cdktn.IResolvable;
        set useLogminerReader(value: boolean | cdktn.IResolvable);
        resetUseLogminerReader(): void;
        get useLogminerReaderInput(): boolean | cdktn.IResolvable | undefined;
        private _usePathPrefix?;
        get usePathPrefix(): string;
        set usePathPrefix(value: string);
        resetUsePathPrefix(): void;
        get usePathPrefixInput(): string | undefined;
    }
    interface PostgresSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#after_connect_script TfEndpoint#after_connect_script}
        */
        readonly afterConnectScript?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#authentication_method TfEndpoint#authentication_method}
        */
        readonly authenticationMethod?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#babelfish_database_name TfEndpoint#babelfish_database_name}
        */
        readonly babelfishDatabaseName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#capture_ddls TfEndpoint#capture_ddls}
        */
        readonly captureDdls?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#database_mode TfEndpoint#database_mode}
        */
        readonly databaseMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#ddl_artifacts_schema TfEndpoint#ddl_artifacts_schema}
        */
        readonly ddlArtifactsSchema?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#execute_timeout TfEndpoint#execute_timeout}
        */
        readonly executeTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#fail_tasks_on_lob_truncation TfEndpoint#fail_tasks_on_lob_truncation}
        */
        readonly failTasksOnLobTruncation?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#heartbeat_enable TfEndpoint#heartbeat_enable}
        */
        readonly heartbeatEnable?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#heartbeat_frequency TfEndpoint#heartbeat_frequency}
        */
        readonly heartbeatFrequency?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#heartbeat_schema TfEndpoint#heartbeat_schema}
        */
        readonly heartbeatSchema?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#map_boolean_as_boolean TfEndpoint#map_boolean_as_boolean}
        */
        readonly mapBooleanAsBoolean?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#map_jsonb_as_clob TfEndpoint#map_jsonb_as_clob}
        */
        readonly mapJsonbAsClob?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#map_long_varchar_as TfEndpoint#map_long_varchar_as}
        */
        readonly mapLongVarcharAs?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#max_file_size TfEndpoint#max_file_size}
        */
        readonly maxFileSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#plugin_name TfEndpoint#plugin_name}
        */
        readonly pluginName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#service_access_role_arn TfEndpoint#service_access_role_arn}
        */
        readonly serviceAccessRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#slot_name TfEndpoint#slot_name}
        */
        readonly slotName?: string;
    }
    class PostgresSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PostgresSettingsProperty | undefined;
        set internalValue(value: PostgresSettingsProperty | undefined);
        private _afterConnectScript?;
        get afterConnectScript(): string;
        set afterConnectScript(value: string);
        resetAfterConnectScript(): void;
        get afterConnectScriptInput(): string | undefined;
        private _authenticationMethod?;
        get authenticationMethod(): string;
        set authenticationMethod(value: string);
        resetAuthenticationMethod(): void;
        get authenticationMethodInput(): string | undefined;
        private _babelfishDatabaseName?;
        get babelfishDatabaseName(): string;
        set babelfishDatabaseName(value: string);
        resetBabelfishDatabaseName(): void;
        get babelfishDatabaseNameInput(): string | undefined;
        private _captureDdls?;
        get captureDdls(): boolean | cdktn.IResolvable;
        set captureDdls(value: boolean | cdktn.IResolvable);
        resetCaptureDdls(): void;
        get captureDdlsInput(): boolean | cdktn.IResolvable | undefined;
        private _databaseMode?;
        get databaseMode(): string;
        set databaseMode(value: string);
        resetDatabaseMode(): void;
        get databaseModeInput(): string | undefined;
        private _ddlArtifactsSchema?;
        get ddlArtifactsSchema(): string;
        set ddlArtifactsSchema(value: string);
        resetDdlArtifactsSchema(): void;
        get ddlArtifactsSchemaInput(): string | undefined;
        private _executeTimeout?;
        get executeTimeout(): number;
        set executeTimeout(value: number);
        resetExecuteTimeout(): void;
        get executeTimeoutInput(): number | undefined;
        private _failTasksOnLobTruncation?;
        get failTasksOnLobTruncation(): boolean | cdktn.IResolvable;
        set failTasksOnLobTruncation(value: boolean | cdktn.IResolvable);
        resetFailTasksOnLobTruncation(): void;
        get failTasksOnLobTruncationInput(): boolean | cdktn.IResolvable | undefined;
        private _heartbeatEnable?;
        get heartbeatEnable(): boolean | cdktn.IResolvable;
        set heartbeatEnable(value: boolean | cdktn.IResolvable);
        resetHeartbeatEnable(): void;
        get heartbeatEnableInput(): boolean | cdktn.IResolvable | undefined;
        private _heartbeatFrequency?;
        get heartbeatFrequency(): number;
        set heartbeatFrequency(value: number);
        resetHeartbeatFrequency(): void;
        get heartbeatFrequencyInput(): number | undefined;
        private _heartbeatSchema?;
        get heartbeatSchema(): string;
        set heartbeatSchema(value: string);
        resetHeartbeatSchema(): void;
        get heartbeatSchemaInput(): string | undefined;
        private _mapBooleanAsBoolean?;
        get mapBooleanAsBoolean(): boolean | cdktn.IResolvable;
        set mapBooleanAsBoolean(value: boolean | cdktn.IResolvable);
        resetMapBooleanAsBoolean(): void;
        get mapBooleanAsBooleanInput(): boolean | cdktn.IResolvable | undefined;
        private _mapJsonbAsClob?;
        get mapJsonbAsClob(): boolean | cdktn.IResolvable;
        set mapJsonbAsClob(value: boolean | cdktn.IResolvable);
        resetMapJsonbAsClob(): void;
        get mapJsonbAsClobInput(): boolean | cdktn.IResolvable | undefined;
        private _mapLongVarcharAs?;
        get mapLongVarcharAs(): string;
        set mapLongVarcharAs(value: string);
        resetMapLongVarcharAs(): void;
        get mapLongVarcharAsInput(): string | undefined;
        private _maxFileSize?;
        get maxFileSize(): number;
        set maxFileSize(value: number);
        resetMaxFileSize(): void;
        get maxFileSizeInput(): number | undefined;
        private _pluginName?;
        get pluginName(): string;
        set pluginName(value: string);
        resetPluginName(): void;
        get pluginNameInput(): string | undefined;
        private _serviceAccessRoleArn?;
        get serviceAccessRoleArn(): string;
        set serviceAccessRoleArn(value: string);
        resetServiceAccessRoleArn(): void;
        get serviceAccessRoleArnInput(): string | undefined;
        private _slotName?;
        get slotName(): string;
        set slotName(value: string);
        resetSlotName(): void;
        get slotNameInput(): string | undefined;
    }
    interface RedisSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#auth_password TfEndpoint#auth_password}
        */
        readonly authPassword?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#auth_type TfEndpoint#auth_type}
        */
        readonly authType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#auth_user_name TfEndpoint#auth_user_name}
        */
        readonly authUserName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#port TfEndpoint#port}
        */
        readonly port: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#server_name TfEndpoint#server_name}
        */
        readonly serverName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#ssl_ca_certificate_arn TfEndpoint#ssl_ca_certificate_arn}
        */
        readonly sslCaCertificateArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#ssl_security_protocol TfEndpoint#ssl_security_protocol}
        */
        readonly sslSecurityProtocol?: string;
    }
    class RedisSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedisSettingsProperty | undefined;
        set internalValue(value: RedisSettingsProperty | undefined);
        private _authPassword?;
        get authPassword(): string;
        set authPassword(value: string);
        resetAuthPassword(): void;
        get authPasswordInput(): string | undefined;
        private _authType?;
        get authType(): string;
        set authType(value: string);
        get authTypeInput(): string | undefined;
        private _authUserName?;
        get authUserName(): string;
        set authUserName(value: string);
        resetAuthUserName(): void;
        get authUserNameInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
        private _serverName?;
        get serverName(): string;
        set serverName(value: string);
        get serverNameInput(): string | undefined;
        private _sslCaCertificateArn?;
        get sslCaCertificateArn(): string;
        set sslCaCertificateArn(value: string);
        resetSslCaCertificateArn(): void;
        get sslCaCertificateArnInput(): string | undefined;
        private _sslSecurityProtocol?;
        get sslSecurityProtocol(): string;
        set sslSecurityProtocol(value: string);
        resetSslSecurityProtocol(): void;
        get sslSecurityProtocolInput(): string | undefined;
    }
    interface RedshiftSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#bucket_folder TfEndpoint#bucket_folder}
        */
        readonly bucketFolder?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#bucket_name TfEndpoint#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#encryption_mode TfEndpoint#encryption_mode}
        */
        readonly encryptionMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#server_side_encryption_kms_key_id TfEndpoint#server_side_encryption_kms_key_id}
        */
        readonly serverSideEncryptionKmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#service_access_role_arn TfEndpoint#service_access_role_arn}
        */
        readonly serviceAccessRoleArn?: string;
    }
    class RedshiftSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedshiftSettingsProperty | undefined;
        set internalValue(value: RedshiftSettingsProperty | undefined);
        private _bucketFolder?;
        get bucketFolder(): string;
        set bucketFolder(value: string);
        resetBucketFolder(): void;
        get bucketFolderInput(): string | undefined;
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _encryptionMode?;
        get encryptionMode(): string;
        set encryptionMode(value: string);
        resetEncryptionMode(): void;
        get encryptionModeInput(): string | undefined;
        private _serverSideEncryptionKmsKeyId?;
        get serverSideEncryptionKmsKeyId(): string;
        set serverSideEncryptionKmsKeyId(value: string);
        resetServerSideEncryptionKmsKeyId(): void;
        get serverSideEncryptionKmsKeyIdInput(): string | undefined;
        private _serviceAccessRoleArn?;
        get serviceAccessRoleArn(): string;
        set serviceAccessRoleArn(value: string);
        resetServiceAccessRoleArn(): void;
        get serviceAccessRoleArnInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#create TfEndpoint#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/dms_endpoint#delete TfEndpoint#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
