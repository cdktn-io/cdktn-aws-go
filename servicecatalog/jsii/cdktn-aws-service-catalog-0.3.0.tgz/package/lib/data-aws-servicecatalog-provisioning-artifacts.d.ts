import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsProvisioningArtifactsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_provisioning_artifacts#accept_language DataAwsProvisioningArtifacts#accept_language}
    */
    readonly acceptLanguage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_provisioning_artifacts#id DataAwsProvisioningArtifacts#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_provisioning_artifacts#product_id DataAwsProvisioningArtifacts#product_id}
    */
    readonly productId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_provisioning_artifacts#region DataAwsProvisioningArtifacts#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_provisioning_artifacts#timeouts DataAwsProvisioningArtifacts#timeouts}
    */
    readonly timeouts?: DataAwsProvisioningArtifacts.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_provisioning_artifacts aws_servicecatalog_provisioning_artifacts}
*/
export declare class DataAwsProvisioningArtifacts extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_servicecatalog_provisioning_artifacts";
    /**
    * Generates CDKTN code for importing a DataAwsProvisioningArtifacts resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsProvisioningArtifacts to import
    * @param importFromId The id of the existing DataAwsProvisioningArtifacts that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_provisioning_artifacts#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsProvisioningArtifacts to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_provisioning_artifacts aws_servicecatalog_provisioning_artifacts} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsProvisioningArtifactsConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsProvisioningArtifactsConfig);
    private _acceptLanguage?;
    get acceptLanguage(): string;
    set acceptLanguage(value: string);
    resetAcceptLanguage(): void;
    get acceptLanguageInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _productId?;
    get productId(): string;
    set productId(value: string);
    get productIdInput(): string | undefined;
    private _provisioningArtifactDetails;
    get provisioningArtifactDetails(): DataAwsProvisioningArtifacts.ProvisioningArtifactDetailsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataAwsProvisioningArtifacts.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataAwsProvisioningArtifacts.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAwsProvisioningArtifacts.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsProvisioningArtifactsProvisioningArtifactDetailsPropertyToTerraform(struct?: DataAwsProvisioningArtifacts.ProvisioningArtifactDetailsProperty): any;
export declare function dataAwsProvisioningArtifactsProvisioningArtifactDetailsPropertyToHclTerraform(struct?: DataAwsProvisioningArtifacts.ProvisioningArtifactDetailsProperty): any;
export declare function dataAwsProvisioningArtifactsTimeoutsPropertyToTerraform(struct?: DataAwsProvisioningArtifacts.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataAwsProvisioningArtifactsTimeoutsPropertyToHclTerraform(struct?: DataAwsProvisioningArtifacts.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataAwsProvisioningArtifacts {
    interface ProvisioningArtifactDetailsProperty {
    }
    class ProvisioningArtifactDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProvisioningArtifactDetailsProperty | undefined;
        set internalValue(value: ProvisioningArtifactDetailsProperty | undefined);
        get active(): cdktn.IResolvable;
        get createdTime(): string;
        get description(): string;
        get guidance(): string;
        get id(): string;
        get name(): string;
        get type(): string;
    }
    class ProvisioningArtifactDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProvisioningArtifactDetailsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/servicecatalog_provisioning_artifacts#read DataAwsProvisioningArtifacts#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
