import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsProvisionedProductConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#accept_language AwsProvisionedProduct#accept_language}
    */
    readonly acceptLanguage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#id AwsProvisionedProduct#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#ignore_errors AwsProvisionedProduct#ignore_errors}
    */
    readonly ignoreErrors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#name AwsProvisionedProduct#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#notification_arns AwsProvisionedProduct#notification_arns}
    */
    readonly notificationArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#path_id AwsProvisionedProduct#path_id}
    */
    readonly pathId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#path_name AwsProvisionedProduct#path_name}
    */
    readonly pathName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#product_id AwsProvisionedProduct#product_id}
    */
    readonly productId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#product_name AwsProvisionedProduct#product_name}
    */
    readonly productName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#provisioning_artifact_id AwsProvisionedProduct#provisioning_artifact_id}
    */
    readonly provisioningArtifactId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#provisioning_artifact_name AwsProvisionedProduct#provisioning_artifact_name}
    */
    readonly provisioningArtifactName?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#region AwsProvisionedProduct#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#retain_physical_resources AwsProvisionedProduct#retain_physical_resources}
    */
    readonly retainPhysicalResources?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#tags AwsProvisionedProduct#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#tags_all AwsProvisionedProduct#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * provisioning_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#provisioning_parameters AwsProvisionedProduct#provisioning_parameters}
    */
    readonly provisioningParameters?: AwsProvisionedProduct.ProvisioningParametersProperty[] | cdktn.IResolvable;
    /**
    * stack_set_provisioning_preferences block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#stack_set_provisioning_preferences AwsProvisionedProduct#stack_set_provisioning_preferences}
    */
    readonly stackSetProvisioningPreferences?: AwsProvisionedProduct.StackSetProvisioningPreferencesProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#timeouts AwsProvisionedProduct#timeouts}
    */
    readonly timeouts?: AwsProvisionedProduct.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product aws_servicecatalog_provisioned_product}
*/
export declare class AwsProvisionedProduct extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_servicecatalog_provisioned_product";
    /**
    * Generates CDKTN code for importing a AwsProvisionedProduct resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsProvisionedProduct to import
    * @param importFromId The id of the existing AwsProvisionedProduct that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsProvisionedProduct to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product aws_servicecatalog_provisioned_product} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsProvisionedProductConfig
    */
    constructor(scope: Construct, id: string, config: AwsProvisionedProductConfig);
    private _acceptLanguage?;
    get acceptLanguage(): string;
    set acceptLanguage(value: string);
    resetAcceptLanguage(): void;
    get acceptLanguageInput(): string | undefined;
    get arn(): string;
    get cloudwatchDashboardNames(): string[];
    get createdTime(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreErrors?;
    get ignoreErrors(): boolean | cdktn.IResolvable;
    set ignoreErrors(value: boolean | cdktn.IResolvable);
    resetIgnoreErrors(): void;
    get ignoreErrorsInput(): boolean | cdktn.IResolvable | undefined;
    get lastProvisioningRecordId(): string;
    get lastRecordId(): string;
    get lastSuccessfulProvisioningRecordId(): string;
    get launchRoleArn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _notificationArns?;
    get notificationArns(): string[];
    set notificationArns(value: string[]);
    resetNotificationArns(): void;
    get notificationArnsInput(): string[] | undefined;
    private _outputs;
    get outputs(): AwsProvisionedProduct.OutputsPropertyList;
    private _pathId?;
    get pathId(): string;
    set pathId(value: string);
    resetPathId(): void;
    get pathIdInput(): string | undefined;
    private _pathName?;
    get pathName(): string;
    set pathName(value: string);
    resetPathName(): void;
    get pathNameInput(): string | undefined;
    private _productId?;
    get productId(): string;
    set productId(value: string);
    resetProductId(): void;
    get productIdInput(): string | undefined;
    private _productName?;
    get productName(): string;
    set productName(value: string);
    resetProductName(): void;
    get productNameInput(): string | undefined;
    private _provisioningArtifactId?;
    get provisioningArtifactId(): string;
    set provisioningArtifactId(value: string);
    resetProvisioningArtifactId(): void;
    get provisioningArtifactIdInput(): string | undefined;
    private _provisioningArtifactName?;
    get provisioningArtifactName(): string;
    set provisioningArtifactName(value: string);
    resetProvisioningArtifactName(): void;
    get provisioningArtifactNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _retainPhysicalResources?;
    get retainPhysicalResources(): boolean | cdktn.IResolvable;
    set retainPhysicalResources(value: boolean | cdktn.IResolvable);
    resetRetainPhysicalResources(): void;
    get retainPhysicalResourcesInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    get statusMessage(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get type(): string;
    private _provisioningParameters;
    get provisioningParameters(): AwsProvisionedProduct.ProvisioningParametersPropertyList;
    putProvisioningParameters(value: AwsProvisionedProduct.ProvisioningParametersProperty[] | cdktn.IResolvable): void;
    resetProvisioningParameters(): void;
    get provisioningParametersInput(): cdktn.IResolvable | AwsProvisionedProduct.ProvisioningParametersProperty[] | undefined;
    private _stackSetProvisioningPreferences;
    get stackSetProvisioningPreferences(): AwsProvisionedProduct.StackSetProvisioningPreferencesPropertyOutputReference;
    putStackSetProvisioningPreferences(value: AwsProvisionedProduct.StackSetProvisioningPreferencesProperty): void;
    resetStackSetProvisioningPreferences(): void;
    get stackSetProvisioningPreferencesInput(): AwsProvisionedProduct.StackSetProvisioningPreferencesProperty | undefined;
    private _timeouts;
    get timeouts(): AwsProvisionedProduct.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsProvisionedProduct.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsProvisionedProduct.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsProvisionedProductOutputsPropertyToTerraform(struct?: AwsProvisionedProduct.OutputsProperty): any;
export declare function awsProvisionedProductOutputsPropertyToHclTerraform(struct?: AwsProvisionedProduct.OutputsProperty): any;
export declare function awsProvisionedProductProvisioningParametersPropertyToTerraform(struct?: AwsProvisionedProduct.ProvisioningParametersProperty | cdktn.IResolvable): any;
export declare function awsProvisionedProductProvisioningParametersPropertyToHclTerraform(struct?: AwsProvisionedProduct.ProvisioningParametersProperty | cdktn.IResolvable): any;
export declare function awsProvisionedProductStackSetProvisioningPreferencesPropertyToTerraform(struct?: AwsProvisionedProduct.StackSetProvisioningPreferencesPropertyOutputReference | AwsProvisionedProduct.StackSetProvisioningPreferencesProperty): any;
export declare function awsProvisionedProductStackSetProvisioningPreferencesPropertyToHclTerraform(struct?: AwsProvisionedProduct.StackSetProvisioningPreferencesPropertyOutputReference | AwsProvisionedProduct.StackSetProvisioningPreferencesProperty): any;
export declare function awsProvisionedProductTimeoutsPropertyToTerraform(struct?: AwsProvisionedProduct.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsProvisionedProductTimeoutsPropertyToHclTerraform(struct?: AwsProvisionedProduct.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsProvisionedProduct {
    interface OutputsProperty {
    }
    class OutputsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputsProperty | undefined;
        set internalValue(value: OutputsProperty | undefined);
        get description(): string;
        get key(): string;
        get value(): string;
    }
    class OutputsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputsPropertyOutputReference;
    }
    interface ProvisioningParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#key AwsProvisionedProduct#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#use_previous_value AwsProvisionedProduct#use_previous_value}
        */
        readonly usePreviousValue?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#value AwsProvisionedProduct#value}
        */
        readonly value?: string;
    }
    class ProvisioningParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProvisioningParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProvisioningParametersProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _usePreviousValue?;
        get usePreviousValue(): boolean | cdktn.IResolvable;
        set usePreviousValue(value: boolean | cdktn.IResolvable);
        resetUsePreviousValue(): void;
        get usePreviousValueInput(): boolean | cdktn.IResolvable | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class ProvisioningParametersPropertyList extends cdktn.ComplexList {
        internalValue?: ProvisioningParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProvisioningParametersPropertyOutputReference;
    }
    interface StackSetProvisioningPreferencesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#accounts AwsProvisionedProduct#accounts}
        */
        readonly accounts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#failure_tolerance_count AwsProvisionedProduct#failure_tolerance_count}
        */
        readonly failureToleranceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#failure_tolerance_percentage AwsProvisionedProduct#failure_tolerance_percentage}
        */
        readonly failureTolerancePercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#max_concurrency_count AwsProvisionedProduct#max_concurrency_count}
        */
        readonly maxConcurrencyCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#max_concurrency_percentage AwsProvisionedProduct#max_concurrency_percentage}
        */
        readonly maxConcurrencyPercentage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#regions AwsProvisionedProduct#regions}
        */
        readonly regions?: string[];
    }
    class StackSetProvisioningPreferencesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StackSetProvisioningPreferencesProperty | undefined;
        set internalValue(value: StackSetProvisioningPreferencesProperty | undefined);
        private _accounts?;
        get accounts(): string[];
        set accounts(value: string[]);
        resetAccounts(): void;
        get accountsInput(): string[] | undefined;
        private _failureToleranceCount?;
        get failureToleranceCount(): number;
        set failureToleranceCount(value: number);
        resetFailureToleranceCount(): void;
        get failureToleranceCountInput(): number | undefined;
        private _failureTolerancePercentage?;
        get failureTolerancePercentage(): number;
        set failureTolerancePercentage(value: number);
        resetFailureTolerancePercentage(): void;
        get failureTolerancePercentageInput(): number | undefined;
        private _maxConcurrencyCount?;
        get maxConcurrencyCount(): number;
        set maxConcurrencyCount(value: number);
        resetMaxConcurrencyCount(): void;
        get maxConcurrencyCountInput(): number | undefined;
        private _maxConcurrencyPercentage?;
        get maxConcurrencyPercentage(): number;
        set maxConcurrencyPercentage(value: number);
        resetMaxConcurrencyPercentage(): void;
        get maxConcurrencyPercentageInput(): number | undefined;
        private _regions?;
        get regions(): string[];
        set regions(value: string[]);
        resetRegions(): void;
        get regionsInput(): string[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#create AwsProvisionedProduct#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#delete AwsProvisionedProduct#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#read AwsProvisionedProduct#read}
        */
        readonly read?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/servicecatalog_provisioned_product#update AwsProvisionedProduct#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
