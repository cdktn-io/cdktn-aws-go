import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfRepositoryAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#id TfRepositoryAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#region TfRepositoryAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#tags TfRepositoryAssociation#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#tags_all TfRepositoryAssociation#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * kms_key_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#kms_key_details TfRepositoryAssociation#kms_key_details}
    */
    readonly kmsKeyDetails?: TfRepositoryAssociation.KmsKeyDetailsProperty;
    /**
    * repository block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#repository TfRepositoryAssociation#repository}
    */
    readonly repository: TfRepositoryAssociation.RepositoryProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#timeouts TfRepositoryAssociation#timeouts}
    */
    readonly timeouts?: TfRepositoryAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association aws_codegurureviewer_repository_association}
*/
export declare class TfRepositoryAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codegurureviewer_repository_association";
    /**
    * Generates CDKTN code for importing a TfRepositoryAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfRepositoryAssociation to import
    * @param importFromId The id of the existing TfRepositoryAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfRepositoryAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association aws_codegurureviewer_repository_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfRepositoryAssociationConfig
    */
    constructor(scope: Construct, id: string, config: TfRepositoryAssociationConfig);
    get arn(): string;
    get associationId(): string;
    get connectionArn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    get owner(): string;
    get providerType(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _s3RepositoryDetails;
    get s3RepositoryDetails(): TfRepositoryAssociation.S3RepositoryDetailsPropertyList;
    get state(): string;
    get stateReason(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _kmsKeyDetails;
    get kmsKeyDetails(): TfRepositoryAssociation.KmsKeyDetailsPropertyOutputReference;
    putKmsKeyDetails(value: TfRepositoryAssociation.KmsKeyDetailsProperty): void;
    resetKmsKeyDetails(): void;
    get kmsKeyDetailsInput(): TfRepositoryAssociation.KmsKeyDetailsProperty | undefined;
    private _repository;
    get repository(): TfRepositoryAssociation.RepositoryPropertyOutputReference;
    putRepository(value: TfRepositoryAssociation.RepositoryProperty): void;
    get repositoryInput(): TfRepositoryAssociation.RepositoryProperty | undefined;
    private _timeouts;
    get timeouts(): TfRepositoryAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfRepositoryAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): TfRepositoryAssociation.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfRepositoryAssociationCodeArtifactsPropertyToTerraform(struct?: TfRepositoryAssociation.CodeArtifactsProperty): any;
export declare function tfRepositoryAssociationCodeArtifactsPropertyToHclTerraform(struct?: TfRepositoryAssociation.CodeArtifactsProperty): any;
export declare function tfRepositoryAssociationS3RepositoryDetailsPropertyToTerraform(struct?: TfRepositoryAssociation.S3RepositoryDetailsProperty): any;
export declare function tfRepositoryAssociationS3RepositoryDetailsPropertyToHclTerraform(struct?: TfRepositoryAssociation.S3RepositoryDetailsProperty): any;
export declare function tfRepositoryAssociationKmsKeyDetailsPropertyToTerraform(struct?: TfRepositoryAssociation.KmsKeyDetailsPropertyOutputReference | TfRepositoryAssociation.KmsKeyDetailsProperty): any;
export declare function tfRepositoryAssociationKmsKeyDetailsPropertyToHclTerraform(struct?: TfRepositoryAssociation.KmsKeyDetailsPropertyOutputReference | TfRepositoryAssociation.KmsKeyDetailsProperty): any;
export declare function tfRepositoryAssociationBitbucketPropertyToTerraform(struct?: TfRepositoryAssociation.BitbucketPropertyOutputReference | TfRepositoryAssociation.BitbucketProperty): any;
export declare function tfRepositoryAssociationBitbucketPropertyToHclTerraform(struct?: TfRepositoryAssociation.BitbucketPropertyOutputReference | TfRepositoryAssociation.BitbucketProperty): any;
export declare function tfRepositoryAssociationCodecommitPropertyToTerraform(struct?: TfRepositoryAssociation.CodecommitPropertyOutputReference | TfRepositoryAssociation.CodecommitProperty): any;
export declare function tfRepositoryAssociationCodecommitPropertyToHclTerraform(struct?: TfRepositoryAssociation.CodecommitPropertyOutputReference | TfRepositoryAssociation.CodecommitProperty): any;
export declare function tfRepositoryAssociationGithubEnterpriseServerPropertyToTerraform(struct?: TfRepositoryAssociation.GithubEnterpriseServerPropertyOutputReference | TfRepositoryAssociation.GithubEnterpriseServerProperty): any;
export declare function tfRepositoryAssociationGithubEnterpriseServerPropertyToHclTerraform(struct?: TfRepositoryAssociation.GithubEnterpriseServerPropertyOutputReference | TfRepositoryAssociation.GithubEnterpriseServerProperty): any;
export declare function tfRepositoryAssociationS3BucketPropertyToTerraform(struct?: TfRepositoryAssociation.S3BucketPropertyOutputReference | TfRepositoryAssociation.S3BucketProperty): any;
export declare function tfRepositoryAssociationS3BucketPropertyToHclTerraform(struct?: TfRepositoryAssociation.S3BucketPropertyOutputReference | TfRepositoryAssociation.S3BucketProperty): any;
export declare function tfRepositoryAssociationRepositoryPropertyToTerraform(struct?: TfRepositoryAssociation.RepositoryPropertyOutputReference | TfRepositoryAssociation.RepositoryProperty): any;
export declare function tfRepositoryAssociationRepositoryPropertyToHclTerraform(struct?: TfRepositoryAssociation.RepositoryPropertyOutputReference | TfRepositoryAssociation.RepositoryProperty): any;
export declare function tfRepositoryAssociationTimeoutsPropertyToTerraform(struct?: TfRepositoryAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfRepositoryAssociationTimeoutsPropertyToHclTerraform(struct?: TfRepositoryAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfRepositoryAssociation {
    interface CodeArtifactsProperty {
    }
    class CodeArtifactsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CodeArtifactsProperty | undefined;
        set internalValue(value: CodeArtifactsProperty | undefined);
        get buildArtifactsObjectKey(): string;
        get sourceCodeArtifactsObjectKey(): string;
    }
    class CodeArtifactsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CodeArtifactsPropertyOutputReference;
    }
    interface S3RepositoryDetailsProperty {
    }
    class S3RepositoryDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3RepositoryDetailsProperty | undefined;
        set internalValue(value: S3RepositoryDetailsProperty | undefined);
        get bucketName(): string;
        private _codeArtifacts;
        get codeArtifacts(): CodeArtifactsPropertyList;
    }
    class S3RepositoryDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3RepositoryDetailsPropertyOutputReference;
    }
    interface KmsKeyDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#encryption_option TfRepositoryAssociation#encryption_option}
        */
        readonly encryptionOption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#kms_key_id TfRepositoryAssociation#kms_key_id}
        */
        readonly kmsKeyId?: string;
    }
    class KmsKeyDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KmsKeyDetailsProperty | undefined;
        set internalValue(value: KmsKeyDetailsProperty | undefined);
        private _encryptionOption?;
        get encryptionOption(): string;
        set encryptionOption(value: string);
        resetEncryptionOption(): void;
        get encryptionOptionInput(): string | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
    }
    interface BitbucketProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#connection_arn TfRepositoryAssociation#connection_arn}
        */
        readonly connectionArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#name TfRepositoryAssociation#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#owner TfRepositoryAssociation#owner}
        */
        readonly owner: string;
    }
    class BitbucketPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BitbucketProperty | undefined;
        set internalValue(value: BitbucketProperty | undefined);
        private _connectionArn?;
        get connectionArn(): string;
        set connectionArn(value: string);
        get connectionArnInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _owner?;
        get owner(): string;
        set owner(value: string);
        get ownerInput(): string | undefined;
    }
    interface CodecommitProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#name TfRepositoryAssociation#name}
        */
        readonly name: string;
    }
    class CodecommitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodecommitProperty | undefined;
        set internalValue(value: CodecommitProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    interface GithubEnterpriseServerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#connection_arn TfRepositoryAssociation#connection_arn}
        */
        readonly connectionArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#name TfRepositoryAssociation#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#owner TfRepositoryAssociation#owner}
        */
        readonly owner: string;
    }
    class GithubEnterpriseServerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GithubEnterpriseServerProperty | undefined;
        set internalValue(value: GithubEnterpriseServerProperty | undefined);
        private _connectionArn?;
        get connectionArn(): string;
        set connectionArn(value: string);
        get connectionArnInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _owner?;
        get owner(): string;
        set owner(value: string);
        get ownerInput(): string | undefined;
    }
    interface S3BucketProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#bucket_name TfRepositoryAssociation#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#name TfRepositoryAssociation#name}
        */
        readonly name: string;
    }
    class S3BucketPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3BucketProperty | undefined;
        set internalValue(value: S3BucketProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    interface RepositoryProperty {
        /**
        * bitbucket block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#bitbucket TfRepositoryAssociation#bitbucket}
        */
        readonly bitbucket?: BitbucketProperty;
        /**
        * codecommit block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#codecommit TfRepositoryAssociation#codecommit}
        */
        readonly codecommit?: CodecommitProperty;
        /**
        * github_enterprise_server block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#github_enterprise_server TfRepositoryAssociation#github_enterprise_server}
        */
        readonly githubEnterpriseServer?: GithubEnterpriseServerProperty;
        /**
        * s3_bucket block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#s3_bucket TfRepositoryAssociation#s3_bucket}
        */
        readonly s3Bucket?: S3BucketProperty;
    }
    class RepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RepositoryProperty | undefined;
        set internalValue(value: RepositoryProperty | undefined);
        private _bitbucket;
        get bitbucket(): BitbucketPropertyOutputReference;
        putBitbucket(value: BitbucketProperty): void;
        resetBitbucket(): void;
        get bitbucketInput(): BitbucketProperty | undefined;
        private _codecommit;
        get codecommit(): CodecommitPropertyOutputReference;
        putCodecommit(value: CodecommitProperty): void;
        resetCodecommit(): void;
        get codecommitInput(): CodecommitProperty | undefined;
        private _githubEnterpriseServer;
        get githubEnterpriseServer(): GithubEnterpriseServerPropertyOutputReference;
        putGithubEnterpriseServer(value: GithubEnterpriseServerProperty): void;
        resetGithubEnterpriseServer(): void;
        get githubEnterpriseServerInput(): GithubEnterpriseServerProperty | undefined;
        private _s3Bucket;
        get s3Bucket(): S3BucketPropertyOutputReference;
        putS3Bucket(value: S3BucketProperty): void;
        resetS3Bucket(): void;
        get s3BucketInput(): S3BucketProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#create TfRepositoryAssociation#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#delete TfRepositoryAssociation#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codegurureviewer_repository_association#update TfRepositoryAssociation#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
