import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVaultLockConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glacier_vault_lock#complete_lock AwsVaultLock#complete_lock}
    */
    readonly completeLock: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glacier_vault_lock#id AwsVaultLock#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glacier_vault_lock#ignore_deletion_error AwsVaultLock#ignore_deletion_error}
    */
    readonly ignoreDeletionError?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glacier_vault_lock#policy AwsVaultLock#policy}
    */
    readonly policy: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glacier_vault_lock#region AwsVaultLock#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glacier_vault_lock#vault_name AwsVaultLock#vault_name}
    */
    readonly vaultName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glacier_vault_lock aws_glacier_vault_lock}
*/
export declare class AwsVaultLock extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_glacier_vault_lock";
    /**
    * Generates CDKTN code for importing a AwsVaultLock resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVaultLock to import
    * @param importFromId The id of the existing AwsVaultLock that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glacier_vault_lock#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVaultLock to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/glacier_vault_lock aws_glacier_vault_lock} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVaultLockConfig
    */
    constructor(scope: Construct, id: string, config: AwsVaultLockConfig);
    private _completeLock?;
    get completeLock(): boolean | cdktn.IResolvable;
    set completeLock(value: boolean | cdktn.IResolvable);
    get completeLockInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreDeletionError?;
    get ignoreDeletionError(): boolean | cdktn.IResolvable;
    set ignoreDeletionError(value: boolean | cdktn.IResolvable);
    resetIgnoreDeletionError(): void;
    get ignoreDeletionErrorInput(): boolean | cdktn.IResolvable | undefined;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    get policyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _vaultName?;
    get vaultName(): string;
    set vaultName(value: string);
    get vaultNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
