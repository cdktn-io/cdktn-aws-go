import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfSigningJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_job#id TfSigningJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_job#ignore_signing_job_failure TfSigningJob#ignore_signing_job_failure}
    */
    readonly ignoreSigningJobFailure?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_job#profile_name TfSigningJob#profile_name}
    */
    readonly profileName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_job#region TfSigningJob#region}
    */
    readonly region?: string;
    /**
    * destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_job#destination TfSigningJob#destination}
    */
    readonly destination: TfSigningJob.DestinationProperty;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_job#source TfSigningJob#source}
    */
    readonly source: TfSigningJob.SourceProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_job aws_signer_signing_job}
*/
export declare class TfSigningJob extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_signer_signing_job";
    /**
    * Generates CDKTN code for importing a TfSigningJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfSigningJob to import
    * @param importFromId The id of the existing TfSigningJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfSigningJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_job aws_signer_signing_job} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfSigningJobConfig
    */
    constructor(scope: Construct, id: string, config: TfSigningJobConfig);
    get completedAt(): string;
    get createdAt(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreSigningJobFailure?;
    get ignoreSigningJobFailure(): boolean | cdktn.IResolvable;
    set ignoreSigningJobFailure(value: boolean | cdktn.IResolvable);
    resetIgnoreSigningJobFailure(): void;
    get ignoreSigningJobFailureInput(): boolean | cdktn.IResolvable | undefined;
    get jobId(): string;
    get jobInvoker(): string;
    get jobOwner(): string;
    get platformDisplayName(): string;
    get platformId(): string;
    private _profileName?;
    get profileName(): string;
    set profileName(value: string);
    get profileNameInput(): string | undefined;
    get profileVersion(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get requestedBy(): string;
    private _revocationRecord;
    get revocationRecord(): TfSigningJob.RevocationRecordPropertyList;
    get signatureExpiresAt(): string;
    private _signedObject;
    get signedObject(): TfSigningJob.SignedObjectPropertyList;
    get status(): string;
    get statusReason(): string;
    private _destination;
    get destination(): TfSigningJob.DestinationPropertyOutputReference;
    putDestination(value: TfSigningJob.DestinationProperty): void;
    get destinationInput(): TfSigningJob.DestinationProperty | undefined;
    private _source;
    get source(): TfSigningJob.SourcePropertyOutputReference;
    putSource(value: TfSigningJob.SourceProperty): void;
    get sourceInput(): TfSigningJob.SourceProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfSigningJobRevocationRecordPropertyToTerraform(struct?: TfSigningJob.RevocationRecordProperty): any;
export declare function tfSigningJobRevocationRecordPropertyToHclTerraform(struct?: TfSigningJob.RevocationRecordProperty): any;
export declare function tfSigningJobSignedObjectS3PropertyToTerraform(struct?: TfSigningJob.SignedObjectS3Property): any;
export declare function tfSigningJobSignedObjectS3PropertyToHclTerraform(struct?: TfSigningJob.SignedObjectS3Property): any;
export declare function tfSigningJobSignedObjectPropertyToTerraform(struct?: TfSigningJob.SignedObjectProperty): any;
export declare function tfSigningJobSignedObjectPropertyToHclTerraform(struct?: TfSigningJob.SignedObjectProperty): any;
export declare function tfSigningJobDestinationS3PropertyToTerraform(struct?: TfSigningJob.DestinationS3PropertyOutputReference | TfSigningJob.DestinationS3Property): any;
export declare function tfSigningJobDestinationS3PropertyToHclTerraform(struct?: TfSigningJob.DestinationS3PropertyOutputReference | TfSigningJob.DestinationS3Property): any;
export declare function tfSigningJobDestinationPropertyToTerraform(struct?: TfSigningJob.DestinationPropertyOutputReference | TfSigningJob.DestinationProperty): any;
export declare function tfSigningJobDestinationPropertyToHclTerraform(struct?: TfSigningJob.DestinationPropertyOutputReference | TfSigningJob.DestinationProperty): any;
export declare function tfSigningJobSourceS3PropertyToTerraform(struct?: TfSigningJob.SourceS3PropertyOutputReference | TfSigningJob.SourceS3Property): any;
export declare function tfSigningJobSourceS3PropertyToHclTerraform(struct?: TfSigningJob.SourceS3PropertyOutputReference | TfSigningJob.SourceS3Property): any;
export declare function tfSigningJobSourcePropertyToTerraform(struct?: TfSigningJob.SourcePropertyOutputReference | TfSigningJob.SourceProperty): any;
export declare function tfSigningJobSourcePropertyToHclTerraform(struct?: TfSigningJob.SourcePropertyOutputReference | TfSigningJob.SourceProperty): any;
export declare namespace TfSigningJob {
    interface RevocationRecordProperty {
    }
    class RevocationRecordPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RevocationRecordProperty | undefined;
        set internalValue(value: RevocationRecordProperty | undefined);
        get reason(): string;
        get revokedAt(): string;
        get revokedBy(): string;
    }
    class RevocationRecordPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RevocationRecordPropertyOutputReference;
    }
    interface SignedObjectS3Property {
    }
    class SignedObjectS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SignedObjectS3Property | undefined;
        set internalValue(value: SignedObjectS3Property | undefined);
        get bucket(): string;
        get key(): string;
    }
    class SignedObjectS3PropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SignedObjectS3PropertyOutputReference;
    }
    interface SignedObjectProperty {
    }
    class SignedObjectPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SignedObjectProperty | undefined;
        set internalValue(value: SignedObjectProperty | undefined);
        private _s3;
        get s3(): SignedObjectS3PropertyList;
    }
    class SignedObjectPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SignedObjectPropertyOutputReference;
    }
    interface DestinationS3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_job#bucket TfSigningJob#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_job#prefix TfSigningJob#prefix}
        */
        readonly prefix?: string;
    }
    class DestinationS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationS3Property | undefined;
        set internalValue(value: DestinationS3Property | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface DestinationProperty {
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_job#s3 TfSigningJob#s3}
        */
        readonly s3: DestinationS3Property;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationProperty | undefined;
        set internalValue(value: DestinationProperty | undefined);
        private _s3;
        get s3(): DestinationS3PropertyOutputReference;
        putS3(value: DestinationS3Property): void;
        get s3Input(): DestinationS3Property | undefined;
    }
    interface SourceS3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_job#bucket TfSigningJob#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_job#key TfSigningJob#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_job#version TfSigningJob#version}
        */
        readonly version: string;
    }
    class SourceS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceS3Property | undefined;
        set internalValue(value: SourceS3Property | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _version?;
        get version(): string;
        set version(value: string);
        get versionInput(): string | undefined;
    }
    interface SourceProperty {
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_job#s3 TfSigningJob#s3}
        */
        readonly s3: SourceS3Property;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceProperty | undefined;
        set internalValue(value: SourceProperty | undefined);
        private _s3;
        get s3(): SourceS3PropertyOutputReference;
        putS3(value: SourceS3Property): void;
        get s3Input(): SourceS3Property | undefined;
    }
}
