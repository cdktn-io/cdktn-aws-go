import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfSigningProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_profile#id TfSigningProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_profile#name TfSigningProfile#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_profile#name_prefix TfSigningProfile#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_profile#platform_id TfSigningProfile#platform_id}
    */
    readonly platformId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_profile#region TfSigningProfile#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_profile#signing_parameters TfSigningProfile#signing_parameters}
    */
    readonly signingParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_profile#tags TfSigningProfile#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_profile#tags_all TfSigningProfile#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * signature_validity_period block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_profile#signature_validity_period TfSigningProfile#signature_validity_period}
    */
    readonly signatureValidityPeriod?: TfSigningProfile.SignatureValidityPeriodProperty;
    /**
    * signing_material block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_profile#signing_material TfSigningProfile#signing_material}
    */
    readonly signingMaterial?: TfSigningProfile.SigningMaterialProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_profile aws_signer_signing_profile}
*/
export declare class TfSigningProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_signer_signing_profile";
    /**
    * Generates CDKTN code for importing a TfSigningProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfSigningProfile to import
    * @param importFromId The id of the existing TfSigningProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfSigningProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_profile aws_signer_signing_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfSigningProfileConfig
    */
    constructor(scope: Construct, id: string, config: TfSigningProfileConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    get platformDisplayName(): string;
    private _platformId?;
    get platformId(): string;
    set platformId(value: string);
    get platformIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _revocationRecord;
    get revocationRecord(): TfSigningProfile.RevocationRecordPropertyList;
    private _signingParameters?;
    get signingParameters(): {
        [key: string]: string;
    };
    set signingParameters(value: {
        [key: string]: string;
    });
    resetSigningParameters(): void;
    get signingParametersInput(): {
        [key: string]: string;
    } | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get version(): string;
    get versionArn(): string;
    private _signatureValidityPeriod;
    get signatureValidityPeriod(): TfSigningProfile.SignatureValidityPeriodPropertyOutputReference;
    putSignatureValidityPeriod(value: TfSigningProfile.SignatureValidityPeriodProperty): void;
    resetSignatureValidityPeriod(): void;
    get signatureValidityPeriodInput(): TfSigningProfile.SignatureValidityPeriodProperty | undefined;
    private _signingMaterial;
    get signingMaterial(): TfSigningProfile.SigningMaterialPropertyOutputReference;
    putSigningMaterial(value: TfSigningProfile.SigningMaterialProperty): void;
    resetSigningMaterial(): void;
    get signingMaterialInput(): TfSigningProfile.SigningMaterialProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfSigningProfileRevocationRecordPropertyToTerraform(struct?: TfSigningProfile.RevocationRecordProperty): any;
export declare function tfSigningProfileRevocationRecordPropertyToHclTerraform(struct?: TfSigningProfile.RevocationRecordProperty): any;
export declare function tfSigningProfileSignatureValidityPeriodPropertyToTerraform(struct?: TfSigningProfile.SignatureValidityPeriodPropertyOutputReference | TfSigningProfile.SignatureValidityPeriodProperty): any;
export declare function tfSigningProfileSignatureValidityPeriodPropertyToHclTerraform(struct?: TfSigningProfile.SignatureValidityPeriodPropertyOutputReference | TfSigningProfile.SignatureValidityPeriodProperty): any;
export declare function tfSigningProfileSigningMaterialPropertyToTerraform(struct?: TfSigningProfile.SigningMaterialPropertyOutputReference | TfSigningProfile.SigningMaterialProperty): any;
export declare function tfSigningProfileSigningMaterialPropertyToHclTerraform(struct?: TfSigningProfile.SigningMaterialPropertyOutputReference | TfSigningProfile.SigningMaterialProperty): any;
export declare namespace TfSigningProfile {
    interface RevocationRecordProperty {
    }
    class RevocationRecordPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RevocationRecordProperty | undefined;
        set internalValue(value: RevocationRecordProperty | undefined);
        get revocationEffectiveFrom(): string;
        get revokedAt(): string;
        get revokedBy(): string;
    }
    class RevocationRecordPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RevocationRecordPropertyOutputReference;
    }
    interface SignatureValidityPeriodProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_profile#type TfSigningProfile#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_profile#value TfSigningProfile#value}
        */
        readonly value: number;
    }
    class SignatureValidityPeriodPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SignatureValidityPeriodProperty | undefined;
        set internalValue(value: SignatureValidityPeriodProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface SigningMaterialProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/signer_signing_profile#certificate_arn TfSigningProfile#certificate_arn}
        */
        readonly certificateArn: string;
    }
    class SigningMaterialPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SigningMaterialProperty | undefined;
        set internalValue(value: SigningMaterialProperty | undefined);
        private _certificateArn?;
        get certificateArn(): string;
        set certificateArn(value: string);
        get certificateArnInput(): string | undefined;
    }
}
