import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsServiceDiscoveryServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#description AwsServiceDiscoveryService#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#force_destroy AwsServiceDiscoveryService#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#id AwsServiceDiscoveryService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#name AwsServiceDiscoveryService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#namespace_id AwsServiceDiscoveryService#namespace_id}
    */
    readonly namespaceId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#region AwsServiceDiscoveryService#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#tags AwsServiceDiscoveryService#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#tags_all AwsServiceDiscoveryService#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#type AwsServiceDiscoveryService#type}
    */
    readonly type?: string;
    /**
    * dns_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#dns_config AwsServiceDiscoveryService#dns_config}
    */
    readonly dnsConfig?: AwsServiceDiscoveryService.DnsConfigProperty;
    /**
    * health_check_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#health_check_config AwsServiceDiscoveryService#health_check_config}
    */
    readonly healthCheckConfig?: AwsServiceDiscoveryService.HealthCheckConfigProperty;
    /**
    * health_check_custom_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#health_check_custom_config AwsServiceDiscoveryService#health_check_custom_config}
    */
    readonly healthCheckCustomConfig?: AwsServiceDiscoveryService.HealthCheckCustomConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service aws_service_discovery_service}
*/
export declare class AwsServiceDiscoveryService extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_service_discovery_service";
    /**
    * Generates CDKTN code for importing a AwsServiceDiscoveryService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsServiceDiscoveryService to import
    * @param importFromId The id of the existing AwsServiceDiscoveryService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsServiceDiscoveryService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service aws_service_discovery_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsServiceDiscoveryServiceConfig
    */
    constructor(scope: Construct, id: string, config: AwsServiceDiscoveryServiceConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespaceId?;
    get namespaceId(): string;
    set namespaceId(value: string);
    resetNamespaceId(): void;
    get namespaceIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _dnsConfig;
    get dnsConfig(): AwsServiceDiscoveryService.DnsConfigPropertyOutputReference;
    putDnsConfig(value: AwsServiceDiscoveryService.DnsConfigProperty): void;
    resetDnsConfig(): void;
    get dnsConfigInput(): AwsServiceDiscoveryService.DnsConfigProperty | undefined;
    private _healthCheckConfig;
    get healthCheckConfig(): AwsServiceDiscoveryService.HealthCheckConfigPropertyOutputReference;
    putHealthCheckConfig(value: AwsServiceDiscoveryService.HealthCheckConfigProperty): void;
    resetHealthCheckConfig(): void;
    get healthCheckConfigInput(): AwsServiceDiscoveryService.HealthCheckConfigProperty | undefined;
    private _healthCheckCustomConfig;
    get healthCheckCustomConfig(): AwsServiceDiscoveryService.HealthCheckCustomConfigPropertyOutputReference;
    putHealthCheckCustomConfig(value: AwsServiceDiscoveryService.HealthCheckCustomConfigProperty): void;
    resetHealthCheckCustomConfig(): void;
    get healthCheckCustomConfigInput(): AwsServiceDiscoveryService.HealthCheckCustomConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsServiceDiscoveryServiceDnsRecordsPropertyToTerraform(struct?: AwsServiceDiscoveryService.DnsRecordsProperty | cdktn.IResolvable): any;
export declare function awsServiceDiscoveryServiceDnsRecordsPropertyToHclTerraform(struct?: AwsServiceDiscoveryService.DnsRecordsProperty | cdktn.IResolvable): any;
export declare function awsServiceDiscoveryServiceDnsConfigPropertyToTerraform(struct?: AwsServiceDiscoveryService.DnsConfigPropertyOutputReference | AwsServiceDiscoveryService.DnsConfigProperty): any;
export declare function awsServiceDiscoveryServiceDnsConfigPropertyToHclTerraform(struct?: AwsServiceDiscoveryService.DnsConfigPropertyOutputReference | AwsServiceDiscoveryService.DnsConfigProperty): any;
export declare function awsServiceDiscoveryServiceHealthCheckConfigPropertyToTerraform(struct?: AwsServiceDiscoveryService.HealthCheckConfigPropertyOutputReference | AwsServiceDiscoveryService.HealthCheckConfigProperty): any;
export declare function awsServiceDiscoveryServiceHealthCheckConfigPropertyToHclTerraform(struct?: AwsServiceDiscoveryService.HealthCheckConfigPropertyOutputReference | AwsServiceDiscoveryService.HealthCheckConfigProperty): any;
export declare function awsServiceDiscoveryServiceHealthCheckCustomConfigPropertyToTerraform(struct?: AwsServiceDiscoveryService.HealthCheckCustomConfigPropertyOutputReference | AwsServiceDiscoveryService.HealthCheckCustomConfigProperty): any;
export declare function awsServiceDiscoveryServiceHealthCheckCustomConfigPropertyToHclTerraform(struct?: AwsServiceDiscoveryService.HealthCheckCustomConfigPropertyOutputReference | AwsServiceDiscoveryService.HealthCheckCustomConfigProperty): any;
export declare namespace AwsServiceDiscoveryService {
    interface DnsRecordsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#ttl AwsServiceDiscoveryService#ttl}
        */
        readonly ttl: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#type AwsServiceDiscoveryService#type}
        */
        readonly type: string;
    }
    class DnsRecordsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DnsRecordsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DnsRecordsProperty | cdktn.IResolvable | undefined);
        private _ttl?;
        get ttl(): number;
        set ttl(value: number);
        get ttlInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class DnsRecordsPropertyList extends cdktn.ComplexList {
        internalValue?: DnsRecordsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DnsRecordsPropertyOutputReference;
    }
    interface DnsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#namespace_id AwsServiceDiscoveryService#namespace_id}
        */
        readonly namespaceId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#routing_policy AwsServiceDiscoveryService#routing_policy}
        */
        readonly routingPolicy?: string;
        /**
        * dns_records block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#dns_records AwsServiceDiscoveryService#dns_records}
        */
        readonly dnsRecords: DnsRecordsProperty[] | cdktn.IResolvable;
    }
    class DnsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DnsConfigProperty | undefined;
        set internalValue(value: DnsConfigProperty | undefined);
        private _namespaceId?;
        get namespaceId(): string;
        set namespaceId(value: string);
        get namespaceIdInput(): string | undefined;
        private _routingPolicy?;
        get routingPolicy(): string;
        set routingPolicy(value: string);
        resetRoutingPolicy(): void;
        get routingPolicyInput(): string | undefined;
        private _dnsRecords;
        get dnsRecords(): DnsRecordsPropertyList;
        putDnsRecords(value: DnsRecordsProperty[] | cdktn.IResolvable): void;
        get dnsRecordsInput(): cdktn.IResolvable | DnsRecordsProperty[] | undefined;
    }
    interface HealthCheckConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#failure_threshold AwsServiceDiscoveryService#failure_threshold}
        */
        readonly failureThreshold?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#resource_path AwsServiceDiscoveryService#resource_path}
        */
        readonly resourcePath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#type AwsServiceDiscoveryService#type}
        */
        readonly type?: string;
    }
    class HealthCheckConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HealthCheckConfigProperty | undefined;
        set internalValue(value: HealthCheckConfigProperty | undefined);
        private _failureThreshold?;
        get failureThreshold(): number;
        set failureThreshold(value: number);
        resetFailureThreshold(): void;
        get failureThresholdInput(): number | undefined;
        private _resourcePath?;
        get resourcePath(): string;
        set resourcePath(value: string);
        resetResourcePath(): void;
        get resourcePathInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface HealthCheckCustomConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/service_discovery_service#failure_threshold AwsServiceDiscoveryService#failure_threshold}
        */
        readonly failureThreshold?: number;
    }
    class HealthCheckCustomConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HealthCheckCustomConfigProperty | undefined;
        set internalValue(value: HealthCheckCustomConfigProperty | undefined);
        private _failureThreshold?;
        get failureThreshold(): number;
        set failureThreshold(value: number);
        resetFailureThreshold(): void;
        get failureThresholdInput(): number | undefined;
    }
}
