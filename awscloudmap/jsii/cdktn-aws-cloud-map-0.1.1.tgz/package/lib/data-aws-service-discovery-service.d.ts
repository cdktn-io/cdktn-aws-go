import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsServiceDiscoveryServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/service_discovery_service#id DataAwsServiceDiscoveryService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/service_discovery_service#name DataAwsServiceDiscoveryService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/service_discovery_service#namespace_id DataAwsServiceDiscoveryService#namespace_id}
    */
    readonly namespaceId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/service_discovery_service#region DataAwsServiceDiscoveryService#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/service_discovery_service#tags DataAwsServiceDiscoveryService#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/service_discovery_service aws_service_discovery_service}
*/
export declare class DataAwsServiceDiscoveryService extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_service_discovery_service";
    /**
    * Generates CDKTN code for importing a DataAwsServiceDiscoveryService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsServiceDiscoveryService to import
    * @param importFromId The id of the existing DataAwsServiceDiscoveryService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/service_discovery_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsServiceDiscoveryService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/service_discovery_service aws_service_discovery_service} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsServiceDiscoveryServiceConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsServiceDiscoveryServiceConfig);
    get arn(): string;
    get description(): string;
    private _dnsConfig;
    get dnsConfig(): DataAwsServiceDiscoveryService.DnsConfigPropertyList;
    private _healthCheckConfig;
    get healthCheckConfig(): DataAwsServiceDiscoveryService.HealthCheckConfigPropertyList;
    private _healthCheckCustomConfig;
    get healthCheckCustomConfig(): DataAwsServiceDiscoveryService.HealthCheckCustomConfigPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespaceId?;
    get namespaceId(): string;
    set namespaceId(value: string);
    get namespaceIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsServiceDiscoveryServiceDnsRecordsPropertyToTerraform(struct?: DataAwsServiceDiscoveryService.DnsRecordsProperty): any;
export declare function dataAwsServiceDiscoveryServiceDnsRecordsPropertyToHclTerraform(struct?: DataAwsServiceDiscoveryService.DnsRecordsProperty): any;
export declare function dataAwsServiceDiscoveryServiceDnsConfigPropertyToTerraform(struct?: DataAwsServiceDiscoveryService.DnsConfigProperty): any;
export declare function dataAwsServiceDiscoveryServiceDnsConfigPropertyToHclTerraform(struct?: DataAwsServiceDiscoveryService.DnsConfigProperty): any;
export declare function dataAwsServiceDiscoveryServiceHealthCheckConfigPropertyToTerraform(struct?: DataAwsServiceDiscoveryService.HealthCheckConfigProperty): any;
export declare function dataAwsServiceDiscoveryServiceHealthCheckConfigPropertyToHclTerraform(struct?: DataAwsServiceDiscoveryService.HealthCheckConfigProperty): any;
export declare function dataAwsServiceDiscoveryServiceHealthCheckCustomConfigPropertyToTerraform(struct?: DataAwsServiceDiscoveryService.HealthCheckCustomConfigProperty): any;
export declare function dataAwsServiceDiscoveryServiceHealthCheckCustomConfigPropertyToHclTerraform(struct?: DataAwsServiceDiscoveryService.HealthCheckCustomConfigProperty): any;
export declare namespace DataAwsServiceDiscoveryService {
    interface DnsRecordsProperty {
    }
    class DnsRecordsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DnsRecordsProperty | undefined;
        set internalValue(value: DnsRecordsProperty | undefined);
        get ttl(): number;
        get type(): string;
    }
    class DnsRecordsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DnsRecordsPropertyOutputReference;
    }
    interface DnsConfigProperty {
    }
    class DnsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DnsConfigProperty | undefined;
        set internalValue(value: DnsConfigProperty | undefined);
        private _dnsRecords;
        get dnsRecords(): DnsRecordsPropertyList;
        get namespaceId(): string;
        get routingPolicy(): string;
    }
    class DnsConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DnsConfigPropertyOutputReference;
    }
    interface HealthCheckConfigProperty {
    }
    class HealthCheckConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HealthCheckConfigProperty | undefined;
        set internalValue(value: HealthCheckConfigProperty | undefined);
        get failureThreshold(): number;
        get resourcePath(): string;
        get type(): string;
    }
    class HealthCheckConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HealthCheckConfigPropertyOutputReference;
    }
    interface HealthCheckCustomConfigProperty {
    }
    class HealthCheckCustomConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HealthCheckCustomConfigProperty | undefined;
        set internalValue(value: HealthCheckCustomConfigProperty | undefined);
        get failureThreshold(): number;
    }
    class HealthCheckCustomConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HealthCheckCustomConfigPropertyOutputReference;
    }
}
