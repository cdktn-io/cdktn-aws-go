import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfEmailTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_email_template#region TfEmailTemplate#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_email_template#tags TfEmailTemplate#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_email_template#template_name TfEmailTemplate#template_name}
    */
    readonly templateName: string;
    /**
    * email_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_email_template#email_template TfEmailTemplate#email_template}
    */
    readonly emailTemplate?: TfEmailTemplate.EmailTemplateProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_email_template aws_pinpoint_email_template}
*/
export declare class TfEmailTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_pinpoint_email_template";
    /**
    * Generates CDKTN code for importing a TfEmailTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfEmailTemplate to import
    * @param importFromId The id of the existing TfEmailTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_email_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfEmailTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_email_template aws_pinpoint_email_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfEmailTemplateConfig
    */
    constructor(scope: Construct, id: string, config: TfEmailTemplateConfig);
    get arn(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _templateName?;
    get templateName(): string;
    set templateName(value: string);
    get templateNameInput(): string | undefined;
    private _emailTemplate;
    get emailTemplate(): TfEmailTemplate.EmailTemplatePropertyList;
    putEmailTemplate(value: TfEmailTemplate.EmailTemplateProperty[] | cdktn.IResolvable): void;
    resetEmailTemplate(): void;
    get emailTemplateInput(): cdktn.IResolvable | TfEmailTemplate.EmailTemplateProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfEmailTemplateHeaderPropertyToTerraform(struct?: TfEmailTemplate.HeaderProperty | cdktn.IResolvable): any;
export declare function tfEmailTemplateHeaderPropertyToHclTerraform(struct?: TfEmailTemplate.HeaderProperty | cdktn.IResolvable): any;
export declare function tfEmailTemplateEmailTemplatePropertyToTerraform(struct?: TfEmailTemplate.EmailTemplateProperty | cdktn.IResolvable): any;
export declare function tfEmailTemplateEmailTemplatePropertyToHclTerraform(struct?: TfEmailTemplate.EmailTemplateProperty | cdktn.IResolvable): any;
export declare namespace TfEmailTemplate {
    interface HeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_email_template#name TfEmailTemplate#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_email_template#value TfEmailTemplate#value}
        */
        readonly value?: string;
    }
    class HeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HeaderProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class HeaderPropertyList extends cdktn.ComplexList {
        internalValue?: HeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HeaderPropertyOutputReference;
    }
    interface EmailTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_email_template#default_substitutions TfEmailTemplate#default_substitutions}
        */
        readonly defaultSubstitutions?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_email_template#description TfEmailTemplate#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_email_template#html_part TfEmailTemplate#html_part}
        */
        readonly htmlPart?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_email_template#recommender_id TfEmailTemplate#recommender_id}
        */
        readonly recommenderId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_email_template#subject TfEmailTemplate#subject}
        */
        readonly subject?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_email_template#text_part TfEmailTemplate#text_part}
        */
        readonly textPart?: string;
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_email_template#header TfEmailTemplate#header}
        */
        readonly header?: HeaderProperty[] | cdktn.IResolvable;
    }
    class EmailTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EmailTemplateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EmailTemplateProperty | cdktn.IResolvable | undefined);
        private _defaultSubstitutions?;
        get defaultSubstitutions(): string;
        set defaultSubstitutions(value: string);
        resetDefaultSubstitutions(): void;
        get defaultSubstitutionsInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _htmlPart?;
        get htmlPart(): string;
        set htmlPart(value: string);
        resetHtmlPart(): void;
        get htmlPartInput(): string | undefined;
        private _recommenderId?;
        get recommenderId(): string;
        set recommenderId(value: string);
        resetRecommenderId(): void;
        get recommenderIdInput(): string | undefined;
        private _subject?;
        get subject(): string;
        set subject(value: string);
        resetSubject(): void;
        get subjectInput(): string | undefined;
        private _textPart?;
        get textPart(): string;
        set textPart(value: string);
        resetTextPart(): void;
        get textPartInput(): string | undefined;
        private _header;
        get header(): HeaderPropertyList;
        putHeader(value: HeaderProperty[] | cdktn.IResolvable): void;
        resetHeader(): void;
        get headerInput(): cdktn.IResolvable | HeaderProperty[] | undefined;
    }
    class EmailTemplatePropertyList extends cdktn.ComplexList {
        internalValue?: EmailTemplateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EmailTemplatePropertyOutputReference;
    }
}
