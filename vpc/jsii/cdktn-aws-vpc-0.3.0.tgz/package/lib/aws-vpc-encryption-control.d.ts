import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEncryptionControlConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#egress_only_internet_gateway_exclusion AwsEncryptionControl#egress_only_internet_gateway_exclusion}
    */
    readonly egressOnlyInternetGatewayExclusion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#elastic_file_system_exclusion AwsEncryptionControl#elastic_file_system_exclusion}
    */
    readonly elasticFileSystemExclusion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#internet_gateway_exclusion AwsEncryptionControl#internet_gateway_exclusion}
    */
    readonly internetGatewayExclusion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#lambda_exclusion AwsEncryptionControl#lambda_exclusion}
    */
    readonly lambdaExclusion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#mode AwsEncryptionControl#mode}
    */
    readonly mode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#nat_gateway_exclusion AwsEncryptionControl#nat_gateway_exclusion}
    */
    readonly natGatewayExclusion?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#region AwsEncryptionControl#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#tags AwsEncryptionControl#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#virtual_private_gateway_exclusion AwsEncryptionControl#virtual_private_gateway_exclusion}
    */
    readonly virtualPrivateGatewayExclusion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#vpc_id AwsEncryptionControl#vpc_id}
    */
    readonly vpcId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#vpc_lattice_exclusion AwsEncryptionControl#vpc_lattice_exclusion}
    */
    readonly vpcLatticeExclusion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#vpc_peering_exclusion AwsEncryptionControl#vpc_peering_exclusion}
    */
    readonly vpcPeeringExclusion?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#timeouts AwsEncryptionControl#timeouts}
    */
    readonly timeouts?: AwsEncryptionControl.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control aws_vpc_encryption_control}
*/
export declare class AwsEncryptionControl extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_encryption_control";
    /**
    * Generates CDKTN code for importing a AwsEncryptionControl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEncryptionControl to import
    * @param importFromId The id of the existing AwsEncryptionControl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEncryptionControl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control aws_vpc_encryption_control} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEncryptionControlConfig
    */
    constructor(scope: Construct, id: string, config: AwsEncryptionControlConfig);
    private _egressOnlyInternetGatewayExclusion?;
    get egressOnlyInternetGatewayExclusion(): string;
    set egressOnlyInternetGatewayExclusion(value: string);
    resetEgressOnlyInternetGatewayExclusion(): void;
    get egressOnlyInternetGatewayExclusionInput(): string | undefined;
    private _elasticFileSystemExclusion?;
    get elasticFileSystemExclusion(): string;
    set elasticFileSystemExclusion(value: string);
    resetElasticFileSystemExclusion(): void;
    get elasticFileSystemExclusionInput(): string | undefined;
    get id(): string;
    private _internetGatewayExclusion?;
    get internetGatewayExclusion(): string;
    set internetGatewayExclusion(value: string);
    resetInternetGatewayExclusion(): void;
    get internetGatewayExclusionInput(): string | undefined;
    private _lambdaExclusion?;
    get lambdaExclusion(): string;
    set lambdaExclusion(value: string);
    resetLambdaExclusion(): void;
    get lambdaExclusionInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _natGatewayExclusion?;
    get natGatewayExclusion(): string;
    set natGatewayExclusion(value: string);
    resetNatGatewayExclusion(): void;
    get natGatewayExclusionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceExclusions;
    get resourceExclusions(): AwsEncryptionControl.ResourceExclusionsPropertyOutputReference;
    get state(): string;
    get stateMessage(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _virtualPrivateGatewayExclusion?;
    get virtualPrivateGatewayExclusion(): string;
    set virtualPrivateGatewayExclusion(value: string);
    resetVirtualPrivateGatewayExclusion(): void;
    get virtualPrivateGatewayExclusionInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    private _vpcLatticeExclusion?;
    get vpcLatticeExclusion(): string;
    set vpcLatticeExclusion(value: string);
    resetVpcLatticeExclusion(): void;
    get vpcLatticeExclusionInput(): string | undefined;
    private _vpcPeeringExclusion?;
    get vpcPeeringExclusion(): string;
    set vpcPeeringExclusion(value: string);
    resetVpcPeeringExclusion(): void;
    get vpcPeeringExclusionInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsEncryptionControl.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEncryptionControl.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsEncryptionControl.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEncryptionControlEgressOnlyInternetGatewayPropertyToTerraform(struct?: AwsEncryptionControl.EgressOnlyInternetGatewayProperty): any;
export declare function awsEncryptionControlEgressOnlyInternetGatewayPropertyToHclTerraform(struct?: AwsEncryptionControl.EgressOnlyInternetGatewayProperty): any;
export declare function awsEncryptionControlElasticFileSystemPropertyToTerraform(struct?: AwsEncryptionControl.ElasticFileSystemProperty): any;
export declare function awsEncryptionControlElasticFileSystemPropertyToHclTerraform(struct?: AwsEncryptionControl.ElasticFileSystemProperty): any;
export declare function awsEncryptionControlInternetGatewayPropertyToTerraform(struct?: AwsEncryptionControl.InternetGatewayProperty): any;
export declare function awsEncryptionControlInternetGatewayPropertyToHclTerraform(struct?: AwsEncryptionControl.InternetGatewayProperty): any;
export declare function awsEncryptionControlLambdaPropertyToTerraform(struct?: AwsEncryptionControl.LambdaProperty): any;
export declare function awsEncryptionControlLambdaPropertyToHclTerraform(struct?: AwsEncryptionControl.LambdaProperty): any;
export declare function awsEncryptionControlNatGatewayPropertyToTerraform(struct?: AwsEncryptionControl.NatGatewayProperty): any;
export declare function awsEncryptionControlNatGatewayPropertyToHclTerraform(struct?: AwsEncryptionControl.NatGatewayProperty): any;
export declare function awsEncryptionControlVirtualPrivateGatewayPropertyToTerraform(struct?: AwsEncryptionControl.VirtualPrivateGatewayProperty): any;
export declare function awsEncryptionControlVirtualPrivateGatewayPropertyToHclTerraform(struct?: AwsEncryptionControl.VirtualPrivateGatewayProperty): any;
export declare function awsEncryptionControlVpcLatticePropertyToTerraform(struct?: AwsEncryptionControl.VpcLatticeProperty): any;
export declare function awsEncryptionControlVpcLatticePropertyToHclTerraform(struct?: AwsEncryptionControl.VpcLatticeProperty): any;
export declare function awsEncryptionControlVpcPeeringPropertyToTerraform(struct?: AwsEncryptionControl.VpcPeeringProperty): any;
export declare function awsEncryptionControlVpcPeeringPropertyToHclTerraform(struct?: AwsEncryptionControl.VpcPeeringProperty): any;
export declare function awsEncryptionControlResourceExclusionsPropertyToTerraform(struct?: AwsEncryptionControl.ResourceExclusionsProperty): any;
export declare function awsEncryptionControlResourceExclusionsPropertyToHclTerraform(struct?: AwsEncryptionControl.ResourceExclusionsProperty): any;
export declare function awsEncryptionControlTimeoutsPropertyToTerraform(struct?: AwsEncryptionControl.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEncryptionControlTimeoutsPropertyToHclTerraform(struct?: AwsEncryptionControl.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsEncryptionControl {
    interface EgressOnlyInternetGatewayProperty {
    }
    class EgressOnlyInternetGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EgressOnlyInternetGatewayProperty | undefined;
        set internalValue(value: EgressOnlyInternetGatewayProperty | undefined);
        get state(): string;
        get stateMessage(): string;
    }
    interface ElasticFileSystemProperty {
    }
    class ElasticFileSystemPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ElasticFileSystemProperty | undefined;
        set internalValue(value: ElasticFileSystemProperty | undefined);
        get state(): string;
        get stateMessage(): string;
    }
    interface InternetGatewayProperty {
    }
    class InternetGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InternetGatewayProperty | undefined;
        set internalValue(value: InternetGatewayProperty | undefined);
        get state(): string;
        get stateMessage(): string;
    }
    interface LambdaProperty {
    }
    class LambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LambdaProperty | undefined;
        set internalValue(value: LambdaProperty | undefined);
        get state(): string;
        get stateMessage(): string;
    }
    interface NatGatewayProperty {
    }
    class NatGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NatGatewayProperty | undefined;
        set internalValue(value: NatGatewayProperty | undefined);
        get state(): string;
        get stateMessage(): string;
    }
    interface VirtualPrivateGatewayProperty {
    }
    class VirtualPrivateGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VirtualPrivateGatewayProperty | undefined;
        set internalValue(value: VirtualPrivateGatewayProperty | undefined);
        get state(): string;
        get stateMessage(): string;
    }
    interface VpcLatticeProperty {
    }
    class VpcLatticePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcLatticeProperty | undefined;
        set internalValue(value: VpcLatticeProperty | undefined);
        get state(): string;
        get stateMessage(): string;
    }
    interface VpcPeeringProperty {
    }
    class VpcPeeringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcPeeringProperty | undefined;
        set internalValue(value: VpcPeeringProperty | undefined);
        get state(): string;
        get stateMessage(): string;
    }
    interface ResourceExclusionsProperty {
    }
    class ResourceExclusionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ResourceExclusionsProperty | undefined;
        set internalValue(value: ResourceExclusionsProperty | undefined);
        private _egressOnlyInternetGateway;
        get egressOnlyInternetGateway(): EgressOnlyInternetGatewayPropertyOutputReference;
        private _elasticFileSystem;
        get elasticFileSystem(): ElasticFileSystemPropertyOutputReference;
        private _internetGateway;
        get internetGateway(): InternetGatewayPropertyOutputReference;
        private _lambda;
        get lambda(): LambdaPropertyOutputReference;
        private _natGateway;
        get natGateway(): NatGatewayPropertyOutputReference;
        private _virtualPrivateGateway;
        get virtualPrivateGateway(): VirtualPrivateGatewayPropertyOutputReference;
        private _vpcLattice;
        get vpcLattice(): VpcLatticePropertyOutputReference;
        private _vpcPeering;
        get vpcPeering(): VpcPeeringPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#create AwsEncryptionControl#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#delete AwsEncryptionControl#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#update AwsEncryptionControl#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
