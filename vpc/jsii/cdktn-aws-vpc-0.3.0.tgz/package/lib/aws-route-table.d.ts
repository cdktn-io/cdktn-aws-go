import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRouteTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#id AwsRouteTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#propagating_vgws AwsRouteTable#propagating_vgws}
    */
    readonly propagatingVgws?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#region AwsRouteTable#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#route AwsRouteTable#route}
    */
    readonly route?: AwsRouteTable.RouteProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#tags AwsRouteTable#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#tags_all AwsRouteTable#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#vpc_id AwsRouteTable#vpc_id}
    */
    readonly vpcId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#timeouts AwsRouteTable#timeouts}
    */
    readonly timeouts?: AwsRouteTable.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table aws_route_table}
*/
export declare class AwsRouteTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route_table";
    /**
    * Generates CDKTN code for importing a AwsRouteTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRouteTable to import
    * @param importFromId The id of the existing AwsRouteTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRouteTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table aws_route_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRouteTableConfig
    */
    constructor(scope: Construct, id: string, config: AwsRouteTableConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ownerId(): string;
    private _propagatingVgws?;
    get propagatingVgws(): string[];
    set propagatingVgws(value: string[]);
    resetPropagatingVgws(): void;
    get propagatingVgwsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _route;
    get route(): AwsRouteTable.RoutePropertyList;
    putRoute(value: AwsRouteTable.RouteProperty[] | cdktn.IResolvable): void;
    resetRoute(): void;
    get routeInput(): cdktn.IResolvable | AwsRouteTable.RouteProperty[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsRouteTable.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsRouteTable.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsRouteTable.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRouteTableRoutePropertyToTerraform(struct?: AwsRouteTable.RouteProperty | cdktn.IResolvable): any;
export declare function awsRouteTableRoutePropertyToHclTerraform(struct?: AwsRouteTable.RouteProperty | cdktn.IResolvable): any;
export declare function awsRouteTableTimeoutsPropertyToTerraform(struct?: AwsRouteTable.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsRouteTableTimeoutsPropertyToHclTerraform(struct?: AwsRouteTable.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsRouteTable {
    interface RouteProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#carrier_gateway_id AwsRouteTable#carrier_gateway_id}
        */
        readonly carrierGatewayId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#cidr_block AwsRouteTable#cidr_block}
        */
        readonly cidrBlock?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#core_network_arn AwsRouteTable#core_network_arn}
        */
        readonly coreNetworkArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#destination_prefix_list_id AwsRouteTable#destination_prefix_list_id}
        */
        readonly destinationPrefixListId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#egress_only_gateway_id AwsRouteTable#egress_only_gateway_id}
        */
        readonly egressOnlyGatewayId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#gateway_id AwsRouteTable#gateway_id}
        */
        readonly gatewayId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#ipv6_cidr_block AwsRouteTable#ipv6_cidr_block}
        */
        readonly ipv6CidrBlock?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#local_gateway_id AwsRouteTable#local_gateway_id}
        */
        readonly localGatewayId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#nat_gateway_id AwsRouteTable#nat_gateway_id}
        */
        readonly natGatewayId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#network_interface_id AwsRouteTable#network_interface_id}
        */
        readonly networkInterfaceId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#odb_network_arn AwsRouteTable#odb_network_arn}
        */
        readonly odbNetworkArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#transit_gateway_id AwsRouteTable#transit_gateway_id}
        */
        readonly transitGatewayId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#vpc_endpoint_id AwsRouteTable#vpc_endpoint_id}
        */
        readonly vpcEndpointId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#vpc_peering_connection_id AwsRouteTable#vpc_peering_connection_id}
        */
        readonly vpcPeeringConnectionId?: string;
    }
    class RoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RouteProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RouteProperty | cdktn.IResolvable | undefined);
        private _carrierGatewayId?;
        get carrierGatewayId(): string;
        set carrierGatewayId(value: string);
        resetCarrierGatewayId(): void;
        get carrierGatewayIdInput(): string | undefined;
        private _cidrBlock?;
        get cidrBlock(): string;
        set cidrBlock(value: string);
        resetCidrBlock(): void;
        get cidrBlockInput(): string | undefined;
        private _coreNetworkArn?;
        get coreNetworkArn(): string;
        set coreNetworkArn(value: string);
        resetCoreNetworkArn(): void;
        get coreNetworkArnInput(): string | undefined;
        private _destinationPrefixListId?;
        get destinationPrefixListId(): string;
        set destinationPrefixListId(value: string);
        resetDestinationPrefixListId(): void;
        get destinationPrefixListIdInput(): string | undefined;
        private _egressOnlyGatewayId?;
        get egressOnlyGatewayId(): string;
        set egressOnlyGatewayId(value: string);
        resetEgressOnlyGatewayId(): void;
        get egressOnlyGatewayIdInput(): string | undefined;
        private _gatewayId?;
        get gatewayId(): string;
        set gatewayId(value: string);
        resetGatewayId(): void;
        get gatewayIdInput(): string | undefined;
        private _ipv6CidrBlock?;
        get ipv6CidrBlock(): string;
        set ipv6CidrBlock(value: string);
        resetIpv6CidrBlock(): void;
        get ipv6CidrBlockInput(): string | undefined;
        private _localGatewayId?;
        get localGatewayId(): string;
        set localGatewayId(value: string);
        resetLocalGatewayId(): void;
        get localGatewayIdInput(): string | undefined;
        private _natGatewayId?;
        get natGatewayId(): string;
        set natGatewayId(value: string);
        resetNatGatewayId(): void;
        get natGatewayIdInput(): string | undefined;
        private _networkInterfaceId?;
        get networkInterfaceId(): string;
        set networkInterfaceId(value: string);
        resetNetworkInterfaceId(): void;
        get networkInterfaceIdInput(): string | undefined;
        private _odbNetworkArn?;
        get odbNetworkArn(): string;
        set odbNetworkArn(value: string);
        resetOdbNetworkArn(): void;
        get odbNetworkArnInput(): string | undefined;
        private _transitGatewayId?;
        get transitGatewayId(): string;
        set transitGatewayId(value: string);
        resetTransitGatewayId(): void;
        get transitGatewayIdInput(): string | undefined;
        private _vpcEndpointId?;
        get vpcEndpointId(): string;
        set vpcEndpointId(value: string);
        resetVpcEndpointId(): void;
        get vpcEndpointIdInput(): string | undefined;
        private _vpcPeeringConnectionId?;
        get vpcPeeringConnectionId(): string;
        set vpcPeeringConnectionId(value: string);
        resetVpcPeeringConnectionId(): void;
        get vpcPeeringConnectionIdInput(): string | undefined;
    }
    class RoutePropertyList extends cdktn.ComplexList {
        internalValue?: RouteProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RoutePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#create AwsRouteTable#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#delete AwsRouteTable#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route_table#update AwsRouteTable#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
