import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEc2ManagedPrefixListConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_managed_prefix_list#address_family AwsEc2ManagedPrefixList#address_family}
    */
    readonly addressFamily: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_managed_prefix_list#id AwsEc2ManagedPrefixList#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_managed_prefix_list#max_entries AwsEc2ManagedPrefixList#max_entries}
    */
    readonly maxEntries: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_managed_prefix_list#name AwsEc2ManagedPrefixList#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_managed_prefix_list#region AwsEc2ManagedPrefixList#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_managed_prefix_list#tags AwsEc2ManagedPrefixList#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_managed_prefix_list#tags_all AwsEc2ManagedPrefixList#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * entry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_managed_prefix_list#entry AwsEc2ManagedPrefixList#entry}
    */
    readonly entry?: AwsEc2ManagedPrefixList.EntryProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_managed_prefix_list aws_ec2_managed_prefix_list}
*/
export declare class AwsEc2ManagedPrefixList extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ec2_managed_prefix_list";
    /**
    * Generates CDKTN code for importing a AwsEc2ManagedPrefixList resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEc2ManagedPrefixList to import
    * @param importFromId The id of the existing AwsEc2ManagedPrefixList that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_managed_prefix_list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEc2ManagedPrefixList to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_managed_prefix_list aws_ec2_managed_prefix_list} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEc2ManagedPrefixListConfig
    */
    constructor(scope: Construct, id: string, config: AwsEc2ManagedPrefixListConfig);
    private _addressFamily?;
    get addressFamily(): string;
    set addressFamily(value: string);
    get addressFamilyInput(): string | undefined;
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxEntries?;
    get maxEntries(): number;
    set maxEntries(value: number);
    get maxEntriesInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get ownerId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get version(): number;
    private _entry;
    get entry(): AwsEc2ManagedPrefixList.EntryPropertyList;
    putEntry(value: AwsEc2ManagedPrefixList.EntryProperty[] | cdktn.IResolvable): void;
    resetEntry(): void;
    get entryInput(): cdktn.IResolvable | AwsEc2ManagedPrefixList.EntryProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEc2ManagedPrefixListEntryPropertyToTerraform(struct?: AwsEc2ManagedPrefixList.EntryProperty | cdktn.IResolvable): any;
export declare function awsEc2ManagedPrefixListEntryPropertyToHclTerraform(struct?: AwsEc2ManagedPrefixList.EntryProperty | cdktn.IResolvable): any;
export declare namespace AwsEc2ManagedPrefixList {
    interface EntryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_managed_prefix_list#cidr AwsEc2ManagedPrefixList#cidr}
        */
        readonly cidr: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_managed_prefix_list#description AwsEc2ManagedPrefixList#description}
        */
        readonly description?: string;
    }
    class EntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EntryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EntryProperty | cdktn.IResolvable | undefined);
        private _cidr?;
        get cidr(): string;
        set cidr(value: string);
        get cidrInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
    }
    class EntryPropertyList extends cdktn.ComplexList {
        internalValue?: EntryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EntryPropertyOutputReference;
    }
}
