import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPeeringConnectionAccepterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#auto_accept AwsPeeringConnectionAccepter#auto_accept}
    */
    readonly autoAccept?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#id AwsPeeringConnectionAccepter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#region AwsPeeringConnectionAccepter#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#tags AwsPeeringConnectionAccepter#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#tags_all AwsPeeringConnectionAccepter#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#vpc_peering_connection_id AwsPeeringConnectionAccepter#vpc_peering_connection_id}
    */
    readonly vpcPeeringConnectionId: string;
    /**
    * accepter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#accepter AwsPeeringConnectionAccepter#accepter}
    */
    readonly accepter?: AwsPeeringConnectionAccepter.AccepterProperty;
    /**
    * requester block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#requester AwsPeeringConnectionAccepter#requester}
    */
    readonly requester?: AwsPeeringConnectionAccepter.RequesterProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#timeouts AwsPeeringConnectionAccepter#timeouts}
    */
    readonly timeouts?: AwsPeeringConnectionAccepter.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter aws_vpc_peering_connection_accepter}
*/
export declare class AwsPeeringConnectionAccepter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_peering_connection_accepter";
    /**
    * Generates CDKTN code for importing a AwsPeeringConnectionAccepter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPeeringConnectionAccepter to import
    * @param importFromId The id of the existing AwsPeeringConnectionAccepter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPeeringConnectionAccepter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter aws_vpc_peering_connection_accepter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPeeringConnectionAccepterConfig
    */
    constructor(scope: Construct, id: string, config: AwsPeeringConnectionAccepterConfig);
    get acceptStatus(): string;
    private _autoAccept?;
    get autoAccept(): boolean | cdktn.IResolvable;
    set autoAccept(value: boolean | cdktn.IResolvable);
    resetAutoAccept(): void;
    get autoAcceptInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get peerOwnerId(): string;
    get peerRegion(): string;
    get peerVpcId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get vpcId(): string;
    private _vpcPeeringConnectionId?;
    get vpcPeeringConnectionId(): string;
    set vpcPeeringConnectionId(value: string);
    get vpcPeeringConnectionIdInput(): string | undefined;
    private _accepter;
    get accepter(): AwsPeeringConnectionAccepter.AccepterPropertyOutputReference;
    putAccepter(value: AwsPeeringConnectionAccepter.AccepterProperty): void;
    resetAccepter(): void;
    get accepterInput(): AwsPeeringConnectionAccepter.AccepterProperty | undefined;
    private _requester;
    get requester(): AwsPeeringConnectionAccepter.RequesterPropertyOutputReference;
    putRequester(value: AwsPeeringConnectionAccepter.RequesterProperty): void;
    resetRequester(): void;
    get requesterInput(): AwsPeeringConnectionAccepter.RequesterProperty | undefined;
    private _timeouts;
    get timeouts(): AwsPeeringConnectionAccepter.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsPeeringConnectionAccepter.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsPeeringConnectionAccepter.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPeeringConnectionAccepterAccepterPropertyToTerraform(struct?: AwsPeeringConnectionAccepter.AccepterPropertyOutputReference | AwsPeeringConnectionAccepter.AccepterProperty): any;
export declare function awsPeeringConnectionAccepterAccepterPropertyToHclTerraform(struct?: AwsPeeringConnectionAccepter.AccepterPropertyOutputReference | AwsPeeringConnectionAccepter.AccepterProperty): any;
export declare function awsPeeringConnectionAccepterRequesterPropertyToTerraform(struct?: AwsPeeringConnectionAccepter.RequesterPropertyOutputReference | AwsPeeringConnectionAccepter.RequesterProperty): any;
export declare function awsPeeringConnectionAccepterRequesterPropertyToHclTerraform(struct?: AwsPeeringConnectionAccepter.RequesterPropertyOutputReference | AwsPeeringConnectionAccepter.RequesterProperty): any;
export declare function awsPeeringConnectionAccepterTimeoutsPropertyToTerraform(struct?: AwsPeeringConnectionAccepter.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsPeeringConnectionAccepterTimeoutsPropertyToHclTerraform(struct?: AwsPeeringConnectionAccepter.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsPeeringConnectionAccepter {
    interface AccepterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#allow_remote_vpc_dns_resolution AwsPeeringConnectionAccepter#allow_remote_vpc_dns_resolution}
        */
        readonly allowRemoteVpcDnsResolution?: boolean | cdktn.IResolvable;
    }
    class AccepterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccepterProperty | undefined;
        set internalValue(value: AccepterProperty | undefined);
        private _allowRemoteVpcDnsResolution?;
        get allowRemoteVpcDnsResolution(): boolean | cdktn.IResolvable;
        set allowRemoteVpcDnsResolution(value: boolean | cdktn.IResolvable);
        resetAllowRemoteVpcDnsResolution(): void;
        get allowRemoteVpcDnsResolutionInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface RequesterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#allow_remote_vpc_dns_resolution AwsPeeringConnectionAccepter#allow_remote_vpc_dns_resolution}
        */
        readonly allowRemoteVpcDnsResolution?: boolean | cdktn.IResolvable;
    }
    class RequesterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RequesterProperty | undefined;
        set internalValue(value: RequesterProperty | undefined);
        private _allowRemoteVpcDnsResolution?;
        get allowRemoteVpcDnsResolution(): boolean | cdktn.IResolvable;
        set allowRemoteVpcDnsResolution(value: boolean | cdktn.IResolvable);
        resetAllowRemoteVpcDnsResolution(): void;
        get allowRemoteVpcDnsResolutionInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#create AwsPeeringConnectionAccepter#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#update AwsPeeringConnectionAccepter#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
