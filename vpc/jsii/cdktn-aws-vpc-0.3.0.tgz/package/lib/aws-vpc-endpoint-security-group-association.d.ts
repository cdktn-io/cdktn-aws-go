import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEndpointSecurityGroupAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_security_group_association#id AwsEndpointSecurityGroupAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_security_group_association#region AwsEndpointSecurityGroupAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_security_group_association#replace_default_association AwsEndpointSecurityGroupAssociation#replace_default_association}
    */
    readonly replaceDefaultAssociation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_security_group_association#security_group_id AwsEndpointSecurityGroupAssociation#security_group_id}
    */
    readonly securityGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_security_group_association#vpc_endpoint_id AwsEndpointSecurityGroupAssociation#vpc_endpoint_id}
    */
    readonly vpcEndpointId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_security_group_association aws_vpc_endpoint_security_group_association}
*/
export declare class AwsEndpointSecurityGroupAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_endpoint_security_group_association";
    /**
    * Generates CDKTN code for importing a AwsEndpointSecurityGroupAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEndpointSecurityGroupAssociation to import
    * @param importFromId The id of the existing AwsEndpointSecurityGroupAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_security_group_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEndpointSecurityGroupAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_security_group_association aws_vpc_endpoint_security_group_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEndpointSecurityGroupAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsEndpointSecurityGroupAssociationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replaceDefaultAssociation?;
    get replaceDefaultAssociation(): boolean | cdktn.IResolvable;
    set replaceDefaultAssociation(value: boolean | cdktn.IResolvable);
    resetReplaceDefaultAssociation(): void;
    get replaceDefaultAssociationInput(): boolean | cdktn.IResolvable | undefined;
    private _securityGroupId?;
    get securityGroupId(): string;
    set securityGroupId(value: string);
    get securityGroupIdInput(): string | undefined;
    private _vpcEndpointId?;
    get vpcEndpointId(): string;
    set vpcEndpointId(value: string);
    get vpcEndpointIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
