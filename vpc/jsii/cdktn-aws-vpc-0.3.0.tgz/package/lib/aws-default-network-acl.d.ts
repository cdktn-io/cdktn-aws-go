import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDefaultNetworkAclConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#default_network_acl_id AwsDefaultNetworkAcl#default_network_acl_id}
    */
    readonly defaultNetworkAclId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#id AwsDefaultNetworkAcl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#region AwsDefaultNetworkAcl#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#subnet_ids AwsDefaultNetworkAcl#subnet_ids}
    */
    readonly subnetIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#tags AwsDefaultNetworkAcl#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#tags_all AwsDefaultNetworkAcl#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * egress block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#egress AwsDefaultNetworkAcl#egress}
    */
    readonly egress?: AwsDefaultNetworkAcl.EgressProperty[] | cdktn.IResolvable;
    /**
    * ingress block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#ingress AwsDefaultNetworkAcl#ingress}
    */
    readonly ingress?: AwsDefaultNetworkAcl.IngressProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl aws_default_network_acl}
*/
export declare class AwsDefaultNetworkAcl extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_default_network_acl";
    /**
    * Generates CDKTN code for importing a AwsDefaultNetworkAcl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDefaultNetworkAcl to import
    * @param importFromId The id of the existing AwsDefaultNetworkAcl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDefaultNetworkAcl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl aws_default_network_acl} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDefaultNetworkAclConfig
    */
    constructor(scope: Construct, id: string, config: AwsDefaultNetworkAclConfig);
    get arn(): string;
    private _defaultNetworkAclId?;
    get defaultNetworkAclId(): string;
    set defaultNetworkAclId(value: string);
    get defaultNetworkAclIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ownerId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get vpcId(): string;
    private _egress;
    get egress(): AwsDefaultNetworkAcl.EgressPropertyList;
    putEgress(value: AwsDefaultNetworkAcl.EgressProperty[] | cdktn.IResolvable): void;
    resetEgress(): void;
    get egressInput(): cdktn.IResolvable | AwsDefaultNetworkAcl.EgressProperty[] | undefined;
    private _ingress;
    get ingress(): AwsDefaultNetworkAcl.IngressPropertyList;
    putIngress(value: AwsDefaultNetworkAcl.IngressProperty[] | cdktn.IResolvable): void;
    resetIngress(): void;
    get ingressInput(): cdktn.IResolvable | AwsDefaultNetworkAcl.IngressProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDefaultNetworkAclEgressPropertyToTerraform(struct?: AwsDefaultNetworkAcl.EgressProperty | cdktn.IResolvable): any;
export declare function awsDefaultNetworkAclEgressPropertyToHclTerraform(struct?: AwsDefaultNetworkAcl.EgressProperty | cdktn.IResolvable): any;
export declare function awsDefaultNetworkAclIngressPropertyToTerraform(struct?: AwsDefaultNetworkAcl.IngressProperty | cdktn.IResolvable): any;
export declare function awsDefaultNetworkAclIngressPropertyToHclTerraform(struct?: AwsDefaultNetworkAcl.IngressProperty | cdktn.IResolvable): any;
export declare namespace AwsDefaultNetworkAcl {
    interface EgressProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#action AwsDefaultNetworkAcl#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#cidr_block AwsDefaultNetworkAcl#cidr_block}
        */
        readonly cidrBlock?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#from_port AwsDefaultNetworkAcl#from_port}
        */
        readonly fromPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#icmp_code AwsDefaultNetworkAcl#icmp_code}
        */
        readonly icmpCode?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#icmp_type AwsDefaultNetworkAcl#icmp_type}
        */
        readonly icmpType?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#ipv6_cidr_block AwsDefaultNetworkAcl#ipv6_cidr_block}
        */
        readonly ipv6CidrBlock?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#protocol AwsDefaultNetworkAcl#protocol}
        */
        readonly protocol: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#rule_no AwsDefaultNetworkAcl#rule_no}
        */
        readonly ruleNo: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#to_port AwsDefaultNetworkAcl#to_port}
        */
        readonly toPort: number;
    }
    class EgressPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EgressProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EgressProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _cidrBlock?;
        get cidrBlock(): string;
        set cidrBlock(value: string);
        resetCidrBlock(): void;
        get cidrBlockInput(): string | undefined;
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        get fromPortInput(): number | undefined;
        private _icmpCode?;
        get icmpCode(): number;
        set icmpCode(value: number);
        resetIcmpCode(): void;
        get icmpCodeInput(): number | undefined;
        private _icmpType?;
        get icmpType(): number;
        set icmpType(value: number);
        resetIcmpType(): void;
        get icmpTypeInput(): number | undefined;
        private _ipv6CidrBlock?;
        get ipv6CidrBlock(): string;
        set ipv6CidrBlock(value: string);
        resetIpv6CidrBlock(): void;
        get ipv6CidrBlockInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        get protocolInput(): string | undefined;
        private _ruleNo?;
        get ruleNo(): number;
        set ruleNo(value: number);
        get ruleNoInput(): number | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        get toPortInput(): number | undefined;
    }
    class EgressPropertyList extends cdktn.ComplexList {
        internalValue?: EgressProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EgressPropertyOutputReference;
    }
    interface IngressProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#action AwsDefaultNetworkAcl#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#cidr_block AwsDefaultNetworkAcl#cidr_block}
        */
        readonly cidrBlock?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#from_port AwsDefaultNetworkAcl#from_port}
        */
        readonly fromPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#icmp_code AwsDefaultNetworkAcl#icmp_code}
        */
        readonly icmpCode?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#icmp_type AwsDefaultNetworkAcl#icmp_type}
        */
        readonly icmpType?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#ipv6_cidr_block AwsDefaultNetworkAcl#ipv6_cidr_block}
        */
        readonly ipv6CidrBlock?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#protocol AwsDefaultNetworkAcl#protocol}
        */
        readonly protocol: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#rule_no AwsDefaultNetworkAcl#rule_no}
        */
        readonly ruleNo: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_network_acl#to_port AwsDefaultNetworkAcl#to_port}
        */
        readonly toPort: number;
    }
    class IngressPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IngressProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IngressProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _cidrBlock?;
        get cidrBlock(): string;
        set cidrBlock(value: string);
        resetCidrBlock(): void;
        get cidrBlockInput(): string | undefined;
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        get fromPortInput(): number | undefined;
        private _icmpCode?;
        get icmpCode(): number;
        set icmpCode(value: number);
        resetIcmpCode(): void;
        get icmpCodeInput(): number | undefined;
        private _icmpType?;
        get icmpType(): number;
        set icmpType(value: number);
        resetIcmpType(): void;
        get icmpTypeInput(): number | undefined;
        private _ipv6CidrBlock?;
        get ipv6CidrBlock(): string;
        set ipv6CidrBlock(value: string);
        resetIpv6CidrBlock(): void;
        get ipv6CidrBlockInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        get protocolInput(): string | undefined;
        private _ruleNo?;
        get ruleNo(): number;
        set ruleNo(value: number);
        get ruleNoInput(): number | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        get toPortInput(): number | undefined;
    }
    class IngressPropertyList extends cdktn.ComplexList {
        internalValue?: IngressProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IngressPropertyOutputReference;
    }
}
