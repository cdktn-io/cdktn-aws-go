import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSecurityGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#description AwsSecurityGroup#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#egress AwsSecurityGroup#egress}
    */
    readonly egress?: AwsSecurityGroup.EgressProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#id AwsSecurityGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#ingress AwsSecurityGroup#ingress}
    */
    readonly ingress?: AwsSecurityGroup.IngressProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#name AwsSecurityGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#name_prefix AwsSecurityGroup#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#region AwsSecurityGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#revoke_rules_on_delete AwsSecurityGroup#revoke_rules_on_delete}
    */
    readonly revokeRulesOnDelete?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#tags AwsSecurityGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#tags_all AwsSecurityGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#vpc_id AwsSecurityGroup#vpc_id}
    */
    readonly vpcId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#timeouts AwsSecurityGroup#timeouts}
    */
    readonly timeouts?: AwsSecurityGroup.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group aws_security_group}
*/
export declare class AwsSecurityGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_security_group";
    /**
    * Generates CDKTN code for importing a AwsSecurityGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSecurityGroup to import
    * @param importFromId The id of the existing AwsSecurityGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSecurityGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group aws_security_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSecurityGroupConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsSecurityGroupConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _egress;
    get egress(): AwsSecurityGroup.EgressPropertyList;
    putEgress(value: AwsSecurityGroup.EgressProperty[] | cdktn.IResolvable): void;
    resetEgress(): void;
    get egressInput(): cdktn.IResolvable | AwsSecurityGroup.EgressProperty[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ingress;
    get ingress(): AwsSecurityGroup.IngressPropertyList;
    putIngress(value: AwsSecurityGroup.IngressProperty[] | cdktn.IResolvable): void;
    resetIngress(): void;
    get ingressInput(): cdktn.IResolvable | AwsSecurityGroup.IngressProperty[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    get ownerId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _revokeRulesOnDelete?;
    get revokeRulesOnDelete(): boolean | cdktn.IResolvable;
    set revokeRulesOnDelete(value: boolean | cdktn.IResolvable);
    resetRevokeRulesOnDelete(): void;
    get revokeRulesOnDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsSecurityGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSecurityGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSecurityGroup.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSecurityGroupEgressPropertyToTerraform(struct?: AwsSecurityGroup.EgressProperty | cdktn.IResolvable): any;
export declare function awsSecurityGroupEgressPropertyToHclTerraform(struct?: AwsSecurityGroup.EgressProperty | cdktn.IResolvable): any;
export declare function awsSecurityGroupIngressPropertyToTerraform(struct?: AwsSecurityGroup.IngressProperty | cdktn.IResolvable): any;
export declare function awsSecurityGroupIngressPropertyToHclTerraform(struct?: AwsSecurityGroup.IngressProperty | cdktn.IResolvable): any;
export declare function awsSecurityGroupTimeoutsPropertyToTerraform(struct?: AwsSecurityGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSecurityGroupTimeoutsPropertyToHclTerraform(struct?: AwsSecurityGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsSecurityGroup {
    interface EgressProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#cidr_blocks AwsSecurityGroup#cidr_blocks}
        */
        readonly cidrBlocks?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#description AwsSecurityGroup#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#from_port AwsSecurityGroup#from_port}
        */
        readonly fromPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#ipv6_cidr_blocks AwsSecurityGroup#ipv6_cidr_blocks}
        */
        readonly ipv6CidrBlocks?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#prefix_list_ids AwsSecurityGroup#prefix_list_ids}
        */
        readonly prefixListIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#protocol AwsSecurityGroup#protocol}
        */
        readonly protocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#security_groups AwsSecurityGroup#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#self AwsSecurityGroup#self}
        */
        readonly selfAttribute?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#to_port AwsSecurityGroup#to_port}
        */
        readonly toPort?: number;
    }
    class EgressPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EgressProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EgressProperty | cdktn.IResolvable | undefined);
        private _cidrBlocks?;
        get cidrBlocks(): string[];
        set cidrBlocks(value: string[]);
        resetCidrBlocks(): void;
        get cidrBlocksInput(): string[] | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        resetFromPort(): void;
        get fromPortInput(): number | undefined;
        private _ipv6CidrBlocks?;
        get ipv6CidrBlocks(): string[];
        set ipv6CidrBlocks(value: string[]);
        resetIpv6CidrBlocks(): void;
        get ipv6CidrBlocksInput(): string[] | undefined;
        private _prefixListIds?;
        get prefixListIds(): string[];
        set prefixListIds(value: string[]);
        resetPrefixListIds(): void;
        get prefixListIdsInput(): string[] | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _self?;
        get selfAttribute(): boolean | cdktn.IResolvable;
        set selfAttribute(value: boolean | cdktn.IResolvable);
        resetSelfAttribute(): void;
        get selfAttributeInput(): boolean | cdktn.IResolvable | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        resetToPort(): void;
        get toPortInput(): number | undefined;
    }
    class EgressPropertyList extends cdktn.ComplexList {
        internalValue?: EgressProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EgressPropertyOutputReference;
    }
    interface IngressProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#cidr_blocks AwsSecurityGroup#cidr_blocks}
        */
        readonly cidrBlocks?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#description AwsSecurityGroup#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#from_port AwsSecurityGroup#from_port}
        */
        readonly fromPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#ipv6_cidr_blocks AwsSecurityGroup#ipv6_cidr_blocks}
        */
        readonly ipv6CidrBlocks?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#prefix_list_ids AwsSecurityGroup#prefix_list_ids}
        */
        readonly prefixListIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#protocol AwsSecurityGroup#protocol}
        */
        readonly protocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#security_groups AwsSecurityGroup#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#self AwsSecurityGroup#self}
        */
        readonly selfAttribute?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#to_port AwsSecurityGroup#to_port}
        */
        readonly toPort?: number;
    }
    class IngressPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IngressProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IngressProperty | cdktn.IResolvable | undefined);
        private _cidrBlocks?;
        get cidrBlocks(): string[];
        set cidrBlocks(value: string[]);
        resetCidrBlocks(): void;
        get cidrBlocksInput(): string[] | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        resetFromPort(): void;
        get fromPortInput(): number | undefined;
        private _ipv6CidrBlocks?;
        get ipv6CidrBlocks(): string[];
        set ipv6CidrBlocks(value: string[]);
        resetIpv6CidrBlocks(): void;
        get ipv6CidrBlocksInput(): string[] | undefined;
        private _prefixListIds?;
        get prefixListIds(): string[];
        set prefixListIds(value: string[]);
        resetPrefixListIds(): void;
        get prefixListIdsInput(): string[] | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _self?;
        get selfAttribute(): boolean | cdktn.IResolvable;
        set selfAttribute(value: boolean | cdktn.IResolvable);
        resetSelfAttribute(): void;
        get selfAttributeInput(): boolean | cdktn.IResolvable | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        resetToPort(): void;
        get toPortInput(): number | undefined;
    }
    class IngressPropertyList extends cdktn.ComplexList {
        internalValue?: IngressProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IngressPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#create AwsSecurityGroup#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/security_group#delete AwsSecurityGroup#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
