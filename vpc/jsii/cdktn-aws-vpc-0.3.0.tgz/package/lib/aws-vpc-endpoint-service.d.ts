import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEndpointServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service#acceptance_required AwsEndpointService#acceptance_required}
    */
    readonly acceptanceRequired: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service#allowed_principals AwsEndpointService#allowed_principals}
    */
    readonly allowedPrincipals?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service#gateway_load_balancer_arns AwsEndpointService#gateway_load_balancer_arns}
    */
    readonly gatewayLoadBalancerArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service#id AwsEndpointService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service#network_load_balancer_arns AwsEndpointService#network_load_balancer_arns}
    */
    readonly networkLoadBalancerArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service#private_dns_name AwsEndpointService#private_dns_name}
    */
    readonly privateDnsName?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service#region AwsEndpointService#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service#supported_ip_address_types AwsEndpointService#supported_ip_address_types}
    */
    readonly supportedIpAddressTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service#supported_regions AwsEndpointService#supported_regions}
    */
    readonly supportedRegions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service#tags AwsEndpointService#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service#tags_all AwsEndpointService#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service#timeouts AwsEndpointService#timeouts}
    */
    readonly timeouts?: AwsEndpointService.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service aws_vpc_endpoint_service}
*/
export declare class AwsEndpointService extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_endpoint_service";
    /**
    * Generates CDKTN code for importing a AwsEndpointService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEndpointService to import
    * @param importFromId The id of the existing AwsEndpointService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEndpointService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service aws_vpc_endpoint_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEndpointServiceConfig
    */
    constructor(scope: Construct, id: string, config: AwsEndpointServiceConfig);
    private _acceptanceRequired?;
    get acceptanceRequired(): boolean | cdktn.IResolvable;
    set acceptanceRequired(value: boolean | cdktn.IResolvable);
    get acceptanceRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _allowedPrincipals?;
    get allowedPrincipals(): string[];
    set allowedPrincipals(value: string[]);
    resetAllowedPrincipals(): void;
    get allowedPrincipalsInput(): string[] | undefined;
    get arn(): string;
    get availabilityZones(): string[];
    get baseEndpointDnsNames(): string[];
    private _gatewayLoadBalancerArns?;
    get gatewayLoadBalancerArns(): string[];
    set gatewayLoadBalancerArns(value: string[]);
    resetGatewayLoadBalancerArns(): void;
    get gatewayLoadBalancerArnsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get managesVpcEndpoints(): cdktn.IResolvable;
    private _networkLoadBalancerArns?;
    get networkLoadBalancerArns(): string[];
    set networkLoadBalancerArns(value: string[]);
    resetNetworkLoadBalancerArns(): void;
    get networkLoadBalancerArnsInput(): string[] | undefined;
    private _privateDnsName?;
    get privateDnsName(): string;
    set privateDnsName(value: string);
    resetPrivateDnsName(): void;
    get privateDnsNameInput(): string | undefined;
    private _privateDnsNameConfiguration;
    get privateDnsNameConfiguration(): AwsEndpointService.PrivateDnsNameConfigurationPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get serviceName(): string;
    get serviceType(): string;
    get state(): string;
    private _supportedIpAddressTypes?;
    get supportedIpAddressTypes(): string[];
    set supportedIpAddressTypes(value: string[]);
    resetSupportedIpAddressTypes(): void;
    get supportedIpAddressTypesInput(): string[] | undefined;
    private _supportedRegions?;
    get supportedRegions(): string[];
    set supportedRegions(value: string[]);
    resetSupportedRegions(): void;
    get supportedRegionsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timeouts;
    get timeouts(): AwsEndpointService.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEndpointService.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsEndpointService.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEndpointServicePrivateDnsNameConfigurationPropertyToTerraform(struct?: AwsEndpointService.PrivateDnsNameConfigurationProperty): any;
export declare function awsEndpointServicePrivateDnsNameConfigurationPropertyToHclTerraform(struct?: AwsEndpointService.PrivateDnsNameConfigurationProperty): any;
export declare function awsEndpointServiceTimeoutsPropertyToTerraform(struct?: AwsEndpointService.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEndpointServiceTimeoutsPropertyToHclTerraform(struct?: AwsEndpointService.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsEndpointService {
    interface PrivateDnsNameConfigurationProperty {
    }
    class PrivateDnsNameConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrivateDnsNameConfigurationProperty | undefined;
        set internalValue(value: PrivateDnsNameConfigurationProperty | undefined);
        get name(): string;
        get state(): string;
        get type(): string;
        get value(): string;
    }
    class PrivateDnsNameConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrivateDnsNameConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service#create AwsEndpointService#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service#delete AwsEndpointService#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service#update AwsEndpointService#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
