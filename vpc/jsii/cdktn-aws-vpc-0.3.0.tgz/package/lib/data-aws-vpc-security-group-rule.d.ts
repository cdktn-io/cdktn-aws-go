import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsSecurityGroupRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_security_group_rule#region DataAwsSecurityGroupRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_security_group_rule#security_group_rule_id DataAwsSecurityGroupRule#security_group_rule_id}
    */
    readonly securityGroupRuleId?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_security_group_rule#filter DataAwsSecurityGroupRule#filter}
    */
    readonly filter?: DataAwsSecurityGroupRule.FilterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_security_group_rule aws_vpc_security_group_rule}
*/
export declare class DataAwsSecurityGroupRule extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_vpc_security_group_rule";
    /**
    * Generates CDKTN code for importing a DataAwsSecurityGroupRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsSecurityGroupRule to import
    * @param importFromId The id of the existing DataAwsSecurityGroupRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_security_group_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsSecurityGroupRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_security_group_rule aws_vpc_security_group_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsSecurityGroupRuleConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsSecurityGroupRuleConfig);
    get arn(): string;
    get cidrIpv4(): string;
    get cidrIpv6(): string;
    get description(): string;
    get fromPort(): number;
    get id(): string;
    get ipProtocol(): string;
    get isEgress(): cdktn.IResolvable;
    get prefixListId(): string;
    get referencedSecurityGroupId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get securityGroupId(): string;
    private _securityGroupRuleId?;
    get securityGroupRuleId(): string;
    set securityGroupRuleId(value: string);
    resetSecurityGroupRuleId(): void;
    get securityGroupRuleIdInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    get toPort(): number;
    private _filter;
    get filter(): DataAwsSecurityGroupRule.FilterPropertyList;
    putFilter(value: DataAwsSecurityGroupRule.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataAwsSecurityGroupRule.FilterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsSecurityGroupRuleFilterPropertyToTerraform(struct?: DataAwsSecurityGroupRule.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsSecurityGroupRuleFilterPropertyToHclTerraform(struct?: DataAwsSecurityGroupRule.FilterProperty | cdktn.IResolvable): any;
export declare namespace DataAwsSecurityGroupRule {
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_security_group_rule#name DataAwsSecurityGroupRule#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_security_group_rule#values DataAwsSecurityGroupRule#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
}
