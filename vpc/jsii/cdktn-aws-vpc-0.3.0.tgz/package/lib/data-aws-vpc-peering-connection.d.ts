import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsPeeringConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection#cidr_block DataAwsPeeringConnection#cidr_block}
    */
    readonly cidrBlock?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection#id DataAwsPeeringConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection#owner_id DataAwsPeeringConnection#owner_id}
    */
    readonly ownerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection#peer_cidr_block DataAwsPeeringConnection#peer_cidr_block}
    */
    readonly peerCidrBlock?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection#peer_owner_id DataAwsPeeringConnection#peer_owner_id}
    */
    readonly peerOwnerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection#peer_vpc_id DataAwsPeeringConnection#peer_vpc_id}
    */
    readonly peerVpcId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection#status DataAwsPeeringConnection#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection#tags DataAwsPeeringConnection#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection#vpc_id DataAwsPeeringConnection#vpc_id}
    */
    readonly vpcId?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection#filter DataAwsPeeringConnection#filter}
    */
    readonly filter?: DataAwsPeeringConnection.FilterProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection#timeouts DataAwsPeeringConnection#timeouts}
    */
    readonly timeouts?: DataAwsPeeringConnection.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection aws_vpc_peering_connection}
*/
export declare class DataAwsPeeringConnection extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_vpc_peering_connection";
    /**
    * Generates CDKTN code for importing a DataAwsPeeringConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsPeeringConnection to import
    * @param importFromId The id of the existing DataAwsPeeringConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsPeeringConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection aws_vpc_peering_connection} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsPeeringConnectionConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsPeeringConnectionConfig);
    private _accepter;
    get accepter(): cdktn.BooleanMap;
    private _cidrBlock?;
    get cidrBlock(): string;
    set cidrBlock(value: string);
    resetCidrBlock(): void;
    get cidrBlockInput(): string | undefined;
    private _cidrBlockSet;
    get cidrBlockSet(): DataAwsPeeringConnection.CidrBlockSetPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipv6CidrBlockSet;
    get ipv6CidrBlockSet(): DataAwsPeeringConnection.Ipv6CidrBlockSetPropertyList;
    private _ownerId?;
    get ownerId(): string;
    set ownerId(value: string);
    resetOwnerId(): void;
    get ownerIdInput(): string | undefined;
    private _peerCidrBlock?;
    get peerCidrBlock(): string;
    set peerCidrBlock(value: string);
    resetPeerCidrBlock(): void;
    get peerCidrBlockInput(): string | undefined;
    private _peerCidrBlockSet;
    get peerCidrBlockSet(): DataAwsPeeringConnection.PeerCidrBlockSetPropertyList;
    private _peerIpv6CidrBlockSet;
    get peerIpv6CidrBlockSet(): DataAwsPeeringConnection.PeerIpv6CidrBlockSetPropertyList;
    private _peerOwnerId?;
    get peerOwnerId(): string;
    set peerOwnerId(value: string);
    resetPeerOwnerId(): void;
    get peerOwnerIdInput(): string | undefined;
    get peerRegion(): string;
    private _peerVpcId?;
    get peerVpcId(): string;
    set peerVpcId(value: string);
    resetPeerVpcId(): void;
    get peerVpcIdInput(): string | undefined;
    get region(): string;
    private _requester;
    get requester(): cdktn.BooleanMap;
    get requesterRegion(): string;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    private _filter;
    get filter(): DataAwsPeeringConnection.FilterPropertyList;
    putFilter(value: DataAwsPeeringConnection.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataAwsPeeringConnection.FilterProperty[] | undefined;
    private _timeouts;
    get timeouts(): DataAwsPeeringConnection.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataAwsPeeringConnection.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAwsPeeringConnection.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsPeeringConnectionCidrBlockSetPropertyToTerraform(struct?: DataAwsPeeringConnection.CidrBlockSetProperty): any;
export declare function dataAwsPeeringConnectionCidrBlockSetPropertyToHclTerraform(struct?: DataAwsPeeringConnection.CidrBlockSetProperty): any;
export declare function dataAwsPeeringConnectionIpv6CidrBlockSetPropertyToTerraform(struct?: DataAwsPeeringConnection.Ipv6CidrBlockSetProperty): any;
export declare function dataAwsPeeringConnectionIpv6CidrBlockSetPropertyToHclTerraform(struct?: DataAwsPeeringConnection.Ipv6CidrBlockSetProperty): any;
export declare function dataAwsPeeringConnectionPeerCidrBlockSetPropertyToTerraform(struct?: DataAwsPeeringConnection.PeerCidrBlockSetProperty): any;
export declare function dataAwsPeeringConnectionPeerCidrBlockSetPropertyToHclTerraform(struct?: DataAwsPeeringConnection.PeerCidrBlockSetProperty): any;
export declare function dataAwsPeeringConnectionPeerIpv6CidrBlockSetPropertyToTerraform(struct?: DataAwsPeeringConnection.PeerIpv6CidrBlockSetProperty): any;
export declare function dataAwsPeeringConnectionPeerIpv6CidrBlockSetPropertyToHclTerraform(struct?: DataAwsPeeringConnection.PeerIpv6CidrBlockSetProperty): any;
export declare function dataAwsPeeringConnectionFilterPropertyToTerraform(struct?: DataAwsPeeringConnection.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsPeeringConnectionFilterPropertyToHclTerraform(struct?: DataAwsPeeringConnection.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsPeeringConnectionTimeoutsPropertyToTerraform(struct?: DataAwsPeeringConnection.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataAwsPeeringConnectionTimeoutsPropertyToHclTerraform(struct?: DataAwsPeeringConnection.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataAwsPeeringConnection {
    interface CidrBlockSetProperty {
    }
    class CidrBlockSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CidrBlockSetProperty | undefined;
        set internalValue(value: CidrBlockSetProperty | undefined);
        get cidrBlock(): string;
    }
    class CidrBlockSetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CidrBlockSetPropertyOutputReference;
    }
    interface Ipv6CidrBlockSetProperty {
    }
    class Ipv6CidrBlockSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Ipv6CidrBlockSetProperty | undefined;
        set internalValue(value: Ipv6CidrBlockSetProperty | undefined);
        get ipv6CidrBlock(): string;
    }
    class Ipv6CidrBlockSetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Ipv6CidrBlockSetPropertyOutputReference;
    }
    interface PeerCidrBlockSetProperty {
    }
    class PeerCidrBlockSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PeerCidrBlockSetProperty | undefined;
        set internalValue(value: PeerCidrBlockSetProperty | undefined);
        get cidrBlock(): string;
    }
    class PeerCidrBlockSetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PeerCidrBlockSetPropertyOutputReference;
    }
    interface PeerIpv6CidrBlockSetProperty {
    }
    class PeerIpv6CidrBlockSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PeerIpv6CidrBlockSetProperty | undefined;
        set internalValue(value: PeerIpv6CidrBlockSetProperty | undefined);
        get ipv6CidrBlock(): string;
    }
    class PeerIpv6CidrBlockSetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PeerIpv6CidrBlockSetPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection#name DataAwsPeeringConnection#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection#values DataAwsPeeringConnection#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_peering_connection#read DataAwsPeeringConnection#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
