import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsEc2NetworkInsightsAnalysisConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis#id DataAwsEc2NetworkInsightsAnalysis#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis#network_insights_analysis_id DataAwsEc2NetworkInsightsAnalysis#network_insights_analysis_id}
    */
    readonly networkInsightsAnalysisId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis#region DataAwsEc2NetworkInsightsAnalysis#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis#tags DataAwsEc2NetworkInsightsAnalysis#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis#filter DataAwsEc2NetworkInsightsAnalysis#filter}
    */
    readonly filter?: DataAwsEc2NetworkInsightsAnalysis.FilterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis aws_ec2_network_insights_analysis}
*/
export declare class DataAwsEc2NetworkInsightsAnalysis extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ec2_network_insights_analysis";
    /**
    * Generates CDKTN code for importing a DataAwsEc2NetworkInsightsAnalysis resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsEc2NetworkInsightsAnalysis to import
    * @param importFromId The id of the existing DataAwsEc2NetworkInsightsAnalysis that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsEc2NetworkInsightsAnalysis to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis aws_ec2_network_insights_analysis} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsEc2NetworkInsightsAnalysisConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsEc2NetworkInsightsAnalysisConfig);
    private _alternatePathHints;
    get alternatePathHints(): DataAwsEc2NetworkInsightsAnalysis.AlternatePathHintsPropertyList;
    get arn(): string;
    private _explanations;
    get explanations(): DataAwsEc2NetworkInsightsAnalysis.ExplanationsPropertyList;
    get filterInArns(): string[];
    private _forwardPathComponents;
    get forwardPathComponents(): DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _networkInsightsAnalysisId?;
    get networkInsightsAnalysisId(): string;
    set networkInsightsAnalysisId(value: string);
    resetNetworkInsightsAnalysisId(): void;
    get networkInsightsAnalysisIdInput(): string | undefined;
    get networkInsightsPathId(): string;
    get pathFound(): cdktn.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _returnPathComponents;
    get returnPathComponents(): DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsPropertyList;
    get startDate(): string;
    get status(): string;
    get statusMessage(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get warningMessage(): string;
    private _filter;
    get filter(): DataAwsEc2NetworkInsightsAnalysis.FilterPropertyList;
    putFilter(value: DataAwsEc2NetworkInsightsAnalysis.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataAwsEc2NetworkInsightsAnalysis.FilterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsEc2NetworkInsightsAnalysisAlternatePathHintsPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.AlternatePathHintsProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisAlternatePathHintsPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.AlternatePathHintsProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisAclPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.AclProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisAclPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.AclProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsAclRulePortRangePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsAclRulePortRangeProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsAclRulePortRangePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsAclRulePortRangeProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsAclRulePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsAclRuleProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsAclRulePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsAclRuleProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsAttachedToPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsAttachedToProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsAttachedToPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsAttachedToProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisClassicLoadBalancerListenerPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ClassicLoadBalancerListenerProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisClassicLoadBalancerListenerPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ClassicLoadBalancerListenerProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsComponentPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsComponentProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsComponentPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsComponentProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisCustomerGatewayPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.CustomerGatewayProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisCustomerGatewayPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.CustomerGatewayProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisDestinationPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.DestinationProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisDestinationPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.DestinationProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsDestinationVpcPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsDestinationVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsDestinationVpcPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsDestinationVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisElasticLoadBalancerListenerPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ElasticLoadBalancerListenerProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisElasticLoadBalancerListenerPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ElasticLoadBalancerListenerProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisIngressRouteTablePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.IngressRouteTableProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisIngressRouteTablePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.IngressRouteTableProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisInternetGatewayPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.InternetGatewayProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisInternetGatewayPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.InternetGatewayProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisLoadBalancerTargetGroupPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.LoadBalancerTargetGroupProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisLoadBalancerTargetGroupPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.LoadBalancerTargetGroupProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisLoadBalancerTargetGroupsPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.LoadBalancerTargetGroupsProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisLoadBalancerTargetGroupsPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.LoadBalancerTargetGroupsProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisNatGatewayPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.NatGatewayProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisNatGatewayPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.NatGatewayProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisNetworkInterfacePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.NetworkInterfaceProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisNetworkInterfacePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.NetworkInterfaceProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisPortRangesPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.PortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisPortRangesPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.PortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisPrefixListPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.PrefixListProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisPrefixListPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.PrefixListProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisRouteTablePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.RouteTableProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisRouteTablePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.RouteTableProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsRouteTableRoutePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsRouteTableRouteProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsRouteTableRoutePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsRouteTableRouteProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisSecurityGroupPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.SecurityGroupProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisSecurityGroupPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.SecurityGroupProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsSecurityGroupRulePortRangePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsSecurityGroupRulePortRangeProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsSecurityGroupRulePortRangePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsSecurityGroupRulePortRangeProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsSecurityGroupRulePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsSecurityGroupRuleProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsSecurityGroupRulePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsSecurityGroupRuleProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisSecurityGroupsPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.SecurityGroupsProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisSecurityGroupsPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.SecurityGroupsProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsSourceVpcPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsSourceVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsSourceVpcPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsSourceVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsSubnetPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsSubnetProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsSubnetPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsSubnetProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisSubnetRouteTablePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.SubnetRouteTableProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisSubnetRouteTablePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.SubnetRouteTableProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsTransitGatewayPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsTransitGatewayProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsTransitGatewayPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsTransitGatewayProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisTransitGatewayAttachmentPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.TransitGatewayAttachmentProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisTransitGatewayAttachmentPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.TransitGatewayAttachmentProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisTransitGatewayRouteTablePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.TransitGatewayRouteTableProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisTransitGatewayRouteTablePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.TransitGatewayRouteTableProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsTransitGatewayRouteTableRoutePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsTransitGatewayRouteTableRouteProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsTransitGatewayRouteTableRoutePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsTransitGatewayRouteTableRouteProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsVpcPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsVpcPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisVpcEndpointPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.VpcEndpointProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisVpcEndpointPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.VpcEndpointProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisVpcPeeringConnectionPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.VpcPeeringConnectionProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisVpcPeeringConnectionPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.VpcPeeringConnectionProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisVpnConnectionPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.VpnConnectionProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisVpnConnectionPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.VpnConnectionProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisVpnGatewayPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.VpnGatewayProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisVpnGatewayPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.VpnGatewayProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisExplanationsPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ExplanationsProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsAclRulePortRangePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsAclRulePortRangeProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsAclRulePortRangePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsAclRulePortRangeProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsAclRulePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsAclRuleProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsAclRulePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsAclRuleProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsAdditionalDetailsComponentPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsAdditionalDetailsComponentProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsAdditionalDetailsComponentPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsAdditionalDetailsComponentProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsAdditionalDetailsPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsAdditionalDetailsProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsAdditionalDetailsPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsAdditionalDetailsProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsAttachedToPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsAttachedToProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsAttachedToPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsAttachedToProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsComponentPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsComponentProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsComponentPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsComponentProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsDestinationVpcPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsDestinationVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsDestinationVpcPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsDestinationVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsInboundHeaderDestinationPortRangesPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsInboundHeaderDestinationPortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsInboundHeaderDestinationPortRangesPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsInboundHeaderDestinationPortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsInboundHeaderSourcePortRangesPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsInboundHeaderSourcePortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsInboundHeaderSourcePortRangesPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsInboundHeaderSourcePortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsInboundHeaderPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsInboundHeaderProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsInboundHeaderPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsInboundHeaderProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsOutboundHeaderDestinationPortRangesPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsOutboundHeaderDestinationPortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsOutboundHeaderDestinationPortRangesPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsOutboundHeaderDestinationPortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsOutboundHeaderSourcePortRangesPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsOutboundHeaderSourcePortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsOutboundHeaderSourcePortRangesPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsOutboundHeaderSourcePortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsOutboundHeaderPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsOutboundHeaderProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsOutboundHeaderPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsOutboundHeaderProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsRouteTableRoutePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsRouteTableRouteProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsRouteTableRoutePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsRouteTableRouteProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsSecurityGroupRulePortRangePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsSecurityGroupRulePortRangeProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsSecurityGroupRulePortRangePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsSecurityGroupRulePortRangeProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsSecurityGroupRulePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsSecurityGroupRuleProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsSecurityGroupRulePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsSecurityGroupRuleProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsSourceVpcPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsSourceVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsSourceVpcPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsSourceVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsSubnetPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsSubnetProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsSubnetPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsSubnetProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsTransitGatewayPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsTransitGatewayProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsTransitGatewayPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsTransitGatewayProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsTransitGatewayRouteTableRoutePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsTransitGatewayRouteTableRouteProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsTransitGatewayRouteTableRoutePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsTransitGatewayRouteTableRouteProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsVpcPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsVpcPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisForwardPathComponentsPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ForwardPathComponentsProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsAclRulePortRangePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsAclRulePortRangeProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsAclRulePortRangePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsAclRulePortRangeProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsAclRulePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsAclRuleProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsAclRulePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsAclRuleProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsAdditionalDetailsComponentPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsAdditionalDetailsComponentProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsAdditionalDetailsComponentPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsAdditionalDetailsComponentProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsAdditionalDetailsPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsAdditionalDetailsProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsAdditionalDetailsPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsAdditionalDetailsProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsAttachedToPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsAttachedToProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsAttachedToPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsAttachedToProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsComponentPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsComponentProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsComponentPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsComponentProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsDestinationVpcPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsDestinationVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsDestinationVpcPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsDestinationVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsInboundHeaderDestinationPortRangesPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsInboundHeaderDestinationPortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsInboundHeaderDestinationPortRangesPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsInboundHeaderDestinationPortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsInboundHeaderSourcePortRangesPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsInboundHeaderSourcePortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsInboundHeaderSourcePortRangesPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsInboundHeaderSourcePortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsInboundHeaderPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsInboundHeaderProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsInboundHeaderPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsInboundHeaderProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsOutboundHeaderDestinationPortRangesPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsOutboundHeaderDestinationPortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsOutboundHeaderDestinationPortRangesPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsOutboundHeaderDestinationPortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsOutboundHeaderSourcePortRangesPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsOutboundHeaderSourcePortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsOutboundHeaderSourcePortRangesPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsOutboundHeaderSourcePortRangesProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsOutboundHeaderPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsOutboundHeaderProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsOutboundHeaderPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsOutboundHeaderProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsRouteTableRoutePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsRouteTableRouteProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsRouteTableRoutePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsRouteTableRouteProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsSecurityGroupRulePortRangePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsSecurityGroupRulePortRangeProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsSecurityGroupRulePortRangePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsSecurityGroupRulePortRangeProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsSecurityGroupRulePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsSecurityGroupRuleProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsSecurityGroupRulePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsSecurityGroupRuleProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsSourceVpcPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsSourceVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsSourceVpcPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsSourceVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsSubnetPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsSubnetProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsSubnetPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsSubnetProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsTransitGatewayPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsTransitGatewayProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsTransitGatewayPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsTransitGatewayProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsTransitGatewayRouteTableRoutePropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsTransitGatewayRouteTableRouteProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsTransitGatewayRouteTableRoutePropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsTransitGatewayRouteTableRouteProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsVpcPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsVpcPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsVpcProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisReturnPathComponentsPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.ReturnPathComponentsProperty): any;
export declare function dataAwsEc2NetworkInsightsAnalysisFilterPropertyToTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsEc2NetworkInsightsAnalysisFilterPropertyToHclTerraform(struct?: DataAwsEc2NetworkInsightsAnalysis.FilterProperty | cdktn.IResolvable): any;
export declare namespace DataAwsEc2NetworkInsightsAnalysis {
    interface AlternatePathHintsProperty {
    }
    class AlternatePathHintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AlternatePathHintsProperty | undefined;
        set internalValue(value: AlternatePathHintsProperty | undefined);
        get componentArn(): string;
        get componentId(): string;
    }
    class AlternatePathHintsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AlternatePathHintsPropertyOutputReference;
    }
    interface AclProperty {
    }
    class AclPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AclProperty | undefined;
        set internalValue(value: AclProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class AclPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AclPropertyOutputReference;
    }
    interface ExplanationsAclRulePortRangeProperty {
    }
    class ExplanationsAclRulePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsAclRulePortRangeProperty | undefined;
        set internalValue(value: ExplanationsAclRulePortRangeProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ExplanationsAclRulePortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsAclRulePortRangePropertyOutputReference;
    }
    interface ExplanationsAclRuleProperty {
    }
    class ExplanationsAclRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsAclRuleProperty | undefined;
        set internalValue(value: ExplanationsAclRuleProperty | undefined);
        get cidr(): string;
        get egress(): cdktn.IResolvable;
        private _portRange;
        get portRange(): ExplanationsAclRulePortRangePropertyList;
        get protocol(): string;
        get ruleAction(): string;
        get ruleNumber(): number;
    }
    class ExplanationsAclRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsAclRulePropertyOutputReference;
    }
    interface ExplanationsAttachedToProperty {
    }
    class ExplanationsAttachedToPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsAttachedToProperty | undefined;
        set internalValue(value: ExplanationsAttachedToProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ExplanationsAttachedToPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsAttachedToPropertyOutputReference;
    }
    interface ClassicLoadBalancerListenerProperty {
    }
    class ClassicLoadBalancerListenerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClassicLoadBalancerListenerProperty | undefined;
        set internalValue(value: ClassicLoadBalancerListenerProperty | undefined);
        get instancePort(): number;
        get loadBalancerPort(): number;
    }
    class ClassicLoadBalancerListenerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClassicLoadBalancerListenerPropertyOutputReference;
    }
    interface ExplanationsComponentProperty {
    }
    class ExplanationsComponentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsComponentProperty | undefined;
        set internalValue(value: ExplanationsComponentProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ExplanationsComponentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsComponentPropertyOutputReference;
    }
    interface CustomerGatewayProperty {
    }
    class CustomerGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomerGatewayProperty | undefined;
        set internalValue(value: CustomerGatewayProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class CustomerGatewayPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomerGatewayPropertyOutputReference;
    }
    interface DestinationProperty {
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationProperty | undefined;
        set internalValue(value: DestinationProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class DestinationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationPropertyOutputReference;
    }
    interface ExplanationsDestinationVpcProperty {
    }
    class ExplanationsDestinationVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsDestinationVpcProperty | undefined;
        set internalValue(value: ExplanationsDestinationVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ExplanationsDestinationVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsDestinationVpcPropertyOutputReference;
    }
    interface ElasticLoadBalancerListenerProperty {
    }
    class ElasticLoadBalancerListenerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ElasticLoadBalancerListenerProperty | undefined;
        set internalValue(value: ElasticLoadBalancerListenerProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ElasticLoadBalancerListenerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ElasticLoadBalancerListenerPropertyOutputReference;
    }
    interface IngressRouteTableProperty {
    }
    class IngressRouteTablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IngressRouteTableProperty | undefined;
        set internalValue(value: IngressRouteTableProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class IngressRouteTablePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IngressRouteTablePropertyOutputReference;
    }
    interface InternetGatewayProperty {
    }
    class InternetGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InternetGatewayProperty | undefined;
        set internalValue(value: InternetGatewayProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class InternetGatewayPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InternetGatewayPropertyOutputReference;
    }
    interface LoadBalancerTargetGroupProperty {
    }
    class LoadBalancerTargetGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoadBalancerTargetGroupProperty | undefined;
        set internalValue(value: LoadBalancerTargetGroupProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class LoadBalancerTargetGroupPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoadBalancerTargetGroupPropertyOutputReference;
    }
    interface LoadBalancerTargetGroupsProperty {
    }
    class LoadBalancerTargetGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoadBalancerTargetGroupsProperty | undefined;
        set internalValue(value: LoadBalancerTargetGroupsProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class LoadBalancerTargetGroupsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoadBalancerTargetGroupsPropertyOutputReference;
    }
    interface NatGatewayProperty {
    }
    class NatGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NatGatewayProperty | undefined;
        set internalValue(value: NatGatewayProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class NatGatewayPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NatGatewayPropertyOutputReference;
    }
    interface NetworkInterfaceProperty {
    }
    class NetworkInterfacePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkInterfaceProperty | undefined;
        set internalValue(value: NetworkInterfaceProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class NetworkInterfacePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkInterfacePropertyOutputReference;
    }
    interface PortRangesProperty {
    }
    class PortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PortRangesProperty | undefined;
        set internalValue(value: PortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class PortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PortRangesPropertyOutputReference;
    }
    interface PrefixListProperty {
    }
    class PrefixListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrefixListProperty | undefined;
        set internalValue(value: PrefixListProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class PrefixListPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrefixListPropertyOutputReference;
    }
    interface RouteTableProperty {
    }
    class RouteTablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RouteTableProperty | undefined;
        set internalValue(value: RouteTableProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class RouteTablePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RouteTablePropertyOutputReference;
    }
    interface ExplanationsRouteTableRouteProperty {
    }
    class ExplanationsRouteTableRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsRouteTableRouteProperty | undefined;
        set internalValue(value: ExplanationsRouteTableRouteProperty | undefined);
        get destinationCidr(): string;
        get destinationPrefixListId(): string;
        get egressOnlyInternetGatewayId(): string;
        get gatewayId(): string;
        get instanceId(): string;
        get natGatewayId(): string;
        get networkInterfaceId(): string;
        get origin(): string;
        get transitGatewayId(): string;
        get vpcPeeringConnectionId(): string;
    }
    class ExplanationsRouteTableRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsRouteTableRoutePropertyOutputReference;
    }
    interface SecurityGroupProperty {
    }
    class SecurityGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecurityGroupProperty | undefined;
        set internalValue(value: SecurityGroupProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class SecurityGroupPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecurityGroupPropertyOutputReference;
    }
    interface ExplanationsSecurityGroupRulePortRangeProperty {
    }
    class ExplanationsSecurityGroupRulePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsSecurityGroupRulePortRangeProperty | undefined;
        set internalValue(value: ExplanationsSecurityGroupRulePortRangeProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ExplanationsSecurityGroupRulePortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsSecurityGroupRulePortRangePropertyOutputReference;
    }
    interface ExplanationsSecurityGroupRuleProperty {
    }
    class ExplanationsSecurityGroupRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsSecurityGroupRuleProperty | undefined;
        set internalValue(value: ExplanationsSecurityGroupRuleProperty | undefined);
        get cidr(): string;
        get direction(): string;
        private _portRange;
        get portRange(): ExplanationsSecurityGroupRulePortRangePropertyList;
        get prefixListId(): string;
        get protocol(): string;
        get securityGroupId(): string;
    }
    class ExplanationsSecurityGroupRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsSecurityGroupRulePropertyOutputReference;
    }
    interface SecurityGroupsProperty {
    }
    class SecurityGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecurityGroupsProperty | undefined;
        set internalValue(value: SecurityGroupsProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class SecurityGroupsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecurityGroupsPropertyOutputReference;
    }
    interface ExplanationsSourceVpcProperty {
    }
    class ExplanationsSourceVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsSourceVpcProperty | undefined;
        set internalValue(value: ExplanationsSourceVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ExplanationsSourceVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsSourceVpcPropertyOutputReference;
    }
    interface ExplanationsSubnetProperty {
    }
    class ExplanationsSubnetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsSubnetProperty | undefined;
        set internalValue(value: ExplanationsSubnetProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ExplanationsSubnetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsSubnetPropertyOutputReference;
    }
    interface SubnetRouteTableProperty {
    }
    class SubnetRouteTablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubnetRouteTableProperty | undefined;
        set internalValue(value: SubnetRouteTableProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class SubnetRouteTablePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubnetRouteTablePropertyOutputReference;
    }
    interface ExplanationsTransitGatewayProperty {
    }
    class ExplanationsTransitGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsTransitGatewayProperty | undefined;
        set internalValue(value: ExplanationsTransitGatewayProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ExplanationsTransitGatewayPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsTransitGatewayPropertyOutputReference;
    }
    interface TransitGatewayAttachmentProperty {
    }
    class TransitGatewayAttachmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransitGatewayAttachmentProperty | undefined;
        set internalValue(value: TransitGatewayAttachmentProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class TransitGatewayAttachmentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransitGatewayAttachmentPropertyOutputReference;
    }
    interface TransitGatewayRouteTableProperty {
    }
    class TransitGatewayRouteTablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransitGatewayRouteTableProperty | undefined;
        set internalValue(value: TransitGatewayRouteTableProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class TransitGatewayRouteTablePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransitGatewayRouteTablePropertyOutputReference;
    }
    interface ExplanationsTransitGatewayRouteTableRouteProperty {
    }
    class ExplanationsTransitGatewayRouteTableRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsTransitGatewayRouteTableRouteProperty | undefined;
        set internalValue(value: ExplanationsTransitGatewayRouteTableRouteProperty | undefined);
        get attachmentId(): string;
        get destinationCidr(): string;
        get prefixListId(): string;
        get resourceId(): string;
        get resourceType(): string;
        get routeOrigin(): string;
        get state(): string;
    }
    class ExplanationsTransitGatewayRouteTableRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsTransitGatewayRouteTableRoutePropertyOutputReference;
    }
    interface ExplanationsVpcProperty {
    }
    class ExplanationsVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsVpcProperty | undefined;
        set internalValue(value: ExplanationsVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ExplanationsVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsVpcPropertyOutputReference;
    }
    interface VpcEndpointProperty {
    }
    class VpcEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcEndpointProperty | undefined;
        set internalValue(value: VpcEndpointProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class VpcEndpointPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcEndpointPropertyOutputReference;
    }
    interface VpcPeeringConnectionProperty {
    }
    class VpcPeeringConnectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcPeeringConnectionProperty | undefined;
        set internalValue(value: VpcPeeringConnectionProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class VpcPeeringConnectionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcPeeringConnectionPropertyOutputReference;
    }
    interface VpnConnectionProperty {
    }
    class VpnConnectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpnConnectionProperty | undefined;
        set internalValue(value: VpnConnectionProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class VpnConnectionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpnConnectionPropertyOutputReference;
    }
    interface VpnGatewayProperty {
    }
    class VpnGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpnGatewayProperty | undefined;
        set internalValue(value: VpnGatewayProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class VpnGatewayPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpnGatewayPropertyOutputReference;
    }
    interface ExplanationsProperty {
    }
    class ExplanationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsProperty | undefined;
        set internalValue(value: ExplanationsProperty | undefined);
        private _acl;
        get acl(): AclPropertyList;
        private _aclRule;
        get aclRule(): ExplanationsAclRulePropertyList;
        get address(): string;
        get addresses(): string[];
        private _attachedTo;
        get attachedTo(): ExplanationsAttachedToPropertyList;
        get availabilityZones(): string[];
        get cidrs(): string[];
        private _classicLoadBalancerListener;
        get classicLoadBalancerListener(): ClassicLoadBalancerListenerPropertyList;
        private _component;
        get component(): ExplanationsComponentPropertyList;
        private _customerGateway;
        get customerGateway(): CustomerGatewayPropertyList;
        private _destination;
        get destination(): DestinationPropertyList;
        private _destinationVpc;
        get destinationVpc(): ExplanationsDestinationVpcPropertyList;
        get direction(): string;
        private _elasticLoadBalancerListener;
        get elasticLoadBalancerListener(): ElasticLoadBalancerListenerPropertyList;
        get explanationCode(): string;
        private _ingressRouteTable;
        get ingressRouteTable(): IngressRouteTablePropertyList;
        private _internetGateway;
        get internetGateway(): InternetGatewayPropertyList;
        get loadBalancerArn(): string;
        get loadBalancerListenerPort(): number;
        private _loadBalancerTargetGroup;
        get loadBalancerTargetGroup(): LoadBalancerTargetGroupPropertyList;
        private _loadBalancerTargetGroups;
        get loadBalancerTargetGroups(): LoadBalancerTargetGroupsPropertyList;
        get loadBalancerTargetPort(): number;
        get missingComponent(): string;
        private _natGateway;
        get natGateway(): NatGatewayPropertyList;
        private _networkInterface;
        get networkInterface(): NetworkInterfacePropertyList;
        get packetField(): string;
        get port(): number;
        private _portRanges;
        get portRanges(): PortRangesPropertyList;
        private _prefixList;
        get prefixList(): PrefixListPropertyList;
        get protocols(): string[];
        private _routeTable;
        get routeTable(): RouteTablePropertyList;
        private _routeTableRoute;
        get routeTableRoute(): ExplanationsRouteTableRoutePropertyList;
        private _securityGroup;
        get securityGroup(): SecurityGroupPropertyList;
        private _securityGroupRule;
        get securityGroupRule(): ExplanationsSecurityGroupRulePropertyList;
        private _securityGroups;
        get securityGroups(): SecurityGroupsPropertyList;
        private _sourceVpc;
        get sourceVpc(): ExplanationsSourceVpcPropertyList;
        get state(): string;
        private _subnet;
        get subnet(): ExplanationsSubnetPropertyList;
        private _subnetRouteTable;
        get subnetRouteTable(): SubnetRouteTablePropertyList;
        private _transitGateway;
        get transitGateway(): ExplanationsTransitGatewayPropertyList;
        private _transitGatewayAttachment;
        get transitGatewayAttachment(): TransitGatewayAttachmentPropertyList;
        private _transitGatewayRouteTable;
        get transitGatewayRouteTable(): TransitGatewayRouteTablePropertyList;
        private _transitGatewayRouteTableRoute;
        get transitGatewayRouteTableRoute(): ExplanationsTransitGatewayRouteTableRoutePropertyList;
        private _vpc;
        get vpc(): ExplanationsVpcPropertyList;
        private _vpcEndpoint;
        get vpcEndpoint(): VpcEndpointPropertyList;
        private _vpcPeeringConnection;
        get vpcPeeringConnection(): VpcPeeringConnectionPropertyList;
        private _vpnConnection;
        get vpnConnection(): VpnConnectionPropertyList;
        private _vpnGateway;
        get vpnGateway(): VpnGatewayPropertyList;
    }
    class ExplanationsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsPropertyOutputReference;
    }
    interface ForwardPathComponentsAclRulePortRangeProperty {
    }
    class ForwardPathComponentsAclRulePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsAclRulePortRangeProperty | undefined;
        set internalValue(value: ForwardPathComponentsAclRulePortRangeProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ForwardPathComponentsAclRulePortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsAclRulePortRangePropertyOutputReference;
    }
    interface ForwardPathComponentsAclRuleProperty {
    }
    class ForwardPathComponentsAclRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsAclRuleProperty | undefined;
        set internalValue(value: ForwardPathComponentsAclRuleProperty | undefined);
        get cidr(): string;
        get egress(): cdktn.IResolvable;
        private _portRange;
        get portRange(): ForwardPathComponentsAclRulePortRangePropertyList;
        get protocol(): string;
        get ruleAction(): string;
        get ruleNumber(): number;
    }
    class ForwardPathComponentsAclRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsAclRulePropertyOutputReference;
    }
    interface ForwardPathComponentsAdditionalDetailsComponentProperty {
    }
    class ForwardPathComponentsAdditionalDetailsComponentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsAdditionalDetailsComponentProperty | undefined;
        set internalValue(value: ForwardPathComponentsAdditionalDetailsComponentProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ForwardPathComponentsAdditionalDetailsComponentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsAdditionalDetailsComponentPropertyOutputReference;
    }
    interface ForwardPathComponentsAdditionalDetailsProperty {
    }
    class ForwardPathComponentsAdditionalDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsAdditionalDetailsProperty | undefined;
        set internalValue(value: ForwardPathComponentsAdditionalDetailsProperty | undefined);
        get additionalDetailType(): string;
        private _component;
        get component(): ForwardPathComponentsAdditionalDetailsComponentPropertyList;
    }
    class ForwardPathComponentsAdditionalDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsAdditionalDetailsPropertyOutputReference;
    }
    interface ForwardPathComponentsAttachedToProperty {
    }
    class ForwardPathComponentsAttachedToPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsAttachedToProperty | undefined;
        set internalValue(value: ForwardPathComponentsAttachedToProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ForwardPathComponentsAttachedToPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsAttachedToPropertyOutputReference;
    }
    interface ForwardPathComponentsComponentProperty {
    }
    class ForwardPathComponentsComponentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsComponentProperty | undefined;
        set internalValue(value: ForwardPathComponentsComponentProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ForwardPathComponentsComponentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsComponentPropertyOutputReference;
    }
    interface ForwardPathComponentsDestinationVpcProperty {
    }
    class ForwardPathComponentsDestinationVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsDestinationVpcProperty | undefined;
        set internalValue(value: ForwardPathComponentsDestinationVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ForwardPathComponentsDestinationVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsDestinationVpcPropertyOutputReference;
    }
    interface ForwardPathComponentsInboundHeaderDestinationPortRangesProperty {
    }
    class ForwardPathComponentsInboundHeaderDestinationPortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsInboundHeaderDestinationPortRangesProperty | undefined;
        set internalValue(value: ForwardPathComponentsInboundHeaderDestinationPortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ForwardPathComponentsInboundHeaderDestinationPortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsInboundHeaderDestinationPortRangesPropertyOutputReference;
    }
    interface ForwardPathComponentsInboundHeaderSourcePortRangesProperty {
    }
    class ForwardPathComponentsInboundHeaderSourcePortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsInboundHeaderSourcePortRangesProperty | undefined;
        set internalValue(value: ForwardPathComponentsInboundHeaderSourcePortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ForwardPathComponentsInboundHeaderSourcePortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsInboundHeaderSourcePortRangesPropertyOutputReference;
    }
    interface ForwardPathComponentsInboundHeaderProperty {
    }
    class ForwardPathComponentsInboundHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsInboundHeaderProperty | undefined;
        set internalValue(value: ForwardPathComponentsInboundHeaderProperty | undefined);
        get destinationAddresses(): string[];
        private _destinationPortRanges;
        get destinationPortRanges(): ForwardPathComponentsInboundHeaderDestinationPortRangesPropertyList;
        get protocol(): string;
        get sourceAddresses(): string[];
        private _sourcePortRanges;
        get sourcePortRanges(): ForwardPathComponentsInboundHeaderSourcePortRangesPropertyList;
    }
    class ForwardPathComponentsInboundHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsInboundHeaderPropertyOutputReference;
    }
    interface ForwardPathComponentsOutboundHeaderDestinationPortRangesProperty {
    }
    class ForwardPathComponentsOutboundHeaderDestinationPortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsOutboundHeaderDestinationPortRangesProperty | undefined;
        set internalValue(value: ForwardPathComponentsOutboundHeaderDestinationPortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ForwardPathComponentsOutboundHeaderDestinationPortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsOutboundHeaderDestinationPortRangesPropertyOutputReference;
    }
    interface ForwardPathComponentsOutboundHeaderSourcePortRangesProperty {
    }
    class ForwardPathComponentsOutboundHeaderSourcePortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsOutboundHeaderSourcePortRangesProperty | undefined;
        set internalValue(value: ForwardPathComponentsOutboundHeaderSourcePortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ForwardPathComponentsOutboundHeaderSourcePortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsOutboundHeaderSourcePortRangesPropertyOutputReference;
    }
    interface ForwardPathComponentsOutboundHeaderProperty {
    }
    class ForwardPathComponentsOutboundHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsOutboundHeaderProperty | undefined;
        set internalValue(value: ForwardPathComponentsOutboundHeaderProperty | undefined);
        get destinationAddresses(): string[];
        private _destinationPortRanges;
        get destinationPortRanges(): ForwardPathComponentsOutboundHeaderDestinationPortRangesPropertyList;
        get protocol(): string;
        get sourceAddresses(): string[];
        private _sourcePortRanges;
        get sourcePortRanges(): ForwardPathComponentsOutboundHeaderSourcePortRangesPropertyList;
    }
    class ForwardPathComponentsOutboundHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsOutboundHeaderPropertyOutputReference;
    }
    interface ForwardPathComponentsRouteTableRouteProperty {
    }
    class ForwardPathComponentsRouteTableRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsRouteTableRouteProperty | undefined;
        set internalValue(value: ForwardPathComponentsRouteTableRouteProperty | undefined);
        get destinationCidr(): string;
        get destinationPrefixListId(): string;
        get egressOnlyInternetGatewayId(): string;
        get gatewayId(): string;
        get instanceId(): string;
        get natGatewayId(): string;
        get networkInterfaceId(): string;
        get origin(): string;
        get transitGatewayId(): string;
        get vpcPeeringConnectionId(): string;
    }
    class ForwardPathComponentsRouteTableRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsRouteTableRoutePropertyOutputReference;
    }
    interface ForwardPathComponentsSecurityGroupRulePortRangeProperty {
    }
    class ForwardPathComponentsSecurityGroupRulePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsSecurityGroupRulePortRangeProperty | undefined;
        set internalValue(value: ForwardPathComponentsSecurityGroupRulePortRangeProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ForwardPathComponentsSecurityGroupRulePortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsSecurityGroupRulePortRangePropertyOutputReference;
    }
    interface ForwardPathComponentsSecurityGroupRuleProperty {
    }
    class ForwardPathComponentsSecurityGroupRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsSecurityGroupRuleProperty | undefined;
        set internalValue(value: ForwardPathComponentsSecurityGroupRuleProperty | undefined);
        get cidr(): string;
        get direction(): string;
        private _portRange;
        get portRange(): ForwardPathComponentsSecurityGroupRulePortRangePropertyList;
        get prefixListId(): string;
        get protocol(): string;
        get securityGroupId(): string;
    }
    class ForwardPathComponentsSecurityGroupRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsSecurityGroupRulePropertyOutputReference;
    }
    interface ForwardPathComponentsSourceVpcProperty {
    }
    class ForwardPathComponentsSourceVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsSourceVpcProperty | undefined;
        set internalValue(value: ForwardPathComponentsSourceVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ForwardPathComponentsSourceVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsSourceVpcPropertyOutputReference;
    }
    interface ForwardPathComponentsSubnetProperty {
    }
    class ForwardPathComponentsSubnetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsSubnetProperty | undefined;
        set internalValue(value: ForwardPathComponentsSubnetProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ForwardPathComponentsSubnetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsSubnetPropertyOutputReference;
    }
    interface ForwardPathComponentsTransitGatewayProperty {
    }
    class ForwardPathComponentsTransitGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsTransitGatewayProperty | undefined;
        set internalValue(value: ForwardPathComponentsTransitGatewayProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ForwardPathComponentsTransitGatewayPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsTransitGatewayPropertyOutputReference;
    }
    interface ForwardPathComponentsTransitGatewayRouteTableRouteProperty {
    }
    class ForwardPathComponentsTransitGatewayRouteTableRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsTransitGatewayRouteTableRouteProperty | undefined;
        set internalValue(value: ForwardPathComponentsTransitGatewayRouteTableRouteProperty | undefined);
        get attachmentId(): string;
        get destinationCidr(): string;
        get prefixListId(): string;
        get resourceId(): string;
        get resourceType(): string;
        get routeOrigin(): string;
        get state(): string;
    }
    class ForwardPathComponentsTransitGatewayRouteTableRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsTransitGatewayRouteTableRoutePropertyOutputReference;
    }
    interface ForwardPathComponentsVpcProperty {
    }
    class ForwardPathComponentsVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsVpcProperty | undefined;
        set internalValue(value: ForwardPathComponentsVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ForwardPathComponentsVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsVpcPropertyOutputReference;
    }
    interface ForwardPathComponentsProperty {
    }
    class ForwardPathComponentsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsProperty | undefined;
        set internalValue(value: ForwardPathComponentsProperty | undefined);
        private _aclRule;
        get aclRule(): ForwardPathComponentsAclRulePropertyList;
        private _additionalDetails;
        get additionalDetails(): ForwardPathComponentsAdditionalDetailsPropertyList;
        private _attachedTo;
        get attachedTo(): ForwardPathComponentsAttachedToPropertyList;
        private _component;
        get component(): ForwardPathComponentsComponentPropertyList;
        private _destinationVpc;
        get destinationVpc(): ForwardPathComponentsDestinationVpcPropertyList;
        private _inboundHeader;
        get inboundHeader(): ForwardPathComponentsInboundHeaderPropertyList;
        private _outboundHeader;
        get outboundHeader(): ForwardPathComponentsOutboundHeaderPropertyList;
        private _routeTableRoute;
        get routeTableRoute(): ForwardPathComponentsRouteTableRoutePropertyList;
        private _securityGroupRule;
        get securityGroupRule(): ForwardPathComponentsSecurityGroupRulePropertyList;
        get sequenceNumber(): number;
        private _sourceVpc;
        get sourceVpc(): ForwardPathComponentsSourceVpcPropertyList;
        private _subnet;
        get subnet(): ForwardPathComponentsSubnetPropertyList;
        private _transitGateway;
        get transitGateway(): ForwardPathComponentsTransitGatewayPropertyList;
        private _transitGatewayRouteTableRoute;
        get transitGatewayRouteTableRoute(): ForwardPathComponentsTransitGatewayRouteTableRoutePropertyList;
        private _vpc;
        get vpc(): ForwardPathComponentsVpcPropertyList;
    }
    class ForwardPathComponentsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsPropertyOutputReference;
    }
    interface ReturnPathComponentsAclRulePortRangeProperty {
    }
    class ReturnPathComponentsAclRulePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsAclRulePortRangeProperty | undefined;
        set internalValue(value: ReturnPathComponentsAclRulePortRangeProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ReturnPathComponentsAclRulePortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsAclRulePortRangePropertyOutputReference;
    }
    interface ReturnPathComponentsAclRuleProperty {
    }
    class ReturnPathComponentsAclRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsAclRuleProperty | undefined;
        set internalValue(value: ReturnPathComponentsAclRuleProperty | undefined);
        get cidr(): string;
        get egress(): cdktn.IResolvable;
        private _portRange;
        get portRange(): ReturnPathComponentsAclRulePortRangePropertyList;
        get protocol(): string;
        get ruleAction(): string;
        get ruleNumber(): number;
    }
    class ReturnPathComponentsAclRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsAclRulePropertyOutputReference;
    }
    interface ReturnPathComponentsAdditionalDetailsComponentProperty {
    }
    class ReturnPathComponentsAdditionalDetailsComponentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsAdditionalDetailsComponentProperty | undefined;
        set internalValue(value: ReturnPathComponentsAdditionalDetailsComponentProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ReturnPathComponentsAdditionalDetailsComponentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsAdditionalDetailsComponentPropertyOutputReference;
    }
    interface ReturnPathComponentsAdditionalDetailsProperty {
    }
    class ReturnPathComponentsAdditionalDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsAdditionalDetailsProperty | undefined;
        set internalValue(value: ReturnPathComponentsAdditionalDetailsProperty | undefined);
        get additionalDetailType(): string;
        private _component;
        get component(): ReturnPathComponentsAdditionalDetailsComponentPropertyList;
    }
    class ReturnPathComponentsAdditionalDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsAdditionalDetailsPropertyOutputReference;
    }
    interface ReturnPathComponentsAttachedToProperty {
    }
    class ReturnPathComponentsAttachedToPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsAttachedToProperty | undefined;
        set internalValue(value: ReturnPathComponentsAttachedToProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ReturnPathComponentsAttachedToPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsAttachedToPropertyOutputReference;
    }
    interface ReturnPathComponentsComponentProperty {
    }
    class ReturnPathComponentsComponentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsComponentProperty | undefined;
        set internalValue(value: ReturnPathComponentsComponentProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ReturnPathComponentsComponentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsComponentPropertyOutputReference;
    }
    interface ReturnPathComponentsDestinationVpcProperty {
    }
    class ReturnPathComponentsDestinationVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsDestinationVpcProperty | undefined;
        set internalValue(value: ReturnPathComponentsDestinationVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ReturnPathComponentsDestinationVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsDestinationVpcPropertyOutputReference;
    }
    interface ReturnPathComponentsInboundHeaderDestinationPortRangesProperty {
    }
    class ReturnPathComponentsInboundHeaderDestinationPortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsInboundHeaderDestinationPortRangesProperty | undefined;
        set internalValue(value: ReturnPathComponentsInboundHeaderDestinationPortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ReturnPathComponentsInboundHeaderDestinationPortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsInboundHeaderDestinationPortRangesPropertyOutputReference;
    }
    interface ReturnPathComponentsInboundHeaderSourcePortRangesProperty {
    }
    class ReturnPathComponentsInboundHeaderSourcePortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsInboundHeaderSourcePortRangesProperty | undefined;
        set internalValue(value: ReturnPathComponentsInboundHeaderSourcePortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ReturnPathComponentsInboundHeaderSourcePortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsInboundHeaderSourcePortRangesPropertyOutputReference;
    }
    interface ReturnPathComponentsInboundHeaderProperty {
    }
    class ReturnPathComponentsInboundHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsInboundHeaderProperty | undefined;
        set internalValue(value: ReturnPathComponentsInboundHeaderProperty | undefined);
        get destinationAddresses(): string[];
        private _destinationPortRanges;
        get destinationPortRanges(): ReturnPathComponentsInboundHeaderDestinationPortRangesPropertyList;
        get protocol(): string;
        get sourceAddresses(): string[];
        private _sourcePortRanges;
        get sourcePortRanges(): ReturnPathComponentsInboundHeaderSourcePortRangesPropertyList;
    }
    class ReturnPathComponentsInboundHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsInboundHeaderPropertyOutputReference;
    }
    interface ReturnPathComponentsOutboundHeaderDestinationPortRangesProperty {
    }
    class ReturnPathComponentsOutboundHeaderDestinationPortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsOutboundHeaderDestinationPortRangesProperty | undefined;
        set internalValue(value: ReturnPathComponentsOutboundHeaderDestinationPortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ReturnPathComponentsOutboundHeaderDestinationPortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsOutboundHeaderDestinationPortRangesPropertyOutputReference;
    }
    interface ReturnPathComponentsOutboundHeaderSourcePortRangesProperty {
    }
    class ReturnPathComponentsOutboundHeaderSourcePortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsOutboundHeaderSourcePortRangesProperty | undefined;
        set internalValue(value: ReturnPathComponentsOutboundHeaderSourcePortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ReturnPathComponentsOutboundHeaderSourcePortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsOutboundHeaderSourcePortRangesPropertyOutputReference;
    }
    interface ReturnPathComponentsOutboundHeaderProperty {
    }
    class ReturnPathComponentsOutboundHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsOutboundHeaderProperty | undefined;
        set internalValue(value: ReturnPathComponentsOutboundHeaderProperty | undefined);
        get destinationAddresses(): string[];
        private _destinationPortRanges;
        get destinationPortRanges(): ReturnPathComponentsOutboundHeaderDestinationPortRangesPropertyList;
        get protocol(): string;
        get sourceAddresses(): string[];
        private _sourcePortRanges;
        get sourcePortRanges(): ReturnPathComponentsOutboundHeaderSourcePortRangesPropertyList;
    }
    class ReturnPathComponentsOutboundHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsOutboundHeaderPropertyOutputReference;
    }
    interface ReturnPathComponentsRouteTableRouteProperty {
    }
    class ReturnPathComponentsRouteTableRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsRouteTableRouteProperty | undefined;
        set internalValue(value: ReturnPathComponentsRouteTableRouteProperty | undefined);
        get destinationCidr(): string;
        get destinationPrefixListId(): string;
        get egressOnlyInternetGatewayId(): string;
        get gatewayId(): string;
        get instanceId(): string;
        get natGatewayId(): string;
        get networkInterfaceId(): string;
        get origin(): string;
        get transitGatewayId(): string;
        get vpcPeeringConnectionId(): string;
    }
    class ReturnPathComponentsRouteTableRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsRouteTableRoutePropertyOutputReference;
    }
    interface ReturnPathComponentsSecurityGroupRulePortRangeProperty {
    }
    class ReturnPathComponentsSecurityGroupRulePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsSecurityGroupRulePortRangeProperty | undefined;
        set internalValue(value: ReturnPathComponentsSecurityGroupRulePortRangeProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ReturnPathComponentsSecurityGroupRulePortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsSecurityGroupRulePortRangePropertyOutputReference;
    }
    interface ReturnPathComponentsSecurityGroupRuleProperty {
    }
    class ReturnPathComponentsSecurityGroupRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsSecurityGroupRuleProperty | undefined;
        set internalValue(value: ReturnPathComponentsSecurityGroupRuleProperty | undefined);
        get cidr(): string;
        get direction(): string;
        private _portRange;
        get portRange(): ReturnPathComponentsSecurityGroupRulePortRangePropertyList;
        get prefixListId(): string;
        get protocol(): string;
        get securityGroupId(): string;
    }
    class ReturnPathComponentsSecurityGroupRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsSecurityGroupRulePropertyOutputReference;
    }
    interface ReturnPathComponentsSourceVpcProperty {
    }
    class ReturnPathComponentsSourceVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsSourceVpcProperty | undefined;
        set internalValue(value: ReturnPathComponentsSourceVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ReturnPathComponentsSourceVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsSourceVpcPropertyOutputReference;
    }
    interface ReturnPathComponentsSubnetProperty {
    }
    class ReturnPathComponentsSubnetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsSubnetProperty | undefined;
        set internalValue(value: ReturnPathComponentsSubnetProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ReturnPathComponentsSubnetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsSubnetPropertyOutputReference;
    }
    interface ReturnPathComponentsTransitGatewayProperty {
    }
    class ReturnPathComponentsTransitGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsTransitGatewayProperty | undefined;
        set internalValue(value: ReturnPathComponentsTransitGatewayProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ReturnPathComponentsTransitGatewayPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsTransitGatewayPropertyOutputReference;
    }
    interface ReturnPathComponentsTransitGatewayRouteTableRouteProperty {
    }
    class ReturnPathComponentsTransitGatewayRouteTableRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsTransitGatewayRouteTableRouteProperty | undefined;
        set internalValue(value: ReturnPathComponentsTransitGatewayRouteTableRouteProperty | undefined);
        get attachmentId(): string;
        get destinationCidr(): string;
        get prefixListId(): string;
        get resourceId(): string;
        get resourceType(): string;
        get routeOrigin(): string;
        get state(): string;
    }
    class ReturnPathComponentsTransitGatewayRouteTableRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsTransitGatewayRouteTableRoutePropertyOutputReference;
    }
    interface ReturnPathComponentsVpcProperty {
    }
    class ReturnPathComponentsVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsVpcProperty | undefined;
        set internalValue(value: ReturnPathComponentsVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ReturnPathComponentsVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsVpcPropertyOutputReference;
    }
    interface ReturnPathComponentsProperty {
    }
    class ReturnPathComponentsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsProperty | undefined;
        set internalValue(value: ReturnPathComponentsProperty | undefined);
        private _aclRule;
        get aclRule(): ReturnPathComponentsAclRulePropertyList;
        private _additionalDetails;
        get additionalDetails(): ReturnPathComponentsAdditionalDetailsPropertyList;
        private _attachedTo;
        get attachedTo(): ReturnPathComponentsAttachedToPropertyList;
        private _component;
        get component(): ReturnPathComponentsComponentPropertyList;
        private _destinationVpc;
        get destinationVpc(): ReturnPathComponentsDestinationVpcPropertyList;
        private _inboundHeader;
        get inboundHeader(): ReturnPathComponentsInboundHeaderPropertyList;
        private _outboundHeader;
        get outboundHeader(): ReturnPathComponentsOutboundHeaderPropertyList;
        private _routeTableRoute;
        get routeTableRoute(): ReturnPathComponentsRouteTableRoutePropertyList;
        private _securityGroupRule;
        get securityGroupRule(): ReturnPathComponentsSecurityGroupRulePropertyList;
        get sequenceNumber(): number;
        private _sourceVpc;
        get sourceVpc(): ReturnPathComponentsSourceVpcPropertyList;
        private _subnet;
        get subnet(): ReturnPathComponentsSubnetPropertyList;
        private _transitGateway;
        get transitGateway(): ReturnPathComponentsTransitGatewayPropertyList;
        private _transitGatewayRouteTableRoute;
        get transitGatewayRouteTableRoute(): ReturnPathComponentsTransitGatewayRouteTableRoutePropertyList;
        private _vpc;
        get vpc(): ReturnPathComponentsVpcPropertyList;
    }
    class ReturnPathComponentsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis#name DataAwsEc2NetworkInsightsAnalysis#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis#values DataAwsEc2NetworkInsightsAnalysis#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
}
