import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBlockPublicAccessOptionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options#internet_gateway_block_mode AwsBlockPublicAccessOptions#internet_gateway_block_mode}
    */
    readonly internetGatewayBlockMode: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options#region AwsBlockPublicAccessOptions#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options#timeouts AwsBlockPublicAccessOptions#timeouts}
    */
    readonly timeouts?: AwsBlockPublicAccessOptions.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options aws_vpc_block_public_access_options}
*/
export declare class AwsBlockPublicAccessOptions extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_block_public_access_options";
    /**
    * Generates CDKTN code for importing a AwsBlockPublicAccessOptions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBlockPublicAccessOptions to import
    * @param importFromId The id of the existing AwsBlockPublicAccessOptions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBlockPublicAccessOptions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options aws_vpc_block_public_access_options} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBlockPublicAccessOptionsConfig
    */
    constructor(scope: Construct, id: string, config: AwsBlockPublicAccessOptionsConfig);
    get awsAccountId(): string;
    get awsRegion(): string;
    get id(): string;
    private _internetGatewayBlockMode?;
    get internetGatewayBlockMode(): string;
    set internetGatewayBlockMode(value: string);
    get internetGatewayBlockModeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsBlockPublicAccessOptions.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBlockPublicAccessOptions.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBlockPublicAccessOptions.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBlockPublicAccessOptionsTimeoutsPropertyToTerraform(struct?: AwsBlockPublicAccessOptions.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBlockPublicAccessOptionsTimeoutsPropertyToHclTerraform(struct?: AwsBlockPublicAccessOptions.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBlockPublicAccessOptions {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options#create AwsBlockPublicAccessOptions#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options#delete AwsBlockPublicAccessOptions#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options#update AwsBlockPublicAccessOptions#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
