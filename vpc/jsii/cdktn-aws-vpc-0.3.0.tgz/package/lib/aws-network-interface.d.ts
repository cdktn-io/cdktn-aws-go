import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNetworkInterfaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#description AwsNetworkInterface#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#enable_primary_ipv6 AwsNetworkInterface#enable_primary_ipv6}
    */
    readonly enablePrimaryIpv6?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#id AwsNetworkInterface#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#interface_type AwsNetworkInterface#interface_type}
    */
    readonly interfaceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#ipv4_prefix_count AwsNetworkInterface#ipv4_prefix_count}
    */
    readonly ipv4PrefixCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#ipv4_prefixes AwsNetworkInterface#ipv4_prefixes}
    */
    readonly ipv4Prefixes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#ipv6_address_count AwsNetworkInterface#ipv6_address_count}
    */
    readonly ipv6AddressCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#ipv6_address_list AwsNetworkInterface#ipv6_address_list}
    */
    readonly ipv6AddressList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#ipv6_address_list_enabled AwsNetworkInterface#ipv6_address_list_enabled}
    */
    readonly ipv6AddressListEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#ipv6_addresses AwsNetworkInterface#ipv6_addresses}
    */
    readonly ipv6Addresses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#ipv6_prefix_count AwsNetworkInterface#ipv6_prefix_count}
    */
    readonly ipv6PrefixCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#ipv6_prefixes AwsNetworkInterface#ipv6_prefixes}
    */
    readonly ipv6Prefixes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#private_ip AwsNetworkInterface#private_ip}
    */
    readonly privateIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#private_ip_list AwsNetworkInterface#private_ip_list}
    */
    readonly privateIpList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#private_ip_list_enabled AwsNetworkInterface#private_ip_list_enabled}
    */
    readonly privateIpListEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#private_ips AwsNetworkInterface#private_ips}
    */
    readonly privateIps?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#private_ips_count AwsNetworkInterface#private_ips_count}
    */
    readonly privateIpsCount?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#region AwsNetworkInterface#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#security_groups AwsNetworkInterface#security_groups}
    */
    readonly securityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#source_dest_check AwsNetworkInterface#source_dest_check}
    */
    readonly sourceDestCheck?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#subnet_id AwsNetworkInterface#subnet_id}
    */
    readonly subnetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#tags AwsNetworkInterface#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#tags_all AwsNetworkInterface#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * attachment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#attachment AwsNetworkInterface#attachment}
    */
    readonly attachment?: AwsNetworkInterface.AttachmentProperty[] | cdktn.IResolvable;
    /**
    * ena_srd_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#ena_srd_specification AwsNetworkInterface#ena_srd_specification}
    */
    readonly enaSrdSpecification?: AwsNetworkInterface.EnaSrdSpecificationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface aws_network_interface}
*/
export declare class AwsNetworkInterface extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_network_interface";
    /**
    * Generates CDKTN code for importing a AwsNetworkInterface resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNetworkInterface to import
    * @param importFromId The id of the existing AwsNetworkInterface that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNetworkInterface to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface aws_network_interface} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNetworkInterfaceConfig
    */
    constructor(scope: Construct, id: string, config: AwsNetworkInterfaceConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enablePrimaryIpv6?;
    get enablePrimaryIpv6(): boolean | cdktn.IResolvable;
    set enablePrimaryIpv6(value: boolean | cdktn.IResolvable);
    resetEnablePrimaryIpv6(): void;
    get enablePrimaryIpv6Input(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _interfaceType?;
    get interfaceType(): string;
    set interfaceType(value: string);
    resetInterfaceType(): void;
    get interfaceTypeInput(): string | undefined;
    private _ipv4PrefixCount?;
    get ipv4PrefixCount(): number;
    set ipv4PrefixCount(value: number);
    resetIpv4PrefixCount(): void;
    get ipv4PrefixCountInput(): number | undefined;
    private _ipv4Prefixes?;
    get ipv4Prefixes(): string[];
    set ipv4Prefixes(value: string[]);
    resetIpv4Prefixes(): void;
    get ipv4PrefixesInput(): string[] | undefined;
    private _ipv6AddressCount?;
    get ipv6AddressCount(): number;
    set ipv6AddressCount(value: number);
    resetIpv6AddressCount(): void;
    get ipv6AddressCountInput(): number | undefined;
    private _ipv6AddressList?;
    get ipv6AddressList(): string[];
    set ipv6AddressList(value: string[]);
    resetIpv6AddressList(): void;
    get ipv6AddressListInput(): string[] | undefined;
    private _ipv6AddressListEnabled?;
    get ipv6AddressListEnabled(): boolean | cdktn.IResolvable;
    set ipv6AddressListEnabled(value: boolean | cdktn.IResolvable);
    resetIpv6AddressListEnabled(): void;
    get ipv6AddressListEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _ipv6Addresses?;
    get ipv6Addresses(): string[];
    set ipv6Addresses(value: string[]);
    resetIpv6Addresses(): void;
    get ipv6AddressesInput(): string[] | undefined;
    private _ipv6PrefixCount?;
    get ipv6PrefixCount(): number;
    set ipv6PrefixCount(value: number);
    resetIpv6PrefixCount(): void;
    get ipv6PrefixCountInput(): number | undefined;
    private _ipv6Prefixes?;
    get ipv6Prefixes(): string[];
    set ipv6Prefixes(value: string[]);
    resetIpv6Prefixes(): void;
    get ipv6PrefixesInput(): string[] | undefined;
    get macAddress(): string;
    get outpostArn(): string;
    get ownerId(): string;
    get privateDnsName(): string;
    private _privateIp?;
    get privateIp(): string;
    set privateIp(value: string);
    resetPrivateIp(): void;
    get privateIpInput(): string | undefined;
    private _privateIpList?;
    get privateIpList(): string[];
    set privateIpList(value: string[]);
    resetPrivateIpList(): void;
    get privateIpListInput(): string[] | undefined;
    private _privateIpListEnabled?;
    get privateIpListEnabled(): boolean | cdktn.IResolvable;
    set privateIpListEnabled(value: boolean | cdktn.IResolvable);
    resetPrivateIpListEnabled(): void;
    get privateIpListEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _privateIps?;
    get privateIps(): string[];
    set privateIps(value: string[]);
    resetPrivateIps(): void;
    get privateIpsInput(): string[] | undefined;
    private _privateIpsCount?;
    get privateIpsCount(): number;
    set privateIpsCount(value: number);
    resetPrivateIpsCount(): void;
    get privateIpsCountInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroups?;
    get securityGroups(): string[];
    set securityGroups(value: string[]);
    resetSecurityGroups(): void;
    get securityGroupsInput(): string[] | undefined;
    private _sourceDestCheck?;
    get sourceDestCheck(): boolean | cdktn.IResolvable;
    set sourceDestCheck(value: boolean | cdktn.IResolvable);
    resetSourceDestCheck(): void;
    get sourceDestCheckInput(): boolean | cdktn.IResolvable | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    get subnetIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _attachment;
    get attachment(): AwsNetworkInterface.AttachmentPropertyList;
    putAttachment(value: AwsNetworkInterface.AttachmentProperty[] | cdktn.IResolvable): void;
    resetAttachment(): void;
    get attachmentInput(): cdktn.IResolvable | AwsNetworkInterface.AttachmentProperty[] | undefined;
    private _enaSrdSpecification;
    get enaSrdSpecification(): AwsNetworkInterface.EnaSrdSpecificationPropertyOutputReference;
    putEnaSrdSpecification(value: AwsNetworkInterface.EnaSrdSpecificationProperty): void;
    resetEnaSrdSpecification(): void;
    get enaSrdSpecificationInput(): AwsNetworkInterface.EnaSrdSpecificationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsNetworkInterfaceAttachmentPropertyToTerraform(struct?: AwsNetworkInterface.AttachmentProperty | cdktn.IResolvable): any;
export declare function awsNetworkInterfaceAttachmentPropertyToHclTerraform(struct?: AwsNetworkInterface.AttachmentProperty | cdktn.IResolvable): any;
export declare function awsNetworkInterfaceEnaSrdUdpSpecificationPropertyToTerraform(struct?: AwsNetworkInterface.EnaSrdUdpSpecificationPropertyOutputReference | AwsNetworkInterface.EnaSrdUdpSpecificationProperty): any;
export declare function awsNetworkInterfaceEnaSrdUdpSpecificationPropertyToHclTerraform(struct?: AwsNetworkInterface.EnaSrdUdpSpecificationPropertyOutputReference | AwsNetworkInterface.EnaSrdUdpSpecificationProperty): any;
export declare function awsNetworkInterfaceEnaSrdSpecificationPropertyToTerraform(struct?: AwsNetworkInterface.EnaSrdSpecificationPropertyOutputReference | AwsNetworkInterface.EnaSrdSpecificationProperty): any;
export declare function awsNetworkInterfaceEnaSrdSpecificationPropertyToHclTerraform(struct?: AwsNetworkInterface.EnaSrdSpecificationPropertyOutputReference | AwsNetworkInterface.EnaSrdSpecificationProperty): any;
export declare namespace AwsNetworkInterface {
    interface AttachmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#device_index AwsNetworkInterface#device_index}
        */
        readonly deviceIndex: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#instance AwsNetworkInterface#instance}
        */
        readonly instance: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#network_card_index AwsNetworkInterface#network_card_index}
        */
        readonly networkCardIndex?: number;
    }
    class AttachmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttachmentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AttachmentProperty | cdktn.IResolvable | undefined);
        get attachmentId(): string;
        private _deviceIndex?;
        get deviceIndex(): number;
        set deviceIndex(value: number);
        get deviceIndexInput(): number | undefined;
        private _instance?;
        get instance(): string;
        set instance(value: string);
        get instanceInput(): string | undefined;
        private _networkCardIndex?;
        get networkCardIndex(): number;
        set networkCardIndex(value: number);
        resetNetworkCardIndex(): void;
        get networkCardIndexInput(): number | undefined;
    }
    class AttachmentPropertyList extends cdktn.ComplexList {
        internalValue?: AttachmentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttachmentPropertyOutputReference;
    }
    interface EnaSrdUdpSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#ena_srd_udp_enabled AwsNetworkInterface#ena_srd_udp_enabled}
        */
        readonly enaSrdUdpEnabled?: boolean | cdktn.IResolvable;
    }
    class EnaSrdUdpSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnaSrdUdpSpecificationProperty | undefined;
        set internalValue(value: EnaSrdUdpSpecificationProperty | undefined);
        private _enaSrdUdpEnabled?;
        get enaSrdUdpEnabled(): boolean | cdktn.IResolvable;
        set enaSrdUdpEnabled(value: boolean | cdktn.IResolvable);
        resetEnaSrdUdpEnabled(): void;
        get enaSrdUdpEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface EnaSrdSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#ena_srd_enabled AwsNetworkInterface#ena_srd_enabled}
        */
        readonly enaSrdEnabled?: boolean | cdktn.IResolvable;
        /**
        * ena_srd_udp_specification block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/network_interface#ena_srd_udp_specification AwsNetworkInterface#ena_srd_udp_specification}
        */
        readonly enaSrdUdpSpecification?: EnaSrdUdpSpecificationProperty;
    }
    class EnaSrdSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnaSrdSpecificationProperty | undefined;
        set internalValue(value: EnaSrdSpecificationProperty | undefined);
        private _enaSrdEnabled?;
        get enaSrdEnabled(): boolean | cdktn.IResolvable;
        set enaSrdEnabled(value: boolean | cdktn.IResolvable);
        resetEnaSrdEnabled(): void;
        get enaSrdEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _enaSrdUdpSpecification;
        get enaSrdUdpSpecification(): EnaSrdUdpSpecificationPropertyOutputReference;
        putEnaSrdUdpSpecification(value: EnaSrdUdpSpecificationProperty): void;
        resetEnaSrdUdpSpecification(): void;
        get enaSrdUdpSpecificationInput(): EnaSrdUdpSpecificationProperty | undefined;
    }
}
