import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEc2TrafficMirrorFilterRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#description AwsEc2TrafficMirrorFilterRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#destination_cidr_block AwsEc2TrafficMirrorFilterRule#destination_cidr_block}
    */
    readonly destinationCidrBlock: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#id AwsEc2TrafficMirrorFilterRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#protocol AwsEc2TrafficMirrorFilterRule#protocol}
    */
    readonly protocol?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#region AwsEc2TrafficMirrorFilterRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#rule_action AwsEc2TrafficMirrorFilterRule#rule_action}
    */
    readonly ruleAction: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#rule_number AwsEc2TrafficMirrorFilterRule#rule_number}
    */
    readonly ruleNumber: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#source_cidr_block AwsEc2TrafficMirrorFilterRule#source_cidr_block}
    */
    readonly sourceCidrBlock: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#traffic_direction AwsEc2TrafficMirrorFilterRule#traffic_direction}
    */
    readonly trafficDirection: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#traffic_mirror_filter_id AwsEc2TrafficMirrorFilterRule#traffic_mirror_filter_id}
    */
    readonly trafficMirrorFilterId: string;
    /**
    * destination_port_range block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#destination_port_range AwsEc2TrafficMirrorFilterRule#destination_port_range}
    */
    readonly destinationPortRange?: AwsEc2TrafficMirrorFilterRule.DestinationPortRangeProperty;
    /**
    * source_port_range block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#source_port_range AwsEc2TrafficMirrorFilterRule#source_port_range}
    */
    readonly sourcePortRange?: AwsEc2TrafficMirrorFilterRule.SourcePortRangeProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule aws_ec2_traffic_mirror_filter_rule}
*/
export declare class AwsEc2TrafficMirrorFilterRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ec2_traffic_mirror_filter_rule";
    /**
    * Generates CDKTN code for importing a AwsEc2TrafficMirrorFilterRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEc2TrafficMirrorFilterRule to import
    * @param importFromId The id of the existing AwsEc2TrafficMirrorFilterRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEc2TrafficMirrorFilterRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule aws_ec2_traffic_mirror_filter_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEc2TrafficMirrorFilterRuleConfig
    */
    constructor(scope: Construct, id: string, config: AwsEc2TrafficMirrorFilterRuleConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _destinationCidrBlock?;
    get destinationCidrBlock(): string;
    set destinationCidrBlock(value: string);
    get destinationCidrBlockInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _protocol?;
    get protocol(): number;
    set protocol(value: number);
    resetProtocol(): void;
    get protocolInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _ruleAction?;
    get ruleAction(): string;
    set ruleAction(value: string);
    get ruleActionInput(): string | undefined;
    private _ruleNumber?;
    get ruleNumber(): number;
    set ruleNumber(value: number);
    get ruleNumberInput(): number | undefined;
    private _sourceCidrBlock?;
    get sourceCidrBlock(): string;
    set sourceCidrBlock(value: string);
    get sourceCidrBlockInput(): string | undefined;
    private _trafficDirection?;
    get trafficDirection(): string;
    set trafficDirection(value: string);
    get trafficDirectionInput(): string | undefined;
    private _trafficMirrorFilterId?;
    get trafficMirrorFilterId(): string;
    set trafficMirrorFilterId(value: string);
    get trafficMirrorFilterIdInput(): string | undefined;
    private _destinationPortRange;
    get destinationPortRange(): AwsEc2TrafficMirrorFilterRule.DestinationPortRangePropertyOutputReference;
    putDestinationPortRange(value: AwsEc2TrafficMirrorFilterRule.DestinationPortRangeProperty): void;
    resetDestinationPortRange(): void;
    get destinationPortRangeInput(): AwsEc2TrafficMirrorFilterRule.DestinationPortRangeProperty | undefined;
    private _sourcePortRange;
    get sourcePortRange(): AwsEc2TrafficMirrorFilterRule.SourcePortRangePropertyOutputReference;
    putSourcePortRange(value: AwsEc2TrafficMirrorFilterRule.SourcePortRangeProperty): void;
    resetSourcePortRange(): void;
    get sourcePortRangeInput(): AwsEc2TrafficMirrorFilterRule.SourcePortRangeProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEc2TrafficMirrorFilterRuleDestinationPortRangePropertyToTerraform(struct?: AwsEc2TrafficMirrorFilterRule.DestinationPortRangePropertyOutputReference | AwsEc2TrafficMirrorFilterRule.DestinationPortRangeProperty): any;
export declare function awsEc2TrafficMirrorFilterRuleDestinationPortRangePropertyToHclTerraform(struct?: AwsEc2TrafficMirrorFilterRule.DestinationPortRangePropertyOutputReference | AwsEc2TrafficMirrorFilterRule.DestinationPortRangeProperty): any;
export declare function awsEc2TrafficMirrorFilterRuleSourcePortRangePropertyToTerraform(struct?: AwsEc2TrafficMirrorFilterRule.SourcePortRangePropertyOutputReference | AwsEc2TrafficMirrorFilterRule.SourcePortRangeProperty): any;
export declare function awsEc2TrafficMirrorFilterRuleSourcePortRangePropertyToHclTerraform(struct?: AwsEc2TrafficMirrorFilterRule.SourcePortRangePropertyOutputReference | AwsEc2TrafficMirrorFilterRule.SourcePortRangeProperty): any;
export declare namespace AwsEc2TrafficMirrorFilterRule {
    interface DestinationPortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#from_port AwsEc2TrafficMirrorFilterRule#from_port}
        */
        readonly fromPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#to_port AwsEc2TrafficMirrorFilterRule#to_port}
        */
        readonly toPort?: number;
    }
    class DestinationPortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationPortRangeProperty | undefined;
        set internalValue(value: DestinationPortRangeProperty | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        resetFromPort(): void;
        get fromPortInput(): number | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        resetToPort(): void;
        get toPortInput(): number | undefined;
    }
    interface SourcePortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#from_port AwsEc2TrafficMirrorFilterRule#from_port}
        */
        readonly fromPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_traffic_mirror_filter_rule#to_port AwsEc2TrafficMirrorFilterRule#to_port}
        */
        readonly toPort?: number;
    }
    class SourcePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourcePortRangeProperty | undefined;
        set internalValue(value: SourcePortRangeProperty | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        resetFromPort(): void;
        get fromPortInput(): number | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        resetToPort(): void;
        get toPortInput(): number | undefined;
    }
}
