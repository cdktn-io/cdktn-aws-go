import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfFleetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codebuild_fleet#name DataTfFleet#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codebuild_fleet#region DataTfFleet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codebuild_fleet#tags DataTfFleet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codebuild_fleet aws_codebuild_fleet}
*/
export declare class DataTfFleet extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_codebuild_fleet";
    /**
    * Generates CDKTN code for importing a DataTfFleet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfFleet to import
    * @param importFromId The id of the existing DataTfFleet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codebuild_fleet#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfFleet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codebuild_fleet aws_codebuild_fleet} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfFleetConfig
    */
    constructor(scope: Construct, id: string, config: DataTfFleetConfig);
    get arn(): string;
    get baseCapacity(): number;
    private _computeConfiguration;
    get computeConfiguration(): DataTfFleet.ComputeConfigurationPropertyList;
    get computeType(): string;
    get created(): string;
    get environmentType(): string;
    get fleetServiceRole(): string;
    get id(): string;
    get imageId(): string;
    get lastModified(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get overflowBehavior(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scalingConfiguration;
    get scalingConfiguration(): DataTfFleet.ScalingConfigurationPropertyList;
    private _status;
    get status(): DataTfFleet.StatusPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcConfig;
    get vpcConfig(): DataTfFleet.VpcConfigPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfFleetComputeConfigurationPropertyToTerraform(struct?: DataTfFleet.ComputeConfigurationProperty): any;
export declare function dataTfFleetComputeConfigurationPropertyToHclTerraform(struct?: DataTfFleet.ComputeConfigurationProperty): any;
export declare function dataTfFleetTargetTrackingScalingConfigsPropertyToTerraform(struct?: DataTfFleet.TargetTrackingScalingConfigsProperty): any;
export declare function dataTfFleetTargetTrackingScalingConfigsPropertyToHclTerraform(struct?: DataTfFleet.TargetTrackingScalingConfigsProperty): any;
export declare function dataTfFleetScalingConfigurationPropertyToTerraform(struct?: DataTfFleet.ScalingConfigurationProperty): any;
export declare function dataTfFleetScalingConfigurationPropertyToHclTerraform(struct?: DataTfFleet.ScalingConfigurationProperty): any;
export declare function dataTfFleetStatusPropertyToTerraform(struct?: DataTfFleet.StatusProperty): any;
export declare function dataTfFleetStatusPropertyToHclTerraform(struct?: DataTfFleet.StatusProperty): any;
export declare function dataTfFleetVpcConfigPropertyToTerraform(struct?: DataTfFleet.VpcConfigProperty): any;
export declare function dataTfFleetVpcConfigPropertyToHclTerraform(struct?: DataTfFleet.VpcConfigProperty): any;
export declare namespace DataTfFleet {
    interface ComputeConfigurationProperty {
    }
    class ComputeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComputeConfigurationProperty | undefined;
        set internalValue(value: ComputeConfigurationProperty | undefined);
        get disk(): number;
        get instanceType(): string;
        get machineType(): string;
        get memory(): number;
        get vcpu(): number;
    }
    class ComputeConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComputeConfigurationPropertyOutputReference;
    }
    interface TargetTrackingScalingConfigsProperty {
    }
    class TargetTrackingScalingConfigsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetTrackingScalingConfigsProperty | undefined;
        set internalValue(value: TargetTrackingScalingConfigsProperty | undefined);
        get metricType(): string;
        get targetValue(): number;
    }
    class TargetTrackingScalingConfigsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetTrackingScalingConfigsPropertyOutputReference;
    }
    interface ScalingConfigurationProperty {
    }
    class ScalingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScalingConfigurationProperty | undefined;
        set internalValue(value: ScalingConfigurationProperty | undefined);
        get desiredCapacity(): number;
        get maxCapacity(): number;
        get scalingType(): string;
        private _targetTrackingScalingConfigs;
        get targetTrackingScalingConfigs(): TargetTrackingScalingConfigsPropertyList;
    }
    class ScalingConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScalingConfigurationPropertyOutputReference;
    }
    interface StatusProperty {
    }
    class StatusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatusProperty | undefined;
        set internalValue(value: StatusProperty | undefined);
        get context(): string;
        get message(): string;
        get statusCode(): string;
    }
    class StatusPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatusPropertyOutputReference;
    }
    interface VpcConfigProperty {
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        get securityGroupIds(): string[];
        get subnets(): string[];
        get vpcId(): string;
    }
    class VpcConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigPropertyOutputReference;
    }
}
