import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfReportGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#delete_reports TfReportGroup#delete_reports}
    */
    readonly deleteReports?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#id TfReportGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#name TfReportGroup#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#region TfReportGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#tags TfReportGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#tags_all TfReportGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#type TfReportGroup#type}
    */
    readonly type: string;
    /**
    * export_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#export_config TfReportGroup#export_config}
    */
    readonly exportConfig: TfReportGroup.ExportConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group aws_codebuild_report_group}
*/
export declare class TfReportGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codebuild_report_group";
    /**
    * Generates CDKTN code for importing a TfReportGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfReportGroup to import
    * @param importFromId The id of the existing TfReportGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfReportGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group aws_codebuild_report_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfReportGroupConfig
    */
    constructor(scope: Construct, id: string, config: TfReportGroupConfig);
    get arn(): string;
    get created(): string;
    private _deleteReports?;
    get deleteReports(): boolean | cdktn.IResolvable;
    set deleteReports(value: boolean | cdktn.IResolvable);
    resetDeleteReports(): void;
    get deleteReportsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _exportConfig;
    get exportConfig(): TfReportGroup.ExportConfigPropertyOutputReference;
    putExportConfig(value: TfReportGroup.ExportConfigProperty): void;
    get exportConfigInput(): TfReportGroup.ExportConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfReportGroupS3DestinationPropertyToTerraform(struct?: TfReportGroup.S3DestinationPropertyOutputReference | TfReportGroup.S3DestinationProperty): any;
export declare function tfReportGroupS3DestinationPropertyToHclTerraform(struct?: TfReportGroup.S3DestinationPropertyOutputReference | TfReportGroup.S3DestinationProperty): any;
export declare function tfReportGroupExportConfigPropertyToTerraform(struct?: TfReportGroup.ExportConfigPropertyOutputReference | TfReportGroup.ExportConfigProperty): any;
export declare function tfReportGroupExportConfigPropertyToHclTerraform(struct?: TfReportGroup.ExportConfigPropertyOutputReference | TfReportGroup.ExportConfigProperty): any;
export declare namespace TfReportGroup {
    interface S3DestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#bucket TfReportGroup#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#encryption_disabled TfReportGroup#encryption_disabled}
        */
        readonly encryptionDisabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#encryption_key TfReportGroup#encryption_key}
        */
        readonly encryptionKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#packaging TfReportGroup#packaging}
        */
        readonly packaging?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#path TfReportGroup#path}
        */
        readonly path?: string;
    }
    class S3DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3DestinationProperty | undefined;
        set internalValue(value: S3DestinationProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _encryptionDisabled?;
        get encryptionDisabled(): boolean | cdktn.IResolvable;
        set encryptionDisabled(value: boolean | cdktn.IResolvable);
        resetEncryptionDisabled(): void;
        get encryptionDisabledInput(): boolean | cdktn.IResolvable | undefined;
        private _encryptionKey?;
        get encryptionKey(): string;
        set encryptionKey(value: string);
        get encryptionKeyInput(): string | undefined;
        private _packaging?;
        get packaging(): string;
        set packaging(value: string);
        resetPackaging(): void;
        get packagingInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
    }
    interface ExportConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#type TfReportGroup#type}
        */
        readonly type: string;
        /**
        * s3_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#s3_destination TfReportGroup#s3_destination}
        */
        readonly s3Destination?: S3DestinationProperty;
    }
    class ExportConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExportConfigProperty | undefined;
        set internalValue(value: ExportConfigProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _s3Destination;
        get s3Destination(): S3DestinationPropertyOutputReference;
        putS3Destination(value: S3DestinationProperty): void;
        resetS3Destination(): void;
        get s3DestinationInput(): S3DestinationProperty | undefined;
    }
}
