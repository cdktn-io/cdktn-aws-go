import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCodebuildReportGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#delete_reports AwsCodebuildReportGroup#delete_reports}
    */
    readonly deleteReports?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#id AwsCodebuildReportGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#name AwsCodebuildReportGroup#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#region AwsCodebuildReportGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#tags AwsCodebuildReportGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#tags_all AwsCodebuildReportGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#type AwsCodebuildReportGroup#type}
    */
    readonly type: string;
    /**
    * export_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#export_config AwsCodebuildReportGroup#export_config}
    */
    readonly exportConfig: AwsCodebuildReportGroup.ExportConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group aws_codebuild_report_group}
*/
export declare class AwsCodebuildReportGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codebuild_report_group";
    /**
    * Generates CDKTN code for importing a AwsCodebuildReportGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCodebuildReportGroup to import
    * @param importFromId The id of the existing AwsCodebuildReportGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCodebuildReportGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group aws_codebuild_report_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCodebuildReportGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsCodebuildReportGroupConfig);
    get arn(): string;
    get created(): string;
    private _deleteReports?;
    get deleteReports(): boolean | cdktn.IResolvable;
    set deleteReports(value: boolean | cdktn.IResolvable);
    resetDeleteReports(): void;
    get deleteReportsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _exportConfig;
    get exportConfig(): AwsCodebuildReportGroup.ExportConfigPropertyOutputReference;
    putExportConfig(value: AwsCodebuildReportGroup.ExportConfigProperty): void;
    get exportConfigInput(): AwsCodebuildReportGroup.ExportConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCodebuildReportGroupS3DestinationPropertyToTerraform(struct?: AwsCodebuildReportGroup.S3DestinationPropertyOutputReference | AwsCodebuildReportGroup.S3DestinationProperty): any;
export declare function awsCodebuildReportGroupS3DestinationPropertyToHclTerraform(struct?: AwsCodebuildReportGroup.S3DestinationPropertyOutputReference | AwsCodebuildReportGroup.S3DestinationProperty): any;
export declare function awsCodebuildReportGroupExportConfigPropertyToTerraform(struct?: AwsCodebuildReportGroup.ExportConfigPropertyOutputReference | AwsCodebuildReportGroup.ExportConfigProperty): any;
export declare function awsCodebuildReportGroupExportConfigPropertyToHclTerraform(struct?: AwsCodebuildReportGroup.ExportConfigPropertyOutputReference | AwsCodebuildReportGroup.ExportConfigProperty): any;
export declare namespace AwsCodebuildReportGroup {
    interface S3DestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#bucket AwsCodebuildReportGroup#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#encryption_disabled AwsCodebuildReportGroup#encryption_disabled}
        */
        readonly encryptionDisabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#encryption_key AwsCodebuildReportGroup#encryption_key}
        */
        readonly encryptionKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#packaging AwsCodebuildReportGroup#packaging}
        */
        readonly packaging?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#path AwsCodebuildReportGroup#path}
        */
        readonly path?: string;
    }
    class S3DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3DestinationProperty | undefined;
        set internalValue(value: S3DestinationProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _encryptionDisabled?;
        get encryptionDisabled(): boolean | cdktn.IResolvable;
        set encryptionDisabled(value: boolean | cdktn.IResolvable);
        resetEncryptionDisabled(): void;
        get encryptionDisabledInput(): boolean | cdktn.IResolvable | undefined;
        private _encryptionKey?;
        get encryptionKey(): string;
        set encryptionKey(value: string);
        get encryptionKeyInput(): string | undefined;
        private _packaging?;
        get packaging(): string;
        set packaging(value: string);
        resetPackaging(): void;
        get packagingInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
    }
    interface ExportConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#type AwsCodebuildReportGroup#type}
        */
        readonly type: string;
        /**
        * s3_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_report_group#s3_destination AwsCodebuildReportGroup#s3_destination}
        */
        readonly s3Destination?: S3DestinationProperty;
    }
    class ExportConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExportConfigProperty | undefined;
        set internalValue(value: ExportConfigProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _s3Destination;
        get s3Destination(): S3DestinationPropertyOutputReference;
        putS3Destination(value: S3DestinationProperty): void;
        resetS3Destination(): void;
        get s3DestinationInput(): S3DestinationProperty | undefined;
    }
}
