import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCodebuildFleetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#base_capacity AwsCodebuildFleet#base_capacity}
    */
    readonly baseCapacity: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#compute_type AwsCodebuildFleet#compute_type}
    */
    readonly computeType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#environment_type AwsCodebuildFleet#environment_type}
    */
    readonly environmentType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#fleet_service_role AwsCodebuildFleet#fleet_service_role}
    */
    readonly fleetServiceRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#image_id AwsCodebuildFleet#image_id}
    */
    readonly imageId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#name AwsCodebuildFleet#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#overflow_behavior AwsCodebuildFleet#overflow_behavior}
    */
    readonly overflowBehavior?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#region AwsCodebuildFleet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#tags AwsCodebuildFleet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#tags_all AwsCodebuildFleet#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * compute_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#compute_configuration AwsCodebuildFleet#compute_configuration}
    */
    readonly computeConfiguration?: AwsCodebuildFleet.ComputeConfigurationProperty;
    /**
    * scaling_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#scaling_configuration AwsCodebuildFleet#scaling_configuration}
    */
    readonly scalingConfiguration?: AwsCodebuildFleet.ScalingConfigurationProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#vpc_config AwsCodebuildFleet#vpc_config}
    */
    readonly vpcConfig?: AwsCodebuildFleet.VpcConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet aws_codebuild_fleet}
*/
export declare class AwsCodebuildFleet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codebuild_fleet";
    /**
    * Generates CDKTN code for importing a AwsCodebuildFleet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCodebuildFleet to import
    * @param importFromId The id of the existing AwsCodebuildFleet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCodebuildFleet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet aws_codebuild_fleet} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCodebuildFleetConfig
    */
    constructor(scope: Construct, id: string, config: AwsCodebuildFleetConfig);
    get arn(): string;
    private _baseCapacity?;
    get baseCapacity(): number;
    set baseCapacity(value: number);
    get baseCapacityInput(): number | undefined;
    private _computeType?;
    get computeType(): string;
    set computeType(value: string);
    get computeTypeInput(): string | undefined;
    get created(): string;
    private _environmentType?;
    get environmentType(): string;
    set environmentType(value: string);
    get environmentTypeInput(): string | undefined;
    private _fleetServiceRole?;
    get fleetServiceRole(): string;
    set fleetServiceRole(value: string);
    resetFleetServiceRole(): void;
    get fleetServiceRoleInput(): string | undefined;
    get id(): string;
    private _imageId?;
    get imageId(): string;
    set imageId(value: string);
    resetImageId(): void;
    get imageIdInput(): string | undefined;
    get lastModified(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _overflowBehavior?;
    get overflowBehavior(): string;
    set overflowBehavior(value: string);
    resetOverflowBehavior(): void;
    get overflowBehaviorInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _status;
    get status(): AwsCodebuildFleet.StatusPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _computeConfiguration;
    get computeConfiguration(): AwsCodebuildFleet.ComputeConfigurationPropertyOutputReference;
    putComputeConfiguration(value: AwsCodebuildFleet.ComputeConfigurationProperty): void;
    resetComputeConfiguration(): void;
    get computeConfigurationInput(): AwsCodebuildFleet.ComputeConfigurationProperty | undefined;
    private _scalingConfiguration;
    get scalingConfiguration(): AwsCodebuildFleet.ScalingConfigurationPropertyOutputReference;
    putScalingConfiguration(value: AwsCodebuildFleet.ScalingConfigurationProperty): void;
    resetScalingConfiguration(): void;
    get scalingConfigurationInput(): AwsCodebuildFleet.ScalingConfigurationProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): AwsCodebuildFleet.VpcConfigPropertyList;
    putVpcConfig(value: AwsCodebuildFleet.VpcConfigProperty[] | cdktn.IResolvable): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): cdktn.IResolvable | AwsCodebuildFleet.VpcConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCodebuildFleetStatusPropertyToTerraform(struct?: AwsCodebuildFleet.StatusProperty): any;
export declare function awsCodebuildFleetStatusPropertyToHclTerraform(struct?: AwsCodebuildFleet.StatusProperty): any;
export declare function awsCodebuildFleetComputeConfigurationPropertyToTerraform(struct?: AwsCodebuildFleet.ComputeConfigurationPropertyOutputReference | AwsCodebuildFleet.ComputeConfigurationProperty): any;
export declare function awsCodebuildFleetComputeConfigurationPropertyToHclTerraform(struct?: AwsCodebuildFleet.ComputeConfigurationPropertyOutputReference | AwsCodebuildFleet.ComputeConfigurationProperty): any;
export declare function awsCodebuildFleetTargetTrackingScalingConfigsPropertyToTerraform(struct?: AwsCodebuildFleet.TargetTrackingScalingConfigsProperty | cdktn.IResolvable): any;
export declare function awsCodebuildFleetTargetTrackingScalingConfigsPropertyToHclTerraform(struct?: AwsCodebuildFleet.TargetTrackingScalingConfigsProperty | cdktn.IResolvable): any;
export declare function awsCodebuildFleetScalingConfigurationPropertyToTerraform(struct?: AwsCodebuildFleet.ScalingConfigurationPropertyOutputReference | AwsCodebuildFleet.ScalingConfigurationProperty): any;
export declare function awsCodebuildFleetScalingConfigurationPropertyToHclTerraform(struct?: AwsCodebuildFleet.ScalingConfigurationPropertyOutputReference | AwsCodebuildFleet.ScalingConfigurationProperty): any;
export declare function awsCodebuildFleetVpcConfigPropertyToTerraform(struct?: AwsCodebuildFleet.VpcConfigProperty | cdktn.IResolvable): any;
export declare function awsCodebuildFleetVpcConfigPropertyToHclTerraform(struct?: AwsCodebuildFleet.VpcConfigProperty | cdktn.IResolvable): any;
export declare namespace AwsCodebuildFleet {
    interface StatusProperty {
    }
    class StatusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatusProperty | undefined;
        set internalValue(value: StatusProperty | undefined);
        get context(): string;
        get message(): string;
        get statusCode(): string;
    }
    class StatusPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatusPropertyOutputReference;
    }
    interface ComputeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#disk AwsCodebuildFleet#disk}
        */
        readonly disk?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#instance_type AwsCodebuildFleet#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#machine_type AwsCodebuildFleet#machine_type}
        */
        readonly machineType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#memory AwsCodebuildFleet#memory}
        */
        readonly memory?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#vcpu AwsCodebuildFleet#vcpu}
        */
        readonly vcpu?: number;
    }
    class ComputeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ComputeConfigurationProperty | undefined;
        set internalValue(value: ComputeConfigurationProperty | undefined);
        private _disk?;
        get disk(): number;
        set disk(value: number);
        resetDisk(): void;
        get diskInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _machineType?;
        get machineType(): string;
        set machineType(value: string);
        resetMachineType(): void;
        get machineTypeInput(): string | undefined;
        private _memory?;
        get memory(): number;
        set memory(value: number);
        resetMemory(): void;
        get memoryInput(): number | undefined;
        private _vcpu?;
        get vcpu(): number;
        set vcpu(value: number);
        resetVcpu(): void;
        get vcpuInput(): number | undefined;
    }
    interface TargetTrackingScalingConfigsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#metric_type AwsCodebuildFleet#metric_type}
        */
        readonly metricType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#target_value AwsCodebuildFleet#target_value}
        */
        readonly targetValue?: number;
    }
    class TargetTrackingScalingConfigsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetTrackingScalingConfigsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetTrackingScalingConfigsProperty | cdktn.IResolvable | undefined);
        private _metricType?;
        get metricType(): string;
        set metricType(value: string);
        resetMetricType(): void;
        get metricTypeInput(): string | undefined;
        private _targetValue?;
        get targetValue(): number;
        set targetValue(value: number);
        resetTargetValue(): void;
        get targetValueInput(): number | undefined;
    }
    class TargetTrackingScalingConfigsPropertyList extends cdktn.ComplexList {
        internalValue?: TargetTrackingScalingConfigsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetTrackingScalingConfigsPropertyOutputReference;
    }
    interface ScalingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#max_capacity AwsCodebuildFleet#max_capacity}
        */
        readonly maxCapacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#scaling_type AwsCodebuildFleet#scaling_type}
        */
        readonly scalingType?: string;
        /**
        * target_tracking_scaling_configs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#target_tracking_scaling_configs AwsCodebuildFleet#target_tracking_scaling_configs}
        */
        readonly targetTrackingScalingConfigs?: TargetTrackingScalingConfigsProperty[] | cdktn.IResolvable;
    }
    class ScalingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScalingConfigurationProperty | undefined;
        set internalValue(value: ScalingConfigurationProperty | undefined);
        get desiredCapacity(): number;
        private _maxCapacity?;
        get maxCapacity(): number;
        set maxCapacity(value: number);
        resetMaxCapacity(): void;
        get maxCapacityInput(): number | undefined;
        private _scalingType?;
        get scalingType(): string;
        set scalingType(value: string);
        resetScalingType(): void;
        get scalingTypeInput(): string | undefined;
        private _targetTrackingScalingConfigs;
        get targetTrackingScalingConfigs(): TargetTrackingScalingConfigsPropertyList;
        putTargetTrackingScalingConfigs(value: TargetTrackingScalingConfigsProperty[] | cdktn.IResolvable): void;
        resetTargetTrackingScalingConfigs(): void;
        get targetTrackingScalingConfigsInput(): cdktn.IResolvable | TargetTrackingScalingConfigsProperty[] | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#security_group_ids AwsCodebuildFleet#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#subnets AwsCodebuildFleet#subnets}
        */
        readonly subnets: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_fleet#vpc_id AwsCodebuildFleet#vpc_id}
        */
        readonly vpcId: string;
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcConfigProperty | cdktn.IResolvable | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        get vpcIdInput(): string | undefined;
    }
    class VpcConfigPropertyList extends cdktn.ComplexList {
        internalValue?: VpcConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigPropertyOutputReference;
    }
}
