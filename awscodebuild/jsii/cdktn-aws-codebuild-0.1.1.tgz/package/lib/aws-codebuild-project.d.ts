import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCodebuildProjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * Maximum number of additional automatic retries after a failed build. The default value is 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#auto_retry_limit AwsCodebuildProject#auto_retry_limit}
    */
    readonly autoRetryLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#badge_enabled AwsCodebuildProject#badge_enabled}
    */
    readonly badgeEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#build_timeout AwsCodebuildProject#build_timeout}
    */
    readonly buildTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#concurrent_build_limit AwsCodebuildProject#concurrent_build_limit}
    */
    readonly concurrentBuildLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#description AwsCodebuildProject#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#encryption_key AwsCodebuildProject#encryption_key}
    */
    readonly encryptionKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#id AwsCodebuildProject#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#name AwsCodebuildProject#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#project_visibility AwsCodebuildProject#project_visibility}
    */
    readonly projectVisibility?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#queued_timeout AwsCodebuildProject#queued_timeout}
    */
    readonly queuedTimeout?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#region AwsCodebuildProject#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#resource_access_role AwsCodebuildProject#resource_access_role}
    */
    readonly resourceAccessRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#service_role AwsCodebuildProject#service_role}
    */
    readonly serviceRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#source_version AwsCodebuildProject#source_version}
    */
    readonly sourceVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#tags AwsCodebuildProject#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#tags_all AwsCodebuildProject#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * artifacts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#artifacts AwsCodebuildProject#artifacts}
    */
    readonly artifacts: AwsCodebuildProject.ArtifactsProperty;
    /**
    * build_batch_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#build_batch_config AwsCodebuildProject#build_batch_config}
    */
    readonly buildBatchConfig?: AwsCodebuildProject.BuildBatchConfigProperty;
    /**
    * cache block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#cache AwsCodebuildProject#cache}
    */
    readonly cache?: AwsCodebuildProject.CacheProperty;
    /**
    * environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#environment AwsCodebuildProject#environment}
    */
    readonly environment: AwsCodebuildProject.EnvironmentProperty;
    /**
    * file_system_locations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#file_system_locations AwsCodebuildProject#file_system_locations}
    */
    readonly fileSystemLocations?: AwsCodebuildProject.FileSystemLocationsProperty[] | cdktn.IResolvable;
    /**
    * logs_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#logs_config AwsCodebuildProject#logs_config}
    */
    readonly logsConfig?: AwsCodebuildProject.LogsConfigProperty;
    /**
    * secondary_artifacts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#secondary_artifacts AwsCodebuildProject#secondary_artifacts}
    */
    readonly secondaryArtifacts?: AwsCodebuildProject.SecondaryArtifactsProperty[] | cdktn.IResolvable;
    /**
    * secondary_source_version block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#secondary_source_version AwsCodebuildProject#secondary_source_version}
    */
    readonly secondarySourceVersion?: AwsCodebuildProject.SecondarySourceVersionProperty[] | cdktn.IResolvable;
    /**
    * secondary_sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#secondary_sources AwsCodebuildProject#secondary_sources}
    */
    readonly secondarySources?: AwsCodebuildProject.SecondarySourcesProperty[] | cdktn.IResolvable;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#source AwsCodebuildProject#source}
    */
    readonly source: AwsCodebuildProject.SourceProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#vpc_config AwsCodebuildProject#vpc_config}
    */
    readonly vpcConfig?: AwsCodebuildProject.VpcConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project aws_codebuild_project}
*/
export declare class AwsCodebuildProject extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codebuild_project";
    /**
    * Generates CDKTN code for importing a AwsCodebuildProject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCodebuildProject to import
    * @param importFromId The id of the existing AwsCodebuildProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCodebuildProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project aws_codebuild_project} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCodebuildProjectConfig
    */
    constructor(scope: Construct, id: string, config: AwsCodebuildProjectConfig);
    get arn(): string;
    private _autoRetryLimit?;
    get autoRetryLimit(): number;
    set autoRetryLimit(value: number);
    resetAutoRetryLimit(): void;
    get autoRetryLimitInput(): number | undefined;
    private _badgeEnabled?;
    get badgeEnabled(): boolean | cdktn.IResolvable;
    set badgeEnabled(value: boolean | cdktn.IResolvable);
    resetBadgeEnabled(): void;
    get badgeEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get badgeUrl(): string;
    private _buildTimeout?;
    get buildTimeout(): number;
    set buildTimeout(value: number);
    resetBuildTimeout(): void;
    get buildTimeoutInput(): number | undefined;
    private _concurrentBuildLimit?;
    get concurrentBuildLimit(): number;
    set concurrentBuildLimit(value: number);
    resetConcurrentBuildLimit(): void;
    get concurrentBuildLimitInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _encryptionKey?;
    get encryptionKey(): string;
    set encryptionKey(value: string);
    resetEncryptionKey(): void;
    get encryptionKeyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectVisibility?;
    get projectVisibility(): string;
    set projectVisibility(value: string);
    resetProjectVisibility(): void;
    get projectVisibilityInput(): string | undefined;
    get publicProjectAlias(): string;
    private _queuedTimeout?;
    get queuedTimeout(): number;
    set queuedTimeout(value: number);
    resetQueuedTimeout(): void;
    get queuedTimeoutInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceAccessRole?;
    get resourceAccessRole(): string;
    set resourceAccessRole(value: string);
    resetResourceAccessRole(): void;
    get resourceAccessRoleInput(): string | undefined;
    private _serviceRole?;
    get serviceRole(): string;
    set serviceRole(value: string);
    get serviceRoleInput(): string | undefined;
    private _sourceVersion?;
    get sourceVersion(): string;
    set sourceVersion(value: string);
    resetSourceVersion(): void;
    get sourceVersionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _artifacts;
    get artifacts(): AwsCodebuildProject.ArtifactsPropertyOutputReference;
    putArtifacts(value: AwsCodebuildProject.ArtifactsProperty): void;
    get artifactsInput(): AwsCodebuildProject.ArtifactsProperty | undefined;
    private _buildBatchConfig;
    get buildBatchConfig(): AwsCodebuildProject.BuildBatchConfigPropertyOutputReference;
    putBuildBatchConfig(value: AwsCodebuildProject.BuildBatchConfigProperty): void;
    resetBuildBatchConfig(): void;
    get buildBatchConfigInput(): AwsCodebuildProject.BuildBatchConfigProperty | undefined;
    private _cache;
    get cache(): AwsCodebuildProject.CachePropertyOutputReference;
    putCache(value: AwsCodebuildProject.CacheProperty): void;
    resetCache(): void;
    get cacheInput(): AwsCodebuildProject.CacheProperty | undefined;
    private _environment;
    get environment(): AwsCodebuildProject.EnvironmentPropertyOutputReference;
    putEnvironment(value: AwsCodebuildProject.EnvironmentProperty): void;
    get environmentInput(): AwsCodebuildProject.EnvironmentProperty | undefined;
    private _fileSystemLocations;
    get fileSystemLocations(): AwsCodebuildProject.FileSystemLocationsPropertyList;
    putFileSystemLocations(value: AwsCodebuildProject.FileSystemLocationsProperty[] | cdktn.IResolvable): void;
    resetFileSystemLocations(): void;
    get fileSystemLocationsInput(): cdktn.IResolvable | AwsCodebuildProject.FileSystemLocationsProperty[] | undefined;
    private _logsConfig;
    get logsConfig(): AwsCodebuildProject.LogsConfigPropertyOutputReference;
    putLogsConfig(value: AwsCodebuildProject.LogsConfigProperty): void;
    resetLogsConfig(): void;
    get logsConfigInput(): AwsCodebuildProject.LogsConfigProperty | undefined;
    private _secondaryArtifacts;
    get secondaryArtifacts(): AwsCodebuildProject.SecondaryArtifactsPropertyList;
    putSecondaryArtifacts(value: AwsCodebuildProject.SecondaryArtifactsProperty[] | cdktn.IResolvable): void;
    resetSecondaryArtifacts(): void;
    get secondaryArtifactsInput(): cdktn.IResolvable | AwsCodebuildProject.SecondaryArtifactsProperty[] | undefined;
    private _secondarySourceVersion;
    get secondarySourceVersion(): AwsCodebuildProject.SecondarySourceVersionPropertyList;
    putSecondarySourceVersion(value: AwsCodebuildProject.SecondarySourceVersionProperty[] | cdktn.IResolvable): void;
    resetSecondarySourceVersion(): void;
    get secondarySourceVersionInput(): cdktn.IResolvable | AwsCodebuildProject.SecondarySourceVersionProperty[] | undefined;
    private _secondarySources;
    get secondarySources(): AwsCodebuildProject.SecondarySourcesPropertyList;
    putSecondarySources(value: AwsCodebuildProject.SecondarySourcesProperty[] | cdktn.IResolvable): void;
    resetSecondarySources(): void;
    get secondarySourcesInput(): cdktn.IResolvable | AwsCodebuildProject.SecondarySourcesProperty[] | undefined;
    private _source;
    get source(): AwsCodebuildProject.SourcePropertyOutputReference;
    putSource(value: AwsCodebuildProject.SourceProperty): void;
    get sourceInput(): AwsCodebuildProject.SourceProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): AwsCodebuildProject.VpcConfigPropertyOutputReference;
    putVpcConfig(value: AwsCodebuildProject.VpcConfigProperty): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): AwsCodebuildProject.VpcConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCodebuildProjectArtifactsPropertyToTerraform(struct?: AwsCodebuildProject.ArtifactsPropertyOutputReference | AwsCodebuildProject.ArtifactsProperty): any;
export declare function awsCodebuildProjectArtifactsPropertyToHclTerraform(struct?: AwsCodebuildProject.ArtifactsPropertyOutputReference | AwsCodebuildProject.ArtifactsProperty): any;
export declare function awsCodebuildProjectRestrictionsPropertyToTerraform(struct?: AwsCodebuildProject.RestrictionsPropertyOutputReference | AwsCodebuildProject.RestrictionsProperty): any;
export declare function awsCodebuildProjectRestrictionsPropertyToHclTerraform(struct?: AwsCodebuildProject.RestrictionsPropertyOutputReference | AwsCodebuildProject.RestrictionsProperty): any;
export declare function awsCodebuildProjectBuildBatchConfigPropertyToTerraform(struct?: AwsCodebuildProject.BuildBatchConfigPropertyOutputReference | AwsCodebuildProject.BuildBatchConfigProperty): any;
export declare function awsCodebuildProjectBuildBatchConfigPropertyToHclTerraform(struct?: AwsCodebuildProject.BuildBatchConfigPropertyOutputReference | AwsCodebuildProject.BuildBatchConfigProperty): any;
export declare function awsCodebuildProjectCachePropertyToTerraform(struct?: AwsCodebuildProject.CachePropertyOutputReference | AwsCodebuildProject.CacheProperty): any;
export declare function awsCodebuildProjectCachePropertyToHclTerraform(struct?: AwsCodebuildProject.CachePropertyOutputReference | AwsCodebuildProject.CacheProperty): any;
export declare function awsCodebuildProjectDockerServerPropertyToTerraform(struct?: AwsCodebuildProject.DockerServerPropertyOutputReference | AwsCodebuildProject.DockerServerProperty): any;
export declare function awsCodebuildProjectDockerServerPropertyToHclTerraform(struct?: AwsCodebuildProject.DockerServerPropertyOutputReference | AwsCodebuildProject.DockerServerProperty): any;
export declare function awsCodebuildProjectEnvironmentVariablePropertyToTerraform(struct?: AwsCodebuildProject.EnvironmentVariableProperty | cdktn.IResolvable): any;
export declare function awsCodebuildProjectEnvironmentVariablePropertyToHclTerraform(struct?: AwsCodebuildProject.EnvironmentVariableProperty | cdktn.IResolvable): any;
export declare function awsCodebuildProjectFleetPropertyToTerraform(struct?: AwsCodebuildProject.FleetPropertyOutputReference | AwsCodebuildProject.FleetProperty): any;
export declare function awsCodebuildProjectFleetPropertyToHclTerraform(struct?: AwsCodebuildProject.FleetPropertyOutputReference | AwsCodebuildProject.FleetProperty): any;
export declare function awsCodebuildProjectRegistryCredentialPropertyToTerraform(struct?: AwsCodebuildProject.RegistryCredentialPropertyOutputReference | AwsCodebuildProject.RegistryCredentialProperty): any;
export declare function awsCodebuildProjectRegistryCredentialPropertyToHclTerraform(struct?: AwsCodebuildProject.RegistryCredentialPropertyOutputReference | AwsCodebuildProject.RegistryCredentialProperty): any;
export declare function awsCodebuildProjectEnvironmentPropertyToTerraform(struct?: AwsCodebuildProject.EnvironmentPropertyOutputReference | AwsCodebuildProject.EnvironmentProperty): any;
export declare function awsCodebuildProjectEnvironmentPropertyToHclTerraform(struct?: AwsCodebuildProject.EnvironmentPropertyOutputReference | AwsCodebuildProject.EnvironmentProperty): any;
export declare function awsCodebuildProjectFileSystemLocationsPropertyToTerraform(struct?: AwsCodebuildProject.FileSystemLocationsProperty | cdktn.IResolvable): any;
export declare function awsCodebuildProjectFileSystemLocationsPropertyToHclTerraform(struct?: AwsCodebuildProject.FileSystemLocationsProperty | cdktn.IResolvable): any;
export declare function awsCodebuildProjectCloudwatchLogsPropertyToTerraform(struct?: AwsCodebuildProject.CloudwatchLogsPropertyOutputReference | AwsCodebuildProject.CloudwatchLogsProperty): any;
export declare function awsCodebuildProjectCloudwatchLogsPropertyToHclTerraform(struct?: AwsCodebuildProject.CloudwatchLogsPropertyOutputReference | AwsCodebuildProject.CloudwatchLogsProperty): any;
export declare function awsCodebuildProjectS3LogsPropertyToTerraform(struct?: AwsCodebuildProject.S3LogsPropertyOutputReference | AwsCodebuildProject.S3LogsProperty): any;
export declare function awsCodebuildProjectS3LogsPropertyToHclTerraform(struct?: AwsCodebuildProject.S3LogsPropertyOutputReference | AwsCodebuildProject.S3LogsProperty): any;
export declare function awsCodebuildProjectLogsConfigPropertyToTerraform(struct?: AwsCodebuildProject.LogsConfigPropertyOutputReference | AwsCodebuildProject.LogsConfigProperty): any;
export declare function awsCodebuildProjectLogsConfigPropertyToHclTerraform(struct?: AwsCodebuildProject.LogsConfigPropertyOutputReference | AwsCodebuildProject.LogsConfigProperty): any;
export declare function awsCodebuildProjectSecondaryArtifactsPropertyToTerraform(struct?: AwsCodebuildProject.SecondaryArtifactsProperty | cdktn.IResolvable): any;
export declare function awsCodebuildProjectSecondaryArtifactsPropertyToHclTerraform(struct?: AwsCodebuildProject.SecondaryArtifactsProperty | cdktn.IResolvable): any;
export declare function awsCodebuildProjectSecondarySourceVersionPropertyToTerraform(struct?: AwsCodebuildProject.SecondarySourceVersionProperty | cdktn.IResolvable): any;
export declare function awsCodebuildProjectSecondarySourceVersionPropertyToHclTerraform(struct?: AwsCodebuildProject.SecondarySourceVersionProperty | cdktn.IResolvable): any;
export declare function awsCodebuildProjectSecondarySourcesAuthPropertyToTerraform(struct?: AwsCodebuildProject.SecondarySourcesAuthPropertyOutputReference | AwsCodebuildProject.SecondarySourcesAuthProperty): any;
export declare function awsCodebuildProjectSecondarySourcesAuthPropertyToHclTerraform(struct?: AwsCodebuildProject.SecondarySourcesAuthPropertyOutputReference | AwsCodebuildProject.SecondarySourcesAuthProperty): any;
export declare function awsCodebuildProjectSecondarySourcesBuildStatusConfigPropertyToTerraform(struct?: AwsCodebuildProject.SecondarySourcesBuildStatusConfigPropertyOutputReference | AwsCodebuildProject.SecondarySourcesBuildStatusConfigProperty): any;
export declare function awsCodebuildProjectSecondarySourcesBuildStatusConfigPropertyToHclTerraform(struct?: AwsCodebuildProject.SecondarySourcesBuildStatusConfigPropertyOutputReference | AwsCodebuildProject.SecondarySourcesBuildStatusConfigProperty): any;
export declare function awsCodebuildProjectSecondarySourcesGitSubmodulesConfigPropertyToTerraform(struct?: AwsCodebuildProject.SecondarySourcesGitSubmodulesConfigPropertyOutputReference | AwsCodebuildProject.SecondarySourcesGitSubmodulesConfigProperty): any;
export declare function awsCodebuildProjectSecondarySourcesGitSubmodulesConfigPropertyToHclTerraform(struct?: AwsCodebuildProject.SecondarySourcesGitSubmodulesConfigPropertyOutputReference | AwsCodebuildProject.SecondarySourcesGitSubmodulesConfigProperty): any;
export declare function awsCodebuildProjectSecondarySourcesPropertyToTerraform(struct?: AwsCodebuildProject.SecondarySourcesProperty | cdktn.IResolvable): any;
export declare function awsCodebuildProjectSecondarySourcesPropertyToHclTerraform(struct?: AwsCodebuildProject.SecondarySourcesProperty | cdktn.IResolvable): any;
export declare function awsCodebuildProjectSourceAuthPropertyToTerraform(struct?: AwsCodebuildProject.SourceAuthPropertyOutputReference | AwsCodebuildProject.SourceAuthProperty): any;
export declare function awsCodebuildProjectSourceAuthPropertyToHclTerraform(struct?: AwsCodebuildProject.SourceAuthPropertyOutputReference | AwsCodebuildProject.SourceAuthProperty): any;
export declare function awsCodebuildProjectSourceBuildStatusConfigPropertyToTerraform(struct?: AwsCodebuildProject.SourceBuildStatusConfigPropertyOutputReference | AwsCodebuildProject.SourceBuildStatusConfigProperty): any;
export declare function awsCodebuildProjectSourceBuildStatusConfigPropertyToHclTerraform(struct?: AwsCodebuildProject.SourceBuildStatusConfigPropertyOutputReference | AwsCodebuildProject.SourceBuildStatusConfigProperty): any;
export declare function awsCodebuildProjectSourceGitSubmodulesConfigPropertyToTerraform(struct?: AwsCodebuildProject.SourceGitSubmodulesConfigPropertyOutputReference | AwsCodebuildProject.SourceGitSubmodulesConfigProperty): any;
export declare function awsCodebuildProjectSourceGitSubmodulesConfigPropertyToHclTerraform(struct?: AwsCodebuildProject.SourceGitSubmodulesConfigPropertyOutputReference | AwsCodebuildProject.SourceGitSubmodulesConfigProperty): any;
export declare function awsCodebuildProjectSourcePropertyToTerraform(struct?: AwsCodebuildProject.SourcePropertyOutputReference | AwsCodebuildProject.SourceProperty): any;
export declare function awsCodebuildProjectSourcePropertyToHclTerraform(struct?: AwsCodebuildProject.SourcePropertyOutputReference | AwsCodebuildProject.SourceProperty): any;
export declare function awsCodebuildProjectVpcConfigPropertyToTerraform(struct?: AwsCodebuildProject.VpcConfigPropertyOutputReference | AwsCodebuildProject.VpcConfigProperty): any;
export declare function awsCodebuildProjectVpcConfigPropertyToHclTerraform(struct?: AwsCodebuildProject.VpcConfigPropertyOutputReference | AwsCodebuildProject.VpcConfigProperty): any;
export declare namespace AwsCodebuildProject {
    interface ArtifactsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#artifact_identifier AwsCodebuildProject#artifact_identifier}
        */
        readonly artifactIdentifier?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#bucket_owner_access AwsCodebuildProject#bucket_owner_access}
        */
        readonly bucketOwnerAccess?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#encryption_disabled AwsCodebuildProject#encryption_disabled}
        */
        readonly encryptionDisabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#location AwsCodebuildProject#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#name AwsCodebuildProject#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#namespace_type AwsCodebuildProject#namespace_type}
        */
        readonly namespaceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#override_artifact_name AwsCodebuildProject#override_artifact_name}
        */
        readonly overrideArtifactName?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#packaging AwsCodebuildProject#packaging}
        */
        readonly packaging?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#path AwsCodebuildProject#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsCodebuildProject#type}
        */
        readonly type: string;
    }
    class ArtifactsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ArtifactsProperty | undefined;
        set internalValue(value: ArtifactsProperty | undefined);
        private _artifactIdentifier?;
        get artifactIdentifier(): string;
        set artifactIdentifier(value: string);
        resetArtifactIdentifier(): void;
        get artifactIdentifierInput(): string | undefined;
        private _bucketOwnerAccess?;
        get bucketOwnerAccess(): string;
        set bucketOwnerAccess(value: string);
        resetBucketOwnerAccess(): void;
        get bucketOwnerAccessInput(): string | undefined;
        private _encryptionDisabled?;
        get encryptionDisabled(): boolean | cdktn.IResolvable;
        set encryptionDisabled(value: boolean | cdktn.IResolvable);
        resetEncryptionDisabled(): void;
        get encryptionDisabledInput(): boolean | cdktn.IResolvable | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _namespaceType?;
        get namespaceType(): string;
        set namespaceType(value: string);
        resetNamespaceType(): void;
        get namespaceTypeInput(): string | undefined;
        private _overrideArtifactName?;
        get overrideArtifactName(): boolean | cdktn.IResolvable;
        set overrideArtifactName(value: boolean | cdktn.IResolvable);
        resetOverrideArtifactName(): void;
        get overrideArtifactNameInput(): boolean | cdktn.IResolvable | undefined;
        private _packaging?;
        get packaging(): string;
        set packaging(value: string);
        resetPackaging(): void;
        get packagingInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface RestrictionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#compute_types_allowed AwsCodebuildProject#compute_types_allowed}
        */
        readonly computeTypesAllowed?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#maximum_builds_allowed AwsCodebuildProject#maximum_builds_allowed}
        */
        readonly maximumBuildsAllowed?: number;
    }
    class RestrictionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RestrictionsProperty | undefined;
        set internalValue(value: RestrictionsProperty | undefined);
        private _computeTypesAllowed?;
        get computeTypesAllowed(): string[];
        set computeTypesAllowed(value: string[]);
        resetComputeTypesAllowed(): void;
        get computeTypesAllowedInput(): string[] | undefined;
        private _maximumBuildsAllowed?;
        get maximumBuildsAllowed(): number;
        set maximumBuildsAllowed(value: number);
        resetMaximumBuildsAllowed(): void;
        get maximumBuildsAllowedInput(): number | undefined;
    }
    interface BuildBatchConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#combine_artifacts AwsCodebuildProject#combine_artifacts}
        */
        readonly combineArtifacts?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#service_role AwsCodebuildProject#service_role}
        */
        readonly serviceRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#timeout_in_mins AwsCodebuildProject#timeout_in_mins}
        */
        readonly timeoutInMins?: number;
        /**
        * restrictions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#restrictions AwsCodebuildProject#restrictions}
        */
        readonly restrictions?: RestrictionsProperty;
    }
    class BuildBatchConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BuildBatchConfigProperty | undefined;
        set internalValue(value: BuildBatchConfigProperty | undefined);
        private _combineArtifacts?;
        get combineArtifacts(): boolean | cdktn.IResolvable;
        set combineArtifacts(value: boolean | cdktn.IResolvable);
        resetCombineArtifacts(): void;
        get combineArtifactsInput(): boolean | cdktn.IResolvable | undefined;
        private _serviceRole?;
        get serviceRole(): string;
        set serviceRole(value: string);
        get serviceRoleInput(): string | undefined;
        private _timeoutInMins?;
        get timeoutInMins(): number;
        set timeoutInMins(value: number);
        resetTimeoutInMins(): void;
        get timeoutInMinsInput(): number | undefined;
        private _restrictions;
        get restrictions(): RestrictionsPropertyOutputReference;
        putRestrictions(value: RestrictionsProperty): void;
        resetRestrictions(): void;
        get restrictionsInput(): RestrictionsProperty | undefined;
    }
    interface CacheProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#cache_namespace AwsCodebuildProject#cache_namespace}
        */
        readonly cacheNamespace?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#location AwsCodebuildProject#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#modes AwsCodebuildProject#modes}
        */
        readonly modes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsCodebuildProject#type}
        */
        readonly type?: string;
    }
    class CachePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CacheProperty | undefined;
        set internalValue(value: CacheProperty | undefined);
        private _cacheNamespace?;
        get cacheNamespace(): string;
        set cacheNamespace(value: string);
        resetCacheNamespace(): void;
        get cacheNamespaceInput(): string | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _modes?;
        get modes(): string[];
        set modes(value: string[]);
        resetModes(): void;
        get modesInput(): string[] | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface DockerServerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#compute_type AwsCodebuildProject#compute_type}
        */
        readonly computeType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#security_group_ids AwsCodebuildProject#security_group_ids}
        */
        readonly securityGroupIds?: string[];
    }
    class DockerServerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DockerServerProperty | undefined;
        set internalValue(value: DockerServerProperty | undefined);
        private _computeType?;
        get computeType(): string;
        set computeType(value: string);
        get computeTypeInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
    }
    interface EnvironmentVariableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#name AwsCodebuildProject#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsCodebuildProject#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#value AwsCodebuildProject#value}
        */
        readonly value: string;
    }
    class EnvironmentVariablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentVariableProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnvironmentVariableProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class EnvironmentVariablePropertyList extends cdktn.ComplexList {
        internalValue?: EnvironmentVariableProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentVariablePropertyOutputReference;
    }
    interface FleetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#fleet_arn AwsCodebuildProject#fleet_arn}
        */
        readonly fleetArn?: string;
    }
    class FleetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FleetProperty | undefined;
        set internalValue(value: FleetProperty | undefined);
        private _fleetArn?;
        get fleetArn(): string;
        set fleetArn(value: string);
        resetFleetArn(): void;
        get fleetArnInput(): string | undefined;
    }
    interface RegistryCredentialProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#credential AwsCodebuildProject#credential}
        */
        readonly credential: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#credential_provider AwsCodebuildProject#credential_provider}
        */
        readonly credentialProvider: string;
    }
    class RegistryCredentialPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RegistryCredentialProperty | undefined;
        set internalValue(value: RegistryCredentialProperty | undefined);
        private _credential?;
        get credential(): string;
        set credential(value: string);
        get credentialInput(): string | undefined;
        private _credentialProvider?;
        get credentialProvider(): string;
        set credentialProvider(value: string);
        get credentialProviderInput(): string | undefined;
    }
    interface EnvironmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#certificate AwsCodebuildProject#certificate}
        */
        readonly certificate?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#compute_type AwsCodebuildProject#compute_type}
        */
        readonly computeType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#host_kernel AwsCodebuildProject#host_kernel}
        */
        readonly hostKernel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#image AwsCodebuildProject#image}
        */
        readonly image: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#image_pull_credentials_type AwsCodebuildProject#image_pull_credentials_type}
        */
        readonly imagePullCredentialsType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#privileged_mode AwsCodebuildProject#privileged_mode}
        */
        readonly privilegedMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsCodebuildProject#type}
        */
        readonly type: string;
        /**
        * docker_server block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#docker_server AwsCodebuildProject#docker_server}
        */
        readonly dockerServer?: DockerServerProperty;
        /**
        * environment_variable block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#environment_variable AwsCodebuildProject#environment_variable}
        */
        readonly environmentVariable?: EnvironmentVariableProperty[] | cdktn.IResolvable;
        /**
        * fleet block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#fleet AwsCodebuildProject#fleet}
        */
        readonly fleet?: FleetProperty;
        /**
        * registry_credential block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#registry_credential AwsCodebuildProject#registry_credential}
        */
        readonly registryCredential?: RegistryCredentialProperty;
    }
    class EnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnvironmentProperty | undefined;
        set internalValue(value: EnvironmentProperty | undefined);
        private _certificate?;
        get certificate(): string;
        set certificate(value: string);
        resetCertificate(): void;
        get certificateInput(): string | undefined;
        private _computeType?;
        get computeType(): string;
        set computeType(value: string);
        get computeTypeInput(): string | undefined;
        private _hostKernel?;
        get hostKernel(): string;
        set hostKernel(value: string);
        resetHostKernel(): void;
        get hostKernelInput(): string | undefined;
        private _image?;
        get image(): string;
        set image(value: string);
        get imageInput(): string | undefined;
        private _imagePullCredentialsType?;
        get imagePullCredentialsType(): string;
        set imagePullCredentialsType(value: string);
        resetImagePullCredentialsType(): void;
        get imagePullCredentialsTypeInput(): string | undefined;
        private _privilegedMode?;
        get privilegedMode(): boolean | cdktn.IResolvable;
        set privilegedMode(value: boolean | cdktn.IResolvable);
        resetPrivilegedMode(): void;
        get privilegedModeInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _dockerServer;
        get dockerServer(): DockerServerPropertyOutputReference;
        putDockerServer(value: DockerServerProperty): void;
        resetDockerServer(): void;
        get dockerServerInput(): DockerServerProperty | undefined;
        private _environmentVariable;
        get environmentVariable(): EnvironmentVariablePropertyList;
        putEnvironmentVariable(value: EnvironmentVariableProperty[] | cdktn.IResolvable): void;
        resetEnvironmentVariable(): void;
        get environmentVariableInput(): cdktn.IResolvable | EnvironmentVariableProperty[] | undefined;
        private _fleet;
        get fleet(): FleetPropertyOutputReference;
        putFleet(value: FleetProperty): void;
        resetFleet(): void;
        get fleetInput(): FleetProperty | undefined;
        private _registryCredential;
        get registryCredential(): RegistryCredentialPropertyOutputReference;
        putRegistryCredential(value: RegistryCredentialProperty): void;
        resetRegistryCredential(): void;
        get registryCredentialInput(): RegistryCredentialProperty | undefined;
    }
    interface FileSystemLocationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#identifier AwsCodebuildProject#identifier}
        */
        readonly identifier?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#location AwsCodebuildProject#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#mount_options AwsCodebuildProject#mount_options}
        */
        readonly mountOptions?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#mount_point AwsCodebuildProject#mount_point}
        */
        readonly mountPoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsCodebuildProject#type}
        */
        readonly type?: string;
    }
    class FileSystemLocationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FileSystemLocationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FileSystemLocationsProperty | cdktn.IResolvable | undefined);
        private _identifier?;
        get identifier(): string;
        set identifier(value: string);
        resetIdentifier(): void;
        get identifierInput(): string | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _mountOptions?;
        get mountOptions(): string;
        set mountOptions(value: string);
        resetMountOptions(): void;
        get mountOptionsInput(): string | undefined;
        private _mountPoint?;
        get mountPoint(): string;
        set mountPoint(value: string);
        resetMountPoint(): void;
        get mountPointInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class FileSystemLocationsPropertyList extends cdktn.ComplexList {
        internalValue?: FileSystemLocationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FileSystemLocationsPropertyOutputReference;
    }
    interface CloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#group_name AwsCodebuildProject#group_name}
        */
        readonly groupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#status AwsCodebuildProject#status}
        */
        readonly status?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#stream_name AwsCodebuildProject#stream_name}
        */
        readonly streamName?: string;
    }
    class CloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLogsProperty | undefined;
        set internalValue(value: CloudwatchLogsProperty | undefined);
        private _groupName?;
        get groupName(): string;
        set groupName(value: string);
        resetGroupName(): void;
        get groupNameInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
        private _streamName?;
        get streamName(): string;
        set streamName(value: string);
        resetStreamName(): void;
        get streamNameInput(): string | undefined;
    }
    interface S3LogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#bucket_owner_access AwsCodebuildProject#bucket_owner_access}
        */
        readonly bucketOwnerAccess?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#encryption_disabled AwsCodebuildProject#encryption_disabled}
        */
        readonly encryptionDisabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#location AwsCodebuildProject#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#status AwsCodebuildProject#status}
        */
        readonly status?: string;
    }
    class S3LogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3LogsProperty | undefined;
        set internalValue(value: S3LogsProperty | undefined);
        private _bucketOwnerAccess?;
        get bucketOwnerAccess(): string;
        set bucketOwnerAccess(value: string);
        resetBucketOwnerAccess(): void;
        get bucketOwnerAccessInput(): string | undefined;
        private _encryptionDisabled?;
        get encryptionDisabled(): boolean | cdktn.IResolvable;
        set encryptionDisabled(value: boolean | cdktn.IResolvable);
        resetEncryptionDisabled(): void;
        get encryptionDisabledInput(): boolean | cdktn.IResolvable | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface LogsConfigProperty {
        /**
        * cloudwatch_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#cloudwatch_logs AwsCodebuildProject#cloudwatch_logs}
        */
        readonly cloudwatchLogs?: CloudwatchLogsProperty;
        /**
        * s3_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#s3_logs AwsCodebuildProject#s3_logs}
        */
        readonly s3Logs?: S3LogsProperty;
    }
    class LogsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LogsConfigProperty | undefined;
        set internalValue(value: LogsConfigProperty | undefined);
        private _cloudwatchLogs;
        get cloudwatchLogs(): CloudwatchLogsPropertyOutputReference;
        putCloudwatchLogs(value: CloudwatchLogsProperty): void;
        resetCloudwatchLogs(): void;
        get cloudwatchLogsInput(): CloudwatchLogsProperty | undefined;
        private _s3Logs;
        get s3Logs(): S3LogsPropertyOutputReference;
        putS3Logs(value: S3LogsProperty): void;
        resetS3Logs(): void;
        get s3LogsInput(): S3LogsProperty | undefined;
    }
    interface SecondaryArtifactsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#artifact_identifier AwsCodebuildProject#artifact_identifier}
        */
        readonly artifactIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#bucket_owner_access AwsCodebuildProject#bucket_owner_access}
        */
        readonly bucketOwnerAccess?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#encryption_disabled AwsCodebuildProject#encryption_disabled}
        */
        readonly encryptionDisabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#location AwsCodebuildProject#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#name AwsCodebuildProject#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#namespace_type AwsCodebuildProject#namespace_type}
        */
        readonly namespaceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#override_artifact_name AwsCodebuildProject#override_artifact_name}
        */
        readonly overrideArtifactName?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#packaging AwsCodebuildProject#packaging}
        */
        readonly packaging?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#path AwsCodebuildProject#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsCodebuildProject#type}
        */
        readonly type: string;
    }
    class SecondaryArtifactsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecondaryArtifactsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecondaryArtifactsProperty | cdktn.IResolvable | undefined);
        private _artifactIdentifier?;
        get artifactIdentifier(): string;
        set artifactIdentifier(value: string);
        get artifactIdentifierInput(): string | undefined;
        private _bucketOwnerAccess?;
        get bucketOwnerAccess(): string;
        set bucketOwnerAccess(value: string);
        resetBucketOwnerAccess(): void;
        get bucketOwnerAccessInput(): string | undefined;
        private _encryptionDisabled?;
        get encryptionDisabled(): boolean | cdktn.IResolvable;
        set encryptionDisabled(value: boolean | cdktn.IResolvable);
        resetEncryptionDisabled(): void;
        get encryptionDisabledInput(): boolean | cdktn.IResolvable | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _namespaceType?;
        get namespaceType(): string;
        set namespaceType(value: string);
        resetNamespaceType(): void;
        get namespaceTypeInput(): string | undefined;
        private _overrideArtifactName?;
        get overrideArtifactName(): boolean | cdktn.IResolvable;
        set overrideArtifactName(value: boolean | cdktn.IResolvable);
        resetOverrideArtifactName(): void;
        get overrideArtifactNameInput(): boolean | cdktn.IResolvable | undefined;
        private _packaging?;
        get packaging(): string;
        set packaging(value: string);
        resetPackaging(): void;
        get packagingInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class SecondaryArtifactsPropertyList extends cdktn.ComplexList {
        internalValue?: SecondaryArtifactsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecondaryArtifactsPropertyOutputReference;
    }
    interface SecondarySourceVersionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#source_identifier AwsCodebuildProject#source_identifier}
        */
        readonly sourceIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#source_version AwsCodebuildProject#source_version}
        */
        readonly sourceVersion: string;
    }
    class SecondarySourceVersionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecondarySourceVersionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecondarySourceVersionProperty | cdktn.IResolvable | undefined);
        private _sourceIdentifier?;
        get sourceIdentifier(): string;
        set sourceIdentifier(value: string);
        get sourceIdentifierInput(): string | undefined;
        private _sourceVersion?;
        get sourceVersion(): string;
        set sourceVersion(value: string);
        get sourceVersionInput(): string | undefined;
    }
    class SecondarySourceVersionPropertyList extends cdktn.ComplexList {
        internalValue?: SecondarySourceVersionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecondarySourceVersionPropertyOutputReference;
    }
    interface SecondarySourcesAuthProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#resource AwsCodebuildProject#resource}
        */
        readonly resource: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsCodebuildProject#type}
        */
        readonly type: string;
    }
    class SecondarySourcesAuthPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecondarySourcesAuthProperty | undefined;
        set internalValue(value: SecondarySourcesAuthProperty | undefined);
        private _resource?;
        get resource(): string;
        set resource(value: string);
        get resourceInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface SecondarySourcesBuildStatusConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#context AwsCodebuildProject#context}
        */
        readonly context?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#target_url AwsCodebuildProject#target_url}
        */
        readonly targetUrl?: string;
    }
    class SecondarySourcesBuildStatusConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecondarySourcesBuildStatusConfigProperty | undefined;
        set internalValue(value: SecondarySourcesBuildStatusConfigProperty | undefined);
        private _context?;
        get context(): string;
        set context(value: string);
        resetContext(): void;
        get contextInput(): string | undefined;
        private _targetUrl?;
        get targetUrl(): string;
        set targetUrl(value: string);
        resetTargetUrl(): void;
        get targetUrlInput(): string | undefined;
    }
    interface SecondarySourcesGitSubmodulesConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#fetch_submodules AwsCodebuildProject#fetch_submodules}
        */
        readonly fetchSubmodules: boolean | cdktn.IResolvable;
    }
    class SecondarySourcesGitSubmodulesConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecondarySourcesGitSubmodulesConfigProperty | undefined;
        set internalValue(value: SecondarySourcesGitSubmodulesConfigProperty | undefined);
        private _fetchSubmodules?;
        get fetchSubmodules(): boolean | cdktn.IResolvable;
        set fetchSubmodules(value: boolean | cdktn.IResolvable);
        get fetchSubmodulesInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SecondarySourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#buildspec AwsCodebuildProject#buildspec}
        */
        readonly buildspec?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#git_clone_depth AwsCodebuildProject#git_clone_depth}
        */
        readonly gitCloneDepth?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#insecure_ssl AwsCodebuildProject#insecure_ssl}
        */
        readonly insecureSsl?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#location AwsCodebuildProject#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#report_build_status AwsCodebuildProject#report_build_status}
        */
        readonly reportBuildStatus?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#source_identifier AwsCodebuildProject#source_identifier}
        */
        readonly sourceIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsCodebuildProject#type}
        */
        readonly type: string;
        /**
        * auth block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#auth AwsCodebuildProject#auth}
        */
        readonly auth?: SecondarySourcesAuthProperty;
        /**
        * build_status_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#build_status_config AwsCodebuildProject#build_status_config}
        */
        readonly buildStatusConfig?: SecondarySourcesBuildStatusConfigProperty;
        /**
        * git_submodules_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#git_submodules_config AwsCodebuildProject#git_submodules_config}
        */
        readonly gitSubmodulesConfig?: SecondarySourcesGitSubmodulesConfigProperty;
    }
    class SecondarySourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecondarySourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecondarySourcesProperty | cdktn.IResolvable | undefined);
        private _buildspec?;
        get buildspec(): string;
        set buildspec(value: string);
        resetBuildspec(): void;
        get buildspecInput(): string | undefined;
        private _gitCloneDepth?;
        get gitCloneDepth(): number;
        set gitCloneDepth(value: number);
        resetGitCloneDepth(): void;
        get gitCloneDepthInput(): number | undefined;
        private _insecureSsl?;
        get insecureSsl(): boolean | cdktn.IResolvable;
        set insecureSsl(value: boolean | cdktn.IResolvable);
        resetInsecureSsl(): void;
        get insecureSslInput(): boolean | cdktn.IResolvable | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _reportBuildStatus?;
        get reportBuildStatus(): boolean | cdktn.IResolvable;
        set reportBuildStatus(value: boolean | cdktn.IResolvable);
        resetReportBuildStatus(): void;
        get reportBuildStatusInput(): boolean | cdktn.IResolvable | undefined;
        private _sourceIdentifier?;
        get sourceIdentifier(): string;
        set sourceIdentifier(value: string);
        get sourceIdentifierInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _auth;
        get auth(): SecondarySourcesAuthPropertyOutputReference;
        putAuth(value: SecondarySourcesAuthProperty): void;
        resetAuth(): void;
        get authInput(): SecondarySourcesAuthProperty | undefined;
        private _buildStatusConfig;
        get buildStatusConfig(): SecondarySourcesBuildStatusConfigPropertyOutputReference;
        putBuildStatusConfig(value: SecondarySourcesBuildStatusConfigProperty): void;
        resetBuildStatusConfig(): void;
        get buildStatusConfigInput(): SecondarySourcesBuildStatusConfigProperty | undefined;
        private _gitSubmodulesConfig;
        get gitSubmodulesConfig(): SecondarySourcesGitSubmodulesConfigPropertyOutputReference;
        putGitSubmodulesConfig(value: SecondarySourcesGitSubmodulesConfigProperty): void;
        resetGitSubmodulesConfig(): void;
        get gitSubmodulesConfigInput(): SecondarySourcesGitSubmodulesConfigProperty | undefined;
    }
    class SecondarySourcesPropertyList extends cdktn.ComplexList {
        internalValue?: SecondarySourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecondarySourcesPropertyOutputReference;
    }
    interface SourceAuthProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#resource AwsCodebuildProject#resource}
        */
        readonly resource: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsCodebuildProject#type}
        */
        readonly type: string;
    }
    class SourceAuthPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceAuthProperty | undefined;
        set internalValue(value: SourceAuthProperty | undefined);
        private _resource?;
        get resource(): string;
        set resource(value: string);
        get resourceInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface SourceBuildStatusConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#context AwsCodebuildProject#context}
        */
        readonly context?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#target_url AwsCodebuildProject#target_url}
        */
        readonly targetUrl?: string;
    }
    class SourceBuildStatusConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceBuildStatusConfigProperty | undefined;
        set internalValue(value: SourceBuildStatusConfigProperty | undefined);
        private _context?;
        get context(): string;
        set context(value: string);
        resetContext(): void;
        get contextInput(): string | undefined;
        private _targetUrl?;
        get targetUrl(): string;
        set targetUrl(value: string);
        resetTargetUrl(): void;
        get targetUrlInput(): string | undefined;
    }
    interface SourceGitSubmodulesConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#fetch_submodules AwsCodebuildProject#fetch_submodules}
        */
        readonly fetchSubmodules: boolean | cdktn.IResolvable;
    }
    class SourceGitSubmodulesConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceGitSubmodulesConfigProperty | undefined;
        set internalValue(value: SourceGitSubmodulesConfigProperty | undefined);
        private _fetchSubmodules?;
        get fetchSubmodules(): boolean | cdktn.IResolvable;
        set fetchSubmodules(value: boolean | cdktn.IResolvable);
        get fetchSubmodulesInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#buildspec AwsCodebuildProject#buildspec}
        */
        readonly buildspec?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#git_clone_depth AwsCodebuildProject#git_clone_depth}
        */
        readonly gitCloneDepth?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#insecure_ssl AwsCodebuildProject#insecure_ssl}
        */
        readonly insecureSsl?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#location AwsCodebuildProject#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#report_build_status AwsCodebuildProject#report_build_status}
        */
        readonly reportBuildStatus?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsCodebuildProject#type}
        */
        readonly type: string;
        /**
        * auth block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#auth AwsCodebuildProject#auth}
        */
        readonly auth?: SourceAuthProperty;
        /**
        * build_status_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#build_status_config AwsCodebuildProject#build_status_config}
        */
        readonly buildStatusConfig?: SourceBuildStatusConfigProperty;
        /**
        * git_submodules_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#git_submodules_config AwsCodebuildProject#git_submodules_config}
        */
        readonly gitSubmodulesConfig?: SourceGitSubmodulesConfigProperty;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceProperty | undefined;
        set internalValue(value: SourceProperty | undefined);
        private _buildspec?;
        get buildspec(): string;
        set buildspec(value: string);
        resetBuildspec(): void;
        get buildspecInput(): string | undefined;
        private _gitCloneDepth?;
        get gitCloneDepth(): number;
        set gitCloneDepth(value: number);
        resetGitCloneDepth(): void;
        get gitCloneDepthInput(): number | undefined;
        private _insecureSsl?;
        get insecureSsl(): boolean | cdktn.IResolvable;
        set insecureSsl(value: boolean | cdktn.IResolvable);
        resetInsecureSsl(): void;
        get insecureSslInput(): boolean | cdktn.IResolvable | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _reportBuildStatus?;
        get reportBuildStatus(): boolean | cdktn.IResolvable;
        set reportBuildStatus(value: boolean | cdktn.IResolvable);
        resetReportBuildStatus(): void;
        get reportBuildStatusInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _auth;
        get auth(): SourceAuthPropertyOutputReference;
        putAuth(value: SourceAuthProperty): void;
        resetAuth(): void;
        get authInput(): SourceAuthProperty | undefined;
        private _buildStatusConfig;
        get buildStatusConfig(): SourceBuildStatusConfigPropertyOutputReference;
        putBuildStatusConfig(value: SourceBuildStatusConfigProperty): void;
        resetBuildStatusConfig(): void;
        get buildStatusConfigInput(): SourceBuildStatusConfigProperty | undefined;
        private _gitSubmodulesConfig;
        get gitSubmodulesConfig(): SourceGitSubmodulesConfigPropertyOutputReference;
        putGitSubmodulesConfig(value: SourceGitSubmodulesConfigProperty): void;
        resetGitSubmodulesConfig(): void;
        get gitSubmodulesConfigInput(): SourceGitSubmodulesConfigProperty | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#security_group_ids AwsCodebuildProject#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#subnets AwsCodebuildProject#subnets}
        */
        readonly subnets: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#vpc_id AwsCodebuildProject#vpc_id}
        */
        readonly vpcId: string;
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        get vpcIdInput(): string | undefined;
    }
}
