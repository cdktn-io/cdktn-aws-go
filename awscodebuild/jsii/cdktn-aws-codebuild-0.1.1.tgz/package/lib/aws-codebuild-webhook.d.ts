import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCodebuildWebhookConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#branch_filter AwsCodebuildWebhook#branch_filter}
    */
    readonly branchFilter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#build_type AwsCodebuildWebhook#build_type}
    */
    readonly buildType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#id AwsCodebuildWebhook#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#manual_creation AwsCodebuildWebhook#manual_creation}
    */
    readonly manualCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#project_name AwsCodebuildWebhook#project_name}
    */
    readonly projectName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#region AwsCodebuildWebhook#region}
    */
    readonly region?: string;
    /**
    * filter_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#filter_group AwsCodebuildWebhook#filter_group}
    */
    readonly filterGroup?: AwsCodebuildWebhook.FilterGroupProperty[] | cdktn.IResolvable;
    /**
    * pull_request_build_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#pull_request_build_policy AwsCodebuildWebhook#pull_request_build_policy}
    */
    readonly pullRequestBuildPolicy?: AwsCodebuildWebhook.PullRequestBuildPolicyProperty;
    /**
    * scope_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#scope_configuration AwsCodebuildWebhook#scope_configuration}
    */
    readonly scopeConfiguration?: AwsCodebuildWebhook.ScopeConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook aws_codebuild_webhook}
*/
export declare class AwsCodebuildWebhook extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codebuild_webhook";
    /**
    * Generates CDKTN code for importing a AwsCodebuildWebhook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCodebuildWebhook to import
    * @param importFromId The id of the existing AwsCodebuildWebhook that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCodebuildWebhook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook aws_codebuild_webhook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCodebuildWebhookConfig
    */
    constructor(scope: Construct, id: string, config: AwsCodebuildWebhookConfig);
    private _branchFilter?;
    get branchFilter(): string;
    set branchFilter(value: string);
    resetBranchFilter(): void;
    get branchFilterInput(): string | undefined;
    private _buildType?;
    get buildType(): string;
    set buildType(value: string);
    resetBuildType(): void;
    get buildTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _manualCreation?;
    get manualCreation(): boolean | cdktn.IResolvable;
    set manualCreation(value: boolean | cdktn.IResolvable);
    resetManualCreation(): void;
    get manualCreationInput(): boolean | cdktn.IResolvable | undefined;
    get payloadUrl(): string;
    private _projectName?;
    get projectName(): string;
    set projectName(value: string);
    get projectNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get secret(): string;
    get url(): string;
    private _filterGroup;
    get filterGroup(): AwsCodebuildWebhook.FilterGroupPropertyList;
    putFilterGroup(value: AwsCodebuildWebhook.FilterGroupProperty[] | cdktn.IResolvable): void;
    resetFilterGroup(): void;
    get filterGroupInput(): cdktn.IResolvable | AwsCodebuildWebhook.FilterGroupProperty[] | undefined;
    private _pullRequestBuildPolicy;
    get pullRequestBuildPolicy(): AwsCodebuildWebhook.PullRequestBuildPolicyPropertyOutputReference;
    putPullRequestBuildPolicy(value: AwsCodebuildWebhook.PullRequestBuildPolicyProperty): void;
    resetPullRequestBuildPolicy(): void;
    get pullRequestBuildPolicyInput(): AwsCodebuildWebhook.PullRequestBuildPolicyProperty | undefined;
    private _scopeConfiguration;
    get scopeConfiguration(): AwsCodebuildWebhook.ScopeConfigurationPropertyOutputReference;
    putScopeConfiguration(value: AwsCodebuildWebhook.ScopeConfigurationProperty): void;
    resetScopeConfiguration(): void;
    get scopeConfigurationInput(): AwsCodebuildWebhook.ScopeConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCodebuildWebhookFilterPropertyToTerraform(struct?: AwsCodebuildWebhook.FilterProperty | cdktn.IResolvable): any;
export declare function awsCodebuildWebhookFilterPropertyToHclTerraform(struct?: AwsCodebuildWebhook.FilterProperty | cdktn.IResolvable): any;
export declare function awsCodebuildWebhookFilterGroupPropertyToTerraform(struct?: AwsCodebuildWebhook.FilterGroupProperty | cdktn.IResolvable): any;
export declare function awsCodebuildWebhookFilterGroupPropertyToHclTerraform(struct?: AwsCodebuildWebhook.FilterGroupProperty | cdktn.IResolvable): any;
export declare function awsCodebuildWebhookPullRequestBuildPolicyPropertyToTerraform(struct?: AwsCodebuildWebhook.PullRequestBuildPolicyPropertyOutputReference | AwsCodebuildWebhook.PullRequestBuildPolicyProperty): any;
export declare function awsCodebuildWebhookPullRequestBuildPolicyPropertyToHclTerraform(struct?: AwsCodebuildWebhook.PullRequestBuildPolicyPropertyOutputReference | AwsCodebuildWebhook.PullRequestBuildPolicyProperty): any;
export declare function awsCodebuildWebhookScopeConfigurationPropertyToTerraform(struct?: AwsCodebuildWebhook.ScopeConfigurationPropertyOutputReference | AwsCodebuildWebhook.ScopeConfigurationProperty): any;
export declare function awsCodebuildWebhookScopeConfigurationPropertyToHclTerraform(struct?: AwsCodebuildWebhook.ScopeConfigurationPropertyOutputReference | AwsCodebuildWebhook.ScopeConfigurationProperty): any;
export declare namespace AwsCodebuildWebhook {
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#exclude_matched_pattern AwsCodebuildWebhook#exclude_matched_pattern}
        */
        readonly excludeMatchedPattern?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#pattern AwsCodebuildWebhook#pattern}
        */
        readonly pattern: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#type AwsCodebuildWebhook#type}
        */
        readonly type: string;
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _excludeMatchedPattern?;
        get excludeMatchedPattern(): boolean | cdktn.IResolvable;
        set excludeMatchedPattern(value: boolean | cdktn.IResolvable);
        resetExcludeMatchedPattern(): void;
        get excludeMatchedPatternInput(): boolean | cdktn.IResolvable | undefined;
        private _pattern?;
        get pattern(): string;
        set pattern(value: string);
        get patternInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface FilterGroupProperty {
        /**
        * filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#filter AwsCodebuildWebhook#filter}
        */
        readonly filter?: FilterProperty[] | cdktn.IResolvable;
    }
    class FilterGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterGroupProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterGroupProperty | cdktn.IResolvable | undefined);
        private _filter;
        get filter(): FilterPropertyList;
        putFilter(value: FilterProperty[] | cdktn.IResolvable): void;
        resetFilter(): void;
        get filterInput(): cdktn.IResolvable | FilterProperty[] | undefined;
    }
    class FilterGroupPropertyList extends cdktn.ComplexList {
        internalValue?: FilterGroupProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterGroupPropertyOutputReference;
    }
    interface PullRequestBuildPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#approver_roles AwsCodebuildWebhook#approver_roles}
        */
        readonly approverRoles?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#requires_comment_approval AwsCodebuildWebhook#requires_comment_approval}
        */
        readonly requiresCommentApproval: string;
    }
    class PullRequestBuildPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PullRequestBuildPolicyProperty | undefined;
        set internalValue(value: PullRequestBuildPolicyProperty | undefined);
        private _approverRoles?;
        get approverRoles(): string[];
        set approverRoles(value: string[]);
        resetApproverRoles(): void;
        get approverRolesInput(): string[] | undefined;
        private _requiresCommentApproval?;
        get requiresCommentApproval(): string;
        set requiresCommentApproval(value: string);
        get requiresCommentApprovalInput(): string | undefined;
    }
    interface ScopeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#domain AwsCodebuildWebhook#domain}
        */
        readonly domain?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#name AwsCodebuildWebhook#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_webhook#scope AwsCodebuildWebhook#scope}
        */
        readonly scope: string;
    }
    class ScopeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScopeConfigurationProperty | undefined;
        set internalValue(value: ScopeConfigurationProperty | undefined);
        private _domain?;
        get domain(): string;
        set domain(value: string);
        resetDomain(): void;
        get domainInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        get scopeInput(): string | undefined;
    }
}
