import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDevEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#alias AwsDevEnvironment#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#id AwsDevEnvironment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#inactivity_timeout_minutes AwsDevEnvironment#inactivity_timeout_minutes}
    */
    readonly inactivityTimeoutMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#instance_type AwsDevEnvironment#instance_type}
    */
    readonly instanceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#project_name AwsDevEnvironment#project_name}
    */
    readonly projectName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#region AwsDevEnvironment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#space_name AwsDevEnvironment#space_name}
    */
    readonly spaceName: string;
    /**
    * ides block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#ides AwsDevEnvironment#ides}
    */
    readonly ides: AwsDevEnvironment.IdesProperty;
    /**
    * persistent_storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#persistent_storage AwsDevEnvironment#persistent_storage}
    */
    readonly persistentStorage: AwsDevEnvironment.PersistentStorageProperty;
    /**
    * repositories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#repositories AwsDevEnvironment#repositories}
    */
    readonly repositories?: AwsDevEnvironment.RepositoriesProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#timeouts AwsDevEnvironment#timeouts}
    */
    readonly timeouts?: AwsDevEnvironment.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment aws_codecatalyst_dev_environment}
*/
export declare class AwsDevEnvironment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codecatalyst_dev_environment";
    /**
    * Generates CDKTN code for importing a AwsDevEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDevEnvironment to import
    * @param importFromId The id of the existing AwsDevEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDevEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment aws_codecatalyst_dev_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDevEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsDevEnvironmentConfig);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inactivityTimeoutMinutes?;
    get inactivityTimeoutMinutes(): number;
    set inactivityTimeoutMinutes(value: number);
    resetInactivityTimeoutMinutes(): void;
    get inactivityTimeoutMinutesInput(): number | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    get instanceTypeInput(): string | undefined;
    private _projectName?;
    get projectName(): string;
    set projectName(value: string);
    get projectNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _spaceName?;
    get spaceName(): string;
    set spaceName(value: string);
    get spaceNameInput(): string | undefined;
    private _ides;
    get ides(): AwsDevEnvironment.IdesPropertyOutputReference;
    putIdes(value: AwsDevEnvironment.IdesProperty): void;
    get idesInput(): AwsDevEnvironment.IdesProperty | undefined;
    private _persistentStorage;
    get persistentStorage(): AwsDevEnvironment.PersistentStoragePropertyOutputReference;
    putPersistentStorage(value: AwsDevEnvironment.PersistentStorageProperty): void;
    get persistentStorageInput(): AwsDevEnvironment.PersistentStorageProperty | undefined;
    private _repositories;
    get repositories(): AwsDevEnvironment.RepositoriesPropertyList;
    putRepositories(value: AwsDevEnvironment.RepositoriesProperty[] | cdktn.IResolvable): void;
    resetRepositories(): void;
    get repositoriesInput(): cdktn.IResolvable | AwsDevEnvironment.RepositoriesProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsDevEnvironment.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDevEnvironment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDevEnvironment.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDevEnvironmentIdesPropertyToTerraform(struct?: AwsDevEnvironment.IdesPropertyOutputReference | AwsDevEnvironment.IdesProperty): any;
export declare function awsDevEnvironmentIdesPropertyToHclTerraform(struct?: AwsDevEnvironment.IdesPropertyOutputReference | AwsDevEnvironment.IdesProperty): any;
export declare function awsDevEnvironmentPersistentStoragePropertyToTerraform(struct?: AwsDevEnvironment.PersistentStoragePropertyOutputReference | AwsDevEnvironment.PersistentStorageProperty): any;
export declare function awsDevEnvironmentPersistentStoragePropertyToHclTerraform(struct?: AwsDevEnvironment.PersistentStoragePropertyOutputReference | AwsDevEnvironment.PersistentStorageProperty): any;
export declare function awsDevEnvironmentRepositoriesPropertyToTerraform(struct?: AwsDevEnvironment.RepositoriesProperty | cdktn.IResolvable): any;
export declare function awsDevEnvironmentRepositoriesPropertyToHclTerraform(struct?: AwsDevEnvironment.RepositoriesProperty | cdktn.IResolvable): any;
export declare function awsDevEnvironmentTimeoutsPropertyToTerraform(struct?: AwsDevEnvironment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDevEnvironmentTimeoutsPropertyToHclTerraform(struct?: AwsDevEnvironment.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDevEnvironment {
    interface IdesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#name AwsDevEnvironment#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#runtime AwsDevEnvironment#runtime}
        */
        readonly runtime?: string;
    }
    class IdesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IdesProperty | undefined;
        set internalValue(value: IdesProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _runtime?;
        get runtime(): string;
        set runtime(value: string);
        resetRuntime(): void;
        get runtimeInput(): string | undefined;
    }
    interface PersistentStorageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#size AwsDevEnvironment#size}
        */
        readonly size: number;
    }
    class PersistentStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PersistentStorageProperty | undefined;
        set internalValue(value: PersistentStorageProperty | undefined);
        private _size?;
        get size(): number;
        set size(value: number);
        get sizeInput(): number | undefined;
    }
    interface RepositoriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#branch_name AwsDevEnvironment#branch_name}
        */
        readonly branchName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#repository_name AwsDevEnvironment#repository_name}
        */
        readonly repositoryName: string;
    }
    class RepositoriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RepositoriesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RepositoriesProperty | cdktn.IResolvable | undefined);
        private _branchName?;
        get branchName(): string;
        set branchName(value: string);
        resetBranchName(): void;
        get branchNameInput(): string | undefined;
        private _repositoryName?;
        get repositoryName(): string;
        set repositoryName(value: string);
        get repositoryNameInput(): string | undefined;
    }
    class RepositoriesPropertyList extends cdktn.ComplexList {
        internalValue?: RepositoriesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RepositoriesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#create AwsDevEnvironment#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#delete AwsDevEnvironment#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecatalyst_dev_environment#update AwsDevEnvironment#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
