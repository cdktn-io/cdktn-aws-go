import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCollectionGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the collection group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_collection_group#id DataAwsCollectionGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the collection group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_collection_group#name DataAwsCollectionGroup#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_collection_group#region DataAwsCollectionGroup#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_collection_group aws_opensearchserverless_collection_group}
*/
export declare class DataAwsCollectionGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_opensearchserverless_collection_group";
    /**
    * Generates CDKTN code for importing a DataAwsCollectionGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCollectionGroup to import
    * @param importFromId The id of the existing DataAwsCollectionGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_collection_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCollectionGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_collection_group aws_opensearchserverless_collection_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCollectionGroupConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsCollectionGroupConfig);
    get arn(): string;
    private _capacityLimits;
    get capacityLimits(): DataAwsCollectionGroup.CapacityLimitsPropertyList;
    get createdDate(): string;
    get description(): string;
    get generation(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get standbyReplicas(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsCollectionGroupCapacityLimitsPropertyToTerraform(struct?: DataAwsCollectionGroup.CapacityLimitsProperty): any;
export declare function dataAwsCollectionGroupCapacityLimitsPropertyToHclTerraform(struct?: DataAwsCollectionGroup.CapacityLimitsProperty): any;
export declare namespace DataAwsCollectionGroup {
    interface CapacityLimitsProperty {
    }
    class CapacityLimitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityLimitsProperty | undefined;
        set internalValue(value: CapacityLimitsProperty | undefined);
        get maxIndexingCapacityInOcu(): number;
        get maxSearchCapacityInOcu(): number;
        get minIndexingCapacityInOcu(): number;
        get minSearchCapacityInOcu(): number;
    }
    class CapacityLimitsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityLimitsPropertyOutputReference;
    }
}
