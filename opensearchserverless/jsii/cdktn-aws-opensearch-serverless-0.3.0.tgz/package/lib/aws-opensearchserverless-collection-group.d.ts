import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCollectionGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection_group#capacity_limits AwsCollectionGroup#capacity_limits}
    */
    readonly capacityLimits?: AwsCollectionGroup.CapacityLimitsProperty[] | cdktn.IResolvable;
    /**
    * Description of the collection group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection_group#description AwsCollectionGroup#description}
    */
    readonly description?: string;
    /**
    * Generation of the collection group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection_group#generation AwsCollectionGroup#generation}
    */
    readonly generation?: string;
    /**
    * Name of the collection group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection_group#name AwsCollectionGroup#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection_group#region AwsCollectionGroup#region}
    */
    readonly region?: string;
    /**
    * Indicates whether standby replicas should be used for collections in this group. One of `ENABLED` or `DISABLED`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection_group#standby_replicas AwsCollectionGroup#standby_replicas}
    */
    readonly standbyReplicas: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection_group#tags AwsCollectionGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection_group aws_opensearchserverless_collection_group}
*/
export declare class AwsCollectionGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_opensearchserverless_collection_group";
    /**
    * Generates CDKTN code for importing a AwsCollectionGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCollectionGroup to import
    * @param importFromId The id of the existing AwsCollectionGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCollectionGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection_group aws_opensearchserverless_collection_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCollectionGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsCollectionGroupConfig);
    get arn(): string;
    private _capacityLimits;
    get capacityLimits(): AwsCollectionGroup.CapacityLimitsPropertyList;
    putCapacityLimits(value: AwsCollectionGroup.CapacityLimitsProperty[] | cdktn.IResolvable): void;
    resetCapacityLimits(): void;
    get capacityLimitsInput(): cdktn.IResolvable | AwsCollectionGroup.CapacityLimitsProperty[] | undefined;
    get createdDate(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _generation?;
    get generation(): string;
    set generation(value: string);
    resetGeneration(): void;
    get generationInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _standbyReplicas?;
    get standbyReplicas(): string;
    set standbyReplicas(value: string);
    get standbyReplicasInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCollectionGroupCapacityLimitsPropertyToTerraform(struct?: AwsCollectionGroup.CapacityLimitsProperty | cdktn.IResolvable): any;
export declare function awsCollectionGroupCapacityLimitsPropertyToHclTerraform(struct?: AwsCollectionGroup.CapacityLimitsProperty | cdktn.IResolvable): any;
export declare namespace AwsCollectionGroup {
    interface CapacityLimitsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection_group#max_indexing_capacity_in_ocu AwsCollectionGroup#max_indexing_capacity_in_ocu}
        */
        readonly maxIndexingCapacityInOcu?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection_group#max_search_capacity_in_ocu AwsCollectionGroup#max_search_capacity_in_ocu}
        */
        readonly maxSearchCapacityInOcu?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection_group#min_indexing_capacity_in_ocu AwsCollectionGroup#min_indexing_capacity_in_ocu}
        */
        readonly minIndexingCapacityInOcu?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_collection_group#min_search_capacity_in_ocu AwsCollectionGroup#min_search_capacity_in_ocu}
        */
        readonly minSearchCapacityInOcu?: number;
    }
    class CapacityLimitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityLimitsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CapacityLimitsProperty | cdktn.IResolvable | undefined);
        private _maxIndexingCapacityInOcu?;
        get maxIndexingCapacityInOcu(): number;
        set maxIndexingCapacityInOcu(value: number);
        resetMaxIndexingCapacityInOcu(): void;
        get maxIndexingCapacityInOcuInput(): number | undefined;
        private _maxSearchCapacityInOcu?;
        get maxSearchCapacityInOcu(): number;
        set maxSearchCapacityInOcu(value: number);
        resetMaxSearchCapacityInOcu(): void;
        get maxSearchCapacityInOcuInput(): number | undefined;
        private _minIndexingCapacityInOcu?;
        get minIndexingCapacityInOcu(): number;
        set minIndexingCapacityInOcu(value: number);
        resetMinIndexingCapacityInOcu(): void;
        get minIndexingCapacityInOcuInput(): number | undefined;
        private _minSearchCapacityInOcu?;
        get minSearchCapacityInOcu(): number;
        set minSearchCapacityInOcu(value: number);
        resetMinSearchCapacityInOcu(): void;
        get minSearchCapacityInOcuInput(): number | undefined;
    }
    class CapacityLimitsPropertyList extends cdktn.ComplexList {
        internalValue?: CapacityLimitsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityLimitsPropertyOutputReference;
    }
}
