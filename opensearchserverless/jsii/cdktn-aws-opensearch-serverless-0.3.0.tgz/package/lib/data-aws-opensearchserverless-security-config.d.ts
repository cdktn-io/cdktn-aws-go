import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsSecurityConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique identifier of the security configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_security_config#id DataAwsSecurityConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_security_config#region DataAwsSecurityConfig#region}
    */
    readonly region?: string;
    /**
    * iam_federation_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_security_config#iam_federation_options DataAwsSecurityConfig#iam_federation_options}
    */
    readonly iamFederationOptions?: DataAwsSecurityConfig.IamFederationOptionsProperty[] | cdktn.IResolvable;
    /**
    * iam_identity_center_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_security_config#iam_identity_center_options DataAwsSecurityConfig#iam_identity_center_options}
    */
    readonly iamIdentityCenterOptions?: DataAwsSecurityConfig.IamIdentityCenterOptionsProperty[] | cdktn.IResolvable;
    /**
    * saml_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_security_config#saml_options DataAwsSecurityConfig#saml_options}
    */
    readonly samlOptions?: DataAwsSecurityConfig.SamlOptionsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_security_config aws_opensearchserverless_security_config}
*/
export declare class DataAwsSecurityConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_opensearchserverless_security_config";
    /**
    * Generates CDKTN code for importing a DataAwsSecurityConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsSecurityConfig to import
    * @param importFromId The id of the existing DataAwsSecurityConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_security_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsSecurityConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearchserverless_security_config aws_opensearchserverless_security_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsSecurityConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsSecurityConfigConfig);
    get configVersion(): string;
    get createdDate(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get lastModifiedDate(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get type(): string;
    private _iamFederationOptions;
    get iamFederationOptions(): DataAwsSecurityConfig.IamFederationOptionsPropertyList;
    putIamFederationOptions(value: DataAwsSecurityConfig.IamFederationOptionsProperty[] | cdktn.IResolvable): void;
    resetIamFederationOptions(): void;
    get iamFederationOptionsInput(): cdktn.IResolvable | DataAwsSecurityConfig.IamFederationOptionsProperty[] | undefined;
    private _iamIdentityCenterOptions;
    get iamIdentityCenterOptions(): DataAwsSecurityConfig.IamIdentityCenterOptionsPropertyList;
    putIamIdentityCenterOptions(value: DataAwsSecurityConfig.IamIdentityCenterOptionsProperty[] | cdktn.IResolvable): void;
    resetIamIdentityCenterOptions(): void;
    get iamIdentityCenterOptionsInput(): cdktn.IResolvable | DataAwsSecurityConfig.IamIdentityCenterOptionsProperty[] | undefined;
    private _samlOptions;
    get samlOptions(): DataAwsSecurityConfig.SamlOptionsPropertyList;
    putSamlOptions(value: DataAwsSecurityConfig.SamlOptionsProperty[] | cdktn.IResolvable): void;
    resetSamlOptions(): void;
    get samlOptionsInput(): cdktn.IResolvable | DataAwsSecurityConfig.SamlOptionsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsSecurityConfigIamFederationOptionsPropertyToTerraform(struct?: DataAwsSecurityConfig.IamFederationOptionsProperty | cdktn.IResolvable): any;
export declare function dataAwsSecurityConfigIamFederationOptionsPropertyToHclTerraform(struct?: DataAwsSecurityConfig.IamFederationOptionsProperty | cdktn.IResolvable): any;
export declare function dataAwsSecurityConfigIamIdentityCenterOptionsPropertyToTerraform(struct?: DataAwsSecurityConfig.IamIdentityCenterOptionsProperty | cdktn.IResolvable): any;
export declare function dataAwsSecurityConfigIamIdentityCenterOptionsPropertyToHclTerraform(struct?: DataAwsSecurityConfig.IamIdentityCenterOptionsProperty | cdktn.IResolvable): any;
export declare function dataAwsSecurityConfigSamlOptionsPropertyToTerraform(struct?: DataAwsSecurityConfig.SamlOptionsProperty | cdktn.IResolvable): any;
export declare function dataAwsSecurityConfigSamlOptionsPropertyToHclTerraform(struct?: DataAwsSecurityConfig.SamlOptionsProperty | cdktn.IResolvable): any;
export declare namespace DataAwsSecurityConfig {
    interface IamFederationOptionsProperty {
    }
    class IamFederationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IamFederationOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IamFederationOptionsProperty | cdktn.IResolvable | undefined);
        get groupAttribute(): string;
        get userAttribute(): string;
    }
    class IamFederationOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: IamFederationOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IamFederationOptionsPropertyOutputReference;
    }
    interface IamIdentityCenterOptionsProperty {
    }
    class IamIdentityCenterOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IamIdentityCenterOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IamIdentityCenterOptionsProperty | cdktn.IResolvable | undefined);
        get groupAttribute(): string;
        get instanceArn(): string;
        get userAttribute(): string;
    }
    class IamIdentityCenterOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: IamIdentityCenterOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IamIdentityCenterOptionsPropertyOutputReference;
    }
    interface SamlOptionsProperty {
    }
    class SamlOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SamlOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SamlOptionsProperty | cdktn.IResolvable | undefined);
        get groupAttribute(): string;
        get metadata(): string;
        get sessionTimeout(): number;
        get userAttribute(): string;
    }
    class SamlOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: SamlOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SamlOptionsPropertyOutputReference;
    }
}
