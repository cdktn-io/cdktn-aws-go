import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSecurityConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the security configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#description AwsSecurityConfig#description}
    */
    readonly description?: string;
    /**
    * Name of the policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#name AwsSecurityConfig#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#region AwsSecurityConfig#region}
    */
    readonly region?: string;
    /**
    * Type of configuration. Valid values: `saml`, `iamidentitycenter` or `iamfederation`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#type AwsSecurityConfig#type}
    */
    readonly type: string;
    /**
    * iam_federation_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#iam_federation_options AwsSecurityConfig#iam_federation_options}
    */
    readonly iamFederationOptions?: AwsSecurityConfig.IamFederationOptionsProperty[] | cdktn.IResolvable;
    /**
    * iam_identity_center_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#iam_identity_center_options AwsSecurityConfig#iam_identity_center_options}
    */
    readonly iamIdentityCenterOptions?: AwsSecurityConfig.IamIdentityCenterOptionsProperty[] | cdktn.IResolvable;
    /**
    * saml_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#saml_options AwsSecurityConfig#saml_options}
    */
    readonly samlOptions?: AwsSecurityConfig.SamlOptionsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config aws_opensearchserverless_security_config}
*/
export declare class AwsSecurityConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_opensearchserverless_security_config";
    /**
    * Generates CDKTN code for importing a AwsSecurityConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSecurityConfig to import
    * @param importFromId The id of the existing AwsSecurityConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSecurityConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config aws_opensearchserverless_security_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSecurityConfigConfig
    */
    constructor(scope: Construct, id: string, config: AwsSecurityConfigConfig);
    get configVersion(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _iamFederationOptions;
    get iamFederationOptions(): AwsSecurityConfig.IamFederationOptionsPropertyList;
    putIamFederationOptions(value: AwsSecurityConfig.IamFederationOptionsProperty[] | cdktn.IResolvable): void;
    resetIamFederationOptions(): void;
    get iamFederationOptionsInput(): cdktn.IResolvable | AwsSecurityConfig.IamFederationOptionsProperty[] | undefined;
    private _iamIdentityCenterOptions;
    get iamIdentityCenterOptions(): AwsSecurityConfig.IamIdentityCenterOptionsPropertyList;
    putIamIdentityCenterOptions(value: AwsSecurityConfig.IamIdentityCenterOptionsProperty[] | cdktn.IResolvable): void;
    resetIamIdentityCenterOptions(): void;
    get iamIdentityCenterOptionsInput(): cdktn.IResolvable | AwsSecurityConfig.IamIdentityCenterOptionsProperty[] | undefined;
    private _samlOptions;
    get samlOptions(): AwsSecurityConfig.SamlOptionsPropertyList;
    putSamlOptions(value: AwsSecurityConfig.SamlOptionsProperty[] | cdktn.IResolvable): void;
    resetSamlOptions(): void;
    get samlOptionsInput(): cdktn.IResolvable | AwsSecurityConfig.SamlOptionsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSecurityConfigIamFederationOptionsPropertyToTerraform(struct?: AwsSecurityConfig.IamFederationOptionsProperty | cdktn.IResolvable): any;
export declare function awsSecurityConfigIamFederationOptionsPropertyToHclTerraform(struct?: AwsSecurityConfig.IamFederationOptionsProperty | cdktn.IResolvable): any;
export declare function awsSecurityConfigIamIdentityCenterOptionsPropertyToTerraform(struct?: AwsSecurityConfig.IamIdentityCenterOptionsProperty | cdktn.IResolvable): any;
export declare function awsSecurityConfigIamIdentityCenterOptionsPropertyToHclTerraform(struct?: AwsSecurityConfig.IamIdentityCenterOptionsProperty | cdktn.IResolvable): any;
export declare function awsSecurityConfigSamlOptionsPropertyToTerraform(struct?: AwsSecurityConfig.SamlOptionsProperty | cdktn.IResolvable): any;
export declare function awsSecurityConfigSamlOptionsPropertyToHclTerraform(struct?: AwsSecurityConfig.SamlOptionsProperty | cdktn.IResolvable): any;
export declare namespace AwsSecurityConfig {
    interface IamFederationOptionsProperty {
        /**
        * Group attribute.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#group_attribute AwsSecurityConfig#group_attribute}
        */
        readonly groupAttribute?: string;
        /**
        * User attribute.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#user_attribute AwsSecurityConfig#user_attribute}
        */
        readonly userAttribute?: string;
    }
    class IamFederationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IamFederationOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IamFederationOptionsProperty | cdktn.IResolvable | undefined);
        private _groupAttribute?;
        get groupAttribute(): string;
        set groupAttribute(value: string);
        resetGroupAttribute(): void;
        get groupAttributeInput(): string | undefined;
        private _userAttribute?;
        get userAttribute(): string;
        set userAttribute(value: string);
        resetUserAttribute(): void;
        get userAttributeInput(): string | undefined;
    }
    class IamFederationOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: IamFederationOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IamFederationOptionsPropertyOutputReference;
    }
    interface IamIdentityCenterOptionsProperty {
        /**
        * Group attribute.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#group_attribute AwsSecurityConfig#group_attribute}
        */
        readonly groupAttribute?: string;
        /**
        * Instance ARN.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#instance_arn AwsSecurityConfig#instance_arn}
        */
        readonly instanceArn: string;
        /**
        * User attribute.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#user_attribute AwsSecurityConfig#user_attribute}
        */
        readonly userAttribute?: string;
    }
    class IamIdentityCenterOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IamIdentityCenterOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IamIdentityCenterOptionsProperty | cdktn.IResolvable | undefined);
        private _groupAttribute?;
        get groupAttribute(): string;
        set groupAttribute(value: string);
        resetGroupAttribute(): void;
        get groupAttributeInput(): string | undefined;
        private _instanceArn?;
        get instanceArn(): string;
        set instanceArn(value: string);
        get instanceArnInput(): string | undefined;
        private _userAttribute?;
        get userAttribute(): string;
        set userAttribute(value: string);
        resetUserAttribute(): void;
        get userAttributeInput(): string | undefined;
    }
    class IamIdentityCenterOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: IamIdentityCenterOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IamIdentityCenterOptionsPropertyOutputReference;
    }
    interface SamlOptionsProperty {
        /**
        * Group attribute for this SAML integration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#group_attribute AwsSecurityConfig#group_attribute}
        */
        readonly groupAttribute?: string;
        /**
        * The XML IdP metadata file generated from your identity provider.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#metadata AwsSecurityConfig#metadata}
        */
        readonly metadata: string;
        /**
        * Session timeout, in minutes. Minimum is 5 minutes and maximum is 720 minutes (12 hours). Default is 60 minutes.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#session_timeout AwsSecurityConfig#session_timeout}
        */
        readonly sessionTimeout?: number;
        /**
        * User attribute for this SAML integration.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearchserverless_security_config#user_attribute AwsSecurityConfig#user_attribute}
        */
        readonly userAttribute?: string;
    }
    class SamlOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SamlOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SamlOptionsProperty | cdktn.IResolvable | undefined);
        private _groupAttribute?;
        get groupAttribute(): string;
        set groupAttribute(value: string);
        resetGroupAttribute(): void;
        get groupAttributeInput(): string | undefined;
        private _metadata?;
        get metadata(): string;
        set metadata(value: string);
        get metadataInput(): string | undefined;
        private _sessionTimeout?;
        get sessionTimeout(): number;
        set sessionTimeout(value: number);
        resetSessionTimeout(): void;
        get sessionTimeoutInput(): number | undefined;
        private _userAttribute?;
        get userAttribute(): string;
        set userAttribute(value: string);
        resetUserAttribute(): void;
        get userAttributeInput(): string | undefined;
    }
    class SamlOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: SamlOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SamlOptionsPropertyOutputReference;
    }
}
