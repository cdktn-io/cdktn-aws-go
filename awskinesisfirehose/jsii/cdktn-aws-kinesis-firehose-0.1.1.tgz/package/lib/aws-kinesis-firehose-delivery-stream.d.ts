import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsKinesisFirehoseDeliveryStreamConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#arn AwsKinesisFirehoseDeliveryStream#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#destination AwsKinesisFirehoseDeliveryStream#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#destination_id AwsKinesisFirehoseDeliveryStream#destination_id}
    */
    readonly destinationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#id AwsKinesisFirehoseDeliveryStream#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#name AwsKinesisFirehoseDeliveryStream#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#region AwsKinesisFirehoseDeliveryStream#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#tags AwsKinesisFirehoseDeliveryStream#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#tags_all AwsKinesisFirehoseDeliveryStream#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#version_id AwsKinesisFirehoseDeliveryStream#version_id}
    */
    readonly versionId?: string;
    /**
    * elasticsearch_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#elasticsearch_configuration AwsKinesisFirehoseDeliveryStream#elasticsearch_configuration}
    */
    readonly elasticsearchConfiguration?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationProperty;
    /**
    * extended_s3_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#extended_s3_configuration AwsKinesisFirehoseDeliveryStream#extended_s3_configuration}
    */
    readonly extendedS3Configuration?: AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationProperty;
    /**
    * http_endpoint_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#http_endpoint_configuration AwsKinesisFirehoseDeliveryStream#http_endpoint_configuration}
    */
    readonly httpEndpointConfiguration?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationProperty;
    /**
    * iceberg_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#iceberg_configuration AwsKinesisFirehoseDeliveryStream#iceberg_configuration}
    */
    readonly icebergConfiguration?: AwsKinesisFirehoseDeliveryStream.IcebergConfigurationProperty;
    /**
    * kinesis_source_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#kinesis_source_configuration AwsKinesisFirehoseDeliveryStream#kinesis_source_configuration}
    */
    readonly kinesisSourceConfiguration?: AwsKinesisFirehoseDeliveryStream.KinesisSourceConfigurationProperty;
    /**
    * msk_source_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#msk_source_configuration AwsKinesisFirehoseDeliveryStream#msk_source_configuration}
    */
    readonly mskSourceConfiguration?: AwsKinesisFirehoseDeliveryStream.MskSourceConfigurationProperty;
    /**
    * opensearch_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#opensearch_configuration AwsKinesisFirehoseDeliveryStream#opensearch_configuration}
    */
    readonly opensearchConfiguration?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationProperty;
    /**
    * opensearchserverless_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#opensearchserverless_configuration AwsKinesisFirehoseDeliveryStream#opensearchserverless_configuration}
    */
    readonly opensearchserverlessConfiguration?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationProperty;
    /**
    * redshift_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#redshift_configuration AwsKinesisFirehoseDeliveryStream#redshift_configuration}
    */
    readonly redshiftConfiguration?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationProperty;
    /**
    * server_side_encryption block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#server_side_encryption AwsKinesisFirehoseDeliveryStream#server_side_encryption}
    */
    readonly serverSideEncryption?: AwsKinesisFirehoseDeliveryStream.ServerSideEncryptionProperty;
    /**
    * snowflake_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#snowflake_configuration AwsKinesisFirehoseDeliveryStream#snowflake_configuration}
    */
    readonly snowflakeConfiguration?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationProperty;
    /**
    * splunk_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#splunk_configuration AwsKinesisFirehoseDeliveryStream#splunk_configuration}
    */
    readonly splunkConfiguration?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#timeouts AwsKinesisFirehoseDeliveryStream#timeouts}
    */
    readonly timeouts?: AwsKinesisFirehoseDeliveryStream.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream aws_kinesis_firehose_delivery_stream}
*/
export declare class AwsKinesisFirehoseDeliveryStream extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_kinesis_firehose_delivery_stream";
    /**
    * Generates CDKTN code for importing a AwsKinesisFirehoseDeliveryStream resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsKinesisFirehoseDeliveryStream to import
    * @param importFromId The id of the existing AwsKinesisFirehoseDeliveryStream that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsKinesisFirehoseDeliveryStream to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream aws_kinesis_firehose_delivery_stream} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsKinesisFirehoseDeliveryStreamConfig
    */
    constructor(scope: Construct, id: string, config: AwsKinesisFirehoseDeliveryStreamConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    resetDestinationId(): void;
    get destinationIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _versionId?;
    get versionId(): string;
    set versionId(value: string);
    resetVersionId(): void;
    get versionIdInput(): string | undefined;
    private _elasticsearchConfiguration;
    get elasticsearchConfiguration(): AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationPropertyOutputReference;
    putElasticsearchConfiguration(value: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationProperty): void;
    resetElasticsearchConfiguration(): void;
    get elasticsearchConfigurationInput(): AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationProperty | undefined;
    private _extendedS3Configuration;
    get extendedS3Configuration(): AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationPropertyOutputReference;
    putExtendedS3Configuration(value: AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationProperty): void;
    resetExtendedS3Configuration(): void;
    get extendedS3ConfigurationInput(): AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationProperty | undefined;
    private _httpEndpointConfiguration;
    get httpEndpointConfiguration(): AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationPropertyOutputReference;
    putHttpEndpointConfiguration(value: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationProperty): void;
    resetHttpEndpointConfiguration(): void;
    get httpEndpointConfigurationInput(): AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationProperty | undefined;
    private _icebergConfiguration;
    get icebergConfiguration(): AwsKinesisFirehoseDeliveryStream.IcebergConfigurationPropertyOutputReference;
    putIcebergConfiguration(value: AwsKinesisFirehoseDeliveryStream.IcebergConfigurationProperty): void;
    resetIcebergConfiguration(): void;
    get icebergConfigurationInput(): AwsKinesisFirehoseDeliveryStream.IcebergConfigurationProperty | undefined;
    private _kinesisSourceConfiguration;
    get kinesisSourceConfiguration(): AwsKinesisFirehoseDeliveryStream.KinesisSourceConfigurationPropertyOutputReference;
    putKinesisSourceConfiguration(value: AwsKinesisFirehoseDeliveryStream.KinesisSourceConfigurationProperty): void;
    resetKinesisSourceConfiguration(): void;
    get kinesisSourceConfigurationInput(): AwsKinesisFirehoseDeliveryStream.KinesisSourceConfigurationProperty | undefined;
    private _mskSourceConfiguration;
    get mskSourceConfiguration(): AwsKinesisFirehoseDeliveryStream.MskSourceConfigurationPropertyOutputReference;
    putMskSourceConfiguration(value: AwsKinesisFirehoseDeliveryStream.MskSourceConfigurationProperty): void;
    resetMskSourceConfiguration(): void;
    get mskSourceConfigurationInput(): AwsKinesisFirehoseDeliveryStream.MskSourceConfigurationProperty | undefined;
    private _opensearchConfiguration;
    get opensearchConfiguration(): AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationPropertyOutputReference;
    putOpensearchConfiguration(value: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationProperty): void;
    resetOpensearchConfiguration(): void;
    get opensearchConfigurationInput(): AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationProperty | undefined;
    private _opensearchserverlessConfiguration;
    get opensearchserverlessConfiguration(): AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationPropertyOutputReference;
    putOpensearchserverlessConfiguration(value: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationProperty): void;
    resetOpensearchserverlessConfiguration(): void;
    get opensearchserverlessConfigurationInput(): AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationProperty | undefined;
    private _redshiftConfiguration;
    get redshiftConfiguration(): AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationPropertyOutputReference;
    putRedshiftConfiguration(value: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationProperty): void;
    resetRedshiftConfiguration(): void;
    get redshiftConfigurationInput(): AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationProperty | undefined;
    private _serverSideEncryption;
    get serverSideEncryption(): AwsKinesisFirehoseDeliveryStream.ServerSideEncryptionPropertyOutputReference;
    putServerSideEncryption(value: AwsKinesisFirehoseDeliveryStream.ServerSideEncryptionProperty): void;
    resetServerSideEncryption(): void;
    get serverSideEncryptionInput(): AwsKinesisFirehoseDeliveryStream.ServerSideEncryptionProperty | undefined;
    private _snowflakeConfiguration;
    get snowflakeConfiguration(): AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationPropertyOutputReference;
    putSnowflakeConfiguration(value: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationProperty): void;
    resetSnowflakeConfiguration(): void;
    get snowflakeConfigurationInput(): AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationProperty | undefined;
    private _splunkConfiguration;
    get splunkConfiguration(): AwsKinesisFirehoseDeliveryStream.SplunkConfigurationPropertyOutputReference;
    putSplunkConfiguration(value: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationProperty): void;
    resetSplunkConfiguration(): void;
    get splunkConfigurationInput(): AwsKinesisFirehoseDeliveryStream.SplunkConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsKinesisFirehoseDeliveryStream.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsKinesisFirehoseDeliveryStream.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsKinesisFirehoseDeliveryStream.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsKinesisFirehoseDeliveryStreamElasticsearchConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamElasticsearchConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamElasticsearchConfigurationProcessingConfigurationProcessorsParametersPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamElasticsearchConfigurationProcessingConfigurationProcessorsParametersPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamElasticsearchConfigurationProcessingConfigurationProcessorsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamElasticsearchConfigurationProcessingConfigurationProcessorsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamElasticsearchConfigurationProcessingConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamElasticsearchConfigurationProcessingConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamElasticsearchConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamElasticsearchConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamElasticsearchConfigurationS3ConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamElasticsearchConfigurationS3ConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamElasticsearchConfigurationVpcConfigPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationVpcConfigPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationVpcConfigProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamElasticsearchConfigurationVpcConfigPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationVpcConfigPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationVpcConfigProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamElasticsearchConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamElasticsearchConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ElasticsearchConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamExtendedS3ConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamExtendedS3ConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamHiveJsonSerDePropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HiveJsonSerDePropertyOutputReference | AwsKinesisFirehoseDeliveryStream.HiveJsonSerDeProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamHiveJsonSerDePropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HiveJsonSerDePropertyOutputReference | AwsKinesisFirehoseDeliveryStream.HiveJsonSerDeProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpenXJsonSerDePropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpenXJsonSerDePropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpenXJsonSerDeProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpenXJsonSerDePropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpenXJsonSerDePropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpenXJsonSerDeProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamDeserializerPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.DeserializerPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.DeserializerProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamDeserializerPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.DeserializerPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.DeserializerProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamInputFormatConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.InputFormatConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.InputFormatConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamInputFormatConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.InputFormatConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.InputFormatConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOrcSerDePropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OrcSerDePropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OrcSerDeProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOrcSerDePropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OrcSerDePropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OrcSerDeProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamParquetSerDePropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ParquetSerDePropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ParquetSerDeProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamParquetSerDePropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ParquetSerDePropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ParquetSerDeProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSerializerPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SerializerPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SerializerProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSerializerPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SerializerPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SerializerProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOutputFormatConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OutputFormatConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OutputFormatConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOutputFormatConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OutputFormatConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OutputFormatConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSchemaConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SchemaConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SchemaConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSchemaConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SchemaConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SchemaConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamDataFormatConversionConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.DataFormatConversionConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.DataFormatConversionConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamDataFormatConversionConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.DataFormatConversionConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.DataFormatConversionConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamDynamicPartitioningConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.DynamicPartitioningConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.DynamicPartitioningConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamDynamicPartitioningConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.DynamicPartitioningConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.DynamicPartitioningConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamExtendedS3ConfigurationProcessingConfigurationProcessorsParametersPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamExtendedS3ConfigurationProcessingConfigurationProcessorsParametersPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamExtendedS3ConfigurationProcessingConfigurationProcessorsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamExtendedS3ConfigurationProcessingConfigurationProcessorsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamExtendedS3ConfigurationProcessingConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamExtendedS3ConfigurationProcessingConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamExtendedS3ConfigurationS3BackupConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationS3BackupConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationS3BackupConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamExtendedS3ConfigurationS3BackupConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationS3BackupConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationS3BackupConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamExtendedS3ConfigurationS3BackupConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationS3BackupConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationS3BackupConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamExtendedS3ConfigurationS3BackupConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationS3BackupConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationS3BackupConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamExtendedS3ConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamExtendedS3ConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ExtendedS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamHttpEndpointConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamHttpEndpointConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamHttpEndpointConfigurationProcessingConfigurationProcessorsParametersPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamHttpEndpointConfigurationProcessingConfigurationProcessorsParametersPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamHttpEndpointConfigurationProcessingConfigurationProcessorsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamHttpEndpointConfigurationProcessingConfigurationProcessorsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamHttpEndpointConfigurationProcessingConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamHttpEndpointConfigurationProcessingConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamCommonAttributesPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.CommonAttributesProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamCommonAttributesPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.CommonAttributesProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamRequestConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RequestConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RequestConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRequestConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RequestConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RequestConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamHttpEndpointConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamHttpEndpointConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamHttpEndpointConfigurationS3ConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamHttpEndpointConfigurationS3ConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamHttpEndpointConfigurationSecretsManagerConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationSecretsManagerConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationSecretsManagerConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamHttpEndpointConfigurationSecretsManagerConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationSecretsManagerConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationSecretsManagerConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamHttpEndpointConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamHttpEndpointConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.HttpEndpointConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamIcebergConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.IcebergConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.IcebergConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamIcebergConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.IcebergConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.IcebergConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamDestinationTableConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.DestinationTableConfigurationProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamDestinationTableConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.DestinationTableConfigurationProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamIcebergConfigurationProcessingConfigurationProcessorsParametersPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.IcebergConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamIcebergConfigurationProcessingConfigurationProcessorsParametersPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.IcebergConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamIcebergConfigurationProcessingConfigurationProcessorsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.IcebergConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamIcebergConfigurationProcessingConfigurationProcessorsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.IcebergConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamIcebergConfigurationProcessingConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.IcebergConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.IcebergConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamIcebergConfigurationProcessingConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.IcebergConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.IcebergConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamIcebergConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.IcebergConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.IcebergConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamIcebergConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.IcebergConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.IcebergConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamIcebergConfigurationS3ConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.IcebergConfigurationS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.IcebergConfigurationS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamIcebergConfigurationS3ConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.IcebergConfigurationS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.IcebergConfigurationS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamIcebergConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.IcebergConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.IcebergConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamIcebergConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.IcebergConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.IcebergConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamKinesisSourceConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.KinesisSourceConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.KinesisSourceConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamKinesisSourceConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.KinesisSourceConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.KinesisSourceConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamAuthenticationConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.AuthenticationConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.AuthenticationConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamAuthenticationConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.AuthenticationConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.AuthenticationConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamMskSourceConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.MskSourceConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.MskSourceConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamMskSourceConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.MskSourceConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.MskSourceConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamDocumentIdOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.DocumentIdOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.DocumentIdOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamDocumentIdOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.DocumentIdOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.DocumentIdOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchConfigurationProcessingConfigurationProcessorsParametersPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchConfigurationProcessingConfigurationProcessorsParametersPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchConfigurationProcessingConfigurationProcessorsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchConfigurationProcessingConfigurationProcessorsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchConfigurationProcessingConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchConfigurationProcessingConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchConfigurationS3ConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchConfigurationS3ConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchConfigurationVpcConfigPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationVpcConfigPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationVpcConfigProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchConfigurationVpcConfigPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationVpcConfigPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationVpcConfigProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchserverlessConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchserverlessConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchserverlessConfigurationProcessingConfigurationProcessorsParametersPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchserverlessConfigurationProcessingConfigurationProcessorsParametersPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchserverlessConfigurationProcessingConfigurationProcessorsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchserverlessConfigurationProcessingConfigurationProcessorsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchserverlessConfigurationProcessingConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchserverlessConfigurationProcessingConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchserverlessConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchserverlessConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchserverlessConfigurationS3ConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchserverlessConfigurationS3ConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchserverlessConfigurationVpcConfigPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationVpcConfigPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationVpcConfigProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchserverlessConfigurationVpcConfigPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationVpcConfigPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationVpcConfigProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchserverlessConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamOpensearchserverlessConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.OpensearchserverlessConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationProcessingConfigurationProcessorsParametersPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationProcessingConfigurationProcessorsParametersPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationProcessingConfigurationProcessorsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationProcessingConfigurationProcessorsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationProcessingConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationProcessingConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationS3BackupConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationS3BackupConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationS3BackupConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationS3BackupConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationS3BackupConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationS3BackupConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationS3BackupConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationS3BackupConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationS3BackupConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationS3BackupConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationS3BackupConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationS3BackupConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationS3ConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationS3ConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationSecretsManagerConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationSecretsManagerConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationSecretsManagerConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationSecretsManagerConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationSecretsManagerConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationSecretsManagerConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamRedshiftConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.RedshiftConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamServerSideEncryptionPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ServerSideEncryptionPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ServerSideEncryptionProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamServerSideEncryptionPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.ServerSideEncryptionPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.ServerSideEncryptionProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeConfigurationProcessingConfigurationProcessorsParametersPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeConfigurationProcessingConfigurationProcessorsParametersPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeConfigurationProcessingConfigurationProcessorsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeConfigurationProcessingConfigurationProcessorsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeConfigurationProcessingConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeConfigurationProcessingConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeConfigurationS3ConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeConfigurationS3ConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeConfigurationSecretsManagerConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationSecretsManagerConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationSecretsManagerConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeConfigurationSecretsManagerConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationSecretsManagerConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationSecretsManagerConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeRoleConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeRoleConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SnowflakeRoleConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeRoleConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeRoleConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SnowflakeRoleConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeVpcConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeVpcConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SnowflakeVpcConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeVpcConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeVpcConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SnowflakeVpcConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSnowflakeConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SnowflakeConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSplunkConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SplunkConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSplunkConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SplunkConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSplunkConfigurationProcessingConfigurationProcessorsParametersPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamSplunkConfigurationProcessingConfigurationProcessorsParametersPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamSplunkConfigurationProcessingConfigurationProcessorsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamSplunkConfigurationProcessingConfigurationProcessorsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamSplunkConfigurationProcessingConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SplunkConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSplunkConfigurationProcessingConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationProcessingConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SplunkConfigurationProcessingConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSplunkConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SplunkConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSplunkConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SplunkConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSplunkConfigurationS3ConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SplunkConfigurationS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSplunkConfigurationS3ConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationS3ConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SplunkConfigurationS3ConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSplunkConfigurationSecretsManagerConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationSecretsManagerConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SplunkConfigurationSecretsManagerConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSplunkConfigurationSecretsManagerConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationSecretsManagerConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SplunkConfigurationSecretsManagerConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSplunkConfigurationPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SplunkConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamSplunkConfigurationPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.SplunkConfigurationPropertyOutputReference | AwsKinesisFirehoseDeliveryStream.SplunkConfigurationProperty): any;
export declare function awsKinesisFirehoseDeliveryStreamTimeoutsPropertyToTerraform(struct?: AwsKinesisFirehoseDeliveryStream.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsKinesisFirehoseDeliveryStreamTimeoutsPropertyToHclTerraform(struct?: AwsKinesisFirehoseDeliveryStream.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsKinesisFirehoseDeliveryStream {
    interface ElasticsearchConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class ElasticsearchConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ElasticsearchConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: ElasticsearchConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface ElasticsearchConfigurationProcessingConfigurationProcessorsParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_name AwsKinesisFirehoseDeliveryStream#parameter_name}
        */
        readonly parameterName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_value AwsKinesisFirehoseDeliveryStream#parameter_value}
        */
        readonly parameterValue: string;
    }
    class ElasticsearchConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ElasticsearchConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ElasticsearchConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined);
        private _parameterName?;
        get parameterName(): string;
        set parameterName(value: string);
        get parameterNameInput(): string | undefined;
        private _parameterValue?;
        get parameterValue(): string;
        set parameterValue(value: string);
        get parameterValueInput(): string | undefined;
    }
    class ElasticsearchConfigurationProcessingConfigurationProcessorsParametersPropertyList extends cdktn.ComplexList {
        internalValue?: ElasticsearchConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ElasticsearchConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference;
    }
    interface ElasticsearchConfigurationProcessingConfigurationProcessorsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#type AwsKinesisFirehoseDeliveryStream#type}
        */
        readonly type: string;
        /**
        * parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameters AwsKinesisFirehoseDeliveryStream#parameters}
        */
        readonly parameters?: ElasticsearchConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
    }
    class ElasticsearchConfigurationProcessingConfigurationProcessorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ElasticsearchConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ElasticsearchConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _parameters;
        get parameters(): ElasticsearchConfigurationProcessingConfigurationProcessorsParametersPropertyList;
        putParameters(value: ElasticsearchConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable): void;
        resetParameters(): void;
        get parametersInput(): cdktn.IResolvable | ElasticsearchConfigurationProcessingConfigurationProcessorsParametersProperty[] | undefined;
    }
    class ElasticsearchConfigurationProcessingConfigurationProcessorsPropertyList extends cdktn.ComplexList {
        internalValue?: ElasticsearchConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ElasticsearchConfigurationProcessingConfigurationProcessorsPropertyOutputReference;
    }
    interface ElasticsearchConfigurationProcessingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * processors block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processors AwsKinesisFirehoseDeliveryStream#processors}
        */
        readonly processors?: ElasticsearchConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
    }
    class ElasticsearchConfigurationProcessingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ElasticsearchConfigurationProcessingConfigurationProperty | undefined;
        set internalValue(value: ElasticsearchConfigurationProcessingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _processors;
        get processors(): ElasticsearchConfigurationProcessingConfigurationProcessorsPropertyList;
        putProcessors(value: ElasticsearchConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable): void;
        resetProcessors(): void;
        get processorsInput(): cdktn.IResolvable | ElasticsearchConfigurationProcessingConfigurationProcessorsProperty[] | undefined;
    }
    interface ElasticsearchConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class ElasticsearchConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ElasticsearchConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: ElasticsearchConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface ElasticsearchConfigurationS3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#bucket_arn AwsKinesisFirehoseDeliveryStream#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#compression_format AwsKinesisFirehoseDeliveryStream#compression_format}
        */
        readonly compressionFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#error_output_prefix AwsKinesisFirehoseDeliveryStream#error_output_prefix}
        */
        readonly errorOutputPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#kms_key_arn AwsKinesisFirehoseDeliveryStream#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#prefix AwsKinesisFirehoseDeliveryStream#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: ElasticsearchConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty;
    }
    class ElasticsearchConfigurationS3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ElasticsearchConfigurationS3ConfigurationProperty | undefined;
        set internalValue(value: ElasticsearchConfigurationS3ConfigurationProperty | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _compressionFormat?;
        get compressionFormat(): string;
        set compressionFormat(value: string);
        resetCompressionFormat(): void;
        get compressionFormatInput(): string | undefined;
        private _errorOutputPrefix?;
        get errorOutputPrefix(): string;
        set errorOutputPrefix(value: string);
        resetErrorOutputPrefix(): void;
        get errorOutputPrefixInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): ElasticsearchConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: ElasticsearchConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): ElasticsearchConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
    }
    interface ElasticsearchConfigurationVpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#security_group_ids AwsKinesisFirehoseDeliveryStream#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#subnet_ids AwsKinesisFirehoseDeliveryStream#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class ElasticsearchConfigurationVpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ElasticsearchConfigurationVpcConfigProperty | undefined;
        set internalValue(value: ElasticsearchConfigurationVpcConfigProperty | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        get vpcId(): string;
    }
    interface ElasticsearchConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cluster_endpoint AwsKinesisFirehoseDeliveryStream#cluster_endpoint}
        */
        readonly clusterEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#domain_arn AwsKinesisFirehoseDeliveryStream#domain_arn}
        */
        readonly domainArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#index_name AwsKinesisFirehoseDeliveryStream#index_name}
        */
        readonly indexName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#index_rotation_period AwsKinesisFirehoseDeliveryStream#index_rotation_period}
        */
        readonly indexRotationPeriod?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#retry_duration AwsKinesisFirehoseDeliveryStream#retry_duration}
        */
        readonly retryDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_backup_mode AwsKinesisFirehoseDeliveryStream#s3_backup_mode}
        */
        readonly s3BackupMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#type_name AwsKinesisFirehoseDeliveryStream#type_name}
        */
        readonly typeName?: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: ElasticsearchConfigurationCloudwatchLoggingOptionsProperty;
        /**
        * processing_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processing_configuration AwsKinesisFirehoseDeliveryStream#processing_configuration}
        */
        readonly processingConfiguration?: ElasticsearchConfigurationProcessingConfigurationProperty;
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_configuration AwsKinesisFirehoseDeliveryStream#s3_configuration}
        */
        readonly s3Configuration: ElasticsearchConfigurationS3ConfigurationProperty;
        /**
        * vpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#vpc_config AwsKinesisFirehoseDeliveryStream#vpc_config}
        */
        readonly vpcConfig?: ElasticsearchConfigurationVpcConfigProperty;
    }
    class ElasticsearchConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ElasticsearchConfigurationProperty | undefined;
        set internalValue(value: ElasticsearchConfigurationProperty | undefined);
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _clusterEndpoint?;
        get clusterEndpoint(): string;
        set clusterEndpoint(value: string);
        resetClusterEndpoint(): void;
        get clusterEndpointInput(): string | undefined;
        private _domainArn?;
        get domainArn(): string;
        set domainArn(value: string);
        resetDomainArn(): void;
        get domainArnInput(): string | undefined;
        private _indexName?;
        get indexName(): string;
        set indexName(value: string);
        get indexNameInput(): string | undefined;
        private _indexRotationPeriod?;
        get indexRotationPeriod(): string;
        set indexRotationPeriod(value: string);
        resetIndexRotationPeriod(): void;
        get indexRotationPeriodInput(): string | undefined;
        private _retryDuration?;
        get retryDuration(): number;
        set retryDuration(value: number);
        resetRetryDuration(): void;
        get retryDurationInput(): number | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _s3BackupMode?;
        get s3BackupMode(): string;
        set s3BackupMode(value: string);
        resetS3BackupMode(): void;
        get s3BackupModeInput(): string | undefined;
        private _typeName?;
        get typeName(): string;
        set typeName(value: string);
        resetTypeName(): void;
        get typeNameInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): ElasticsearchConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: ElasticsearchConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): ElasticsearchConfigurationCloudwatchLoggingOptionsProperty | undefined;
        private _processingConfiguration;
        get processingConfiguration(): ElasticsearchConfigurationProcessingConfigurationPropertyOutputReference;
        putProcessingConfiguration(value: ElasticsearchConfigurationProcessingConfigurationProperty): void;
        resetProcessingConfiguration(): void;
        get processingConfigurationInput(): ElasticsearchConfigurationProcessingConfigurationProperty | undefined;
        private _s3Configuration;
        get s3Configuration(): ElasticsearchConfigurationS3ConfigurationPropertyOutputReference;
        putS3Configuration(value: ElasticsearchConfigurationS3ConfigurationProperty): void;
        get s3ConfigurationInput(): ElasticsearchConfigurationS3ConfigurationProperty | undefined;
        private _vpcConfig;
        get vpcConfig(): ElasticsearchConfigurationVpcConfigPropertyOutputReference;
        putVpcConfig(value: ElasticsearchConfigurationVpcConfigProperty): void;
        resetVpcConfig(): void;
        get vpcConfigInput(): ElasticsearchConfigurationVpcConfigProperty | undefined;
    }
    interface ExtendedS3ConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class ExtendedS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExtendedS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: ExtendedS3ConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface HiveJsonSerDeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#timestamp_formats AwsKinesisFirehoseDeliveryStream#timestamp_formats}
        */
        readonly timestampFormats?: string[];
    }
    class HiveJsonSerDePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HiveJsonSerDeProperty | undefined;
        set internalValue(value: HiveJsonSerDeProperty | undefined);
        private _timestampFormats?;
        get timestampFormats(): string[];
        set timestampFormats(value: string[]);
        resetTimestampFormats(): void;
        get timestampFormatsInput(): string[] | undefined;
    }
    interface OpenXJsonSerDeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#case_insensitive AwsKinesisFirehoseDeliveryStream#case_insensitive}
        */
        readonly caseInsensitive?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#column_to_json_key_mappings AwsKinesisFirehoseDeliveryStream#column_to_json_key_mappings}
        */
        readonly columnToJsonKeyMappings?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#convert_dots_in_json_keys_to_underscores AwsKinesisFirehoseDeliveryStream#convert_dots_in_json_keys_to_underscores}
        */
        readonly convertDotsInJsonKeysToUnderscores?: boolean | cdktn.IResolvable;
    }
    class OpenXJsonSerDePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpenXJsonSerDeProperty | undefined;
        set internalValue(value: OpenXJsonSerDeProperty | undefined);
        private _caseInsensitive?;
        get caseInsensitive(): boolean | cdktn.IResolvable;
        set caseInsensitive(value: boolean | cdktn.IResolvable);
        resetCaseInsensitive(): void;
        get caseInsensitiveInput(): boolean | cdktn.IResolvable | undefined;
        private _columnToJsonKeyMappings?;
        get columnToJsonKeyMappings(): {
            [key: string]: string;
        };
        set columnToJsonKeyMappings(value: {
            [key: string]: string;
        });
        resetColumnToJsonKeyMappings(): void;
        get columnToJsonKeyMappingsInput(): {
            [key: string]: string;
        } | undefined;
        private _convertDotsInJsonKeysToUnderscores?;
        get convertDotsInJsonKeysToUnderscores(): boolean | cdktn.IResolvable;
        set convertDotsInJsonKeysToUnderscores(value: boolean | cdktn.IResolvable);
        resetConvertDotsInJsonKeysToUnderscores(): void;
        get convertDotsInJsonKeysToUnderscoresInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DeserializerProperty {
        /**
        * hive_json_ser_de block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#hive_json_ser_de AwsKinesisFirehoseDeliveryStream#hive_json_ser_de}
        */
        readonly hiveJsonSerDe?: HiveJsonSerDeProperty;
        /**
        * open_x_json_ser_de block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#open_x_json_ser_de AwsKinesisFirehoseDeliveryStream#open_x_json_ser_de}
        */
        readonly openXJsonSerDe?: OpenXJsonSerDeProperty;
    }
    class DeserializerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeserializerProperty | undefined;
        set internalValue(value: DeserializerProperty | undefined);
        private _hiveJsonSerDe;
        get hiveJsonSerDe(): HiveJsonSerDePropertyOutputReference;
        putHiveJsonSerDe(value: HiveJsonSerDeProperty): void;
        resetHiveJsonSerDe(): void;
        get hiveJsonSerDeInput(): HiveJsonSerDeProperty | undefined;
        private _openXJsonSerDe;
        get openXJsonSerDe(): OpenXJsonSerDePropertyOutputReference;
        putOpenXJsonSerDe(value: OpenXJsonSerDeProperty): void;
        resetOpenXJsonSerDe(): void;
        get openXJsonSerDeInput(): OpenXJsonSerDeProperty | undefined;
    }
    interface InputFormatConfigurationProperty {
        /**
        * deserializer block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#deserializer AwsKinesisFirehoseDeliveryStream#deserializer}
        */
        readonly deserializer: DeserializerProperty;
    }
    class InputFormatConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputFormatConfigurationProperty | undefined;
        set internalValue(value: InputFormatConfigurationProperty | undefined);
        private _deserializer;
        get deserializer(): DeserializerPropertyOutputReference;
        putDeserializer(value: DeserializerProperty): void;
        get deserializerInput(): DeserializerProperty | undefined;
    }
    interface OrcSerDeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#block_size_bytes AwsKinesisFirehoseDeliveryStream#block_size_bytes}
        */
        readonly blockSizeBytes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#bloom_filter_columns AwsKinesisFirehoseDeliveryStream#bloom_filter_columns}
        */
        readonly bloomFilterColumns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#bloom_filter_false_positive_probability AwsKinesisFirehoseDeliveryStream#bloom_filter_false_positive_probability}
        */
        readonly bloomFilterFalsePositiveProbability?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#compression AwsKinesisFirehoseDeliveryStream#compression}
        */
        readonly compression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#dictionary_key_threshold AwsKinesisFirehoseDeliveryStream#dictionary_key_threshold}
        */
        readonly dictionaryKeyThreshold?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enable_padding AwsKinesisFirehoseDeliveryStream#enable_padding}
        */
        readonly enablePadding?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#format_version AwsKinesisFirehoseDeliveryStream#format_version}
        */
        readonly formatVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#padding_tolerance AwsKinesisFirehoseDeliveryStream#padding_tolerance}
        */
        readonly paddingTolerance?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#row_index_stride AwsKinesisFirehoseDeliveryStream#row_index_stride}
        */
        readonly rowIndexStride?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#stripe_size_bytes AwsKinesisFirehoseDeliveryStream#stripe_size_bytes}
        */
        readonly stripeSizeBytes?: number;
    }
    class OrcSerDePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OrcSerDeProperty | undefined;
        set internalValue(value: OrcSerDeProperty | undefined);
        private _blockSizeBytes?;
        get blockSizeBytes(): number;
        set blockSizeBytes(value: number);
        resetBlockSizeBytes(): void;
        get blockSizeBytesInput(): number | undefined;
        private _bloomFilterColumns?;
        get bloomFilterColumns(): string[];
        set bloomFilterColumns(value: string[]);
        resetBloomFilterColumns(): void;
        get bloomFilterColumnsInput(): string[] | undefined;
        private _bloomFilterFalsePositiveProbability?;
        get bloomFilterFalsePositiveProbability(): number;
        set bloomFilterFalsePositiveProbability(value: number);
        resetBloomFilterFalsePositiveProbability(): void;
        get bloomFilterFalsePositiveProbabilityInput(): number | undefined;
        private _compression?;
        get compression(): string;
        set compression(value: string);
        resetCompression(): void;
        get compressionInput(): string | undefined;
        private _dictionaryKeyThreshold?;
        get dictionaryKeyThreshold(): number;
        set dictionaryKeyThreshold(value: number);
        resetDictionaryKeyThreshold(): void;
        get dictionaryKeyThresholdInput(): number | undefined;
        private _enablePadding?;
        get enablePadding(): boolean | cdktn.IResolvable;
        set enablePadding(value: boolean | cdktn.IResolvable);
        resetEnablePadding(): void;
        get enablePaddingInput(): boolean | cdktn.IResolvable | undefined;
        private _formatVersion?;
        get formatVersion(): string;
        set formatVersion(value: string);
        resetFormatVersion(): void;
        get formatVersionInput(): string | undefined;
        private _paddingTolerance?;
        get paddingTolerance(): number;
        set paddingTolerance(value: number);
        resetPaddingTolerance(): void;
        get paddingToleranceInput(): number | undefined;
        private _rowIndexStride?;
        get rowIndexStride(): number;
        set rowIndexStride(value: number);
        resetRowIndexStride(): void;
        get rowIndexStrideInput(): number | undefined;
        private _stripeSizeBytes?;
        get stripeSizeBytes(): number;
        set stripeSizeBytes(value: number);
        resetStripeSizeBytes(): void;
        get stripeSizeBytesInput(): number | undefined;
    }
    interface ParquetSerDeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#block_size_bytes AwsKinesisFirehoseDeliveryStream#block_size_bytes}
        */
        readonly blockSizeBytes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#compression AwsKinesisFirehoseDeliveryStream#compression}
        */
        readonly compression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enable_dictionary_compression AwsKinesisFirehoseDeliveryStream#enable_dictionary_compression}
        */
        readonly enableDictionaryCompression?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#max_padding_bytes AwsKinesisFirehoseDeliveryStream#max_padding_bytes}
        */
        readonly maxPaddingBytes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#page_size_bytes AwsKinesisFirehoseDeliveryStream#page_size_bytes}
        */
        readonly pageSizeBytes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#writer_version AwsKinesisFirehoseDeliveryStream#writer_version}
        */
        readonly writerVersion?: string;
    }
    class ParquetSerDePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ParquetSerDeProperty | undefined;
        set internalValue(value: ParquetSerDeProperty | undefined);
        private _blockSizeBytes?;
        get blockSizeBytes(): number;
        set blockSizeBytes(value: number);
        resetBlockSizeBytes(): void;
        get blockSizeBytesInput(): number | undefined;
        private _compression?;
        get compression(): string;
        set compression(value: string);
        resetCompression(): void;
        get compressionInput(): string | undefined;
        private _enableDictionaryCompression?;
        get enableDictionaryCompression(): boolean | cdktn.IResolvable;
        set enableDictionaryCompression(value: boolean | cdktn.IResolvable);
        resetEnableDictionaryCompression(): void;
        get enableDictionaryCompressionInput(): boolean | cdktn.IResolvable | undefined;
        private _maxPaddingBytes?;
        get maxPaddingBytes(): number;
        set maxPaddingBytes(value: number);
        resetMaxPaddingBytes(): void;
        get maxPaddingBytesInput(): number | undefined;
        private _pageSizeBytes?;
        get pageSizeBytes(): number;
        set pageSizeBytes(value: number);
        resetPageSizeBytes(): void;
        get pageSizeBytesInput(): number | undefined;
        private _writerVersion?;
        get writerVersion(): string;
        set writerVersion(value: string);
        resetWriterVersion(): void;
        get writerVersionInput(): string | undefined;
    }
    interface SerializerProperty {
        /**
        * orc_ser_de block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#orc_ser_de AwsKinesisFirehoseDeliveryStream#orc_ser_de}
        */
        readonly orcSerDe?: OrcSerDeProperty;
        /**
        * parquet_ser_de block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parquet_ser_de AwsKinesisFirehoseDeliveryStream#parquet_ser_de}
        */
        readonly parquetSerDe?: ParquetSerDeProperty;
    }
    class SerializerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SerializerProperty | undefined;
        set internalValue(value: SerializerProperty | undefined);
        private _orcSerDe;
        get orcSerDe(): OrcSerDePropertyOutputReference;
        putOrcSerDe(value: OrcSerDeProperty): void;
        resetOrcSerDe(): void;
        get orcSerDeInput(): OrcSerDeProperty | undefined;
        private _parquetSerDe;
        get parquetSerDe(): ParquetSerDePropertyOutputReference;
        putParquetSerDe(value: ParquetSerDeProperty): void;
        resetParquetSerDe(): void;
        get parquetSerDeInput(): ParquetSerDeProperty | undefined;
    }
    interface OutputFormatConfigurationProperty {
        /**
        * serializer block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#serializer AwsKinesisFirehoseDeliveryStream#serializer}
        */
        readonly serializer: SerializerProperty;
    }
    class OutputFormatConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutputFormatConfigurationProperty | undefined;
        set internalValue(value: OutputFormatConfigurationProperty | undefined);
        private _serializer;
        get serializer(): SerializerPropertyOutputReference;
        putSerializer(value: SerializerProperty): void;
        get serializerInput(): SerializerProperty | undefined;
    }
    interface SchemaConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#catalog_id AwsKinesisFirehoseDeliveryStream#catalog_id}
        */
        readonly catalogId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#database_name AwsKinesisFirehoseDeliveryStream#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#region AwsKinesisFirehoseDeliveryStream#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#table_name AwsKinesisFirehoseDeliveryStream#table_name}
        */
        readonly tableName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#version_id AwsKinesisFirehoseDeliveryStream#version_id}
        */
        readonly versionId?: string;
    }
    class SchemaConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchemaConfigurationProperty | undefined;
        set internalValue(value: SchemaConfigurationProperty | undefined);
        private _catalogId?;
        get catalogId(): string;
        set catalogId(value: string);
        resetCatalogId(): void;
        get catalogIdInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
        private _versionId?;
        get versionId(): string;
        set versionId(value: string);
        resetVersionId(): void;
        get versionIdInput(): string | undefined;
    }
    interface DataFormatConversionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * input_format_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#input_format_configuration AwsKinesisFirehoseDeliveryStream#input_format_configuration}
        */
        readonly inputFormatConfiguration: InputFormatConfigurationProperty;
        /**
        * output_format_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#output_format_configuration AwsKinesisFirehoseDeliveryStream#output_format_configuration}
        */
        readonly outputFormatConfiguration: OutputFormatConfigurationProperty;
        /**
        * schema_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#schema_configuration AwsKinesisFirehoseDeliveryStream#schema_configuration}
        */
        readonly schemaConfiguration: SchemaConfigurationProperty;
    }
    class DataFormatConversionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataFormatConversionConfigurationProperty | undefined;
        set internalValue(value: DataFormatConversionConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _inputFormatConfiguration;
        get inputFormatConfiguration(): InputFormatConfigurationPropertyOutputReference;
        putInputFormatConfiguration(value: InputFormatConfigurationProperty): void;
        get inputFormatConfigurationInput(): InputFormatConfigurationProperty | undefined;
        private _outputFormatConfiguration;
        get outputFormatConfiguration(): OutputFormatConfigurationPropertyOutputReference;
        putOutputFormatConfiguration(value: OutputFormatConfigurationProperty): void;
        get outputFormatConfigurationInput(): OutputFormatConfigurationProperty | undefined;
        private _schemaConfiguration;
        get schemaConfiguration(): SchemaConfigurationPropertyOutputReference;
        putSchemaConfiguration(value: SchemaConfigurationProperty): void;
        get schemaConfigurationInput(): SchemaConfigurationProperty | undefined;
    }
    interface DynamicPartitioningConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#retry_duration AwsKinesisFirehoseDeliveryStream#retry_duration}
        */
        readonly retryDuration?: number;
    }
    class DynamicPartitioningConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DynamicPartitioningConfigurationProperty | undefined;
        set internalValue(value: DynamicPartitioningConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _retryDuration?;
        get retryDuration(): number;
        set retryDuration(value: number);
        resetRetryDuration(): void;
        get retryDurationInput(): number | undefined;
    }
    interface ExtendedS3ConfigurationProcessingConfigurationProcessorsParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_name AwsKinesisFirehoseDeliveryStream#parameter_name}
        */
        readonly parameterName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_value AwsKinesisFirehoseDeliveryStream#parameter_value}
        */
        readonly parameterValue: string;
    }
    class ExtendedS3ConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExtendedS3ConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExtendedS3ConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined);
        private _parameterName?;
        get parameterName(): string;
        set parameterName(value: string);
        get parameterNameInput(): string | undefined;
        private _parameterValue?;
        get parameterValue(): string;
        set parameterValue(value: string);
        get parameterValueInput(): string | undefined;
    }
    class ExtendedS3ConfigurationProcessingConfigurationProcessorsParametersPropertyList extends cdktn.ComplexList {
        internalValue?: ExtendedS3ConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExtendedS3ConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference;
    }
    interface ExtendedS3ConfigurationProcessingConfigurationProcessorsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#type AwsKinesisFirehoseDeliveryStream#type}
        */
        readonly type: string;
        /**
        * parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameters AwsKinesisFirehoseDeliveryStream#parameters}
        */
        readonly parameters?: ExtendedS3ConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
    }
    class ExtendedS3ConfigurationProcessingConfigurationProcessorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExtendedS3ConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExtendedS3ConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _parameters;
        get parameters(): ExtendedS3ConfigurationProcessingConfigurationProcessorsParametersPropertyList;
        putParameters(value: ExtendedS3ConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable): void;
        resetParameters(): void;
        get parametersInput(): cdktn.IResolvable | ExtendedS3ConfigurationProcessingConfigurationProcessorsParametersProperty[] | undefined;
    }
    class ExtendedS3ConfigurationProcessingConfigurationProcessorsPropertyList extends cdktn.ComplexList {
        internalValue?: ExtendedS3ConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExtendedS3ConfigurationProcessingConfigurationProcessorsPropertyOutputReference;
    }
    interface ExtendedS3ConfigurationProcessingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * processors block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processors AwsKinesisFirehoseDeliveryStream#processors}
        */
        readonly processors?: ExtendedS3ConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
    }
    class ExtendedS3ConfigurationProcessingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExtendedS3ConfigurationProcessingConfigurationProperty | undefined;
        set internalValue(value: ExtendedS3ConfigurationProcessingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _processors;
        get processors(): ExtendedS3ConfigurationProcessingConfigurationProcessorsPropertyList;
        putProcessors(value: ExtendedS3ConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable): void;
        resetProcessors(): void;
        get processorsInput(): cdktn.IResolvable | ExtendedS3ConfigurationProcessingConfigurationProcessorsProperty[] | undefined;
    }
    interface ExtendedS3ConfigurationS3BackupConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class ExtendedS3ConfigurationS3BackupConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExtendedS3ConfigurationS3BackupConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: ExtendedS3ConfigurationS3BackupConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface ExtendedS3ConfigurationS3BackupConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#bucket_arn AwsKinesisFirehoseDeliveryStream#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#compression_format AwsKinesisFirehoseDeliveryStream#compression_format}
        */
        readonly compressionFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#error_output_prefix AwsKinesisFirehoseDeliveryStream#error_output_prefix}
        */
        readonly errorOutputPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#kms_key_arn AwsKinesisFirehoseDeliveryStream#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#prefix AwsKinesisFirehoseDeliveryStream#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: ExtendedS3ConfigurationS3BackupConfigurationCloudwatchLoggingOptionsProperty;
    }
    class ExtendedS3ConfigurationS3BackupConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExtendedS3ConfigurationS3BackupConfigurationProperty | undefined;
        set internalValue(value: ExtendedS3ConfigurationS3BackupConfigurationProperty | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _compressionFormat?;
        get compressionFormat(): string;
        set compressionFormat(value: string);
        resetCompressionFormat(): void;
        get compressionFormatInput(): string | undefined;
        private _errorOutputPrefix?;
        get errorOutputPrefix(): string;
        set errorOutputPrefix(value: string);
        resetErrorOutputPrefix(): void;
        get errorOutputPrefixInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): ExtendedS3ConfigurationS3BackupConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: ExtendedS3ConfigurationS3BackupConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): ExtendedS3ConfigurationS3BackupConfigurationCloudwatchLoggingOptionsProperty | undefined;
    }
    interface ExtendedS3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#bucket_arn AwsKinesisFirehoseDeliveryStream#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#compression_format AwsKinesisFirehoseDeliveryStream#compression_format}
        */
        readonly compressionFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#custom_time_zone AwsKinesisFirehoseDeliveryStream#custom_time_zone}
        */
        readonly customTimeZone?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#error_output_prefix AwsKinesisFirehoseDeliveryStream#error_output_prefix}
        */
        readonly errorOutputPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#file_extension AwsKinesisFirehoseDeliveryStream#file_extension}
        */
        readonly fileExtension?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#kms_key_arn AwsKinesisFirehoseDeliveryStream#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#prefix AwsKinesisFirehoseDeliveryStream#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_backup_mode AwsKinesisFirehoseDeliveryStream#s3_backup_mode}
        */
        readonly s3BackupMode?: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: ExtendedS3ConfigurationCloudwatchLoggingOptionsProperty;
        /**
        * data_format_conversion_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#data_format_conversion_configuration AwsKinesisFirehoseDeliveryStream#data_format_conversion_configuration}
        */
        readonly dataFormatConversionConfiguration?: DataFormatConversionConfigurationProperty;
        /**
        * dynamic_partitioning_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#dynamic_partitioning_configuration AwsKinesisFirehoseDeliveryStream#dynamic_partitioning_configuration}
        */
        readonly dynamicPartitioningConfiguration?: DynamicPartitioningConfigurationProperty;
        /**
        * processing_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processing_configuration AwsKinesisFirehoseDeliveryStream#processing_configuration}
        */
        readonly processingConfiguration?: ExtendedS3ConfigurationProcessingConfigurationProperty;
        /**
        * s3_backup_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_backup_configuration AwsKinesisFirehoseDeliveryStream#s3_backup_configuration}
        */
        readonly s3BackupConfiguration?: ExtendedS3ConfigurationS3BackupConfigurationProperty;
    }
    class ExtendedS3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExtendedS3ConfigurationProperty | undefined;
        set internalValue(value: ExtendedS3ConfigurationProperty | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _compressionFormat?;
        get compressionFormat(): string;
        set compressionFormat(value: string);
        resetCompressionFormat(): void;
        get compressionFormatInput(): string | undefined;
        private _customTimeZone?;
        get customTimeZone(): string;
        set customTimeZone(value: string);
        resetCustomTimeZone(): void;
        get customTimeZoneInput(): string | undefined;
        private _errorOutputPrefix?;
        get errorOutputPrefix(): string;
        set errorOutputPrefix(value: string);
        resetErrorOutputPrefix(): void;
        get errorOutputPrefixInput(): string | undefined;
        private _fileExtension?;
        get fileExtension(): string;
        set fileExtension(value: string);
        resetFileExtension(): void;
        get fileExtensionInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _s3BackupMode?;
        get s3BackupMode(): string;
        set s3BackupMode(value: string);
        resetS3BackupMode(): void;
        get s3BackupModeInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): ExtendedS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: ExtendedS3ConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): ExtendedS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
        private _dataFormatConversionConfiguration;
        get dataFormatConversionConfiguration(): DataFormatConversionConfigurationPropertyOutputReference;
        putDataFormatConversionConfiguration(value: DataFormatConversionConfigurationProperty): void;
        resetDataFormatConversionConfiguration(): void;
        get dataFormatConversionConfigurationInput(): DataFormatConversionConfigurationProperty | undefined;
        private _dynamicPartitioningConfiguration;
        get dynamicPartitioningConfiguration(): DynamicPartitioningConfigurationPropertyOutputReference;
        putDynamicPartitioningConfiguration(value: DynamicPartitioningConfigurationProperty): void;
        resetDynamicPartitioningConfiguration(): void;
        get dynamicPartitioningConfigurationInput(): DynamicPartitioningConfigurationProperty | undefined;
        private _processingConfiguration;
        get processingConfiguration(): ExtendedS3ConfigurationProcessingConfigurationPropertyOutputReference;
        putProcessingConfiguration(value: ExtendedS3ConfigurationProcessingConfigurationProperty): void;
        resetProcessingConfiguration(): void;
        get processingConfigurationInput(): ExtendedS3ConfigurationProcessingConfigurationProperty | undefined;
        private _s3BackupConfiguration;
        get s3BackupConfiguration(): ExtendedS3ConfigurationS3BackupConfigurationPropertyOutputReference;
        putS3BackupConfiguration(value: ExtendedS3ConfigurationS3BackupConfigurationProperty): void;
        resetS3BackupConfiguration(): void;
        get s3BackupConfigurationInput(): ExtendedS3ConfigurationS3BackupConfigurationProperty | undefined;
    }
    interface HttpEndpointConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class HttpEndpointConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpEndpointConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: HttpEndpointConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface HttpEndpointConfigurationProcessingConfigurationProcessorsParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_name AwsKinesisFirehoseDeliveryStream#parameter_name}
        */
        readonly parameterName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_value AwsKinesisFirehoseDeliveryStream#parameter_value}
        */
        readonly parameterValue: string;
    }
    class HttpEndpointConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HttpEndpointConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HttpEndpointConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined);
        private _parameterName?;
        get parameterName(): string;
        set parameterName(value: string);
        get parameterNameInput(): string | undefined;
        private _parameterValue?;
        get parameterValue(): string;
        set parameterValue(value: string);
        get parameterValueInput(): string | undefined;
    }
    class HttpEndpointConfigurationProcessingConfigurationProcessorsParametersPropertyList extends cdktn.ComplexList {
        internalValue?: HttpEndpointConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HttpEndpointConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference;
    }
    interface HttpEndpointConfigurationProcessingConfigurationProcessorsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#type AwsKinesisFirehoseDeliveryStream#type}
        */
        readonly type: string;
        /**
        * parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameters AwsKinesisFirehoseDeliveryStream#parameters}
        */
        readonly parameters?: HttpEndpointConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
    }
    class HttpEndpointConfigurationProcessingConfigurationProcessorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HttpEndpointConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HttpEndpointConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _parameters;
        get parameters(): HttpEndpointConfigurationProcessingConfigurationProcessorsParametersPropertyList;
        putParameters(value: HttpEndpointConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable): void;
        resetParameters(): void;
        get parametersInput(): cdktn.IResolvable | HttpEndpointConfigurationProcessingConfigurationProcessorsParametersProperty[] | undefined;
    }
    class HttpEndpointConfigurationProcessingConfigurationProcessorsPropertyList extends cdktn.ComplexList {
        internalValue?: HttpEndpointConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HttpEndpointConfigurationProcessingConfigurationProcessorsPropertyOutputReference;
    }
    interface HttpEndpointConfigurationProcessingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * processors block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processors AwsKinesisFirehoseDeliveryStream#processors}
        */
        readonly processors?: HttpEndpointConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
    }
    class HttpEndpointConfigurationProcessingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpEndpointConfigurationProcessingConfigurationProperty | undefined;
        set internalValue(value: HttpEndpointConfigurationProcessingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _processors;
        get processors(): HttpEndpointConfigurationProcessingConfigurationProcessorsPropertyList;
        putProcessors(value: HttpEndpointConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable): void;
        resetProcessors(): void;
        get processorsInput(): cdktn.IResolvable | HttpEndpointConfigurationProcessingConfigurationProcessorsProperty[] | undefined;
    }
    interface CommonAttributesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#name AwsKinesisFirehoseDeliveryStream#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#value AwsKinesisFirehoseDeliveryStream#value}
        */
        readonly value: string;
    }
    class CommonAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CommonAttributesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CommonAttributesProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class CommonAttributesPropertyList extends cdktn.ComplexList {
        internalValue?: CommonAttributesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CommonAttributesPropertyOutputReference;
    }
    interface RequestConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#content_encoding AwsKinesisFirehoseDeliveryStream#content_encoding}
        */
        readonly contentEncoding?: string;
        /**
        * common_attributes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#common_attributes AwsKinesisFirehoseDeliveryStream#common_attributes}
        */
        readonly commonAttributes?: CommonAttributesProperty[] | cdktn.IResolvable;
    }
    class RequestConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RequestConfigurationProperty | undefined;
        set internalValue(value: RequestConfigurationProperty | undefined);
        private _contentEncoding?;
        get contentEncoding(): string;
        set contentEncoding(value: string);
        resetContentEncoding(): void;
        get contentEncodingInput(): string | undefined;
        private _commonAttributes;
        get commonAttributes(): CommonAttributesPropertyList;
        putCommonAttributes(value: CommonAttributesProperty[] | cdktn.IResolvable): void;
        resetCommonAttributes(): void;
        get commonAttributesInput(): cdktn.IResolvable | CommonAttributesProperty[] | undefined;
    }
    interface HttpEndpointConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class HttpEndpointConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpEndpointConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: HttpEndpointConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface HttpEndpointConfigurationS3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#bucket_arn AwsKinesisFirehoseDeliveryStream#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#compression_format AwsKinesisFirehoseDeliveryStream#compression_format}
        */
        readonly compressionFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#error_output_prefix AwsKinesisFirehoseDeliveryStream#error_output_prefix}
        */
        readonly errorOutputPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#kms_key_arn AwsKinesisFirehoseDeliveryStream#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#prefix AwsKinesisFirehoseDeliveryStream#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: HttpEndpointConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty;
    }
    class HttpEndpointConfigurationS3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpEndpointConfigurationS3ConfigurationProperty | undefined;
        set internalValue(value: HttpEndpointConfigurationS3ConfigurationProperty | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _compressionFormat?;
        get compressionFormat(): string;
        set compressionFormat(value: string);
        resetCompressionFormat(): void;
        get compressionFormatInput(): string | undefined;
        private _errorOutputPrefix?;
        get errorOutputPrefix(): string;
        set errorOutputPrefix(value: string);
        resetErrorOutputPrefix(): void;
        get errorOutputPrefixInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): HttpEndpointConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: HttpEndpointConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): HttpEndpointConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
    }
    interface HttpEndpointConfigurationSecretsManagerConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#secret_arn AwsKinesisFirehoseDeliveryStream#secret_arn}
        */
        readonly secretArn?: string;
    }
    class HttpEndpointConfigurationSecretsManagerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpEndpointConfigurationSecretsManagerConfigurationProperty | undefined;
        set internalValue(value: HttpEndpointConfigurationSecretsManagerConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _secretArn?;
        get secretArn(): string;
        set secretArn(value: string);
        resetSecretArn(): void;
        get secretArnInput(): string | undefined;
    }
    interface HttpEndpointConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#access_key AwsKinesisFirehoseDeliveryStream#access_key}
        */
        readonly accessKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#name AwsKinesisFirehoseDeliveryStream#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#retry_duration AwsKinesisFirehoseDeliveryStream#retry_duration}
        */
        readonly retryDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_backup_mode AwsKinesisFirehoseDeliveryStream#s3_backup_mode}
        */
        readonly s3BackupMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#url AwsKinesisFirehoseDeliveryStream#url}
        */
        readonly url: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: HttpEndpointConfigurationCloudwatchLoggingOptionsProperty;
        /**
        * processing_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processing_configuration AwsKinesisFirehoseDeliveryStream#processing_configuration}
        */
        readonly processingConfiguration?: HttpEndpointConfigurationProcessingConfigurationProperty;
        /**
        * request_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#request_configuration AwsKinesisFirehoseDeliveryStream#request_configuration}
        */
        readonly requestConfiguration?: RequestConfigurationProperty;
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_configuration AwsKinesisFirehoseDeliveryStream#s3_configuration}
        */
        readonly s3Configuration: HttpEndpointConfigurationS3ConfigurationProperty;
        /**
        * secrets_manager_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#secrets_manager_configuration AwsKinesisFirehoseDeliveryStream#secrets_manager_configuration}
        */
        readonly secretsManagerConfiguration?: HttpEndpointConfigurationSecretsManagerConfigurationProperty;
    }
    class HttpEndpointConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpEndpointConfigurationProperty | undefined;
        set internalValue(value: HttpEndpointConfigurationProperty | undefined);
        private _accessKey?;
        get accessKey(): string;
        set accessKey(value: string);
        resetAccessKey(): void;
        get accessKeyInput(): string | undefined;
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _retryDuration?;
        get retryDuration(): number;
        set retryDuration(value: number);
        resetRetryDuration(): void;
        get retryDurationInput(): number | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _s3BackupMode?;
        get s3BackupMode(): string;
        set s3BackupMode(value: string);
        resetS3BackupMode(): void;
        get s3BackupModeInput(): string | undefined;
        private _url?;
        get url(): string;
        set url(value: string);
        get urlInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): HttpEndpointConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: HttpEndpointConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): HttpEndpointConfigurationCloudwatchLoggingOptionsProperty | undefined;
        private _processingConfiguration;
        get processingConfiguration(): HttpEndpointConfigurationProcessingConfigurationPropertyOutputReference;
        putProcessingConfiguration(value: HttpEndpointConfigurationProcessingConfigurationProperty): void;
        resetProcessingConfiguration(): void;
        get processingConfigurationInput(): HttpEndpointConfigurationProcessingConfigurationProperty | undefined;
        private _requestConfiguration;
        get requestConfiguration(): RequestConfigurationPropertyOutputReference;
        putRequestConfiguration(value: RequestConfigurationProperty): void;
        resetRequestConfiguration(): void;
        get requestConfigurationInput(): RequestConfigurationProperty | undefined;
        private _s3Configuration;
        get s3Configuration(): HttpEndpointConfigurationS3ConfigurationPropertyOutputReference;
        putS3Configuration(value: HttpEndpointConfigurationS3ConfigurationProperty): void;
        get s3ConfigurationInput(): HttpEndpointConfigurationS3ConfigurationProperty | undefined;
        private _secretsManagerConfiguration;
        get secretsManagerConfiguration(): HttpEndpointConfigurationSecretsManagerConfigurationPropertyOutputReference;
        putSecretsManagerConfiguration(value: HttpEndpointConfigurationSecretsManagerConfigurationProperty): void;
        resetSecretsManagerConfiguration(): void;
        get secretsManagerConfigurationInput(): HttpEndpointConfigurationSecretsManagerConfigurationProperty | undefined;
    }
    interface IcebergConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class IcebergConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IcebergConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: IcebergConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface DestinationTableConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#database_name AwsKinesisFirehoseDeliveryStream#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_error_output_prefix AwsKinesisFirehoseDeliveryStream#s3_error_output_prefix}
        */
        readonly s3ErrorOutputPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#table_name AwsKinesisFirehoseDeliveryStream#table_name}
        */
        readonly tableName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#unique_keys AwsKinesisFirehoseDeliveryStream#unique_keys}
        */
        readonly uniqueKeys?: string[];
    }
    class DestinationTableConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationTableConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationTableConfigurationProperty | cdktn.IResolvable | undefined);
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _s3ErrorOutputPrefix?;
        get s3ErrorOutputPrefix(): string;
        set s3ErrorOutputPrefix(value: string);
        resetS3ErrorOutputPrefix(): void;
        get s3ErrorOutputPrefixInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
        private _uniqueKeys?;
        get uniqueKeys(): string[];
        set uniqueKeys(value: string[]);
        resetUniqueKeys(): void;
        get uniqueKeysInput(): string[] | undefined;
    }
    class DestinationTableConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationTableConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationTableConfigurationPropertyOutputReference;
    }
    interface IcebergConfigurationProcessingConfigurationProcessorsParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_name AwsKinesisFirehoseDeliveryStream#parameter_name}
        */
        readonly parameterName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_value AwsKinesisFirehoseDeliveryStream#parameter_value}
        */
        readonly parameterValue: string;
    }
    class IcebergConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IcebergConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IcebergConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined);
        private _parameterName?;
        get parameterName(): string;
        set parameterName(value: string);
        get parameterNameInput(): string | undefined;
        private _parameterValue?;
        get parameterValue(): string;
        set parameterValue(value: string);
        get parameterValueInput(): string | undefined;
    }
    class IcebergConfigurationProcessingConfigurationProcessorsParametersPropertyList extends cdktn.ComplexList {
        internalValue?: IcebergConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IcebergConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference;
    }
    interface IcebergConfigurationProcessingConfigurationProcessorsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#type AwsKinesisFirehoseDeliveryStream#type}
        */
        readonly type: string;
        /**
        * parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameters AwsKinesisFirehoseDeliveryStream#parameters}
        */
        readonly parameters?: IcebergConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
    }
    class IcebergConfigurationProcessingConfigurationProcessorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IcebergConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IcebergConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _parameters;
        get parameters(): IcebergConfigurationProcessingConfigurationProcessorsParametersPropertyList;
        putParameters(value: IcebergConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable): void;
        resetParameters(): void;
        get parametersInput(): cdktn.IResolvable | IcebergConfigurationProcessingConfigurationProcessorsParametersProperty[] | undefined;
    }
    class IcebergConfigurationProcessingConfigurationProcessorsPropertyList extends cdktn.ComplexList {
        internalValue?: IcebergConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IcebergConfigurationProcessingConfigurationProcessorsPropertyOutputReference;
    }
    interface IcebergConfigurationProcessingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * processors block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processors AwsKinesisFirehoseDeliveryStream#processors}
        */
        readonly processors?: IcebergConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
    }
    class IcebergConfigurationProcessingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IcebergConfigurationProcessingConfigurationProperty | undefined;
        set internalValue(value: IcebergConfigurationProcessingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _processors;
        get processors(): IcebergConfigurationProcessingConfigurationProcessorsPropertyList;
        putProcessors(value: IcebergConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable): void;
        resetProcessors(): void;
        get processorsInput(): cdktn.IResolvable | IcebergConfigurationProcessingConfigurationProcessorsProperty[] | undefined;
    }
    interface IcebergConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class IcebergConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IcebergConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: IcebergConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface IcebergConfigurationS3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#bucket_arn AwsKinesisFirehoseDeliveryStream#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#compression_format AwsKinesisFirehoseDeliveryStream#compression_format}
        */
        readonly compressionFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#error_output_prefix AwsKinesisFirehoseDeliveryStream#error_output_prefix}
        */
        readonly errorOutputPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#kms_key_arn AwsKinesisFirehoseDeliveryStream#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#prefix AwsKinesisFirehoseDeliveryStream#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: IcebergConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty;
    }
    class IcebergConfigurationS3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IcebergConfigurationS3ConfigurationProperty | undefined;
        set internalValue(value: IcebergConfigurationS3ConfigurationProperty | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _compressionFormat?;
        get compressionFormat(): string;
        set compressionFormat(value: string);
        resetCompressionFormat(): void;
        get compressionFormatInput(): string | undefined;
        private _errorOutputPrefix?;
        get errorOutputPrefix(): string;
        set errorOutputPrefix(value: string);
        resetErrorOutputPrefix(): void;
        get errorOutputPrefixInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): IcebergConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: IcebergConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): IcebergConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
    }
    interface IcebergConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#append_only AwsKinesisFirehoseDeliveryStream#append_only}
        */
        readonly appendOnly?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#catalog_arn AwsKinesisFirehoseDeliveryStream#catalog_arn}
        */
        readonly catalogArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#retry_duration AwsKinesisFirehoseDeliveryStream#retry_duration}
        */
        readonly retryDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_backup_mode AwsKinesisFirehoseDeliveryStream#s3_backup_mode}
        */
        readonly s3BackupMode?: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: IcebergConfigurationCloudwatchLoggingOptionsProperty;
        /**
        * destination_table_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#destination_table_configuration AwsKinesisFirehoseDeliveryStream#destination_table_configuration}
        */
        readonly destinationTableConfiguration?: DestinationTableConfigurationProperty[] | cdktn.IResolvable;
        /**
        * processing_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processing_configuration AwsKinesisFirehoseDeliveryStream#processing_configuration}
        */
        readonly processingConfiguration?: IcebergConfigurationProcessingConfigurationProperty;
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_configuration AwsKinesisFirehoseDeliveryStream#s3_configuration}
        */
        readonly s3Configuration: IcebergConfigurationS3ConfigurationProperty;
    }
    class IcebergConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IcebergConfigurationProperty | undefined;
        set internalValue(value: IcebergConfigurationProperty | undefined);
        private _appendOnly?;
        get appendOnly(): boolean | cdktn.IResolvable;
        set appendOnly(value: boolean | cdktn.IResolvable);
        resetAppendOnly(): void;
        get appendOnlyInput(): boolean | cdktn.IResolvable | undefined;
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _catalogArn?;
        get catalogArn(): string;
        set catalogArn(value: string);
        get catalogArnInput(): string | undefined;
        private _retryDuration?;
        get retryDuration(): number;
        set retryDuration(value: number);
        resetRetryDuration(): void;
        get retryDurationInput(): number | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _s3BackupMode?;
        get s3BackupMode(): string;
        set s3BackupMode(value: string);
        resetS3BackupMode(): void;
        get s3BackupModeInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): IcebergConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: IcebergConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): IcebergConfigurationCloudwatchLoggingOptionsProperty | undefined;
        private _destinationTableConfiguration;
        get destinationTableConfiguration(): DestinationTableConfigurationPropertyList;
        putDestinationTableConfiguration(value: DestinationTableConfigurationProperty[] | cdktn.IResolvable): void;
        resetDestinationTableConfiguration(): void;
        get destinationTableConfigurationInput(): cdktn.IResolvable | DestinationTableConfigurationProperty[] | undefined;
        private _processingConfiguration;
        get processingConfiguration(): IcebergConfigurationProcessingConfigurationPropertyOutputReference;
        putProcessingConfiguration(value: IcebergConfigurationProcessingConfigurationProperty): void;
        resetProcessingConfiguration(): void;
        get processingConfigurationInput(): IcebergConfigurationProcessingConfigurationProperty | undefined;
        private _s3Configuration;
        get s3Configuration(): IcebergConfigurationS3ConfigurationPropertyOutputReference;
        putS3Configuration(value: IcebergConfigurationS3ConfigurationProperty): void;
        get s3ConfigurationInput(): IcebergConfigurationS3ConfigurationProperty | undefined;
    }
    interface KinesisSourceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#kinesis_stream_arn AwsKinesisFirehoseDeliveryStream#kinesis_stream_arn}
        */
        readonly kinesisStreamArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
    }
    class KinesisSourceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisSourceConfigurationProperty | undefined;
        set internalValue(value: KinesisSourceConfigurationProperty | undefined);
        private _kinesisStreamArn?;
        get kinesisStreamArn(): string;
        set kinesisStreamArn(value: string);
        get kinesisStreamArnInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface AuthenticationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#connectivity AwsKinesisFirehoseDeliveryStream#connectivity}
        */
        readonly connectivity: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
    }
    class AuthenticationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthenticationConfigurationProperty | undefined;
        set internalValue(value: AuthenticationConfigurationProperty | undefined);
        private _connectivity?;
        get connectivity(): string;
        set connectivity(value: string);
        get connectivityInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface MskSourceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#msk_cluster_arn AwsKinesisFirehoseDeliveryStream#msk_cluster_arn}
        */
        readonly mskClusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#read_from_timestamp AwsKinesisFirehoseDeliveryStream#read_from_timestamp}
        */
        readonly readFromTimestamp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#topic_name AwsKinesisFirehoseDeliveryStream#topic_name}
        */
        readonly topicName: string;
        /**
        * authentication_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#authentication_configuration AwsKinesisFirehoseDeliveryStream#authentication_configuration}
        */
        readonly authenticationConfiguration: AuthenticationConfigurationProperty;
    }
    class MskSourceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MskSourceConfigurationProperty | undefined;
        set internalValue(value: MskSourceConfigurationProperty | undefined);
        private _mskClusterArn?;
        get mskClusterArn(): string;
        set mskClusterArn(value: string);
        get mskClusterArnInput(): string | undefined;
        private _readFromTimestamp?;
        get readFromTimestamp(): string;
        set readFromTimestamp(value: string);
        resetReadFromTimestamp(): void;
        get readFromTimestampInput(): string | undefined;
        private _topicName?;
        get topicName(): string;
        set topicName(value: string);
        get topicNameInput(): string | undefined;
        private _authenticationConfiguration;
        get authenticationConfiguration(): AuthenticationConfigurationPropertyOutputReference;
        putAuthenticationConfiguration(value: AuthenticationConfigurationProperty): void;
        get authenticationConfigurationInput(): AuthenticationConfigurationProperty | undefined;
    }
    interface OpensearchConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class OpensearchConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpensearchConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: OpensearchConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface DocumentIdOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#default_document_id_format AwsKinesisFirehoseDeliveryStream#default_document_id_format}
        */
        readonly defaultDocumentIdFormat: string;
    }
    class DocumentIdOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DocumentIdOptionsProperty | undefined;
        set internalValue(value: DocumentIdOptionsProperty | undefined);
        private _defaultDocumentIdFormat?;
        get defaultDocumentIdFormat(): string;
        set defaultDocumentIdFormat(value: string);
        get defaultDocumentIdFormatInput(): string | undefined;
    }
    interface OpensearchConfigurationProcessingConfigurationProcessorsParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_name AwsKinesisFirehoseDeliveryStream#parameter_name}
        */
        readonly parameterName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_value AwsKinesisFirehoseDeliveryStream#parameter_value}
        */
        readonly parameterValue: string;
    }
    class OpensearchConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpensearchConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpensearchConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined);
        private _parameterName?;
        get parameterName(): string;
        set parameterName(value: string);
        get parameterNameInput(): string | undefined;
        private _parameterValue?;
        get parameterValue(): string;
        set parameterValue(value: string);
        get parameterValueInput(): string | undefined;
    }
    class OpensearchConfigurationProcessingConfigurationProcessorsParametersPropertyList extends cdktn.ComplexList {
        internalValue?: OpensearchConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpensearchConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference;
    }
    interface OpensearchConfigurationProcessingConfigurationProcessorsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#type AwsKinesisFirehoseDeliveryStream#type}
        */
        readonly type: string;
        /**
        * parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameters AwsKinesisFirehoseDeliveryStream#parameters}
        */
        readonly parameters?: OpensearchConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
    }
    class OpensearchConfigurationProcessingConfigurationProcessorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpensearchConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpensearchConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _parameters;
        get parameters(): OpensearchConfigurationProcessingConfigurationProcessorsParametersPropertyList;
        putParameters(value: OpensearchConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable): void;
        resetParameters(): void;
        get parametersInput(): cdktn.IResolvable | OpensearchConfigurationProcessingConfigurationProcessorsParametersProperty[] | undefined;
    }
    class OpensearchConfigurationProcessingConfigurationProcessorsPropertyList extends cdktn.ComplexList {
        internalValue?: OpensearchConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpensearchConfigurationProcessingConfigurationProcessorsPropertyOutputReference;
    }
    interface OpensearchConfigurationProcessingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * processors block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processors AwsKinesisFirehoseDeliveryStream#processors}
        */
        readonly processors?: OpensearchConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
    }
    class OpensearchConfigurationProcessingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpensearchConfigurationProcessingConfigurationProperty | undefined;
        set internalValue(value: OpensearchConfigurationProcessingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _processors;
        get processors(): OpensearchConfigurationProcessingConfigurationProcessorsPropertyList;
        putProcessors(value: OpensearchConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable): void;
        resetProcessors(): void;
        get processorsInput(): cdktn.IResolvable | OpensearchConfigurationProcessingConfigurationProcessorsProperty[] | undefined;
    }
    interface OpensearchConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class OpensearchConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpensearchConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: OpensearchConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface OpensearchConfigurationS3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#bucket_arn AwsKinesisFirehoseDeliveryStream#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#compression_format AwsKinesisFirehoseDeliveryStream#compression_format}
        */
        readonly compressionFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#error_output_prefix AwsKinesisFirehoseDeliveryStream#error_output_prefix}
        */
        readonly errorOutputPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#kms_key_arn AwsKinesisFirehoseDeliveryStream#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#prefix AwsKinesisFirehoseDeliveryStream#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: OpensearchConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty;
    }
    class OpensearchConfigurationS3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpensearchConfigurationS3ConfigurationProperty | undefined;
        set internalValue(value: OpensearchConfigurationS3ConfigurationProperty | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _compressionFormat?;
        get compressionFormat(): string;
        set compressionFormat(value: string);
        resetCompressionFormat(): void;
        get compressionFormatInput(): string | undefined;
        private _errorOutputPrefix?;
        get errorOutputPrefix(): string;
        set errorOutputPrefix(value: string);
        resetErrorOutputPrefix(): void;
        get errorOutputPrefixInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): OpensearchConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: OpensearchConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): OpensearchConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
    }
    interface OpensearchConfigurationVpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#security_group_ids AwsKinesisFirehoseDeliveryStream#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#subnet_ids AwsKinesisFirehoseDeliveryStream#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class OpensearchConfigurationVpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpensearchConfigurationVpcConfigProperty | undefined;
        set internalValue(value: OpensearchConfigurationVpcConfigProperty | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        get vpcId(): string;
    }
    interface OpensearchConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cluster_endpoint AwsKinesisFirehoseDeliveryStream#cluster_endpoint}
        */
        readonly clusterEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#domain_arn AwsKinesisFirehoseDeliveryStream#domain_arn}
        */
        readonly domainArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#index_name AwsKinesisFirehoseDeliveryStream#index_name}
        */
        readonly indexName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#index_rotation_period AwsKinesisFirehoseDeliveryStream#index_rotation_period}
        */
        readonly indexRotationPeriod?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#retry_duration AwsKinesisFirehoseDeliveryStream#retry_duration}
        */
        readonly retryDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_backup_mode AwsKinesisFirehoseDeliveryStream#s3_backup_mode}
        */
        readonly s3BackupMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#type_name AwsKinesisFirehoseDeliveryStream#type_name}
        */
        readonly typeName?: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: OpensearchConfigurationCloudwatchLoggingOptionsProperty;
        /**
        * document_id_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#document_id_options AwsKinesisFirehoseDeliveryStream#document_id_options}
        */
        readonly documentIdOptions?: DocumentIdOptionsProperty;
        /**
        * processing_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processing_configuration AwsKinesisFirehoseDeliveryStream#processing_configuration}
        */
        readonly processingConfiguration?: OpensearchConfigurationProcessingConfigurationProperty;
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_configuration AwsKinesisFirehoseDeliveryStream#s3_configuration}
        */
        readonly s3Configuration: OpensearchConfigurationS3ConfigurationProperty;
        /**
        * vpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#vpc_config AwsKinesisFirehoseDeliveryStream#vpc_config}
        */
        readonly vpcConfig?: OpensearchConfigurationVpcConfigProperty;
    }
    class OpensearchConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpensearchConfigurationProperty | undefined;
        set internalValue(value: OpensearchConfigurationProperty | undefined);
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _clusterEndpoint?;
        get clusterEndpoint(): string;
        set clusterEndpoint(value: string);
        resetClusterEndpoint(): void;
        get clusterEndpointInput(): string | undefined;
        private _domainArn?;
        get domainArn(): string;
        set domainArn(value: string);
        resetDomainArn(): void;
        get domainArnInput(): string | undefined;
        private _indexName?;
        get indexName(): string;
        set indexName(value: string);
        get indexNameInput(): string | undefined;
        private _indexRotationPeriod?;
        get indexRotationPeriod(): string;
        set indexRotationPeriod(value: string);
        resetIndexRotationPeriod(): void;
        get indexRotationPeriodInput(): string | undefined;
        private _retryDuration?;
        get retryDuration(): number;
        set retryDuration(value: number);
        resetRetryDuration(): void;
        get retryDurationInput(): number | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _s3BackupMode?;
        get s3BackupMode(): string;
        set s3BackupMode(value: string);
        resetS3BackupMode(): void;
        get s3BackupModeInput(): string | undefined;
        private _typeName?;
        get typeName(): string;
        set typeName(value: string);
        resetTypeName(): void;
        get typeNameInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): OpensearchConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: OpensearchConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): OpensearchConfigurationCloudwatchLoggingOptionsProperty | undefined;
        private _documentIdOptions;
        get documentIdOptions(): DocumentIdOptionsPropertyOutputReference;
        putDocumentIdOptions(value: DocumentIdOptionsProperty): void;
        resetDocumentIdOptions(): void;
        get documentIdOptionsInput(): DocumentIdOptionsProperty | undefined;
        private _processingConfiguration;
        get processingConfiguration(): OpensearchConfigurationProcessingConfigurationPropertyOutputReference;
        putProcessingConfiguration(value: OpensearchConfigurationProcessingConfigurationProperty): void;
        resetProcessingConfiguration(): void;
        get processingConfigurationInput(): OpensearchConfigurationProcessingConfigurationProperty | undefined;
        private _s3Configuration;
        get s3Configuration(): OpensearchConfigurationS3ConfigurationPropertyOutputReference;
        putS3Configuration(value: OpensearchConfigurationS3ConfigurationProperty): void;
        get s3ConfigurationInput(): OpensearchConfigurationS3ConfigurationProperty | undefined;
        private _vpcConfig;
        get vpcConfig(): OpensearchConfigurationVpcConfigPropertyOutputReference;
        putVpcConfig(value: OpensearchConfigurationVpcConfigProperty): void;
        resetVpcConfig(): void;
        get vpcConfigInput(): OpensearchConfigurationVpcConfigProperty | undefined;
    }
    interface OpensearchserverlessConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class OpensearchserverlessConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpensearchserverlessConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: OpensearchserverlessConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface OpensearchserverlessConfigurationProcessingConfigurationProcessorsParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_name AwsKinesisFirehoseDeliveryStream#parameter_name}
        */
        readonly parameterName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_value AwsKinesisFirehoseDeliveryStream#parameter_value}
        */
        readonly parameterValue: string;
    }
    class OpensearchserverlessConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpensearchserverlessConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpensearchserverlessConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined);
        private _parameterName?;
        get parameterName(): string;
        set parameterName(value: string);
        get parameterNameInput(): string | undefined;
        private _parameterValue?;
        get parameterValue(): string;
        set parameterValue(value: string);
        get parameterValueInput(): string | undefined;
    }
    class OpensearchserverlessConfigurationProcessingConfigurationProcessorsParametersPropertyList extends cdktn.ComplexList {
        internalValue?: OpensearchserverlessConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpensearchserverlessConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference;
    }
    interface OpensearchserverlessConfigurationProcessingConfigurationProcessorsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#type AwsKinesisFirehoseDeliveryStream#type}
        */
        readonly type: string;
        /**
        * parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameters AwsKinesisFirehoseDeliveryStream#parameters}
        */
        readonly parameters?: OpensearchserverlessConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
    }
    class OpensearchserverlessConfigurationProcessingConfigurationProcessorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpensearchserverlessConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpensearchserverlessConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _parameters;
        get parameters(): OpensearchserverlessConfigurationProcessingConfigurationProcessorsParametersPropertyList;
        putParameters(value: OpensearchserverlessConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable): void;
        resetParameters(): void;
        get parametersInput(): cdktn.IResolvable | OpensearchserverlessConfigurationProcessingConfigurationProcessorsParametersProperty[] | undefined;
    }
    class OpensearchserverlessConfigurationProcessingConfigurationProcessorsPropertyList extends cdktn.ComplexList {
        internalValue?: OpensearchserverlessConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpensearchserverlessConfigurationProcessingConfigurationProcessorsPropertyOutputReference;
    }
    interface OpensearchserverlessConfigurationProcessingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * processors block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processors AwsKinesisFirehoseDeliveryStream#processors}
        */
        readonly processors?: OpensearchserverlessConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
    }
    class OpensearchserverlessConfigurationProcessingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpensearchserverlessConfigurationProcessingConfigurationProperty | undefined;
        set internalValue(value: OpensearchserverlessConfigurationProcessingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _processors;
        get processors(): OpensearchserverlessConfigurationProcessingConfigurationProcessorsPropertyList;
        putProcessors(value: OpensearchserverlessConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable): void;
        resetProcessors(): void;
        get processorsInput(): cdktn.IResolvable | OpensearchserverlessConfigurationProcessingConfigurationProcessorsProperty[] | undefined;
    }
    interface OpensearchserverlessConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class OpensearchserverlessConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpensearchserverlessConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: OpensearchserverlessConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface OpensearchserverlessConfigurationS3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#bucket_arn AwsKinesisFirehoseDeliveryStream#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#compression_format AwsKinesisFirehoseDeliveryStream#compression_format}
        */
        readonly compressionFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#error_output_prefix AwsKinesisFirehoseDeliveryStream#error_output_prefix}
        */
        readonly errorOutputPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#kms_key_arn AwsKinesisFirehoseDeliveryStream#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#prefix AwsKinesisFirehoseDeliveryStream#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: OpensearchserverlessConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty;
    }
    class OpensearchserverlessConfigurationS3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpensearchserverlessConfigurationS3ConfigurationProperty | undefined;
        set internalValue(value: OpensearchserverlessConfigurationS3ConfigurationProperty | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _compressionFormat?;
        get compressionFormat(): string;
        set compressionFormat(value: string);
        resetCompressionFormat(): void;
        get compressionFormatInput(): string | undefined;
        private _errorOutputPrefix?;
        get errorOutputPrefix(): string;
        set errorOutputPrefix(value: string);
        resetErrorOutputPrefix(): void;
        get errorOutputPrefixInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): OpensearchserverlessConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: OpensearchserverlessConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): OpensearchserverlessConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
    }
    interface OpensearchserverlessConfigurationVpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#security_group_ids AwsKinesisFirehoseDeliveryStream#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#subnet_ids AwsKinesisFirehoseDeliveryStream#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class OpensearchserverlessConfigurationVpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpensearchserverlessConfigurationVpcConfigProperty | undefined;
        set internalValue(value: OpensearchserverlessConfigurationVpcConfigProperty | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        get vpcId(): string;
    }
    interface OpensearchserverlessConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#collection_endpoint AwsKinesisFirehoseDeliveryStream#collection_endpoint}
        */
        readonly collectionEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#index_name AwsKinesisFirehoseDeliveryStream#index_name}
        */
        readonly indexName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#retry_duration AwsKinesisFirehoseDeliveryStream#retry_duration}
        */
        readonly retryDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_backup_mode AwsKinesisFirehoseDeliveryStream#s3_backup_mode}
        */
        readonly s3BackupMode?: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: OpensearchserverlessConfigurationCloudwatchLoggingOptionsProperty;
        /**
        * processing_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processing_configuration AwsKinesisFirehoseDeliveryStream#processing_configuration}
        */
        readonly processingConfiguration?: OpensearchserverlessConfigurationProcessingConfigurationProperty;
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_configuration AwsKinesisFirehoseDeliveryStream#s3_configuration}
        */
        readonly s3Configuration: OpensearchserverlessConfigurationS3ConfigurationProperty;
        /**
        * vpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#vpc_config AwsKinesisFirehoseDeliveryStream#vpc_config}
        */
        readonly vpcConfig?: OpensearchserverlessConfigurationVpcConfigProperty;
    }
    class OpensearchserverlessConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OpensearchserverlessConfigurationProperty | undefined;
        set internalValue(value: OpensearchserverlessConfigurationProperty | undefined);
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _collectionEndpoint?;
        get collectionEndpoint(): string;
        set collectionEndpoint(value: string);
        get collectionEndpointInput(): string | undefined;
        private _indexName?;
        get indexName(): string;
        set indexName(value: string);
        get indexNameInput(): string | undefined;
        private _retryDuration?;
        get retryDuration(): number;
        set retryDuration(value: number);
        resetRetryDuration(): void;
        get retryDurationInput(): number | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _s3BackupMode?;
        get s3BackupMode(): string;
        set s3BackupMode(value: string);
        resetS3BackupMode(): void;
        get s3BackupModeInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): OpensearchserverlessConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: OpensearchserverlessConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): OpensearchserverlessConfigurationCloudwatchLoggingOptionsProperty | undefined;
        private _processingConfiguration;
        get processingConfiguration(): OpensearchserverlessConfigurationProcessingConfigurationPropertyOutputReference;
        putProcessingConfiguration(value: OpensearchserverlessConfigurationProcessingConfigurationProperty): void;
        resetProcessingConfiguration(): void;
        get processingConfigurationInput(): OpensearchserverlessConfigurationProcessingConfigurationProperty | undefined;
        private _s3Configuration;
        get s3Configuration(): OpensearchserverlessConfigurationS3ConfigurationPropertyOutputReference;
        putS3Configuration(value: OpensearchserverlessConfigurationS3ConfigurationProperty): void;
        get s3ConfigurationInput(): OpensearchserverlessConfigurationS3ConfigurationProperty | undefined;
        private _vpcConfig;
        get vpcConfig(): OpensearchserverlessConfigurationVpcConfigPropertyOutputReference;
        putVpcConfig(value: OpensearchserverlessConfigurationVpcConfigProperty): void;
        resetVpcConfig(): void;
        get vpcConfigInput(): OpensearchserverlessConfigurationVpcConfigProperty | undefined;
    }
    interface RedshiftConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class RedshiftConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedshiftConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: RedshiftConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface RedshiftConfigurationProcessingConfigurationProcessorsParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_name AwsKinesisFirehoseDeliveryStream#parameter_name}
        */
        readonly parameterName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_value AwsKinesisFirehoseDeliveryStream#parameter_value}
        */
        readonly parameterValue: string;
    }
    class RedshiftConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RedshiftConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RedshiftConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined);
        private _parameterName?;
        get parameterName(): string;
        set parameterName(value: string);
        get parameterNameInput(): string | undefined;
        private _parameterValue?;
        get parameterValue(): string;
        set parameterValue(value: string);
        get parameterValueInput(): string | undefined;
    }
    class RedshiftConfigurationProcessingConfigurationProcessorsParametersPropertyList extends cdktn.ComplexList {
        internalValue?: RedshiftConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RedshiftConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference;
    }
    interface RedshiftConfigurationProcessingConfigurationProcessorsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#type AwsKinesisFirehoseDeliveryStream#type}
        */
        readonly type: string;
        /**
        * parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameters AwsKinesisFirehoseDeliveryStream#parameters}
        */
        readonly parameters?: RedshiftConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
    }
    class RedshiftConfigurationProcessingConfigurationProcessorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RedshiftConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RedshiftConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _parameters;
        get parameters(): RedshiftConfigurationProcessingConfigurationProcessorsParametersPropertyList;
        putParameters(value: RedshiftConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable): void;
        resetParameters(): void;
        get parametersInput(): cdktn.IResolvable | RedshiftConfigurationProcessingConfigurationProcessorsParametersProperty[] | undefined;
    }
    class RedshiftConfigurationProcessingConfigurationProcessorsPropertyList extends cdktn.ComplexList {
        internalValue?: RedshiftConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RedshiftConfigurationProcessingConfigurationProcessorsPropertyOutputReference;
    }
    interface RedshiftConfigurationProcessingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * processors block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processors AwsKinesisFirehoseDeliveryStream#processors}
        */
        readonly processors?: RedshiftConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
    }
    class RedshiftConfigurationProcessingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedshiftConfigurationProcessingConfigurationProperty | undefined;
        set internalValue(value: RedshiftConfigurationProcessingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _processors;
        get processors(): RedshiftConfigurationProcessingConfigurationProcessorsPropertyList;
        putProcessors(value: RedshiftConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable): void;
        resetProcessors(): void;
        get processorsInput(): cdktn.IResolvable | RedshiftConfigurationProcessingConfigurationProcessorsProperty[] | undefined;
    }
    interface RedshiftConfigurationS3BackupConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class RedshiftConfigurationS3BackupConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedshiftConfigurationS3BackupConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: RedshiftConfigurationS3BackupConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface RedshiftConfigurationS3BackupConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#bucket_arn AwsKinesisFirehoseDeliveryStream#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#compression_format AwsKinesisFirehoseDeliveryStream#compression_format}
        */
        readonly compressionFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#error_output_prefix AwsKinesisFirehoseDeliveryStream#error_output_prefix}
        */
        readonly errorOutputPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#kms_key_arn AwsKinesisFirehoseDeliveryStream#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#prefix AwsKinesisFirehoseDeliveryStream#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: RedshiftConfigurationS3BackupConfigurationCloudwatchLoggingOptionsProperty;
    }
    class RedshiftConfigurationS3BackupConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedshiftConfigurationS3BackupConfigurationProperty | undefined;
        set internalValue(value: RedshiftConfigurationS3BackupConfigurationProperty | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _compressionFormat?;
        get compressionFormat(): string;
        set compressionFormat(value: string);
        resetCompressionFormat(): void;
        get compressionFormatInput(): string | undefined;
        private _errorOutputPrefix?;
        get errorOutputPrefix(): string;
        set errorOutputPrefix(value: string);
        resetErrorOutputPrefix(): void;
        get errorOutputPrefixInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): RedshiftConfigurationS3BackupConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: RedshiftConfigurationS3BackupConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): RedshiftConfigurationS3BackupConfigurationCloudwatchLoggingOptionsProperty | undefined;
    }
    interface RedshiftConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class RedshiftConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedshiftConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: RedshiftConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface RedshiftConfigurationS3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#bucket_arn AwsKinesisFirehoseDeliveryStream#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#compression_format AwsKinesisFirehoseDeliveryStream#compression_format}
        */
        readonly compressionFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#error_output_prefix AwsKinesisFirehoseDeliveryStream#error_output_prefix}
        */
        readonly errorOutputPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#kms_key_arn AwsKinesisFirehoseDeliveryStream#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#prefix AwsKinesisFirehoseDeliveryStream#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: RedshiftConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty;
    }
    class RedshiftConfigurationS3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedshiftConfigurationS3ConfigurationProperty | undefined;
        set internalValue(value: RedshiftConfigurationS3ConfigurationProperty | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _compressionFormat?;
        get compressionFormat(): string;
        set compressionFormat(value: string);
        resetCompressionFormat(): void;
        get compressionFormatInput(): string | undefined;
        private _errorOutputPrefix?;
        get errorOutputPrefix(): string;
        set errorOutputPrefix(value: string);
        resetErrorOutputPrefix(): void;
        get errorOutputPrefixInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): RedshiftConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: RedshiftConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): RedshiftConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
    }
    interface RedshiftConfigurationSecretsManagerConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#secret_arn AwsKinesisFirehoseDeliveryStream#secret_arn}
        */
        readonly secretArn?: string;
    }
    class RedshiftConfigurationSecretsManagerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedshiftConfigurationSecretsManagerConfigurationProperty | undefined;
        set internalValue(value: RedshiftConfigurationSecretsManagerConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _secretArn?;
        get secretArn(): string;
        set secretArn(value: string);
        resetSecretArn(): void;
        get secretArnInput(): string | undefined;
    }
    interface RedshiftConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cluster_jdbcurl AwsKinesisFirehoseDeliveryStream#cluster_jdbcurl}
        */
        readonly clusterJdbcurl: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#copy_options AwsKinesisFirehoseDeliveryStream#copy_options}
        */
        readonly copyOptions?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#data_table_columns AwsKinesisFirehoseDeliveryStream#data_table_columns}
        */
        readonly dataTableColumns?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#data_table_name AwsKinesisFirehoseDeliveryStream#data_table_name}
        */
        readonly dataTableName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#password AwsKinesisFirehoseDeliveryStream#password}
        */
        readonly password?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#retry_duration AwsKinesisFirehoseDeliveryStream#retry_duration}
        */
        readonly retryDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_backup_mode AwsKinesisFirehoseDeliveryStream#s3_backup_mode}
        */
        readonly s3BackupMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#username AwsKinesisFirehoseDeliveryStream#username}
        */
        readonly username?: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: RedshiftConfigurationCloudwatchLoggingOptionsProperty;
        /**
        * processing_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processing_configuration AwsKinesisFirehoseDeliveryStream#processing_configuration}
        */
        readonly processingConfiguration?: RedshiftConfigurationProcessingConfigurationProperty;
        /**
        * s3_backup_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_backup_configuration AwsKinesisFirehoseDeliveryStream#s3_backup_configuration}
        */
        readonly s3BackupConfiguration?: RedshiftConfigurationS3BackupConfigurationProperty;
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_configuration AwsKinesisFirehoseDeliveryStream#s3_configuration}
        */
        readonly s3Configuration: RedshiftConfigurationS3ConfigurationProperty;
        /**
        * secrets_manager_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#secrets_manager_configuration AwsKinesisFirehoseDeliveryStream#secrets_manager_configuration}
        */
        readonly secretsManagerConfiguration?: RedshiftConfigurationSecretsManagerConfigurationProperty;
    }
    class RedshiftConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedshiftConfigurationProperty | undefined;
        set internalValue(value: RedshiftConfigurationProperty | undefined);
        private _clusterJdbcurl?;
        get clusterJdbcurl(): string;
        set clusterJdbcurl(value: string);
        get clusterJdbcurlInput(): string | undefined;
        private _copyOptions?;
        get copyOptions(): string;
        set copyOptions(value: string);
        resetCopyOptions(): void;
        get copyOptionsInput(): string | undefined;
        private _dataTableColumns?;
        get dataTableColumns(): string;
        set dataTableColumns(value: string);
        resetDataTableColumns(): void;
        get dataTableColumnsInput(): string | undefined;
        private _dataTableName?;
        get dataTableName(): string;
        set dataTableName(value: string);
        get dataTableNameInput(): string | undefined;
        private _password?;
        get password(): string;
        set password(value: string);
        resetPassword(): void;
        get passwordInput(): string | undefined;
        private _retryDuration?;
        get retryDuration(): number;
        set retryDuration(value: number);
        resetRetryDuration(): void;
        get retryDurationInput(): number | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _s3BackupMode?;
        get s3BackupMode(): string;
        set s3BackupMode(value: string);
        resetS3BackupMode(): void;
        get s3BackupModeInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        resetUsername(): void;
        get usernameInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): RedshiftConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: RedshiftConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): RedshiftConfigurationCloudwatchLoggingOptionsProperty | undefined;
        private _processingConfiguration;
        get processingConfiguration(): RedshiftConfigurationProcessingConfigurationPropertyOutputReference;
        putProcessingConfiguration(value: RedshiftConfigurationProcessingConfigurationProperty): void;
        resetProcessingConfiguration(): void;
        get processingConfigurationInput(): RedshiftConfigurationProcessingConfigurationProperty | undefined;
        private _s3BackupConfiguration;
        get s3BackupConfiguration(): RedshiftConfigurationS3BackupConfigurationPropertyOutputReference;
        putS3BackupConfiguration(value: RedshiftConfigurationS3BackupConfigurationProperty): void;
        resetS3BackupConfiguration(): void;
        get s3BackupConfigurationInput(): RedshiftConfigurationS3BackupConfigurationProperty | undefined;
        private _s3Configuration;
        get s3Configuration(): RedshiftConfigurationS3ConfigurationPropertyOutputReference;
        putS3Configuration(value: RedshiftConfigurationS3ConfigurationProperty): void;
        get s3ConfigurationInput(): RedshiftConfigurationS3ConfigurationProperty | undefined;
        private _secretsManagerConfiguration;
        get secretsManagerConfiguration(): RedshiftConfigurationSecretsManagerConfigurationPropertyOutputReference;
        putSecretsManagerConfiguration(value: RedshiftConfigurationSecretsManagerConfigurationProperty): void;
        resetSecretsManagerConfiguration(): void;
        get secretsManagerConfigurationInput(): RedshiftConfigurationSecretsManagerConfigurationProperty | undefined;
    }
    interface ServerSideEncryptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#key_arn AwsKinesisFirehoseDeliveryStream#key_arn}
        */
        readonly keyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#key_type AwsKinesisFirehoseDeliveryStream#key_type}
        */
        readonly keyType?: string;
    }
    class ServerSideEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServerSideEncryptionProperty | undefined;
        set internalValue(value: ServerSideEncryptionProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _keyArn?;
        get keyArn(): string;
        set keyArn(value: string);
        resetKeyArn(): void;
        get keyArnInput(): string | undefined;
        private _keyType?;
        get keyType(): string;
        set keyType(value: string);
        resetKeyType(): void;
        get keyTypeInput(): string | undefined;
    }
    interface SnowflakeConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class SnowflakeConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnowflakeConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: SnowflakeConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface SnowflakeConfigurationProcessingConfigurationProcessorsParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_name AwsKinesisFirehoseDeliveryStream#parameter_name}
        */
        readonly parameterName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_value AwsKinesisFirehoseDeliveryStream#parameter_value}
        */
        readonly parameterValue: string;
    }
    class SnowflakeConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnowflakeConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SnowflakeConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined);
        private _parameterName?;
        get parameterName(): string;
        set parameterName(value: string);
        get parameterNameInput(): string | undefined;
        private _parameterValue?;
        get parameterValue(): string;
        set parameterValue(value: string);
        get parameterValueInput(): string | undefined;
    }
    class SnowflakeConfigurationProcessingConfigurationProcessorsParametersPropertyList extends cdktn.ComplexList {
        internalValue?: SnowflakeConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnowflakeConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference;
    }
    interface SnowflakeConfigurationProcessingConfigurationProcessorsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#type AwsKinesisFirehoseDeliveryStream#type}
        */
        readonly type: string;
        /**
        * parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameters AwsKinesisFirehoseDeliveryStream#parameters}
        */
        readonly parameters?: SnowflakeConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
    }
    class SnowflakeConfigurationProcessingConfigurationProcessorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnowflakeConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SnowflakeConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _parameters;
        get parameters(): SnowflakeConfigurationProcessingConfigurationProcessorsParametersPropertyList;
        putParameters(value: SnowflakeConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable): void;
        resetParameters(): void;
        get parametersInput(): cdktn.IResolvable | SnowflakeConfigurationProcessingConfigurationProcessorsParametersProperty[] | undefined;
    }
    class SnowflakeConfigurationProcessingConfigurationProcessorsPropertyList extends cdktn.ComplexList {
        internalValue?: SnowflakeConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnowflakeConfigurationProcessingConfigurationProcessorsPropertyOutputReference;
    }
    interface SnowflakeConfigurationProcessingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * processors block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processors AwsKinesisFirehoseDeliveryStream#processors}
        */
        readonly processors?: SnowflakeConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
    }
    class SnowflakeConfigurationProcessingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnowflakeConfigurationProcessingConfigurationProperty | undefined;
        set internalValue(value: SnowflakeConfigurationProcessingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _processors;
        get processors(): SnowflakeConfigurationProcessingConfigurationProcessorsPropertyList;
        putProcessors(value: SnowflakeConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable): void;
        resetProcessors(): void;
        get processorsInput(): cdktn.IResolvable | SnowflakeConfigurationProcessingConfigurationProcessorsProperty[] | undefined;
    }
    interface SnowflakeConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class SnowflakeConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnowflakeConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: SnowflakeConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface SnowflakeConfigurationS3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#bucket_arn AwsKinesisFirehoseDeliveryStream#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#compression_format AwsKinesisFirehoseDeliveryStream#compression_format}
        */
        readonly compressionFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#error_output_prefix AwsKinesisFirehoseDeliveryStream#error_output_prefix}
        */
        readonly errorOutputPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#kms_key_arn AwsKinesisFirehoseDeliveryStream#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#prefix AwsKinesisFirehoseDeliveryStream#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: SnowflakeConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty;
    }
    class SnowflakeConfigurationS3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnowflakeConfigurationS3ConfigurationProperty | undefined;
        set internalValue(value: SnowflakeConfigurationS3ConfigurationProperty | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _compressionFormat?;
        get compressionFormat(): string;
        set compressionFormat(value: string);
        resetCompressionFormat(): void;
        get compressionFormatInput(): string | undefined;
        private _errorOutputPrefix?;
        get errorOutputPrefix(): string;
        set errorOutputPrefix(value: string);
        resetErrorOutputPrefix(): void;
        get errorOutputPrefixInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): SnowflakeConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: SnowflakeConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): SnowflakeConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
    }
    interface SnowflakeConfigurationSecretsManagerConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#secret_arn AwsKinesisFirehoseDeliveryStream#secret_arn}
        */
        readonly secretArn?: string;
    }
    class SnowflakeConfigurationSecretsManagerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnowflakeConfigurationSecretsManagerConfigurationProperty | undefined;
        set internalValue(value: SnowflakeConfigurationSecretsManagerConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _secretArn?;
        get secretArn(): string;
        set secretArn(value: string);
        resetSecretArn(): void;
        get secretArnInput(): string | undefined;
    }
    interface SnowflakeRoleConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#snowflake_role AwsKinesisFirehoseDeliveryStream#snowflake_role}
        */
        readonly snowflakeRole?: string;
    }
    class SnowflakeRoleConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnowflakeRoleConfigurationProperty | undefined;
        set internalValue(value: SnowflakeRoleConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _snowflakeRole?;
        get snowflakeRole(): string;
        set snowflakeRole(value: string);
        resetSnowflakeRole(): void;
        get snowflakeRoleInput(): string | undefined;
    }
    interface SnowflakeVpcConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#private_link_vpce_id AwsKinesisFirehoseDeliveryStream#private_link_vpce_id}
        */
        readonly privateLinkVpceId: string;
    }
    class SnowflakeVpcConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnowflakeVpcConfigurationProperty | undefined;
        set internalValue(value: SnowflakeVpcConfigurationProperty | undefined);
        private _privateLinkVpceId?;
        get privateLinkVpceId(): string;
        set privateLinkVpceId(value: string);
        get privateLinkVpceIdInput(): string | undefined;
    }
    interface SnowflakeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#account_url AwsKinesisFirehoseDeliveryStream#account_url}
        */
        readonly accountUrl: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#content_column_name AwsKinesisFirehoseDeliveryStream#content_column_name}
        */
        readonly contentColumnName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#data_loading_option AwsKinesisFirehoseDeliveryStream#data_loading_option}
        */
        readonly dataLoadingOption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#database AwsKinesisFirehoseDeliveryStream#database}
        */
        readonly database: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#key_passphrase AwsKinesisFirehoseDeliveryStream#key_passphrase}
        */
        readonly keyPassphrase?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#metadata_column_name AwsKinesisFirehoseDeliveryStream#metadata_column_name}
        */
        readonly metadataColumnName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#private_key AwsKinesisFirehoseDeliveryStream#private_key}
        */
        readonly privateKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#retry_duration AwsKinesisFirehoseDeliveryStream#retry_duration}
        */
        readonly retryDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_backup_mode AwsKinesisFirehoseDeliveryStream#s3_backup_mode}
        */
        readonly s3BackupMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#schema AwsKinesisFirehoseDeliveryStream#schema}
        */
        readonly schema: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#table AwsKinesisFirehoseDeliveryStream#table}
        */
        readonly table: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#user AwsKinesisFirehoseDeliveryStream#user}
        */
        readonly user?: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: SnowflakeConfigurationCloudwatchLoggingOptionsProperty;
        /**
        * processing_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processing_configuration AwsKinesisFirehoseDeliveryStream#processing_configuration}
        */
        readonly processingConfiguration?: SnowflakeConfigurationProcessingConfigurationProperty;
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_configuration AwsKinesisFirehoseDeliveryStream#s3_configuration}
        */
        readonly s3Configuration: SnowflakeConfigurationS3ConfigurationProperty;
        /**
        * secrets_manager_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#secrets_manager_configuration AwsKinesisFirehoseDeliveryStream#secrets_manager_configuration}
        */
        readonly secretsManagerConfiguration?: SnowflakeConfigurationSecretsManagerConfigurationProperty;
        /**
        * snowflake_role_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#snowflake_role_configuration AwsKinesisFirehoseDeliveryStream#snowflake_role_configuration}
        */
        readonly snowflakeRoleConfiguration?: SnowflakeRoleConfigurationProperty;
        /**
        * snowflake_vpc_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#snowflake_vpc_configuration AwsKinesisFirehoseDeliveryStream#snowflake_vpc_configuration}
        */
        readonly snowflakeVpcConfiguration?: SnowflakeVpcConfigurationProperty;
    }
    class SnowflakeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnowflakeConfigurationProperty | undefined;
        set internalValue(value: SnowflakeConfigurationProperty | undefined);
        private _accountUrl?;
        get accountUrl(): string;
        set accountUrl(value: string);
        get accountUrlInput(): string | undefined;
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _contentColumnName?;
        get contentColumnName(): string;
        set contentColumnName(value: string);
        resetContentColumnName(): void;
        get contentColumnNameInput(): string | undefined;
        private _dataLoadingOption?;
        get dataLoadingOption(): string;
        set dataLoadingOption(value: string);
        resetDataLoadingOption(): void;
        get dataLoadingOptionInput(): string | undefined;
        private _database?;
        get database(): string;
        set database(value: string);
        get databaseInput(): string | undefined;
        private _keyPassphrase?;
        get keyPassphrase(): string;
        set keyPassphrase(value: string);
        resetKeyPassphrase(): void;
        get keyPassphraseInput(): string | undefined;
        private _metadataColumnName?;
        get metadataColumnName(): string;
        set metadataColumnName(value: string);
        resetMetadataColumnName(): void;
        get metadataColumnNameInput(): string | undefined;
        private _privateKey?;
        get privateKey(): string;
        set privateKey(value: string);
        resetPrivateKey(): void;
        get privateKeyInput(): string | undefined;
        private _retryDuration?;
        get retryDuration(): number;
        set retryDuration(value: number);
        resetRetryDuration(): void;
        get retryDurationInput(): number | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _s3BackupMode?;
        get s3BackupMode(): string;
        set s3BackupMode(value: string);
        resetS3BackupMode(): void;
        get s3BackupModeInput(): string | undefined;
        private _schema?;
        get schema(): string;
        set schema(value: string);
        get schemaInput(): string | undefined;
        private _table?;
        get table(): string;
        set table(value: string);
        get tableInput(): string | undefined;
        private _user?;
        get user(): string;
        set user(value: string);
        resetUser(): void;
        get userInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): SnowflakeConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: SnowflakeConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): SnowflakeConfigurationCloudwatchLoggingOptionsProperty | undefined;
        private _processingConfiguration;
        get processingConfiguration(): SnowflakeConfigurationProcessingConfigurationPropertyOutputReference;
        putProcessingConfiguration(value: SnowflakeConfigurationProcessingConfigurationProperty): void;
        resetProcessingConfiguration(): void;
        get processingConfigurationInput(): SnowflakeConfigurationProcessingConfigurationProperty | undefined;
        private _s3Configuration;
        get s3Configuration(): SnowflakeConfigurationS3ConfigurationPropertyOutputReference;
        putS3Configuration(value: SnowflakeConfigurationS3ConfigurationProperty): void;
        get s3ConfigurationInput(): SnowflakeConfigurationS3ConfigurationProperty | undefined;
        private _secretsManagerConfiguration;
        get secretsManagerConfiguration(): SnowflakeConfigurationSecretsManagerConfigurationPropertyOutputReference;
        putSecretsManagerConfiguration(value: SnowflakeConfigurationSecretsManagerConfigurationProperty): void;
        resetSecretsManagerConfiguration(): void;
        get secretsManagerConfigurationInput(): SnowflakeConfigurationSecretsManagerConfigurationProperty | undefined;
        private _snowflakeRoleConfiguration;
        get snowflakeRoleConfiguration(): SnowflakeRoleConfigurationPropertyOutputReference;
        putSnowflakeRoleConfiguration(value: SnowflakeRoleConfigurationProperty): void;
        resetSnowflakeRoleConfiguration(): void;
        get snowflakeRoleConfigurationInput(): SnowflakeRoleConfigurationProperty | undefined;
        private _snowflakeVpcConfiguration;
        get snowflakeVpcConfiguration(): SnowflakeVpcConfigurationPropertyOutputReference;
        putSnowflakeVpcConfiguration(value: SnowflakeVpcConfigurationProperty): void;
        resetSnowflakeVpcConfiguration(): void;
        get snowflakeVpcConfigurationInput(): SnowflakeVpcConfigurationProperty | undefined;
    }
    interface SplunkConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class SplunkConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SplunkConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: SplunkConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface SplunkConfigurationProcessingConfigurationProcessorsParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_name AwsKinesisFirehoseDeliveryStream#parameter_name}
        */
        readonly parameterName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameter_value AwsKinesisFirehoseDeliveryStream#parameter_value}
        */
        readonly parameterValue: string;
    }
    class SplunkConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SplunkConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SplunkConfigurationProcessingConfigurationProcessorsParametersProperty | cdktn.IResolvable | undefined);
        private _parameterName?;
        get parameterName(): string;
        set parameterName(value: string);
        get parameterNameInput(): string | undefined;
        private _parameterValue?;
        get parameterValue(): string;
        set parameterValue(value: string);
        get parameterValueInput(): string | undefined;
    }
    class SplunkConfigurationProcessingConfigurationProcessorsParametersPropertyList extends cdktn.ComplexList {
        internalValue?: SplunkConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SplunkConfigurationProcessingConfigurationProcessorsParametersPropertyOutputReference;
    }
    interface SplunkConfigurationProcessingConfigurationProcessorsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#type AwsKinesisFirehoseDeliveryStream#type}
        */
        readonly type: string;
        /**
        * parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#parameters AwsKinesisFirehoseDeliveryStream#parameters}
        */
        readonly parameters?: SplunkConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable;
    }
    class SplunkConfigurationProcessingConfigurationProcessorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SplunkConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SplunkConfigurationProcessingConfigurationProcessorsProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _parameters;
        get parameters(): SplunkConfigurationProcessingConfigurationProcessorsParametersPropertyList;
        putParameters(value: SplunkConfigurationProcessingConfigurationProcessorsParametersProperty[] | cdktn.IResolvable): void;
        resetParameters(): void;
        get parametersInput(): cdktn.IResolvable | SplunkConfigurationProcessingConfigurationProcessorsParametersProperty[] | undefined;
    }
    class SplunkConfigurationProcessingConfigurationProcessorsPropertyList extends cdktn.ComplexList {
        internalValue?: SplunkConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SplunkConfigurationProcessingConfigurationProcessorsPropertyOutputReference;
    }
    interface SplunkConfigurationProcessingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * processors block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processors AwsKinesisFirehoseDeliveryStream#processors}
        */
        readonly processors?: SplunkConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable;
    }
    class SplunkConfigurationProcessingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SplunkConfigurationProcessingConfigurationProperty | undefined;
        set internalValue(value: SplunkConfigurationProcessingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _processors;
        get processors(): SplunkConfigurationProcessingConfigurationProcessorsPropertyList;
        putProcessors(value: SplunkConfigurationProcessingConfigurationProcessorsProperty[] | cdktn.IResolvable): void;
        resetProcessors(): void;
        get processorsInput(): cdktn.IResolvable | SplunkConfigurationProcessingConfigurationProcessorsProperty[] | undefined;
    }
    interface SplunkConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_group_name AwsKinesisFirehoseDeliveryStream#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#log_stream_name AwsKinesisFirehoseDeliveryStream#log_stream_name}
        */
        readonly logStreamName?: string;
    }
    class SplunkConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SplunkConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: SplunkConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamName?;
        get logStreamName(): string;
        set logStreamName(value: string);
        resetLogStreamName(): void;
        get logStreamNameInput(): string | undefined;
    }
    interface SplunkConfigurationS3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#bucket_arn AwsKinesisFirehoseDeliveryStream#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#compression_format AwsKinesisFirehoseDeliveryStream#compression_format}
        */
        readonly compressionFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#error_output_prefix AwsKinesisFirehoseDeliveryStream#error_output_prefix}
        */
        readonly errorOutputPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#kms_key_arn AwsKinesisFirehoseDeliveryStream#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#prefix AwsKinesisFirehoseDeliveryStream#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: SplunkConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty;
    }
    class SplunkConfigurationS3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SplunkConfigurationS3ConfigurationProperty | undefined;
        set internalValue(value: SplunkConfigurationS3ConfigurationProperty | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _compressionFormat?;
        get compressionFormat(): string;
        set compressionFormat(value: string);
        resetCompressionFormat(): void;
        get compressionFormatInput(): string | undefined;
        private _errorOutputPrefix?;
        get errorOutputPrefix(): string;
        set errorOutputPrefix(value: string);
        resetErrorOutputPrefix(): void;
        get errorOutputPrefixInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): SplunkConfigurationS3ConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: SplunkConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): SplunkConfigurationS3ConfigurationCloudwatchLoggingOptionsProperty | undefined;
    }
    interface SplunkConfigurationSecretsManagerConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#enabled AwsKinesisFirehoseDeliveryStream#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#role_arn AwsKinesisFirehoseDeliveryStream#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#secret_arn AwsKinesisFirehoseDeliveryStream#secret_arn}
        */
        readonly secretArn?: string;
    }
    class SplunkConfigurationSecretsManagerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SplunkConfigurationSecretsManagerConfigurationProperty | undefined;
        set internalValue(value: SplunkConfigurationSecretsManagerConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _secretArn?;
        get secretArn(): string;
        set secretArn(value: string);
        resetSecretArn(): void;
        get secretArnInput(): string | undefined;
    }
    interface SplunkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_interval AwsKinesisFirehoseDeliveryStream#buffering_interval}
        */
        readonly bufferingInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#buffering_size AwsKinesisFirehoseDeliveryStream#buffering_size}
        */
        readonly bufferingSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#hec_acknowledgment_timeout AwsKinesisFirehoseDeliveryStream#hec_acknowledgment_timeout}
        */
        readonly hecAcknowledgmentTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#hec_endpoint AwsKinesisFirehoseDeliveryStream#hec_endpoint}
        */
        readonly hecEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#hec_endpoint_type AwsKinesisFirehoseDeliveryStream#hec_endpoint_type}
        */
        readonly hecEndpointType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#hec_token AwsKinesisFirehoseDeliveryStream#hec_token}
        */
        readonly hecToken?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#retry_duration AwsKinesisFirehoseDeliveryStream#retry_duration}
        */
        readonly retryDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_backup_mode AwsKinesisFirehoseDeliveryStream#s3_backup_mode}
        */
        readonly s3BackupMode?: string;
        /**
        * cloudwatch_logging_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#cloudwatch_logging_options AwsKinesisFirehoseDeliveryStream#cloudwatch_logging_options}
        */
        readonly cloudwatchLoggingOptions?: SplunkConfigurationCloudwatchLoggingOptionsProperty;
        /**
        * processing_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#processing_configuration AwsKinesisFirehoseDeliveryStream#processing_configuration}
        */
        readonly processingConfiguration?: SplunkConfigurationProcessingConfigurationProperty;
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#s3_configuration AwsKinesisFirehoseDeliveryStream#s3_configuration}
        */
        readonly s3Configuration: SplunkConfigurationS3ConfigurationProperty;
        /**
        * secrets_manager_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#secrets_manager_configuration AwsKinesisFirehoseDeliveryStream#secrets_manager_configuration}
        */
        readonly secretsManagerConfiguration?: SplunkConfigurationSecretsManagerConfigurationProperty;
    }
    class SplunkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SplunkConfigurationProperty | undefined;
        set internalValue(value: SplunkConfigurationProperty | undefined);
        private _bufferingInterval?;
        get bufferingInterval(): number;
        set bufferingInterval(value: number);
        resetBufferingInterval(): void;
        get bufferingIntervalInput(): number | undefined;
        private _bufferingSize?;
        get bufferingSize(): number;
        set bufferingSize(value: number);
        resetBufferingSize(): void;
        get bufferingSizeInput(): number | undefined;
        private _hecAcknowledgmentTimeout?;
        get hecAcknowledgmentTimeout(): number;
        set hecAcknowledgmentTimeout(value: number);
        resetHecAcknowledgmentTimeout(): void;
        get hecAcknowledgmentTimeoutInput(): number | undefined;
        private _hecEndpoint?;
        get hecEndpoint(): string;
        set hecEndpoint(value: string);
        get hecEndpointInput(): string | undefined;
        private _hecEndpointType?;
        get hecEndpointType(): string;
        set hecEndpointType(value: string);
        resetHecEndpointType(): void;
        get hecEndpointTypeInput(): string | undefined;
        private _hecToken?;
        get hecToken(): string;
        set hecToken(value: string);
        resetHecToken(): void;
        get hecTokenInput(): string | undefined;
        private _retryDuration?;
        get retryDuration(): number;
        set retryDuration(value: number);
        resetRetryDuration(): void;
        get retryDurationInput(): number | undefined;
        private _s3BackupMode?;
        get s3BackupMode(): string;
        set s3BackupMode(value: string);
        resetS3BackupMode(): void;
        get s3BackupModeInput(): string | undefined;
        private _cloudwatchLoggingOptions;
        get cloudwatchLoggingOptions(): SplunkConfigurationCloudwatchLoggingOptionsPropertyOutputReference;
        putCloudwatchLoggingOptions(value: SplunkConfigurationCloudwatchLoggingOptionsProperty): void;
        resetCloudwatchLoggingOptions(): void;
        get cloudwatchLoggingOptionsInput(): SplunkConfigurationCloudwatchLoggingOptionsProperty | undefined;
        private _processingConfiguration;
        get processingConfiguration(): SplunkConfigurationProcessingConfigurationPropertyOutputReference;
        putProcessingConfiguration(value: SplunkConfigurationProcessingConfigurationProperty): void;
        resetProcessingConfiguration(): void;
        get processingConfigurationInput(): SplunkConfigurationProcessingConfigurationProperty | undefined;
        private _s3Configuration;
        get s3Configuration(): SplunkConfigurationS3ConfigurationPropertyOutputReference;
        putS3Configuration(value: SplunkConfigurationS3ConfigurationProperty): void;
        get s3ConfigurationInput(): SplunkConfigurationS3ConfigurationProperty | undefined;
        private _secretsManagerConfiguration;
        get secretsManagerConfiguration(): SplunkConfigurationSecretsManagerConfigurationPropertyOutputReference;
        putSecretsManagerConfiguration(value: SplunkConfigurationSecretsManagerConfigurationProperty): void;
        resetSecretsManagerConfiguration(): void;
        get secretsManagerConfigurationInput(): SplunkConfigurationSecretsManagerConfigurationProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#create AwsKinesisFirehoseDeliveryStream#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#delete AwsKinesisFirehoseDeliveryStream#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_firehose_delivery_stream#update AwsKinesisFirehoseDeliveryStream#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
