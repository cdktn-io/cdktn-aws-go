import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsConfigRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#description AwsConfigRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#id AwsConfigRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#input_parameters AwsConfigRule#input_parameters}
    */
    readonly inputParameters?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#maximum_execution_frequency AwsConfigRule#maximum_execution_frequency}
    */
    readonly maximumExecutionFrequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#name AwsConfigRule#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#region AwsConfigRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#tags AwsConfigRule#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#tags_all AwsConfigRule#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * evaluation_mode block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#evaluation_mode AwsConfigRule#evaluation_mode}
    */
    readonly evaluationMode?: AwsConfigRule.EvaluationModeProperty[] | cdktn.IResolvable;
    /**
    * scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#scope AwsConfigRule#scope}
    */
    readonly scope?: AwsConfigRule.ScopeProperty;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#source AwsConfigRule#source}
    */
    readonly source: AwsConfigRule.SourceProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule aws_config_config_rule}
*/
export declare class AwsConfigRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_config_config_rule";
    /**
    * Generates CDKTN code for importing a AwsConfigRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsConfigRule to import
    * @param importFromId The id of the existing AwsConfigRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsConfigRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule aws_config_config_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsConfigRuleConfig
    */
    constructor(scope: Construct, id: string, config: AwsConfigRuleConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputParameters?;
    get inputParameters(): string;
    set inputParameters(value: string);
    resetInputParameters(): void;
    get inputParametersInput(): string | undefined;
    private _maximumExecutionFrequency?;
    get maximumExecutionFrequency(): string;
    set maximumExecutionFrequency(value: string);
    resetMaximumExecutionFrequency(): void;
    get maximumExecutionFrequencyInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get ruleId(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _evaluationMode;
    get evaluationMode(): AwsConfigRule.EvaluationModePropertyList;
    putEvaluationMode(value: AwsConfigRule.EvaluationModeProperty[] | cdktn.IResolvable): void;
    resetEvaluationMode(): void;
    get evaluationModeInput(): cdktn.IResolvable | AwsConfigRule.EvaluationModeProperty[] | undefined;
    private _scope;
    get scope(): AwsConfigRule.ScopePropertyOutputReference;
    putScope(value: AwsConfigRule.ScopeProperty): void;
    resetScope(): void;
    get scopeInput(): AwsConfigRule.ScopeProperty | undefined;
    private _source;
    get source(): AwsConfigRule.SourcePropertyOutputReference;
    putSource(value: AwsConfigRule.SourceProperty): void;
    get sourceInput(): AwsConfigRule.SourceProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsConfigRuleEvaluationModePropertyToTerraform(struct?: AwsConfigRule.EvaluationModeProperty | cdktn.IResolvable): any;
export declare function awsConfigRuleEvaluationModePropertyToHclTerraform(struct?: AwsConfigRule.EvaluationModeProperty | cdktn.IResolvable): any;
export declare function awsConfigRuleScopePropertyToTerraform(struct?: AwsConfigRule.ScopePropertyOutputReference | AwsConfigRule.ScopeProperty): any;
export declare function awsConfigRuleScopePropertyToHclTerraform(struct?: AwsConfigRule.ScopePropertyOutputReference | AwsConfigRule.ScopeProperty): any;
export declare function awsConfigRuleCustomPolicyDetailsPropertyToTerraform(struct?: AwsConfigRule.CustomPolicyDetailsPropertyOutputReference | AwsConfigRule.CustomPolicyDetailsProperty): any;
export declare function awsConfigRuleCustomPolicyDetailsPropertyToHclTerraform(struct?: AwsConfigRule.CustomPolicyDetailsPropertyOutputReference | AwsConfigRule.CustomPolicyDetailsProperty): any;
export declare function awsConfigRuleSourceDetailPropertyToTerraform(struct?: AwsConfigRule.SourceDetailProperty | cdktn.IResolvable): any;
export declare function awsConfigRuleSourceDetailPropertyToHclTerraform(struct?: AwsConfigRule.SourceDetailProperty | cdktn.IResolvable): any;
export declare function awsConfigRuleSourcePropertyToTerraform(struct?: AwsConfigRule.SourcePropertyOutputReference | AwsConfigRule.SourceProperty): any;
export declare function awsConfigRuleSourcePropertyToHclTerraform(struct?: AwsConfigRule.SourcePropertyOutputReference | AwsConfigRule.SourceProperty): any;
export declare namespace AwsConfigRule {
    interface EvaluationModeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#mode AwsConfigRule#mode}
        */
        readonly mode?: string;
    }
    class EvaluationModePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationModeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluationModeProperty | cdktn.IResolvable | undefined);
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
    }
    class EvaluationModePropertyList extends cdktn.ComplexList {
        internalValue?: EvaluationModeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationModePropertyOutputReference;
    }
    interface ScopeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#compliance_resource_id AwsConfigRule#compliance_resource_id}
        */
        readonly complianceResourceId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#compliance_resource_types AwsConfigRule#compliance_resource_types}
        */
        readonly complianceResourceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#tag_key AwsConfigRule#tag_key}
        */
        readonly tagKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#tag_value AwsConfigRule#tag_value}
        */
        readonly tagValue?: string;
    }
    class ScopePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScopeProperty | undefined;
        set internalValue(value: ScopeProperty | undefined);
        private _complianceResourceId?;
        get complianceResourceId(): string;
        set complianceResourceId(value: string);
        resetComplianceResourceId(): void;
        get complianceResourceIdInput(): string | undefined;
        private _complianceResourceTypes?;
        get complianceResourceTypes(): string[];
        set complianceResourceTypes(value: string[]);
        resetComplianceResourceTypes(): void;
        get complianceResourceTypesInput(): string[] | undefined;
        private _tagKey?;
        get tagKey(): string;
        set tagKey(value: string);
        resetTagKey(): void;
        get tagKeyInput(): string | undefined;
        private _tagValue?;
        get tagValue(): string;
        set tagValue(value: string);
        resetTagValue(): void;
        get tagValueInput(): string | undefined;
    }
    interface CustomPolicyDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#enable_debug_log_delivery AwsConfigRule#enable_debug_log_delivery}
        */
        readonly enableDebugLogDelivery?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#policy_runtime AwsConfigRule#policy_runtime}
        */
        readonly policyRuntime: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#policy_text AwsConfigRule#policy_text}
        */
        readonly policyText: string;
    }
    class CustomPolicyDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomPolicyDetailsProperty | undefined;
        set internalValue(value: CustomPolicyDetailsProperty | undefined);
        private _enableDebugLogDelivery?;
        get enableDebugLogDelivery(): boolean | cdktn.IResolvable;
        set enableDebugLogDelivery(value: boolean | cdktn.IResolvable);
        resetEnableDebugLogDelivery(): void;
        get enableDebugLogDeliveryInput(): boolean | cdktn.IResolvable | undefined;
        private _policyRuntime?;
        get policyRuntime(): string;
        set policyRuntime(value: string);
        get policyRuntimeInput(): string | undefined;
        private _policyText?;
        get policyText(): string;
        set policyText(value: string);
        get policyTextInput(): string | undefined;
    }
    interface SourceDetailProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#event_source AwsConfigRule#event_source}
        */
        readonly eventSource?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#maximum_execution_frequency AwsConfigRule#maximum_execution_frequency}
        */
        readonly maximumExecutionFrequency?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#message_type AwsConfigRule#message_type}
        */
        readonly messageType?: string;
    }
    class SourceDetailPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceDetailProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceDetailProperty | cdktn.IResolvable | undefined);
        private _eventSource?;
        get eventSource(): string;
        set eventSource(value: string);
        resetEventSource(): void;
        get eventSourceInput(): string | undefined;
        private _maximumExecutionFrequency?;
        get maximumExecutionFrequency(): string;
        set maximumExecutionFrequency(value: string);
        resetMaximumExecutionFrequency(): void;
        get maximumExecutionFrequencyInput(): string | undefined;
        private _messageType?;
        get messageType(): string;
        set messageType(value: string);
        resetMessageType(): void;
        get messageTypeInput(): string | undefined;
    }
    class SourceDetailPropertyList extends cdktn.ComplexList {
        internalValue?: SourceDetailProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceDetailPropertyOutputReference;
    }
    interface SourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#owner AwsConfigRule#owner}
        */
        readonly owner: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#source_identifier AwsConfigRule#source_identifier}
        */
        readonly sourceIdentifier?: string;
        /**
        * custom_policy_details block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#custom_policy_details AwsConfigRule#custom_policy_details}
        */
        readonly customPolicyDetails?: CustomPolicyDetailsProperty;
        /**
        * source_detail block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/config_config_rule#source_detail AwsConfigRule#source_detail}
        */
        readonly sourceDetail?: SourceDetailProperty[] | cdktn.IResolvable;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceProperty | undefined;
        set internalValue(value: SourceProperty | undefined);
        private _owner?;
        get owner(): string;
        set owner(value: string);
        get ownerInput(): string | undefined;
        private _sourceIdentifier?;
        get sourceIdentifier(): string;
        set sourceIdentifier(value: string);
        resetSourceIdentifier(): void;
        get sourceIdentifierInput(): string | undefined;
        private _customPolicyDetails;
        get customPolicyDetails(): CustomPolicyDetailsPropertyOutputReference;
        putCustomPolicyDetails(value: CustomPolicyDetailsProperty): void;
        resetCustomPolicyDetails(): void;
        get customPolicyDetailsInput(): CustomPolicyDetailsProperty | undefined;
        private _sourceDetail;
        get sourceDetail(): SourceDetailPropertyList;
        putSourceDetail(value: SourceDetailProperty[] | cdktn.IResolvable): void;
        resetSourceDetail(): void;
        get sourceDetailInput(): cdktn.IResolvable | SourceDetailProperty[] | undefined;
    }
}
