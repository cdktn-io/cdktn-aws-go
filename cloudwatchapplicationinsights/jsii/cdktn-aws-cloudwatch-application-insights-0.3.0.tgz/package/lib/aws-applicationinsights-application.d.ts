import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/applicationinsights_application#auto_config_enabled AwsApplication#auto_config_enabled}
    */
    readonly autoConfigEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/applicationinsights_application#auto_create AwsApplication#auto_create}
    */
    readonly autoCreate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/applicationinsights_application#cwe_monitor_enabled AwsApplication#cwe_monitor_enabled}
    */
    readonly cweMonitorEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/applicationinsights_application#grouping_type AwsApplication#grouping_type}
    */
    readonly groupingType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/applicationinsights_application#id AwsApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/applicationinsights_application#ops_center_enabled AwsApplication#ops_center_enabled}
    */
    readonly opsCenterEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/applicationinsights_application#ops_item_sns_topic_arn AwsApplication#ops_item_sns_topic_arn}
    */
    readonly opsItemSnsTopicArn?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/applicationinsights_application#region AwsApplication#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/applicationinsights_application#resource_group_name AwsApplication#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/applicationinsights_application#tags AwsApplication#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/applicationinsights_application#tags_all AwsApplication#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/applicationinsights_application aws_applicationinsights_application}
*/
export declare class AwsApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_applicationinsights_application";
    /**
    * Generates CDKTN code for importing a AwsApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApplication to import
    * @param importFromId The id of the existing AwsApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/applicationinsights_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/applicationinsights_application aws_applicationinsights_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApplicationConfig
    */
    constructor(scope: Construct, id: string, config: AwsApplicationConfig);
    get arn(): string;
    private _autoConfigEnabled?;
    get autoConfigEnabled(): boolean | cdktn.IResolvable;
    set autoConfigEnabled(value: boolean | cdktn.IResolvable);
    resetAutoConfigEnabled(): void;
    get autoConfigEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _autoCreate?;
    get autoCreate(): boolean | cdktn.IResolvable;
    set autoCreate(value: boolean | cdktn.IResolvable);
    resetAutoCreate(): void;
    get autoCreateInput(): boolean | cdktn.IResolvable | undefined;
    private _cweMonitorEnabled?;
    get cweMonitorEnabled(): boolean | cdktn.IResolvable;
    set cweMonitorEnabled(value: boolean | cdktn.IResolvable);
    resetCweMonitorEnabled(): void;
    get cweMonitorEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _groupingType?;
    get groupingType(): string;
    set groupingType(value: string);
    resetGroupingType(): void;
    get groupingTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _opsCenterEnabled?;
    get opsCenterEnabled(): boolean | cdktn.IResolvable;
    set opsCenterEnabled(value: boolean | cdktn.IResolvable);
    resetOpsCenterEnabled(): void;
    get opsCenterEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _opsItemSnsTopicArn?;
    get opsItemSnsTopicArn(): string;
    set opsItemSnsTopicArn(value: string);
    resetOpsItemSnsTopicArn(): void;
    get opsItemSnsTopicArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
