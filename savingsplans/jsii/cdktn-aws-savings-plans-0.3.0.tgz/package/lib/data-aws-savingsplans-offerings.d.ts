import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsOfferingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_offerings#currencies DataAwsOfferings#currencies}
    */
    readonly currencies?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_offerings#descriptions DataAwsOfferings#descriptions}
    */
    readonly descriptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_offerings#durations DataAwsOfferings#durations}
    */
    readonly durations?: number[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_offerings#offering_ids DataAwsOfferings#offering_ids}
    */
    readonly offeringIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_offerings#operations DataAwsOfferings#operations}
    */
    readonly operations?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_offerings#payment_options DataAwsOfferings#payment_options}
    */
    readonly paymentOptions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_offerings#plan_types DataAwsOfferings#plan_types}
    */
    readonly planTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_offerings#product_type DataAwsOfferings#product_type}
    */
    readonly productType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_offerings#service_codes DataAwsOfferings#service_codes}
    */
    readonly serviceCodes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_offerings#usage_types DataAwsOfferings#usage_types}
    */
    readonly usageTypes?: string[];
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_offerings#filter DataAwsOfferings#filter}
    */
    readonly filter?: DataAwsOfferings.FilterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_offerings aws_savingsplans_offerings}
*/
export declare class DataAwsOfferings extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_savingsplans_offerings";
    /**
    * Generates CDKTN code for importing a DataAwsOfferings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsOfferings to import
    * @param importFromId The id of the existing DataAwsOfferings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_offerings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsOfferings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_offerings aws_savingsplans_offerings} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsOfferingsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsOfferingsConfig);
    private _currencies?;
    get currencies(): string[];
    set currencies(value: string[]);
    resetCurrencies(): void;
    get currenciesInput(): string[] | undefined;
    private _descriptions?;
    get descriptions(): string[];
    set descriptions(value: string[]);
    resetDescriptions(): void;
    get descriptionsInput(): string[] | undefined;
    private _durations?;
    get durations(): number[];
    set durations(value: number[]);
    resetDurations(): void;
    get durationsInput(): number[] | undefined;
    private _offeringIds?;
    get offeringIds(): string[];
    set offeringIds(value: string[]);
    resetOfferingIds(): void;
    get offeringIdsInput(): string[] | undefined;
    private _offerings;
    get offerings(): DataAwsOfferings.OfferingsPropertyList;
    private _operations?;
    get operations(): string[];
    set operations(value: string[]);
    resetOperations(): void;
    get operationsInput(): string[] | undefined;
    private _paymentOptions?;
    get paymentOptions(): string[];
    set paymentOptions(value: string[]);
    resetPaymentOptions(): void;
    get paymentOptionsInput(): string[] | undefined;
    private _planTypes?;
    get planTypes(): string[];
    set planTypes(value: string[]);
    resetPlanTypes(): void;
    get planTypesInput(): string[] | undefined;
    private _productType?;
    get productType(): string;
    set productType(value: string);
    resetProductType(): void;
    get productTypeInput(): string | undefined;
    private _serviceCodes?;
    get serviceCodes(): string[];
    set serviceCodes(value: string[]);
    resetServiceCodes(): void;
    get serviceCodesInput(): string[] | undefined;
    private _usageTypes?;
    get usageTypes(): string[];
    set usageTypes(value: string[]);
    resetUsageTypes(): void;
    get usageTypesInput(): string[] | undefined;
    private _filter;
    get filter(): DataAwsOfferings.FilterPropertyList;
    putFilter(value: DataAwsOfferings.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataAwsOfferings.FilterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsOfferingsPropertiesPropertyToTerraform(struct?: DataAwsOfferings.PropertiesProperty): any;
export declare function dataAwsOfferingsPropertiesPropertyToHclTerraform(struct?: DataAwsOfferings.PropertiesProperty): any;
export declare function dataAwsOfferingsOfferingsPropertyToTerraform(struct?: DataAwsOfferings.OfferingsProperty): any;
export declare function dataAwsOfferingsOfferingsPropertyToHclTerraform(struct?: DataAwsOfferings.OfferingsProperty): any;
export declare function dataAwsOfferingsFilterPropertyToTerraform(struct?: DataAwsOfferings.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsOfferingsFilterPropertyToHclTerraform(struct?: DataAwsOfferings.FilterProperty | cdktn.IResolvable): any;
export declare namespace DataAwsOfferings {
    interface PropertiesProperty {
    }
    class PropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PropertiesProperty | undefined;
        set internalValue(value: PropertiesProperty | undefined);
        get name(): string;
        get value(): string;
    }
    class PropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PropertiesPropertyOutputReference;
    }
    interface OfferingsProperty {
    }
    class OfferingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OfferingsProperty | undefined;
        set internalValue(value: OfferingsProperty | undefined);
        get currency(): string;
        get description(): string;
        get durationSeconds(): number;
        get offeringId(): string;
        get operation(): string;
        get paymentOption(): string;
        get planType(): string;
        get productTypes(): string[];
        private _properties;
        get properties(): PropertiesPropertyList;
        get serviceCode(): string;
        get usageType(): string;
    }
    class OfferingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OfferingsPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_offerings#name DataAwsOfferings#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/savingsplans_offerings#values DataAwsOfferings#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
}
