import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfLocalGatewayVirtualInterfaceGroupsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#id DataTfLocalGatewayVirtualInterfaceGroups#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#region DataTfLocalGatewayVirtualInterfaceGroups#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#tags DataTfLocalGatewayVirtualInterfaceGroups#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#filter DataTfLocalGatewayVirtualInterfaceGroups#filter}
    */
    readonly filter?: DataTfLocalGatewayVirtualInterfaceGroups.FilterProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#timeouts DataTfLocalGatewayVirtualInterfaceGroups#timeouts}
    */
    readonly timeouts?: DataTfLocalGatewayVirtualInterfaceGroups.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups aws_ec2_local_gateway_virtual_interface_groups}
*/
export declare class DataTfLocalGatewayVirtualInterfaceGroups extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ec2_local_gateway_virtual_interface_groups";
    /**
    * Generates CDKTN code for importing a DataTfLocalGatewayVirtualInterfaceGroups resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfLocalGatewayVirtualInterfaceGroups to import
    * @param importFromId The id of the existing DataTfLocalGatewayVirtualInterfaceGroups that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfLocalGatewayVirtualInterfaceGroups to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups aws_ec2_local_gateway_virtual_interface_groups} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfLocalGatewayVirtualInterfaceGroupsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfLocalGatewayVirtualInterfaceGroupsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ids(): string[];
    get localGatewayVirtualInterfaceIds(): string[];
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _filter;
    get filter(): DataTfLocalGatewayVirtualInterfaceGroups.FilterPropertyList;
    putFilter(value: DataTfLocalGatewayVirtualInterfaceGroups.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataTfLocalGatewayVirtualInterfaceGroups.FilterProperty[] | undefined;
    private _timeouts;
    get timeouts(): DataTfLocalGatewayVirtualInterfaceGroups.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataTfLocalGatewayVirtualInterfaceGroups.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataTfLocalGatewayVirtualInterfaceGroups.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfLocalGatewayVirtualInterfaceGroupsFilterPropertyToTerraform(struct?: DataTfLocalGatewayVirtualInterfaceGroups.FilterProperty | cdktn.IResolvable): any;
export declare function dataTfLocalGatewayVirtualInterfaceGroupsFilterPropertyToHclTerraform(struct?: DataTfLocalGatewayVirtualInterfaceGroups.FilterProperty | cdktn.IResolvable): any;
export declare function dataTfLocalGatewayVirtualInterfaceGroupsTimeoutsPropertyToTerraform(struct?: DataTfLocalGatewayVirtualInterfaceGroups.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataTfLocalGatewayVirtualInterfaceGroupsTimeoutsPropertyToHclTerraform(struct?: DataTfLocalGatewayVirtualInterfaceGroups.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataTfLocalGatewayVirtualInterfaceGroups {
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#name DataTfLocalGatewayVirtualInterfaceGroups#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#values DataTfLocalGatewayVirtualInterfaceGroups#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#read DataTfLocalGatewayVirtualInterfaceGroups#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
