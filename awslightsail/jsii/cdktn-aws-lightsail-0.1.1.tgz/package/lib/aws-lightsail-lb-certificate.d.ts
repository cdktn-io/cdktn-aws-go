import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLightsailLbCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_lb_certificate#domain_name AwsLightsailLbCertificate#domain_name}
    */
    readonly domainName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_lb_certificate#id AwsLightsailLbCertificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_lb_certificate#lb_name AwsLightsailLbCertificate#lb_name}
    */
    readonly lbName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_lb_certificate#name AwsLightsailLbCertificate#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_lb_certificate#region AwsLightsailLbCertificate#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_lb_certificate#subject_alternative_names AwsLightsailLbCertificate#subject_alternative_names}
    */
    readonly subjectAlternativeNames?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_lb_certificate aws_lightsail_lb_certificate}
*/
export declare class AwsLightsailLbCertificate extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lightsail_lb_certificate";
    /**
    * Generates CDKTN code for importing a AwsLightsailLbCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLightsailLbCertificate to import
    * @param importFromId The id of the existing AwsLightsailLbCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_lb_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLightsailLbCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lightsail_lb_certificate aws_lightsail_lb_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLightsailLbCertificateConfig
    */
    constructor(scope: Construct, id: string, config: AwsLightsailLbCertificateConfig);
    get arn(): string;
    get createdAt(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    resetDomainName(): void;
    get domainNameInput(): string | undefined;
    private _domainValidationRecords;
    get domainValidationRecords(): AwsLightsailLbCertificate.DomainValidationRecordsPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _lbName?;
    get lbName(): string;
    set lbName(value: string);
    get lbNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _subjectAlternativeNames?;
    get subjectAlternativeNames(): string[];
    set subjectAlternativeNames(value: string[]);
    resetSubjectAlternativeNames(): void;
    get subjectAlternativeNamesInput(): string[] | undefined;
    get supportCode(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLightsailLbCertificateDomainValidationRecordsPropertyToTerraform(struct?: AwsLightsailLbCertificate.DomainValidationRecordsProperty): any;
export declare function awsLightsailLbCertificateDomainValidationRecordsPropertyToHclTerraform(struct?: AwsLightsailLbCertificate.DomainValidationRecordsProperty): any;
export declare namespace AwsLightsailLbCertificate {
    interface DomainValidationRecordsProperty {
    }
    class DomainValidationRecordsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DomainValidationRecordsProperty | undefined;
        set internalValue(value: DomainValidationRecordsProperty | undefined);
        get domainName(): string;
        get resourceRecordName(): string;
        get resourceRecordType(): string;
        get resourceRecordValue(): string;
    }
    class DomainValidationRecordsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DomainValidationRecordsPropertyOutputReference;
    }
}
