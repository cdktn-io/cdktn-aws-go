import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsOutpostsCapacityTaskConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/outposts_capacity_task#asset_id AwsOutpostsCapacityTask#asset_id}
    */
    readonly assetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/outposts_capacity_task#order_id AwsOutpostsCapacityTask#order_id}
    */
    readonly orderId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/outposts_capacity_task#outpost_identifier AwsOutpostsCapacityTask#outpost_identifier}
    */
    readonly outpostIdentifier: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/outposts_capacity_task#region AwsOutpostsCapacityTask#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/outposts_capacity_task#task_action_on_blocking_instances AwsOutpostsCapacityTask#task_action_on_blocking_instances}
    */
    readonly taskActionOnBlockingInstances?: string;
    /**
    * instance_pool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/outposts_capacity_task#instance_pool AwsOutpostsCapacityTask#instance_pool}
    */
    readonly instancePool?: AwsOutpostsCapacityTask.InstancePoolProperty[] | cdktn.IResolvable;
    /**
    * instances_to_exclude block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/outposts_capacity_task#instances_to_exclude AwsOutpostsCapacityTask#instances_to_exclude}
    */
    readonly instancesToExclude?: AwsOutpostsCapacityTask.InstancesToExcludeProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/outposts_capacity_task#timeouts AwsOutpostsCapacityTask#timeouts}
    */
    readonly timeouts?: AwsOutpostsCapacityTask.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/outposts_capacity_task aws_outposts_capacity_task}
*/
export declare class AwsOutpostsCapacityTask extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_outposts_capacity_task";
    /**
    * Generates CDKTN code for importing a AwsOutpostsCapacityTask resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsOutpostsCapacityTask to import
    * @param importFromId The id of the existing AwsOutpostsCapacityTask that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/outposts_capacity_task#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsOutpostsCapacityTask to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/outposts_capacity_task aws_outposts_capacity_task} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsOutpostsCapacityTaskConfig
    */
    constructor(scope: Construct, id: string, config: AwsOutpostsCapacityTaskConfig);
    private _assetId?;
    get assetId(): string;
    set assetId(value: string);
    resetAssetId(): void;
    get assetIdInput(): string | undefined;
    get capacityTaskId(): string;
    get completionDate(): string;
    get creationDate(): string;
    get failureReason(): string;
    private _orderId?;
    get orderId(): string;
    set orderId(value: string);
    resetOrderId(): void;
    get orderIdInput(): string | undefined;
    private _outpostIdentifier?;
    get outpostIdentifier(): string;
    set outpostIdentifier(value: string);
    get outpostIdentifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _taskActionOnBlockingInstances?;
    get taskActionOnBlockingInstances(): string;
    set taskActionOnBlockingInstances(value: string);
    resetTaskActionOnBlockingInstances(): void;
    get taskActionOnBlockingInstancesInput(): string | undefined;
    private _instancePool;
    get instancePool(): AwsOutpostsCapacityTask.InstancePoolPropertyList;
    putInstancePool(value: AwsOutpostsCapacityTask.InstancePoolProperty[] | cdktn.IResolvable): void;
    resetInstancePool(): void;
    get instancePoolInput(): cdktn.IResolvable | AwsOutpostsCapacityTask.InstancePoolProperty[] | undefined;
    private _instancesToExclude;
    get instancesToExclude(): AwsOutpostsCapacityTask.InstancesToExcludePropertyList;
    putInstancesToExclude(value: AwsOutpostsCapacityTask.InstancesToExcludeProperty[] | cdktn.IResolvable): void;
    resetInstancesToExclude(): void;
    get instancesToExcludeInput(): cdktn.IResolvable | AwsOutpostsCapacityTask.InstancesToExcludeProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsOutpostsCapacityTask.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsOutpostsCapacityTask.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsOutpostsCapacityTask.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsOutpostsCapacityTaskInstancePoolPropertyToTerraform(struct?: AwsOutpostsCapacityTask.InstancePoolProperty | cdktn.IResolvable): any;
export declare function awsOutpostsCapacityTaskInstancePoolPropertyToHclTerraform(struct?: AwsOutpostsCapacityTask.InstancePoolProperty | cdktn.IResolvable): any;
export declare function awsOutpostsCapacityTaskInstancesToExcludePropertyToTerraform(struct?: AwsOutpostsCapacityTask.InstancesToExcludeProperty | cdktn.IResolvable): any;
export declare function awsOutpostsCapacityTaskInstancesToExcludePropertyToHclTerraform(struct?: AwsOutpostsCapacityTask.InstancesToExcludeProperty | cdktn.IResolvable): any;
export declare function awsOutpostsCapacityTaskTimeoutsPropertyToTerraform(struct?: AwsOutpostsCapacityTask.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsOutpostsCapacityTaskTimeoutsPropertyToHclTerraform(struct?: AwsOutpostsCapacityTask.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsOutpostsCapacityTask {
    interface InstancePoolProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/outposts_capacity_task#count AwsOutpostsCapacityTask#count}
        */
        readonly count: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/outposts_capacity_task#instance_type AwsOutpostsCapacityTask#instance_type}
        */
        readonly instanceType: string;
    }
    class InstancePoolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstancePoolProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InstancePoolProperty | cdktn.IResolvable | undefined);
        private _count?;
        get count(): number;
        set count(value: number);
        get countInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        get instanceTypeInput(): string | undefined;
    }
    class InstancePoolPropertyList extends cdktn.ComplexList {
        internalValue?: InstancePoolProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstancePoolPropertyOutputReference;
    }
    interface InstancesToExcludeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/outposts_capacity_task#instances AwsOutpostsCapacityTask#instances}
        */
        readonly instances: string[];
    }
    class InstancesToExcludePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InstancesToExcludeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InstancesToExcludeProperty | cdktn.IResolvable | undefined);
        private _instances?;
        get instances(): string[];
        set instances(value: string[]);
        get instancesInput(): string[] | undefined;
    }
    class InstancesToExcludePropertyList extends cdktn.ComplexList {
        internalValue?: InstancesToExcludeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InstancesToExcludePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/outposts_capacity_task#create AwsOutpostsCapacityTask#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/outposts_capacity_task#delete AwsOutpostsCapacityTask#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
