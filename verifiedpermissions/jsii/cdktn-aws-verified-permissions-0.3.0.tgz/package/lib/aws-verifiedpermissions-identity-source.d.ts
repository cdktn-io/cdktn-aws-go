import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsIdentitySourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#policy_store_id AwsIdentitySource#policy_store_id}
    */
    readonly policyStoreId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#principal_entity_type AwsIdentitySource#principal_entity_type}
    */
    readonly principalEntityType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#region AwsIdentitySource#region}
    */
    readonly region?: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#configuration AwsIdentitySource#configuration}
    */
    readonly configuration?: AwsIdentitySource.ConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source aws_verifiedpermissions_identity_source}
*/
export declare class AwsIdentitySource extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_verifiedpermissions_identity_source";
    /**
    * Generates CDKTN code for importing a AwsIdentitySource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsIdentitySource to import
    * @param importFromId The id of the existing AwsIdentitySource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsIdentitySource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source aws_verifiedpermissions_identity_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsIdentitySourceConfig
    */
    constructor(scope: Construct, id: string, config: AwsIdentitySourceConfig);
    get id(): string;
    private _policyStoreId?;
    get policyStoreId(): string;
    set policyStoreId(value: string);
    get policyStoreIdInput(): string | undefined;
    private _principalEntityType?;
    get principalEntityType(): string;
    set principalEntityType(value: string);
    resetPrincipalEntityType(): void;
    get principalEntityTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _configuration;
    get configuration(): AwsIdentitySource.ConfigurationPropertyList;
    putConfiguration(value: AwsIdentitySource.ConfigurationProperty[] | cdktn.IResolvable): void;
    resetConfiguration(): void;
    get configurationInput(): cdktn.IResolvable | AwsIdentitySource.ConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsIdentitySourceConfigurationCognitoUserPoolConfigurationGroupConfigurationPropertyToTerraform(struct?: AwsIdentitySource.ConfigurationCognitoUserPoolConfigurationGroupConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIdentitySourceConfigurationCognitoUserPoolConfigurationGroupConfigurationPropertyToHclTerraform(struct?: AwsIdentitySource.ConfigurationCognitoUserPoolConfigurationGroupConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIdentitySourceCognitoUserPoolConfigurationPropertyToTerraform(struct?: AwsIdentitySource.CognitoUserPoolConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIdentitySourceCognitoUserPoolConfigurationPropertyToHclTerraform(struct?: AwsIdentitySource.CognitoUserPoolConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIdentitySourceConfigurationOpenIdConnectConfigurationGroupConfigurationPropertyToTerraform(struct?: AwsIdentitySource.ConfigurationOpenIdConnectConfigurationGroupConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIdentitySourceConfigurationOpenIdConnectConfigurationGroupConfigurationPropertyToHclTerraform(struct?: AwsIdentitySource.ConfigurationOpenIdConnectConfigurationGroupConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIdentitySourceAccessTokenOnlyPropertyToTerraform(struct?: AwsIdentitySource.AccessTokenOnlyProperty | cdktn.IResolvable): any;
export declare function awsIdentitySourceAccessTokenOnlyPropertyToHclTerraform(struct?: AwsIdentitySource.AccessTokenOnlyProperty | cdktn.IResolvable): any;
export declare function awsIdentitySourceIdentityTokenOnlyPropertyToTerraform(struct?: AwsIdentitySource.IdentityTokenOnlyProperty | cdktn.IResolvable): any;
export declare function awsIdentitySourceIdentityTokenOnlyPropertyToHclTerraform(struct?: AwsIdentitySource.IdentityTokenOnlyProperty | cdktn.IResolvable): any;
export declare function awsIdentitySourceTokenSelectionPropertyToTerraform(struct?: AwsIdentitySource.TokenSelectionProperty | cdktn.IResolvable): any;
export declare function awsIdentitySourceTokenSelectionPropertyToHclTerraform(struct?: AwsIdentitySource.TokenSelectionProperty | cdktn.IResolvable): any;
export declare function awsIdentitySourceOpenIdConnectConfigurationPropertyToTerraform(struct?: AwsIdentitySource.OpenIdConnectConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIdentitySourceOpenIdConnectConfigurationPropertyToHclTerraform(struct?: AwsIdentitySource.OpenIdConnectConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIdentitySourceConfigurationPropertyToTerraform(struct?: AwsIdentitySource.ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsIdentitySourceConfigurationPropertyToHclTerraform(struct?: AwsIdentitySource.ConfigurationProperty | cdktn.IResolvable): any;
export declare namespace AwsIdentitySource {
    interface ConfigurationCognitoUserPoolConfigurationGroupConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#group_entity_type AwsIdentitySource#group_entity_type}
        */
        readonly groupEntityType: string;
    }
    class ConfigurationCognitoUserPoolConfigurationGroupConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationCognitoUserPoolConfigurationGroupConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationCognitoUserPoolConfigurationGroupConfigurationProperty | cdktn.IResolvable | undefined);
        private _groupEntityType?;
        get groupEntityType(): string;
        set groupEntityType(value: string);
        get groupEntityTypeInput(): string | undefined;
    }
    class ConfigurationCognitoUserPoolConfigurationGroupConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationCognitoUserPoolConfigurationGroupConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationCognitoUserPoolConfigurationGroupConfigurationPropertyOutputReference;
    }
    interface CognitoUserPoolConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#client_ids AwsIdentitySource#client_ids}
        */
        readonly clientIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#user_pool_arn AwsIdentitySource#user_pool_arn}
        */
        readonly userPoolArn: string;
        /**
        * group_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#group_configuration AwsIdentitySource#group_configuration}
        */
        readonly groupConfiguration?: ConfigurationCognitoUserPoolConfigurationGroupConfigurationProperty[] | cdktn.IResolvable;
    }
    class CognitoUserPoolConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CognitoUserPoolConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CognitoUserPoolConfigurationProperty | cdktn.IResolvable | undefined);
        private _clientIds?;
        get clientIds(): string[];
        set clientIds(value: string[]);
        resetClientIds(): void;
        get clientIdsInput(): string[] | undefined;
        private _userPoolArn?;
        get userPoolArn(): string;
        set userPoolArn(value: string);
        get userPoolArnInput(): string | undefined;
        private _groupConfiguration;
        get groupConfiguration(): ConfigurationCognitoUserPoolConfigurationGroupConfigurationPropertyList;
        putGroupConfiguration(value: ConfigurationCognitoUserPoolConfigurationGroupConfigurationProperty[] | cdktn.IResolvable): void;
        resetGroupConfiguration(): void;
        get groupConfigurationInput(): cdktn.IResolvable | ConfigurationCognitoUserPoolConfigurationGroupConfigurationProperty[] | undefined;
    }
    class CognitoUserPoolConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: CognitoUserPoolConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CognitoUserPoolConfigurationPropertyOutputReference;
    }
    interface ConfigurationOpenIdConnectConfigurationGroupConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#group_claim AwsIdentitySource#group_claim}
        */
        readonly groupClaim: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#group_entity_type AwsIdentitySource#group_entity_type}
        */
        readonly groupEntityType: string;
    }
    class ConfigurationOpenIdConnectConfigurationGroupConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationOpenIdConnectConfigurationGroupConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationOpenIdConnectConfigurationGroupConfigurationProperty | cdktn.IResolvable | undefined);
        private _groupClaim?;
        get groupClaim(): string;
        set groupClaim(value: string);
        get groupClaimInput(): string | undefined;
        private _groupEntityType?;
        get groupEntityType(): string;
        set groupEntityType(value: string);
        get groupEntityTypeInput(): string | undefined;
    }
    class ConfigurationOpenIdConnectConfigurationGroupConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationOpenIdConnectConfigurationGroupConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationOpenIdConnectConfigurationGroupConfigurationPropertyOutputReference;
    }
    interface AccessTokenOnlyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#audiences AwsIdentitySource#audiences}
        */
        readonly audiences?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#principal_id_claim AwsIdentitySource#principal_id_claim}
        */
        readonly principalIdClaim?: string;
    }
    class AccessTokenOnlyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessTokenOnlyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AccessTokenOnlyProperty | cdktn.IResolvable | undefined);
        private _audiences?;
        get audiences(): string[];
        set audiences(value: string[]);
        resetAudiences(): void;
        get audiencesInput(): string[] | undefined;
        private _principalIdClaim?;
        get principalIdClaim(): string;
        set principalIdClaim(value: string);
        resetPrincipalIdClaim(): void;
        get principalIdClaimInput(): string | undefined;
    }
    class AccessTokenOnlyPropertyList extends cdktn.ComplexList {
        internalValue?: AccessTokenOnlyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessTokenOnlyPropertyOutputReference;
    }
    interface IdentityTokenOnlyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#client_ids AwsIdentitySource#client_ids}
        */
        readonly clientIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#principal_id_claim AwsIdentitySource#principal_id_claim}
        */
        readonly principalIdClaim?: string;
    }
    class IdentityTokenOnlyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IdentityTokenOnlyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IdentityTokenOnlyProperty | cdktn.IResolvable | undefined);
        private _clientIds?;
        get clientIds(): string[];
        set clientIds(value: string[]);
        resetClientIds(): void;
        get clientIdsInput(): string[] | undefined;
        private _principalIdClaim?;
        get principalIdClaim(): string;
        set principalIdClaim(value: string);
        resetPrincipalIdClaim(): void;
        get principalIdClaimInput(): string | undefined;
    }
    class IdentityTokenOnlyPropertyList extends cdktn.ComplexList {
        internalValue?: IdentityTokenOnlyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IdentityTokenOnlyPropertyOutputReference;
    }
    interface TokenSelectionProperty {
        /**
        * access_token_only block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#access_token_only AwsIdentitySource#access_token_only}
        */
        readonly accessTokenOnly?: AccessTokenOnlyProperty[] | cdktn.IResolvable;
        /**
        * identity_token_only block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#identity_token_only AwsIdentitySource#identity_token_only}
        */
        readonly identityTokenOnly?: IdentityTokenOnlyProperty[] | cdktn.IResolvable;
    }
    class TokenSelectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TokenSelectionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TokenSelectionProperty | cdktn.IResolvable | undefined);
        private _accessTokenOnly;
        get accessTokenOnly(): AccessTokenOnlyPropertyList;
        putAccessTokenOnly(value: AccessTokenOnlyProperty[] | cdktn.IResolvable): void;
        resetAccessTokenOnly(): void;
        get accessTokenOnlyInput(): cdktn.IResolvable | AccessTokenOnlyProperty[] | undefined;
        private _identityTokenOnly;
        get identityTokenOnly(): IdentityTokenOnlyPropertyList;
        putIdentityTokenOnly(value: IdentityTokenOnlyProperty[] | cdktn.IResolvable): void;
        resetIdentityTokenOnly(): void;
        get identityTokenOnlyInput(): cdktn.IResolvable | IdentityTokenOnlyProperty[] | undefined;
    }
    class TokenSelectionPropertyList extends cdktn.ComplexList {
        internalValue?: TokenSelectionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TokenSelectionPropertyOutputReference;
    }
    interface OpenIdConnectConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#entity_id_prefix AwsIdentitySource#entity_id_prefix}
        */
        readonly entityIdPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#issuer AwsIdentitySource#issuer}
        */
        readonly issuer: string;
        /**
        * group_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#group_configuration AwsIdentitySource#group_configuration}
        */
        readonly groupConfiguration?: ConfigurationOpenIdConnectConfigurationGroupConfigurationProperty[] | cdktn.IResolvable;
        /**
        * token_selection block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#token_selection AwsIdentitySource#token_selection}
        */
        readonly tokenSelection?: TokenSelectionProperty[] | cdktn.IResolvable;
    }
    class OpenIdConnectConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpenIdConnectConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpenIdConnectConfigurationProperty | cdktn.IResolvable | undefined);
        private _entityIdPrefix?;
        get entityIdPrefix(): string;
        set entityIdPrefix(value: string);
        resetEntityIdPrefix(): void;
        get entityIdPrefixInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
        private _groupConfiguration;
        get groupConfiguration(): ConfigurationOpenIdConnectConfigurationGroupConfigurationPropertyList;
        putGroupConfiguration(value: ConfigurationOpenIdConnectConfigurationGroupConfigurationProperty[] | cdktn.IResolvable): void;
        resetGroupConfiguration(): void;
        get groupConfigurationInput(): cdktn.IResolvable | ConfigurationOpenIdConnectConfigurationGroupConfigurationProperty[] | undefined;
        private _tokenSelection;
        get tokenSelection(): TokenSelectionPropertyList;
        putTokenSelection(value: TokenSelectionProperty[] | cdktn.IResolvable): void;
        resetTokenSelection(): void;
        get tokenSelectionInput(): cdktn.IResolvable | TokenSelectionProperty[] | undefined;
    }
    class OpenIdConnectConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: OpenIdConnectConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpenIdConnectConfigurationPropertyOutputReference;
    }
    interface ConfigurationProperty {
        /**
        * cognito_user_pool_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#cognito_user_pool_configuration AwsIdentitySource#cognito_user_pool_configuration}
        */
        readonly cognitoUserPoolConfiguration?: CognitoUserPoolConfigurationProperty[] | cdktn.IResolvable;
        /**
        * open_id_connect_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_identity_source#open_id_connect_configuration AwsIdentitySource#open_id_connect_configuration}
        */
        readonly openIdConnectConfiguration?: OpenIdConnectConfigurationProperty[] | cdktn.IResolvable;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationProperty | cdktn.IResolvable | undefined);
        private _cognitoUserPoolConfiguration;
        get cognitoUserPoolConfiguration(): CognitoUserPoolConfigurationPropertyList;
        putCognitoUserPoolConfiguration(value: CognitoUserPoolConfigurationProperty[] | cdktn.IResolvable): void;
        resetCognitoUserPoolConfiguration(): void;
        get cognitoUserPoolConfigurationInput(): cdktn.IResolvable | CognitoUserPoolConfigurationProperty[] | undefined;
        private _openIdConnectConfiguration;
        get openIdConnectConfiguration(): OpenIdConnectConfigurationPropertyList;
        putOpenIdConnectConfiguration(value: OpenIdConnectConfigurationProperty[] | cdktn.IResolvable): void;
        resetOpenIdConnectConfiguration(): void;
        get openIdConnectConfigurationInput(): cdktn.IResolvable | OpenIdConnectConfigurationProperty[] | undefined;
    }
    class ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationPropertyOutputReference;
    }
}
