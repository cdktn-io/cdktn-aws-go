import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy#policy_store_id AwsPolicy#policy_store_id}
    */
    readonly policyStoreId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy#region AwsPolicy#region}
    */
    readonly region?: string;
    /**
    * definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy#definition AwsPolicy#definition}
    */
    readonly definition?: AwsPolicy.DefinitionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy aws_verifiedpermissions_policy}
*/
export declare class AwsPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_verifiedpermissions_policy";
    /**
    * Generates CDKTN code for importing a AwsPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPolicy to import
    * @param importFromId The id of the existing AwsPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy aws_verifiedpermissions_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsPolicyConfig);
    get createdDate(): string;
    get id(): string;
    get policyId(): string;
    private _policyStoreId?;
    get policyStoreId(): string;
    set policyStoreId(value: string);
    get policyStoreIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _definition;
    get definition(): AwsPolicy.DefinitionPropertyList;
    putDefinition(value: AwsPolicy.DefinitionProperty[] | cdktn.IResolvable): void;
    resetDefinition(): void;
    get definitionInput(): cdktn.IResolvable | AwsPolicy.DefinitionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPolicyStaticPropertyToTerraform(struct?: AwsPolicy.StaticProperty | cdktn.IResolvable): any;
export declare function awsPolicyStaticPropertyToHclTerraform(struct?: AwsPolicy.StaticProperty | cdktn.IResolvable): any;
export declare function awsPolicyPrincipalPropertyToTerraform(struct?: AwsPolicy.PrincipalProperty | cdktn.IResolvable): any;
export declare function awsPolicyPrincipalPropertyToHclTerraform(struct?: AwsPolicy.PrincipalProperty | cdktn.IResolvable): any;
export declare function awsPolicyResourcePropertyToTerraform(struct?: AwsPolicy.ResourceProperty | cdktn.IResolvable): any;
export declare function awsPolicyResourcePropertyToHclTerraform(struct?: AwsPolicy.ResourceProperty | cdktn.IResolvable): any;
export declare function awsPolicyTemplateLinkedPropertyToTerraform(struct?: AwsPolicy.TemplateLinkedProperty | cdktn.IResolvable): any;
export declare function awsPolicyTemplateLinkedPropertyToHclTerraform(struct?: AwsPolicy.TemplateLinkedProperty | cdktn.IResolvable): any;
export declare function awsPolicyDefinitionPropertyToTerraform(struct?: AwsPolicy.DefinitionProperty | cdktn.IResolvable): any;
export declare function awsPolicyDefinitionPropertyToHclTerraform(struct?: AwsPolicy.DefinitionProperty | cdktn.IResolvable): any;
export declare namespace AwsPolicy {
    interface StaticProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy#description AwsPolicy#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy#statement AwsPolicy#statement}
        */
        readonly statement: string;
    }
    class StaticPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StaticProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StaticProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _statement?;
        get statement(): string;
        set statement(value: string);
        get statementInput(): string | undefined;
    }
    class StaticPropertyList extends cdktn.ComplexList {
        internalValue?: StaticProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StaticPropertyOutputReference;
    }
    interface PrincipalProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy#entity_id AwsPolicy#entity_id}
        */
        readonly entityId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy#entity_type AwsPolicy#entity_type}
        */
        readonly entityType: string;
    }
    class PrincipalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrincipalProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PrincipalProperty | cdktn.IResolvable | undefined);
        private _entityId?;
        get entityId(): string;
        set entityId(value: string);
        get entityIdInput(): string | undefined;
        private _entityType?;
        get entityType(): string;
        set entityType(value: string);
        get entityTypeInput(): string | undefined;
    }
    class PrincipalPropertyList extends cdktn.ComplexList {
        internalValue?: PrincipalProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrincipalPropertyOutputReference;
    }
    interface ResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy#entity_id AwsPolicy#entity_id}
        */
        readonly entityId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy#entity_type AwsPolicy#entity_type}
        */
        readonly entityType: string;
    }
    class ResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceProperty | cdktn.IResolvable | undefined);
        private _entityId?;
        get entityId(): string;
        set entityId(value: string);
        get entityIdInput(): string | undefined;
        private _entityType?;
        get entityType(): string;
        set entityType(value: string);
        get entityTypeInput(): string | undefined;
    }
    class ResourcePropertyList extends cdktn.ComplexList {
        internalValue?: ResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourcePropertyOutputReference;
    }
    interface TemplateLinkedProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy#policy_template_id AwsPolicy#policy_template_id}
        */
        readonly policyTemplateId: string;
        /**
        * principal block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy#principal AwsPolicy#principal}
        */
        readonly principal?: PrincipalProperty[] | cdktn.IResolvable;
        /**
        * resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy#resource AwsPolicy#resource}
        */
        readonly resource?: ResourceProperty[] | cdktn.IResolvable;
    }
    class TemplateLinkedPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TemplateLinkedProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TemplateLinkedProperty | cdktn.IResolvable | undefined);
        private _policyTemplateId?;
        get policyTemplateId(): string;
        set policyTemplateId(value: string);
        get policyTemplateIdInput(): string | undefined;
        private _principal;
        get principal(): PrincipalPropertyList;
        putPrincipal(value: PrincipalProperty[] | cdktn.IResolvable): void;
        resetPrincipal(): void;
        get principalInput(): cdktn.IResolvable | PrincipalProperty[] | undefined;
        private _resource;
        get resource(): ResourcePropertyList;
        putResource(value: ResourceProperty[] | cdktn.IResolvable): void;
        resetResource(): void;
        get resourceInput(): cdktn.IResolvable | ResourceProperty[] | undefined;
    }
    class TemplateLinkedPropertyList extends cdktn.ComplexList {
        internalValue?: TemplateLinkedProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TemplateLinkedPropertyOutputReference;
    }
    interface DefinitionProperty {
        /**
        * static block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy#static AwsPolicy#static}
        */
        readonly static?: StaticProperty[] | cdktn.IResolvable;
        /**
        * template_linked block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/verifiedpermissions_policy#template_linked AwsPolicy#template_linked}
        */
        readonly templateLinked?: TemplateLinkedProperty[] | cdktn.IResolvable;
    }
    class DefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionProperty | cdktn.IResolvable | undefined);
        private _static;
        get static(): StaticPropertyList;
        putStatic(value: StaticProperty[] | cdktn.IResolvable): void;
        resetStatic(): void;
        get staticInput(): cdktn.IResolvable | StaticProperty[] | undefined;
        private _templateLinked;
        get templateLinked(): TemplateLinkedPropertyList;
        putTemplateLinked(value: TemplateLinkedProperty[] | cdktn.IResolvable): void;
        resetTemplateLinked(): void;
        get templateLinkedInput(): cdktn.IResolvable | TemplateLinkedProperty[] | undefined;
    }
    class DefinitionPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionPropertyOutputReference;
    }
}
