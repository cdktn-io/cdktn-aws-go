import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsIndexingRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_indexing_rule#name AwsIndexingRule#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_indexing_rule#region AwsIndexingRule#region}
    */
    readonly region?: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_indexing_rule#rule AwsIndexingRule#rule}
    */
    readonly rule?: AwsIndexingRule.RuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_indexing_rule aws_xray_indexing_rule}
*/
export declare class AwsIndexingRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_xray_indexing_rule";
    /**
    * Generates CDKTN code for importing a AwsIndexingRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsIndexingRule to import
    * @param importFromId The id of the existing AwsIndexingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_indexing_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsIndexingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_indexing_rule aws_xray_indexing_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsIndexingRuleConfig
    */
    constructor(scope: Construct, id: string, config: AwsIndexingRuleConfig);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rule;
    get rule(): AwsIndexingRule.RulePropertyList;
    putRule(value: AwsIndexingRule.RuleProperty[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | AwsIndexingRule.RuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsIndexingRuleProbabilisticPropertyToTerraform(struct?: AwsIndexingRule.ProbabilisticProperty | cdktn.IResolvable): any;
export declare function awsIndexingRuleProbabilisticPropertyToHclTerraform(struct?: AwsIndexingRule.ProbabilisticProperty | cdktn.IResolvable): any;
export declare function awsIndexingRuleRulePropertyToTerraform(struct?: AwsIndexingRule.RuleProperty | cdktn.IResolvable): any;
export declare function awsIndexingRuleRulePropertyToHclTerraform(struct?: AwsIndexingRule.RuleProperty | cdktn.IResolvable): any;
export declare namespace AwsIndexingRule {
    interface ProbabilisticProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_indexing_rule#desired_sampling_percentage AwsIndexingRule#desired_sampling_percentage}
        */
        readonly desiredSamplingPercentage: number;
    }
    class ProbabilisticPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProbabilisticProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProbabilisticProperty | cdktn.IResolvable | undefined);
        get actualSamplingPercentage(): number;
        private _desiredSamplingPercentage?;
        get desiredSamplingPercentage(): number;
        set desiredSamplingPercentage(value: number);
        get desiredSamplingPercentageInput(): number | undefined;
    }
    class ProbabilisticPropertyList extends cdktn.ComplexList {
        internalValue?: ProbabilisticProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProbabilisticPropertyOutputReference;
    }
    interface RuleProperty {
        /**
        * probabilistic block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_indexing_rule#probabilistic AwsIndexingRule#probabilistic}
        */
        readonly probabilistic?: ProbabilisticProperty[] | cdktn.IResolvable;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _probabilistic;
        get probabilistic(): ProbabilisticPropertyList;
        putProbabilistic(value: ProbabilisticProperty[] | cdktn.IResolvable): void;
        resetProbabilistic(): void;
        get probabilisticInput(): cdktn.IResolvable | ProbabilisticProperty[] | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
}
