import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSelectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#iam_role_arn AwsSelection#iam_role_arn}
    */
    readonly iamRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#id AwsSelection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#name AwsSelection#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#not_resources AwsSelection#not_resources}
    */
    readonly notResources?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#plan_id AwsSelection#plan_id}
    */
    readonly planId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#region AwsSelection#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#resources AwsSelection#resources}
    */
    readonly resources?: string[];
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#condition AwsSelection#condition}
    */
    readonly condition?: AwsSelection.ConditionProperty[] | cdktn.IResolvable;
    /**
    * selection_tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#selection_tag AwsSelection#selection_tag}
    */
    readonly selectionTag?: AwsSelection.SelectionTagProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection aws_backup_selection}
*/
export declare class AwsSelection extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_backup_selection";
    /**
    * Generates CDKTN code for importing a AwsSelection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSelection to import
    * @param importFromId The id of the existing AwsSelection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSelection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection aws_backup_selection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSelectionConfig
    */
    constructor(scope: Construct, id: string, config: AwsSelectionConfig);
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    get iamRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _notResources?;
    get notResources(): string[];
    set notResources(value: string[]);
    resetNotResources(): void;
    get notResourcesInput(): string[] | undefined;
    private _planId?;
    get planId(): string;
    set planId(value: string);
    get planIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resources?;
    get resources(): string[];
    set resources(value: string[]);
    resetResources(): void;
    get resourcesInput(): string[] | undefined;
    private _condition;
    get condition(): AwsSelection.ConditionPropertyList;
    putCondition(value: AwsSelection.ConditionProperty[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | AwsSelection.ConditionProperty[] | undefined;
    private _selectionTag;
    get selectionTag(): AwsSelection.SelectionTagPropertyList;
    putSelectionTag(value: AwsSelection.SelectionTagProperty[] | cdktn.IResolvable): void;
    resetSelectionTag(): void;
    get selectionTagInput(): cdktn.IResolvable | AwsSelection.SelectionTagProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSelectionStringEqualsPropertyToTerraform(struct?: AwsSelection.StringEqualsProperty | cdktn.IResolvable): any;
export declare function awsSelectionStringEqualsPropertyToHclTerraform(struct?: AwsSelection.StringEqualsProperty | cdktn.IResolvable): any;
export declare function awsSelectionStringLikePropertyToTerraform(struct?: AwsSelection.StringLikeProperty | cdktn.IResolvable): any;
export declare function awsSelectionStringLikePropertyToHclTerraform(struct?: AwsSelection.StringLikeProperty | cdktn.IResolvable): any;
export declare function awsSelectionStringNotEqualsPropertyToTerraform(struct?: AwsSelection.StringNotEqualsProperty | cdktn.IResolvable): any;
export declare function awsSelectionStringNotEqualsPropertyToHclTerraform(struct?: AwsSelection.StringNotEqualsProperty | cdktn.IResolvable): any;
export declare function awsSelectionStringNotLikePropertyToTerraform(struct?: AwsSelection.StringNotLikeProperty | cdktn.IResolvable): any;
export declare function awsSelectionStringNotLikePropertyToHclTerraform(struct?: AwsSelection.StringNotLikeProperty | cdktn.IResolvable): any;
export declare function awsSelectionConditionPropertyToTerraform(struct?: AwsSelection.ConditionProperty | cdktn.IResolvable): any;
export declare function awsSelectionConditionPropertyToHclTerraform(struct?: AwsSelection.ConditionProperty | cdktn.IResolvable): any;
export declare function awsSelectionSelectionTagPropertyToTerraform(struct?: AwsSelection.SelectionTagProperty | cdktn.IResolvable): any;
export declare function awsSelectionSelectionTagPropertyToHclTerraform(struct?: AwsSelection.SelectionTagProperty | cdktn.IResolvable): any;
export declare namespace AwsSelection {
    interface StringEqualsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#key AwsSelection#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#value AwsSelection#value}
        */
        readonly value: string;
    }
    class StringEqualsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StringEqualsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StringEqualsProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class StringEqualsPropertyList extends cdktn.ComplexList {
        internalValue?: StringEqualsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StringEqualsPropertyOutputReference;
    }
    interface StringLikeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#key AwsSelection#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#value AwsSelection#value}
        */
        readonly value: string;
    }
    class StringLikePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StringLikeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StringLikeProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class StringLikePropertyList extends cdktn.ComplexList {
        internalValue?: StringLikeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StringLikePropertyOutputReference;
    }
    interface StringNotEqualsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#key AwsSelection#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#value AwsSelection#value}
        */
        readonly value: string;
    }
    class StringNotEqualsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StringNotEqualsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StringNotEqualsProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class StringNotEqualsPropertyList extends cdktn.ComplexList {
        internalValue?: StringNotEqualsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StringNotEqualsPropertyOutputReference;
    }
    interface StringNotLikeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#key AwsSelection#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#value AwsSelection#value}
        */
        readonly value: string;
    }
    class StringNotLikePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StringNotLikeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StringNotLikeProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class StringNotLikePropertyList extends cdktn.ComplexList {
        internalValue?: StringNotLikeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StringNotLikePropertyOutputReference;
    }
    interface ConditionProperty {
        /**
        * string_equals block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#string_equals AwsSelection#string_equals}
        */
        readonly stringEquals?: StringEqualsProperty[] | cdktn.IResolvable;
        /**
        * string_like block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#string_like AwsSelection#string_like}
        */
        readonly stringLike?: StringLikeProperty[] | cdktn.IResolvable;
        /**
        * string_not_equals block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#string_not_equals AwsSelection#string_not_equals}
        */
        readonly stringNotEquals?: StringNotEqualsProperty[] | cdktn.IResolvable;
        /**
        * string_not_like block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#string_not_like AwsSelection#string_not_like}
        */
        readonly stringNotLike?: StringNotLikeProperty[] | cdktn.IResolvable;
    }
    class ConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionProperty | cdktn.IResolvable | undefined);
        private _stringEquals;
        get stringEquals(): StringEqualsPropertyList;
        putStringEquals(value: StringEqualsProperty[] | cdktn.IResolvable): void;
        resetStringEquals(): void;
        get stringEqualsInput(): cdktn.IResolvable | StringEqualsProperty[] | undefined;
        private _stringLike;
        get stringLike(): StringLikePropertyList;
        putStringLike(value: StringLikeProperty[] | cdktn.IResolvable): void;
        resetStringLike(): void;
        get stringLikeInput(): cdktn.IResolvable | StringLikeProperty[] | undefined;
        private _stringNotEquals;
        get stringNotEquals(): StringNotEqualsPropertyList;
        putStringNotEquals(value: StringNotEqualsProperty[] | cdktn.IResolvable): void;
        resetStringNotEquals(): void;
        get stringNotEqualsInput(): cdktn.IResolvable | StringNotEqualsProperty[] | undefined;
        private _stringNotLike;
        get stringNotLike(): StringNotLikePropertyList;
        putStringNotLike(value: StringNotLikeProperty[] | cdktn.IResolvable): void;
        resetStringNotLike(): void;
        get stringNotLikeInput(): cdktn.IResolvable | StringNotLikeProperty[] | undefined;
    }
    class ConditionPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionPropertyOutputReference;
    }
    interface SelectionTagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#key AwsSelection#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#type AwsSelection#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/backup_selection#value AwsSelection#value}
        */
        readonly value: string;
    }
    class SelectionTagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SelectionTagProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SelectionTagProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class SelectionTagPropertyList extends cdktn.ComplexList {
        internalValue?: SelectionTagProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SelectionTagPropertyOutputReference;
    }
}
