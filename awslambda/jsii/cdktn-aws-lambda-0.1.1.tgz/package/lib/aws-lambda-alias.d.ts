import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLambdaAliasConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_alias#description AwsLambdaAlias#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_alias#function_name AwsLambdaAlias#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_alias#function_version AwsLambdaAlias#function_version}
    */
    readonly functionVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_alias#id AwsLambdaAlias#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_alias#name AwsLambdaAlias#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_alias#region AwsLambdaAlias#region}
    */
    readonly region?: string;
    /**
    * routing_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_alias#routing_config AwsLambdaAlias#routing_config}
    */
    readonly routingConfig?: AwsLambdaAlias.RoutingConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_alias#timeouts AwsLambdaAlias#timeouts}
    */
    readonly timeouts?: AwsLambdaAlias.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_alias aws_lambda_alias}
*/
export declare class AwsLambdaAlias extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambda_alias";
    /**
    * Generates CDKTN code for importing a AwsLambdaAlias resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLambdaAlias to import
    * @param importFromId The id of the existing AwsLambdaAlias that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_alias#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLambdaAlias to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_alias aws_lambda_alias} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLambdaAliasConfig
    */
    constructor(scope: Construct, id: string, config: AwsLambdaAliasConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _functionVersion?;
    get functionVersion(): string;
    set functionVersion(value: string);
    get functionVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get invokeArn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routingConfig;
    get routingConfig(): AwsLambdaAlias.RoutingConfigPropertyOutputReference;
    putRoutingConfig(value: AwsLambdaAlias.RoutingConfigProperty): void;
    resetRoutingConfig(): void;
    get routingConfigInput(): AwsLambdaAlias.RoutingConfigProperty | undefined;
    private _timeouts;
    get timeouts(): AwsLambdaAlias.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsLambdaAlias.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsLambdaAlias.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLambdaAliasRoutingConfigPropertyToTerraform(struct?: AwsLambdaAlias.RoutingConfigPropertyOutputReference | AwsLambdaAlias.RoutingConfigProperty): any;
export declare function awsLambdaAliasRoutingConfigPropertyToHclTerraform(struct?: AwsLambdaAlias.RoutingConfigPropertyOutputReference | AwsLambdaAlias.RoutingConfigProperty): any;
export declare function awsLambdaAliasTimeoutsPropertyToTerraform(struct?: AwsLambdaAlias.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLambdaAliasTimeoutsPropertyToHclTerraform(struct?: AwsLambdaAlias.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsLambdaAlias {
    interface RoutingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_alias#additional_version_weights AwsLambdaAlias#additional_version_weights}
        */
        readonly additionalVersionWeights?: {
            [key: string]: number;
        };
    }
    class RoutingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RoutingConfigProperty | undefined;
        set internalValue(value: RoutingConfigProperty | undefined);
        private _additionalVersionWeights?;
        get additionalVersionWeights(): {
            [key: string]: number;
        };
        set additionalVersionWeights(value: {
            [key: string]: number;
        });
        resetAdditionalVersionWeights(): void;
        get additionalVersionWeightsInput(): {
            [key: string]: number;
        } | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_alias#update AwsLambdaAlias#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
