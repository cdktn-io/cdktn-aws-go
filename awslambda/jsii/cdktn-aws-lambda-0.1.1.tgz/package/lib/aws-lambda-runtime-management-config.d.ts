import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLambdaRuntimeManagementConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_runtime_management_config#function_name AwsLambdaRuntimeManagementConfig#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_runtime_management_config#qualifier AwsLambdaRuntimeManagementConfig#qualifier}
    */
    readonly qualifier?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_runtime_management_config#region AwsLambdaRuntimeManagementConfig#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_runtime_management_config#runtime_version_arn AwsLambdaRuntimeManagementConfig#runtime_version_arn}
    */
    readonly runtimeVersionArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_runtime_management_config#update_runtime_on AwsLambdaRuntimeManagementConfig#update_runtime_on}
    */
    readonly updateRuntimeOn?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_runtime_management_config aws_lambda_runtime_management_config}
*/
export declare class AwsLambdaRuntimeManagementConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambda_runtime_management_config";
    /**
    * Generates CDKTN code for importing a AwsLambdaRuntimeManagementConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLambdaRuntimeManagementConfig to import
    * @param importFromId The id of the existing AwsLambdaRuntimeManagementConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_runtime_management_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLambdaRuntimeManagementConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_runtime_management_config aws_lambda_runtime_management_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLambdaRuntimeManagementConfigConfig
    */
    constructor(scope: Construct, id: string, config: AwsLambdaRuntimeManagementConfigConfig);
    get functionArn(): string;
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _qualifier?;
    get qualifier(): string;
    set qualifier(value: string);
    resetQualifier(): void;
    get qualifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _runtimeVersionArn?;
    get runtimeVersionArn(): string;
    set runtimeVersionArn(value: string);
    resetRuntimeVersionArn(): void;
    get runtimeVersionArnInput(): string | undefined;
    private _updateRuntimeOn?;
    get updateRuntimeOn(): string;
    set updateRuntimeOn(value: string);
    resetUpdateRuntimeOn(): void;
    get updateRuntimeOnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
