import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsLambdaFunctionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_function#function_name DataAwsLambdaFunction#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_function#id DataAwsLambdaFunction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_function#qualifier DataAwsLambdaFunction#qualifier}
    */
    readonly qualifier?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_function#region DataAwsLambdaFunction#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_function#tags DataAwsLambdaFunction#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_function aws_lambda_function}
*/
export declare class DataAwsLambdaFunction extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_lambda_function";
    /**
    * Generates CDKTN code for importing a DataAwsLambdaFunction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsLambdaFunction to import
    * @param importFromId The id of the existing DataAwsLambdaFunction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_function#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsLambdaFunction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_function aws_lambda_function} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsLambdaFunctionConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsLambdaFunctionConfig);
    get architectures(): string[];
    get arn(): string;
    private _capacityProviderConfig;
    get capacityProviderConfig(): DataAwsLambdaFunction.CapacityProviderConfigPropertyList;
    get codeSha256(): string;
    get codeSigningConfigArn(): string;
    private _deadLetterConfig;
    get deadLetterConfig(): DataAwsLambdaFunction.DeadLetterConfigPropertyList;
    get description(): string;
    private _durableConfig;
    get durableConfig(): DataAwsLambdaFunction.DurableConfigPropertyList;
    private _environment;
    get environment(): DataAwsLambdaFunction.EnvironmentPropertyList;
    private _ephemeralStorage;
    get ephemeralStorage(): DataAwsLambdaFunction.EphemeralStoragePropertyList;
    private _fileSystemConfig;
    get fileSystemConfig(): DataAwsLambdaFunction.FileSystemConfigPropertyList;
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    get handler(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get imageUri(): string;
    get invokeArn(): string;
    get kmsKeyArn(): string;
    get lastModified(): string;
    get layers(): string[];
    private _loggingConfig;
    get loggingConfig(): DataAwsLambdaFunction.LoggingConfigPropertyList;
    get memorySize(): number;
    get qualifiedArn(): string;
    get qualifiedInvokeArn(): string;
    private _qualifier?;
    get qualifier(): string;
    set qualifier(value: string);
    resetQualifier(): void;
    get qualifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get reservedConcurrentExecutions(): number;
    get responseStreamingInvokeArn(): string;
    get role(): string;
    get runtime(): string;
    get signingJobArn(): string;
    get signingProfileVersionArn(): string;
    get sourceCodeHash(): string;
    get sourceCodeSize(): number;
    get sourceKmsKeyArn(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tenancyConfig;
    get tenancyConfig(): DataAwsLambdaFunction.TenancyConfigPropertyList;
    get timeout(): number;
    private _tracingConfig;
    get tracingConfig(): DataAwsLambdaFunction.TracingConfigPropertyList;
    get version(): string;
    private _vpcConfig;
    get vpcConfig(): DataAwsLambdaFunction.VpcConfigPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsLambdaFunctionLambdaManagedInstancesCapacityProviderConfigPropertyToTerraform(struct?: DataAwsLambdaFunction.LambdaManagedInstancesCapacityProviderConfigProperty): any;
export declare function dataAwsLambdaFunctionLambdaManagedInstancesCapacityProviderConfigPropertyToHclTerraform(struct?: DataAwsLambdaFunction.LambdaManagedInstancesCapacityProviderConfigProperty): any;
export declare function dataAwsLambdaFunctionCapacityProviderConfigPropertyToTerraform(struct?: DataAwsLambdaFunction.CapacityProviderConfigProperty): any;
export declare function dataAwsLambdaFunctionCapacityProviderConfigPropertyToHclTerraform(struct?: DataAwsLambdaFunction.CapacityProviderConfigProperty): any;
export declare function dataAwsLambdaFunctionDeadLetterConfigPropertyToTerraform(struct?: DataAwsLambdaFunction.DeadLetterConfigProperty): any;
export declare function dataAwsLambdaFunctionDeadLetterConfigPropertyToHclTerraform(struct?: DataAwsLambdaFunction.DeadLetterConfigProperty): any;
export declare function dataAwsLambdaFunctionDurableConfigPropertyToTerraform(struct?: DataAwsLambdaFunction.DurableConfigProperty): any;
export declare function dataAwsLambdaFunctionDurableConfigPropertyToHclTerraform(struct?: DataAwsLambdaFunction.DurableConfigProperty): any;
export declare function dataAwsLambdaFunctionEnvironmentPropertyToTerraform(struct?: DataAwsLambdaFunction.EnvironmentProperty): any;
export declare function dataAwsLambdaFunctionEnvironmentPropertyToHclTerraform(struct?: DataAwsLambdaFunction.EnvironmentProperty): any;
export declare function dataAwsLambdaFunctionEphemeralStoragePropertyToTerraform(struct?: DataAwsLambdaFunction.EphemeralStorageProperty): any;
export declare function dataAwsLambdaFunctionEphemeralStoragePropertyToHclTerraform(struct?: DataAwsLambdaFunction.EphemeralStorageProperty): any;
export declare function dataAwsLambdaFunctionFileSystemConfigPropertyToTerraform(struct?: DataAwsLambdaFunction.FileSystemConfigProperty): any;
export declare function dataAwsLambdaFunctionFileSystemConfigPropertyToHclTerraform(struct?: DataAwsLambdaFunction.FileSystemConfigProperty): any;
export declare function dataAwsLambdaFunctionLoggingConfigPropertyToTerraform(struct?: DataAwsLambdaFunction.LoggingConfigProperty): any;
export declare function dataAwsLambdaFunctionLoggingConfigPropertyToHclTerraform(struct?: DataAwsLambdaFunction.LoggingConfigProperty): any;
export declare function dataAwsLambdaFunctionTenancyConfigPropertyToTerraform(struct?: DataAwsLambdaFunction.TenancyConfigProperty): any;
export declare function dataAwsLambdaFunctionTenancyConfigPropertyToHclTerraform(struct?: DataAwsLambdaFunction.TenancyConfigProperty): any;
export declare function dataAwsLambdaFunctionTracingConfigPropertyToTerraform(struct?: DataAwsLambdaFunction.TracingConfigProperty): any;
export declare function dataAwsLambdaFunctionTracingConfigPropertyToHclTerraform(struct?: DataAwsLambdaFunction.TracingConfigProperty): any;
export declare function dataAwsLambdaFunctionVpcConfigPropertyToTerraform(struct?: DataAwsLambdaFunction.VpcConfigProperty): any;
export declare function dataAwsLambdaFunctionVpcConfigPropertyToHclTerraform(struct?: DataAwsLambdaFunction.VpcConfigProperty): any;
export declare namespace DataAwsLambdaFunction {
    interface LambdaManagedInstancesCapacityProviderConfigProperty {
    }
    class LambdaManagedInstancesCapacityProviderConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaManagedInstancesCapacityProviderConfigProperty | undefined;
        set internalValue(value: LambdaManagedInstancesCapacityProviderConfigProperty | undefined);
        get capacityProviderArn(): string;
        get executionEnvironmentMemoryGibPerVcpu(): number;
        get perExecutionEnvironmentMaxConcurrency(): number;
    }
    class LambdaManagedInstancesCapacityProviderConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaManagedInstancesCapacityProviderConfigPropertyOutputReference;
    }
    interface CapacityProviderConfigProperty {
    }
    class CapacityProviderConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityProviderConfigProperty | undefined;
        set internalValue(value: CapacityProviderConfigProperty | undefined);
        private _lambdaManagedInstancesCapacityProviderConfig;
        get lambdaManagedInstancesCapacityProviderConfig(): LambdaManagedInstancesCapacityProviderConfigPropertyList;
    }
    class CapacityProviderConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityProviderConfigPropertyOutputReference;
    }
    interface DeadLetterConfigProperty {
    }
    class DeadLetterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeadLetterConfigProperty | undefined;
        set internalValue(value: DeadLetterConfigProperty | undefined);
        get targetArn(): string;
    }
    class DeadLetterConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeadLetterConfigPropertyOutputReference;
    }
    interface DurableConfigProperty {
    }
    class DurableConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DurableConfigProperty | undefined;
        set internalValue(value: DurableConfigProperty | undefined);
        get executionTimeout(): number;
        get retentionPeriod(): number;
    }
    class DurableConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DurableConfigPropertyOutputReference;
    }
    interface EnvironmentProperty {
    }
    class EnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentProperty | undefined;
        set internalValue(value: EnvironmentProperty | undefined);
        private _variables;
        get variables(): cdktn.StringMap;
    }
    class EnvironmentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentPropertyOutputReference;
    }
    interface EphemeralStorageProperty {
    }
    class EphemeralStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EphemeralStorageProperty | undefined;
        set internalValue(value: EphemeralStorageProperty | undefined);
        get size(): number;
    }
    class EphemeralStoragePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EphemeralStoragePropertyOutputReference;
    }
    interface FileSystemConfigProperty {
    }
    class FileSystemConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FileSystemConfigProperty | undefined;
        set internalValue(value: FileSystemConfigProperty | undefined);
        get arn(): string;
        get localMountPath(): string;
    }
    class FileSystemConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FileSystemConfigPropertyOutputReference;
    }
    interface LoggingConfigProperty {
    }
    class LoggingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoggingConfigProperty | undefined;
        set internalValue(value: LoggingConfigProperty | undefined);
        get applicationLogLevel(): string;
        get logFormat(): string;
        get logGroup(): string;
        get systemLogLevel(): string;
    }
    class LoggingConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoggingConfigPropertyOutputReference;
    }
    interface TenancyConfigProperty {
    }
    class TenancyConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TenancyConfigProperty | undefined;
        set internalValue(value: TenancyConfigProperty | undefined);
        get tenantIsolationMode(): string;
    }
    class TenancyConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TenancyConfigPropertyOutputReference;
    }
    interface TracingConfigProperty {
    }
    class TracingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TracingConfigProperty | undefined;
        set internalValue(value: TracingConfigProperty | undefined);
        get mode(): string;
    }
    class TracingConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TracingConfigPropertyOutputReference;
    }
    interface VpcConfigProperty {
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        get ipv6AllowedForDualStack(): cdktn.IResolvable;
        get securityGroupIds(): string[];
        get subnetIds(): string[];
        get vpcId(): string;
    }
    class VpcConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigPropertyOutputReference;
    }
}
