import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsLambdaCodeSigningConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_code_signing_config#arn DataAwsLambdaCodeSigningConfig#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_code_signing_config#id DataAwsLambdaCodeSigningConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_code_signing_config#region DataAwsLambdaCodeSigningConfig#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_code_signing_config aws_lambda_code_signing_config}
*/
export declare class DataAwsLambdaCodeSigningConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_lambda_code_signing_config";
    /**
    * Generates CDKTN code for importing a DataAwsLambdaCodeSigningConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsLambdaCodeSigningConfig to import
    * @param importFromId The id of the existing DataAwsLambdaCodeSigningConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_code_signing_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsLambdaCodeSigningConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/lambda_code_signing_config aws_lambda_code_signing_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsLambdaCodeSigningConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsLambdaCodeSigningConfigConfig);
    private _allowedPublishers;
    get allowedPublishers(): DataAwsLambdaCodeSigningConfig.AllowedPublishersPropertyList;
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    get configId(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastModified(): string;
    private _policies;
    get policies(): DataAwsLambdaCodeSigningConfig.PoliciesPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsLambdaCodeSigningConfigAllowedPublishersPropertyToTerraform(struct?: DataAwsLambdaCodeSigningConfig.AllowedPublishersProperty): any;
export declare function dataAwsLambdaCodeSigningConfigAllowedPublishersPropertyToHclTerraform(struct?: DataAwsLambdaCodeSigningConfig.AllowedPublishersProperty): any;
export declare function dataAwsLambdaCodeSigningConfigPoliciesPropertyToTerraform(struct?: DataAwsLambdaCodeSigningConfig.PoliciesProperty): any;
export declare function dataAwsLambdaCodeSigningConfigPoliciesPropertyToHclTerraform(struct?: DataAwsLambdaCodeSigningConfig.PoliciesProperty): any;
export declare namespace DataAwsLambdaCodeSigningConfig {
    interface AllowedPublishersProperty {
    }
    class AllowedPublishersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AllowedPublishersProperty | undefined;
        set internalValue(value: AllowedPublishersProperty | undefined);
        get signingProfileVersionArns(): string[];
    }
    class AllowedPublishersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AllowedPublishersPropertyOutputReference;
    }
    interface PoliciesProperty {
    }
    class PoliciesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PoliciesProperty | undefined;
        set internalValue(value: PoliciesProperty | undefined);
        get untrustedArtifactOnDeployment(): string;
    }
    class PoliciesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PoliciesPropertyOutputReference;
    }
}
