import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLambdaFunctionUrlConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url#authorization_type AwsLambdaFunctionUrl#authorization_type}
    */
    readonly authorizationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url#function_name AwsLambdaFunctionUrl#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url#id AwsLambdaFunctionUrl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url#invoke_mode AwsLambdaFunctionUrl#invoke_mode}
    */
    readonly invokeMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url#qualifier AwsLambdaFunctionUrl#qualifier}
    */
    readonly qualifier?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url#region AwsLambdaFunctionUrl#region}
    */
    readonly region?: string;
    /**
    * cors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url#cors AwsLambdaFunctionUrl#cors}
    */
    readonly cors?: AwsLambdaFunctionUrl.CorsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url#timeouts AwsLambdaFunctionUrl#timeouts}
    */
    readonly timeouts?: AwsLambdaFunctionUrl.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url aws_lambda_function_url}
*/
export declare class AwsLambdaFunctionUrl extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambda_function_url";
    /**
    * Generates CDKTN code for importing a AwsLambdaFunctionUrl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLambdaFunctionUrl to import
    * @param importFromId The id of the existing AwsLambdaFunctionUrl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLambdaFunctionUrl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url aws_lambda_function_url} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLambdaFunctionUrlConfig
    */
    constructor(scope: Construct, id: string, config: AwsLambdaFunctionUrlConfig);
    private _authorizationType?;
    get authorizationType(): string;
    set authorizationType(value: string);
    get authorizationTypeInput(): string | undefined;
    get functionArn(): string;
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    get functionUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _invokeMode?;
    get invokeMode(): string;
    set invokeMode(value: string);
    resetInvokeMode(): void;
    get invokeModeInput(): string | undefined;
    private _qualifier?;
    get qualifier(): string;
    set qualifier(value: string);
    resetQualifier(): void;
    get qualifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get urlId(): string;
    private _cors;
    get cors(): AwsLambdaFunctionUrl.CorsPropertyOutputReference;
    putCors(value: AwsLambdaFunctionUrl.CorsProperty): void;
    resetCors(): void;
    get corsInput(): AwsLambdaFunctionUrl.CorsProperty | undefined;
    private _timeouts;
    get timeouts(): AwsLambdaFunctionUrl.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsLambdaFunctionUrl.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsLambdaFunctionUrl.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLambdaFunctionUrlCorsPropertyToTerraform(struct?: AwsLambdaFunctionUrl.CorsPropertyOutputReference | AwsLambdaFunctionUrl.CorsProperty): any;
export declare function awsLambdaFunctionUrlCorsPropertyToHclTerraform(struct?: AwsLambdaFunctionUrl.CorsPropertyOutputReference | AwsLambdaFunctionUrl.CorsProperty): any;
export declare function awsLambdaFunctionUrlTimeoutsPropertyToTerraform(struct?: AwsLambdaFunctionUrl.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLambdaFunctionUrlTimeoutsPropertyToHclTerraform(struct?: AwsLambdaFunctionUrl.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsLambdaFunctionUrl {
    interface CorsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url#allow_credentials AwsLambdaFunctionUrl#allow_credentials}
        */
        readonly allowCredentials?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url#allow_headers AwsLambdaFunctionUrl#allow_headers}
        */
        readonly allowHeaders?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url#allow_methods AwsLambdaFunctionUrl#allow_methods}
        */
        readonly allowMethods?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url#allow_origins AwsLambdaFunctionUrl#allow_origins}
        */
        readonly allowOrigins?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url#expose_headers AwsLambdaFunctionUrl#expose_headers}
        */
        readonly exposeHeaders?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url#max_age AwsLambdaFunctionUrl#max_age}
        */
        readonly maxAge?: number;
    }
    class CorsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CorsProperty | undefined;
        set internalValue(value: CorsProperty | undefined);
        private _allowCredentials?;
        get allowCredentials(): boolean | cdktn.IResolvable;
        set allowCredentials(value: boolean | cdktn.IResolvable);
        resetAllowCredentials(): void;
        get allowCredentialsInput(): boolean | cdktn.IResolvable | undefined;
        private _allowHeaders?;
        get allowHeaders(): string[];
        set allowHeaders(value: string[]);
        resetAllowHeaders(): void;
        get allowHeadersInput(): string[] | undefined;
        private _allowMethods?;
        get allowMethods(): string[];
        set allowMethods(value: string[]);
        resetAllowMethods(): void;
        get allowMethodsInput(): string[] | undefined;
        private _allowOrigins?;
        get allowOrigins(): string[];
        set allowOrigins(value: string[]);
        resetAllowOrigins(): void;
        get allowOriginsInput(): string[] | undefined;
        private _exposeHeaders?;
        get exposeHeaders(): string[];
        set exposeHeaders(value: string[]);
        resetExposeHeaders(): void;
        get exposeHeadersInput(): string[] | undefined;
        private _maxAge?;
        get maxAge(): number;
        set maxAge(value: number);
        resetMaxAge(): void;
        get maxAgeInput(): number | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_url#create AwsLambdaFunctionUrl#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
