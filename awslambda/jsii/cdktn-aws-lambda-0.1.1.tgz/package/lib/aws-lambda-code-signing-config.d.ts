import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLambdaCodeSigningConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_code_signing_config#description AwsLambdaCodeSigningConfig#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_code_signing_config#id AwsLambdaCodeSigningConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_code_signing_config#region AwsLambdaCodeSigningConfig#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_code_signing_config#tags AwsLambdaCodeSigningConfig#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_code_signing_config#tags_all AwsLambdaCodeSigningConfig#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * allowed_publishers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_code_signing_config#allowed_publishers AwsLambdaCodeSigningConfig#allowed_publishers}
    */
    readonly allowedPublishers: AwsLambdaCodeSigningConfig.AllowedPublishersProperty;
    /**
    * policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_code_signing_config#policies AwsLambdaCodeSigningConfig#policies}
    */
    readonly policies?: AwsLambdaCodeSigningConfig.PoliciesProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_code_signing_config aws_lambda_code_signing_config}
*/
export declare class AwsLambdaCodeSigningConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambda_code_signing_config";
    /**
    * Generates CDKTN code for importing a AwsLambdaCodeSigningConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLambdaCodeSigningConfig to import
    * @param importFromId The id of the existing AwsLambdaCodeSigningConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_code_signing_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLambdaCodeSigningConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_code_signing_config aws_lambda_code_signing_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLambdaCodeSigningConfigConfig
    */
    constructor(scope: Construct, id: string, config: AwsLambdaCodeSigningConfigConfig);
    get arn(): string;
    get configId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastModified(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _allowedPublishers;
    get allowedPublishers(): AwsLambdaCodeSigningConfig.AllowedPublishersPropertyOutputReference;
    putAllowedPublishers(value: AwsLambdaCodeSigningConfig.AllowedPublishersProperty): void;
    get allowedPublishersInput(): AwsLambdaCodeSigningConfig.AllowedPublishersProperty | undefined;
    private _policies;
    get policies(): AwsLambdaCodeSigningConfig.PoliciesPropertyOutputReference;
    putPolicies(value: AwsLambdaCodeSigningConfig.PoliciesProperty): void;
    resetPolicies(): void;
    get policiesInput(): AwsLambdaCodeSigningConfig.PoliciesProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLambdaCodeSigningConfigAllowedPublishersPropertyToTerraform(struct?: AwsLambdaCodeSigningConfig.AllowedPublishersPropertyOutputReference | AwsLambdaCodeSigningConfig.AllowedPublishersProperty): any;
export declare function awsLambdaCodeSigningConfigAllowedPublishersPropertyToHclTerraform(struct?: AwsLambdaCodeSigningConfig.AllowedPublishersPropertyOutputReference | AwsLambdaCodeSigningConfig.AllowedPublishersProperty): any;
export declare function awsLambdaCodeSigningConfigPoliciesPropertyToTerraform(struct?: AwsLambdaCodeSigningConfig.PoliciesPropertyOutputReference | AwsLambdaCodeSigningConfig.PoliciesProperty): any;
export declare function awsLambdaCodeSigningConfigPoliciesPropertyToHclTerraform(struct?: AwsLambdaCodeSigningConfig.PoliciesPropertyOutputReference | AwsLambdaCodeSigningConfig.PoliciesProperty): any;
export declare namespace AwsLambdaCodeSigningConfig {
    interface AllowedPublishersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_code_signing_config#signing_profile_version_arns AwsLambdaCodeSigningConfig#signing_profile_version_arns}
        */
        readonly signingProfileVersionArns: string[];
    }
    class AllowedPublishersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AllowedPublishersProperty | undefined;
        set internalValue(value: AllowedPublishersProperty | undefined);
        private _signingProfileVersionArns?;
        get signingProfileVersionArns(): string[];
        set signingProfileVersionArns(value: string[]);
        get signingProfileVersionArnsInput(): string[] | undefined;
    }
    interface PoliciesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_code_signing_config#untrusted_artifact_on_deployment AwsLambdaCodeSigningConfig#untrusted_artifact_on_deployment}
        */
        readonly untrustedArtifactOnDeployment: string;
    }
    class PoliciesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PoliciesProperty | undefined;
        set internalValue(value: PoliciesProperty | undefined);
        private _untrustedArtifactOnDeployment?;
        get untrustedArtifactOnDeployment(): string;
        set untrustedArtifactOnDeployment(value: string);
        get untrustedArtifactOnDeploymentInput(): string | undefined;
    }
}
