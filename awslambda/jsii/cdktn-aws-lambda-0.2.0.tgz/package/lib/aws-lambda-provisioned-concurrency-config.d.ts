import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfProvisionedConcurrencyConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_provisioned_concurrency_config#function_name TfProvisionedConcurrencyConfig#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_provisioned_concurrency_config#id TfProvisionedConcurrencyConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_provisioned_concurrency_config#provisioned_concurrent_executions TfProvisionedConcurrencyConfig#provisioned_concurrent_executions}
    */
    readonly provisionedConcurrentExecutions: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_provisioned_concurrency_config#qualifier TfProvisionedConcurrencyConfig#qualifier}
    */
    readonly qualifier: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_provisioned_concurrency_config#region TfProvisionedConcurrencyConfig#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_provisioned_concurrency_config#skip_destroy TfProvisionedConcurrencyConfig#skip_destroy}
    */
    readonly skipDestroy?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_provisioned_concurrency_config#timeouts TfProvisionedConcurrencyConfig#timeouts}
    */
    readonly timeouts?: TfProvisionedConcurrencyConfig.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_provisioned_concurrency_config aws_lambda_provisioned_concurrency_config}
*/
export declare class TfProvisionedConcurrencyConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambda_provisioned_concurrency_config";
    /**
    * Generates CDKTN code for importing a TfProvisionedConcurrencyConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfProvisionedConcurrencyConfig to import
    * @param importFromId The id of the existing TfProvisionedConcurrencyConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_provisioned_concurrency_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfProvisionedConcurrencyConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_provisioned_concurrency_config aws_lambda_provisioned_concurrency_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfProvisionedConcurrencyConfigConfig
    */
    constructor(scope: Construct, id: string, config: TfProvisionedConcurrencyConfigConfig);
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _provisionedConcurrentExecutions?;
    get provisionedConcurrentExecutions(): number;
    set provisionedConcurrentExecutions(value: number);
    get provisionedConcurrentExecutionsInput(): number | undefined;
    private _qualifier?;
    get qualifier(): string;
    set qualifier(value: string);
    get qualifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _skipDestroy?;
    get skipDestroy(): boolean | cdktn.IResolvable;
    set skipDestroy(value: boolean | cdktn.IResolvable);
    resetSkipDestroy(): void;
    get skipDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): TfProvisionedConcurrencyConfig.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfProvisionedConcurrencyConfig.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfProvisionedConcurrencyConfig.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfProvisionedConcurrencyConfigTimeoutsPropertyToTerraform(struct?: TfProvisionedConcurrencyConfig.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfProvisionedConcurrencyConfigTimeoutsPropertyToHclTerraform(struct?: TfProvisionedConcurrencyConfig.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfProvisionedConcurrencyConfig {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_provisioned_concurrency_config#create TfProvisionedConcurrencyConfig#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_provisioned_concurrency_config#update TfProvisionedConcurrencyConfig#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
