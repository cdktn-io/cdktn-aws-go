import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFunctionScalingConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name or ARN of the Lambda function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_scaling_config#function_name TfFunctionScalingConfig#function_name}
    */
    readonly functionName: string;
    /**
    * Qualifier for the scaling configuration. Valid values: $LATEST.PUBLISHED or a numeric version number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_scaling_config#qualifier TfFunctionScalingConfig#qualifier}
    */
    readonly qualifier: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_scaling_config#region TfFunctionScalingConfig#region}
    */
    readonly region?: string;
    /**
    * function_scaling_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_scaling_config#function_scaling_config TfFunctionScalingConfig#function_scaling_config}
    */
    readonly functionScalingConfig?: TfFunctionScalingConfig.FunctionScalingConfigProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_scaling_config#timeouts TfFunctionScalingConfig#timeouts}
    */
    readonly timeouts?: TfFunctionScalingConfig.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_scaling_config aws_lambda_function_scaling_config}
*/
export declare class TfFunctionScalingConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambda_function_scaling_config";
    /**
    * Generates CDKTN code for importing a TfFunctionScalingConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFunctionScalingConfig to import
    * @param importFromId The id of the existing TfFunctionScalingConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_scaling_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFunctionScalingConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_scaling_config aws_lambda_function_scaling_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFunctionScalingConfigConfig
    */
    constructor(scope: Construct, id: string, config: TfFunctionScalingConfigConfig);
    get functionArn(): string;
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    get functionState(): string;
    private _qualifier?;
    get qualifier(): string;
    set qualifier(value: string);
    get qualifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _functionScalingConfig;
    get functionScalingConfig(): TfFunctionScalingConfig.FunctionScalingConfigPropertyList;
    putFunctionScalingConfig(value: TfFunctionScalingConfig.FunctionScalingConfigProperty[] | cdktn.IResolvable): void;
    resetFunctionScalingConfig(): void;
    get functionScalingConfigInput(): cdktn.IResolvable | TfFunctionScalingConfig.FunctionScalingConfigProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfFunctionScalingConfig.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfFunctionScalingConfig.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfFunctionScalingConfig.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfFunctionScalingConfigFunctionScalingConfigPropertyToTerraform(struct?: TfFunctionScalingConfig.FunctionScalingConfigProperty | cdktn.IResolvable): any;
export declare function tfFunctionScalingConfigFunctionScalingConfigPropertyToHclTerraform(struct?: TfFunctionScalingConfig.FunctionScalingConfigProperty | cdktn.IResolvable): any;
export declare function tfFunctionScalingConfigTimeoutsPropertyToTerraform(struct?: TfFunctionScalingConfig.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfFunctionScalingConfigTimeoutsPropertyToHclTerraform(struct?: TfFunctionScalingConfig.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfFunctionScalingConfig {
    interface FunctionScalingConfigProperty {
        /**
        * Maximum number of execution environments that can be provisioned for the function.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_scaling_config#max_execution_environments TfFunctionScalingConfig#max_execution_environments}
        */
        readonly maxExecutionEnvironments?: number;
        /**
        * Minimum number of execution environments to maintain for the function.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_scaling_config#min_execution_environments TfFunctionScalingConfig#min_execution_environments}
        */
        readonly minExecutionEnvironments?: number;
    }
    class FunctionScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FunctionScalingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FunctionScalingConfigProperty | cdktn.IResolvable | undefined);
        private _maxExecutionEnvironments?;
        get maxExecutionEnvironments(): number;
        set maxExecutionEnvironments(value: number);
        resetMaxExecutionEnvironments(): void;
        get maxExecutionEnvironmentsInput(): number | undefined;
        private _minExecutionEnvironments?;
        get minExecutionEnvironments(): number;
        set minExecutionEnvironments(value: number);
        resetMinExecutionEnvironments(): void;
        get minExecutionEnvironmentsInput(): number | undefined;
    }
    class FunctionScalingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: FunctionScalingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FunctionScalingConfigPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_scaling_config#create TfFunctionScalingConfig#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_scaling_config#delete TfFunctionScalingConfig#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_scaling_config#update TfFunctionScalingConfig#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
