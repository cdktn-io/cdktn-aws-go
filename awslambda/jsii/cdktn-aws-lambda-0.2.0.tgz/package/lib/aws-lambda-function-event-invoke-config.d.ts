import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFunctionEventInvokeConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_event_invoke_config#function_name TfFunctionEventInvokeConfig#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_event_invoke_config#id TfFunctionEventInvokeConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_event_invoke_config#maximum_event_age_in_seconds TfFunctionEventInvokeConfig#maximum_event_age_in_seconds}
    */
    readonly maximumEventAgeInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_event_invoke_config#maximum_retry_attempts TfFunctionEventInvokeConfig#maximum_retry_attempts}
    */
    readonly maximumRetryAttempts?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_event_invoke_config#qualifier TfFunctionEventInvokeConfig#qualifier}
    */
    readonly qualifier?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_event_invoke_config#region TfFunctionEventInvokeConfig#region}
    */
    readonly region?: string;
    /**
    * destination_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_event_invoke_config#destination_config TfFunctionEventInvokeConfig#destination_config}
    */
    readonly destinationConfig?: TfFunctionEventInvokeConfig.DestinationConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_event_invoke_config aws_lambda_function_event_invoke_config}
*/
export declare class TfFunctionEventInvokeConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambda_function_event_invoke_config";
    /**
    * Generates CDKTN code for importing a TfFunctionEventInvokeConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFunctionEventInvokeConfig to import
    * @param importFromId The id of the existing TfFunctionEventInvokeConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_event_invoke_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFunctionEventInvokeConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_event_invoke_config aws_lambda_function_event_invoke_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFunctionEventInvokeConfigConfig
    */
    constructor(scope: Construct, id: string, config: TfFunctionEventInvokeConfigConfig);
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maximumEventAgeInSeconds?;
    get maximumEventAgeInSeconds(): number;
    set maximumEventAgeInSeconds(value: number);
    resetMaximumEventAgeInSeconds(): void;
    get maximumEventAgeInSecondsInput(): number | undefined;
    private _maximumRetryAttempts?;
    get maximumRetryAttempts(): number;
    set maximumRetryAttempts(value: number);
    resetMaximumRetryAttempts(): void;
    get maximumRetryAttemptsInput(): number | undefined;
    private _qualifier?;
    get qualifier(): string;
    set qualifier(value: string);
    resetQualifier(): void;
    get qualifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _destinationConfig;
    get destinationConfig(): TfFunctionEventInvokeConfig.DestinationConfigPropertyOutputReference;
    putDestinationConfig(value: TfFunctionEventInvokeConfig.DestinationConfigProperty): void;
    resetDestinationConfig(): void;
    get destinationConfigInput(): TfFunctionEventInvokeConfig.DestinationConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfFunctionEventInvokeConfigOnFailurePropertyToTerraform(struct?: TfFunctionEventInvokeConfig.OnFailurePropertyOutputReference | TfFunctionEventInvokeConfig.OnFailureProperty): any;
export declare function tfFunctionEventInvokeConfigOnFailurePropertyToHclTerraform(struct?: TfFunctionEventInvokeConfig.OnFailurePropertyOutputReference | TfFunctionEventInvokeConfig.OnFailureProperty): any;
export declare function tfFunctionEventInvokeConfigOnSuccessPropertyToTerraform(struct?: TfFunctionEventInvokeConfig.OnSuccessPropertyOutputReference | TfFunctionEventInvokeConfig.OnSuccessProperty): any;
export declare function tfFunctionEventInvokeConfigOnSuccessPropertyToHclTerraform(struct?: TfFunctionEventInvokeConfig.OnSuccessPropertyOutputReference | TfFunctionEventInvokeConfig.OnSuccessProperty): any;
export declare function tfFunctionEventInvokeConfigDestinationConfigPropertyToTerraform(struct?: TfFunctionEventInvokeConfig.DestinationConfigPropertyOutputReference | TfFunctionEventInvokeConfig.DestinationConfigProperty): any;
export declare function tfFunctionEventInvokeConfigDestinationConfigPropertyToHclTerraform(struct?: TfFunctionEventInvokeConfig.DestinationConfigPropertyOutputReference | TfFunctionEventInvokeConfig.DestinationConfigProperty): any;
export declare namespace TfFunctionEventInvokeConfig {
    interface OnFailureProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_event_invoke_config#destination TfFunctionEventInvokeConfig#destination}
        */
        readonly destination: string;
    }
    class OnFailurePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnFailureProperty | undefined;
        set internalValue(value: OnFailureProperty | undefined);
        private _destination?;
        get destination(): string;
        set destination(value: string);
        get destinationInput(): string | undefined;
    }
    interface OnSuccessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_event_invoke_config#destination TfFunctionEventInvokeConfig#destination}
        */
        readonly destination: string;
    }
    class OnSuccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnSuccessProperty | undefined;
        set internalValue(value: OnSuccessProperty | undefined);
        private _destination?;
        get destination(): string;
        set destination(value: string);
        get destinationInput(): string | undefined;
    }
    interface DestinationConfigProperty {
        /**
        * on_failure block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_event_invoke_config#on_failure TfFunctionEventInvokeConfig#on_failure}
        */
        readonly onFailure?: OnFailureProperty;
        /**
        * on_success block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_event_invoke_config#on_success TfFunctionEventInvokeConfig#on_success}
        */
        readonly onSuccess?: OnSuccessProperty;
    }
    class DestinationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationConfigProperty | undefined;
        set internalValue(value: DestinationConfigProperty | undefined);
        private _onFailure;
        get onFailure(): OnFailurePropertyOutputReference;
        putOnFailure(value: OnFailureProperty): void;
        resetOnFailure(): void;
        get onFailureInput(): OnFailureProperty | undefined;
        private _onSuccess;
        get onSuccess(): OnSuccessPropertyOutputReference;
        putOnSuccess(value: OnSuccessProperty): void;
        resetOnSuccess(): void;
        get onSuccessInput(): OnSuccessProperty | undefined;
    }
}
