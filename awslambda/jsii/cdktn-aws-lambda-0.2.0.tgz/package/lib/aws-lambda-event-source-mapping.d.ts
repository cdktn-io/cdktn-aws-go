import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfEventSourceMappingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#batch_size TfEventSourceMapping#batch_size}
    */
    readonly batchSize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#bisect_batch_on_function_error TfEventSourceMapping#bisect_batch_on_function_error}
    */
    readonly bisectBatchOnFunctionError?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#enabled TfEventSourceMapping#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#event_source_arn TfEventSourceMapping#event_source_arn}
    */
    readonly eventSourceArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#function_name TfEventSourceMapping#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#function_response_types TfEventSourceMapping#function_response_types}
    */
    readonly functionResponseTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#id TfEventSourceMapping#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#kms_key_arn TfEventSourceMapping#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#maximum_batching_window_in_seconds TfEventSourceMapping#maximum_batching_window_in_seconds}
    */
    readonly maximumBatchingWindowInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#maximum_record_age_in_seconds TfEventSourceMapping#maximum_record_age_in_seconds}
    */
    readonly maximumRecordAgeInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#maximum_retry_attempts TfEventSourceMapping#maximum_retry_attempts}
    */
    readonly maximumRetryAttempts?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#parallelization_factor TfEventSourceMapping#parallelization_factor}
    */
    readonly parallelizationFactor?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#queues TfEventSourceMapping#queues}
    */
    readonly queues?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#region TfEventSourceMapping#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#starting_position TfEventSourceMapping#starting_position}
    */
    readonly startingPosition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#starting_position_timestamp TfEventSourceMapping#starting_position_timestamp}
    */
    readonly startingPositionTimestamp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#tags TfEventSourceMapping#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#tags_all TfEventSourceMapping#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#topics TfEventSourceMapping#topics}
    */
    readonly topics?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#tumbling_window_in_seconds TfEventSourceMapping#tumbling_window_in_seconds}
    */
    readonly tumblingWindowInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#use_resource_timeout_for_propagation TfEventSourceMapping#use_resource_timeout_for_propagation}
    */
    readonly useResourceTimeoutForPropagation?: boolean | cdktn.IResolvable;
    /**
    * amazon_managed_kafka_event_source_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#amazon_managed_kafka_event_source_config TfEventSourceMapping#amazon_managed_kafka_event_source_config}
    */
    readonly amazonManagedKafkaEventSourceConfig?: TfEventSourceMapping.AmazonManagedKafkaEventSourceConfigProperty;
    /**
    * destination_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#destination_config TfEventSourceMapping#destination_config}
    */
    readonly destinationConfig?: TfEventSourceMapping.DestinationConfigProperty;
    /**
    * document_db_event_source_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#document_db_event_source_config TfEventSourceMapping#document_db_event_source_config}
    */
    readonly documentDbEventSourceConfig?: TfEventSourceMapping.DocumentDbEventSourceConfigProperty;
    /**
    * filter_criteria block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#filter_criteria TfEventSourceMapping#filter_criteria}
    */
    readonly filterCriteria?: TfEventSourceMapping.FilterCriteriaProperty;
    /**
    * metrics_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#metrics_config TfEventSourceMapping#metrics_config}
    */
    readonly metricsConfig?: TfEventSourceMapping.MetricsConfigProperty;
    /**
    * provisioned_poller_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#provisioned_poller_config TfEventSourceMapping#provisioned_poller_config}
    */
    readonly provisionedPollerConfig?: TfEventSourceMapping.ProvisionedPollerConfigProperty;
    /**
    * scaling_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#scaling_config TfEventSourceMapping#scaling_config}
    */
    readonly scalingConfig?: TfEventSourceMapping.ScalingConfigProperty;
    /**
    * self_managed_event_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#self_managed_event_source TfEventSourceMapping#self_managed_event_source}
    */
    readonly selfManagedEventSource?: TfEventSourceMapping.SelfManagedEventSourceProperty;
    /**
    * self_managed_kafka_event_source_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#self_managed_kafka_event_source_config TfEventSourceMapping#self_managed_kafka_event_source_config}
    */
    readonly selfManagedKafkaEventSourceConfig?: TfEventSourceMapping.SelfManagedKafkaEventSourceConfigProperty;
    /**
    * source_access_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#source_access_configuration TfEventSourceMapping#source_access_configuration}
    */
    readonly sourceAccessConfiguration?: TfEventSourceMapping.SourceAccessConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#timeouts TfEventSourceMapping#timeouts}
    */
    readonly timeouts?: TfEventSourceMapping.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping aws_lambda_event_source_mapping}
*/
export declare class TfEventSourceMapping extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambda_event_source_mapping";
    /**
    * Generates CDKTN code for importing a TfEventSourceMapping resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfEventSourceMapping to import
    * @param importFromId The id of the existing TfEventSourceMapping that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfEventSourceMapping to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping aws_lambda_event_source_mapping} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfEventSourceMappingConfig
    */
    constructor(scope: Construct, id: string, config: TfEventSourceMappingConfig);
    get arn(): string;
    private _batchSize?;
    get batchSize(): number;
    set batchSize(value: number);
    resetBatchSize(): void;
    get batchSizeInput(): number | undefined;
    private _bisectBatchOnFunctionError?;
    get bisectBatchOnFunctionError(): boolean | cdktn.IResolvable;
    set bisectBatchOnFunctionError(value: boolean | cdktn.IResolvable);
    resetBisectBatchOnFunctionError(): void;
    get bisectBatchOnFunctionErrorInput(): boolean | cdktn.IResolvable | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _eventSourceArn?;
    get eventSourceArn(): string;
    set eventSourceArn(value: string);
    resetEventSourceArn(): void;
    get eventSourceArnInput(): string | undefined;
    get functionArn(): string;
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _functionResponseTypes?;
    get functionResponseTypes(): string[];
    set functionResponseTypes(value: string[]);
    resetFunctionResponseTypes(): void;
    get functionResponseTypesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    get lastModified(): string;
    get lastProcessingResult(): string;
    private _maximumBatchingWindowInSeconds?;
    get maximumBatchingWindowInSeconds(): number;
    set maximumBatchingWindowInSeconds(value: number);
    resetMaximumBatchingWindowInSeconds(): void;
    get maximumBatchingWindowInSecondsInput(): number | undefined;
    private _maximumRecordAgeInSeconds?;
    get maximumRecordAgeInSeconds(): number;
    set maximumRecordAgeInSeconds(value: number);
    resetMaximumRecordAgeInSeconds(): void;
    get maximumRecordAgeInSecondsInput(): number | undefined;
    private _maximumRetryAttempts?;
    get maximumRetryAttempts(): number;
    set maximumRetryAttempts(value: number);
    resetMaximumRetryAttempts(): void;
    get maximumRetryAttemptsInput(): number | undefined;
    private _parallelizationFactor?;
    get parallelizationFactor(): number;
    set parallelizationFactor(value: number);
    resetParallelizationFactor(): void;
    get parallelizationFactorInput(): number | undefined;
    private _queues?;
    get queues(): string[];
    set queues(value: string[]);
    resetQueues(): void;
    get queuesInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _startingPosition?;
    get startingPosition(): string;
    set startingPosition(value: string);
    resetStartingPosition(): void;
    get startingPositionInput(): string | undefined;
    private _startingPositionTimestamp?;
    get startingPositionTimestamp(): string;
    set startingPositionTimestamp(value: string);
    resetStartingPositionTimestamp(): void;
    get startingPositionTimestampInput(): string | undefined;
    get state(): string;
    get stateTransitionReason(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _topics?;
    get topics(): string[];
    set topics(value: string[]);
    resetTopics(): void;
    get topicsInput(): string[] | undefined;
    private _tumblingWindowInSeconds?;
    get tumblingWindowInSeconds(): number;
    set tumblingWindowInSeconds(value: number);
    resetTumblingWindowInSeconds(): void;
    get tumblingWindowInSecondsInput(): number | undefined;
    private _useResourceTimeoutForPropagation?;
    get useResourceTimeoutForPropagation(): boolean | cdktn.IResolvable;
    set useResourceTimeoutForPropagation(value: boolean | cdktn.IResolvable);
    resetUseResourceTimeoutForPropagation(): void;
    get useResourceTimeoutForPropagationInput(): boolean | cdktn.IResolvable | undefined;
    get uuid(): string;
    private _amazonManagedKafkaEventSourceConfig;
    get amazonManagedKafkaEventSourceConfig(): TfEventSourceMapping.AmazonManagedKafkaEventSourceConfigPropertyOutputReference;
    putAmazonManagedKafkaEventSourceConfig(value: TfEventSourceMapping.AmazonManagedKafkaEventSourceConfigProperty): void;
    resetAmazonManagedKafkaEventSourceConfig(): void;
    get amazonManagedKafkaEventSourceConfigInput(): TfEventSourceMapping.AmazonManagedKafkaEventSourceConfigProperty | undefined;
    private _destinationConfig;
    get destinationConfig(): TfEventSourceMapping.DestinationConfigPropertyOutputReference;
    putDestinationConfig(value: TfEventSourceMapping.DestinationConfigProperty): void;
    resetDestinationConfig(): void;
    get destinationConfigInput(): TfEventSourceMapping.DestinationConfigProperty | undefined;
    private _documentDbEventSourceConfig;
    get documentDbEventSourceConfig(): TfEventSourceMapping.DocumentDbEventSourceConfigPropertyOutputReference;
    putDocumentDbEventSourceConfig(value: TfEventSourceMapping.DocumentDbEventSourceConfigProperty): void;
    resetDocumentDbEventSourceConfig(): void;
    get documentDbEventSourceConfigInput(): TfEventSourceMapping.DocumentDbEventSourceConfigProperty | undefined;
    private _filterCriteria;
    get filterCriteria(): TfEventSourceMapping.FilterCriteriaPropertyOutputReference;
    putFilterCriteria(value: TfEventSourceMapping.FilterCriteriaProperty): void;
    resetFilterCriteria(): void;
    get filterCriteriaInput(): TfEventSourceMapping.FilterCriteriaProperty | undefined;
    private _metricsConfig;
    get metricsConfig(): TfEventSourceMapping.MetricsConfigPropertyOutputReference;
    putMetricsConfig(value: TfEventSourceMapping.MetricsConfigProperty): void;
    resetMetricsConfig(): void;
    get metricsConfigInput(): TfEventSourceMapping.MetricsConfigProperty | undefined;
    private _provisionedPollerConfig;
    get provisionedPollerConfig(): TfEventSourceMapping.ProvisionedPollerConfigPropertyOutputReference;
    putProvisionedPollerConfig(value: TfEventSourceMapping.ProvisionedPollerConfigProperty): void;
    resetProvisionedPollerConfig(): void;
    get provisionedPollerConfigInput(): TfEventSourceMapping.ProvisionedPollerConfigProperty | undefined;
    private _scalingConfig;
    get scalingConfig(): TfEventSourceMapping.ScalingConfigPropertyOutputReference;
    putScalingConfig(value: TfEventSourceMapping.ScalingConfigProperty): void;
    resetScalingConfig(): void;
    get scalingConfigInput(): TfEventSourceMapping.ScalingConfigProperty | undefined;
    private _selfManagedEventSource;
    get selfManagedEventSource(): TfEventSourceMapping.SelfManagedEventSourcePropertyOutputReference;
    putSelfManagedEventSource(value: TfEventSourceMapping.SelfManagedEventSourceProperty): void;
    resetSelfManagedEventSource(): void;
    get selfManagedEventSourceInput(): TfEventSourceMapping.SelfManagedEventSourceProperty | undefined;
    private _selfManagedKafkaEventSourceConfig;
    get selfManagedKafkaEventSourceConfig(): TfEventSourceMapping.SelfManagedKafkaEventSourceConfigPropertyOutputReference;
    putSelfManagedKafkaEventSourceConfig(value: TfEventSourceMapping.SelfManagedKafkaEventSourceConfigProperty): void;
    resetSelfManagedKafkaEventSourceConfig(): void;
    get selfManagedKafkaEventSourceConfigInput(): TfEventSourceMapping.SelfManagedKafkaEventSourceConfigProperty | undefined;
    private _sourceAccessConfiguration;
    get sourceAccessConfiguration(): TfEventSourceMapping.SourceAccessConfigurationPropertyList;
    putSourceAccessConfiguration(value: TfEventSourceMapping.SourceAccessConfigurationProperty[] | cdktn.IResolvable): void;
    resetSourceAccessConfiguration(): void;
    get sourceAccessConfigurationInput(): cdktn.IResolvable | TfEventSourceMapping.SourceAccessConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfEventSourceMapping.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfEventSourceMapping.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfEventSourceMapping.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfEventSourceMappingAmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyToTerraform(struct?: TfEventSourceMapping.AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty | cdktn.IResolvable): any;
export declare function tfEventSourceMappingAmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyToHclTerraform(struct?: TfEventSourceMapping.AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty | cdktn.IResolvable): any;
export declare function tfEventSourceMappingAmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyToTerraform(struct?: TfEventSourceMapping.AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty | cdktn.IResolvable): any;
export declare function tfEventSourceMappingAmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyToHclTerraform(struct?: TfEventSourceMapping.AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty | cdktn.IResolvable): any;
export declare function tfEventSourceMappingAmazonManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyToTerraform(struct?: TfEventSourceMapping.AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyOutputReference | TfEventSourceMapping.AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigProperty): any;
export declare function tfEventSourceMappingAmazonManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyToHclTerraform(struct?: TfEventSourceMapping.AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyOutputReference | TfEventSourceMapping.AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigProperty): any;
export declare function tfEventSourceMappingAmazonManagedKafkaEventSourceConfigPropertyToTerraform(struct?: TfEventSourceMapping.AmazonManagedKafkaEventSourceConfigPropertyOutputReference | TfEventSourceMapping.AmazonManagedKafkaEventSourceConfigProperty): any;
export declare function tfEventSourceMappingAmazonManagedKafkaEventSourceConfigPropertyToHclTerraform(struct?: TfEventSourceMapping.AmazonManagedKafkaEventSourceConfigPropertyOutputReference | TfEventSourceMapping.AmazonManagedKafkaEventSourceConfigProperty): any;
export declare function tfEventSourceMappingOnFailurePropertyToTerraform(struct?: TfEventSourceMapping.OnFailurePropertyOutputReference | TfEventSourceMapping.OnFailureProperty): any;
export declare function tfEventSourceMappingOnFailurePropertyToHclTerraform(struct?: TfEventSourceMapping.OnFailurePropertyOutputReference | TfEventSourceMapping.OnFailureProperty): any;
export declare function tfEventSourceMappingDestinationConfigPropertyToTerraform(struct?: TfEventSourceMapping.DestinationConfigPropertyOutputReference | TfEventSourceMapping.DestinationConfigProperty): any;
export declare function tfEventSourceMappingDestinationConfigPropertyToHclTerraform(struct?: TfEventSourceMapping.DestinationConfigPropertyOutputReference | TfEventSourceMapping.DestinationConfigProperty): any;
export declare function tfEventSourceMappingDocumentDbEventSourceConfigPropertyToTerraform(struct?: TfEventSourceMapping.DocumentDbEventSourceConfigPropertyOutputReference | TfEventSourceMapping.DocumentDbEventSourceConfigProperty): any;
export declare function tfEventSourceMappingDocumentDbEventSourceConfigPropertyToHclTerraform(struct?: TfEventSourceMapping.DocumentDbEventSourceConfigPropertyOutputReference | TfEventSourceMapping.DocumentDbEventSourceConfigProperty): any;
export declare function tfEventSourceMappingFilterPropertyToTerraform(struct?: TfEventSourceMapping.FilterProperty | cdktn.IResolvable): any;
export declare function tfEventSourceMappingFilterPropertyToHclTerraform(struct?: TfEventSourceMapping.FilterProperty | cdktn.IResolvable): any;
export declare function tfEventSourceMappingFilterCriteriaPropertyToTerraform(struct?: TfEventSourceMapping.FilterCriteriaPropertyOutputReference | TfEventSourceMapping.FilterCriteriaProperty): any;
export declare function tfEventSourceMappingFilterCriteriaPropertyToHclTerraform(struct?: TfEventSourceMapping.FilterCriteriaPropertyOutputReference | TfEventSourceMapping.FilterCriteriaProperty): any;
export declare function tfEventSourceMappingMetricsConfigPropertyToTerraform(struct?: TfEventSourceMapping.MetricsConfigPropertyOutputReference | TfEventSourceMapping.MetricsConfigProperty): any;
export declare function tfEventSourceMappingMetricsConfigPropertyToHclTerraform(struct?: TfEventSourceMapping.MetricsConfigPropertyOutputReference | TfEventSourceMapping.MetricsConfigProperty): any;
export declare function tfEventSourceMappingProvisionedPollerConfigPropertyToTerraform(struct?: TfEventSourceMapping.ProvisionedPollerConfigPropertyOutputReference | TfEventSourceMapping.ProvisionedPollerConfigProperty): any;
export declare function tfEventSourceMappingProvisionedPollerConfigPropertyToHclTerraform(struct?: TfEventSourceMapping.ProvisionedPollerConfigPropertyOutputReference | TfEventSourceMapping.ProvisionedPollerConfigProperty): any;
export declare function tfEventSourceMappingScalingConfigPropertyToTerraform(struct?: TfEventSourceMapping.ScalingConfigPropertyOutputReference | TfEventSourceMapping.ScalingConfigProperty): any;
export declare function tfEventSourceMappingScalingConfigPropertyToHclTerraform(struct?: TfEventSourceMapping.ScalingConfigPropertyOutputReference | TfEventSourceMapping.ScalingConfigProperty): any;
export declare function tfEventSourceMappingSelfManagedEventSourcePropertyToTerraform(struct?: TfEventSourceMapping.SelfManagedEventSourcePropertyOutputReference | TfEventSourceMapping.SelfManagedEventSourceProperty): any;
export declare function tfEventSourceMappingSelfManagedEventSourcePropertyToHclTerraform(struct?: TfEventSourceMapping.SelfManagedEventSourcePropertyOutputReference | TfEventSourceMapping.SelfManagedEventSourceProperty): any;
export declare function tfEventSourceMappingSelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyToTerraform(struct?: TfEventSourceMapping.SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty | cdktn.IResolvable): any;
export declare function tfEventSourceMappingSelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyToHclTerraform(struct?: TfEventSourceMapping.SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty | cdktn.IResolvable): any;
export declare function tfEventSourceMappingSelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyToTerraform(struct?: TfEventSourceMapping.SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty | cdktn.IResolvable): any;
export declare function tfEventSourceMappingSelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyToHclTerraform(struct?: TfEventSourceMapping.SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty | cdktn.IResolvable): any;
export declare function tfEventSourceMappingSelfManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyToTerraform(struct?: TfEventSourceMapping.SelfManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyOutputReference | TfEventSourceMapping.SelfManagedKafkaEventSourceConfigSchemaRegistryConfigProperty): any;
export declare function tfEventSourceMappingSelfManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyToHclTerraform(struct?: TfEventSourceMapping.SelfManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyOutputReference | TfEventSourceMapping.SelfManagedKafkaEventSourceConfigSchemaRegistryConfigProperty): any;
export declare function tfEventSourceMappingSelfManagedKafkaEventSourceConfigPropertyToTerraform(struct?: TfEventSourceMapping.SelfManagedKafkaEventSourceConfigPropertyOutputReference | TfEventSourceMapping.SelfManagedKafkaEventSourceConfigProperty): any;
export declare function tfEventSourceMappingSelfManagedKafkaEventSourceConfigPropertyToHclTerraform(struct?: TfEventSourceMapping.SelfManagedKafkaEventSourceConfigPropertyOutputReference | TfEventSourceMapping.SelfManagedKafkaEventSourceConfigProperty): any;
export declare function tfEventSourceMappingSourceAccessConfigurationPropertyToTerraform(struct?: TfEventSourceMapping.SourceAccessConfigurationProperty | cdktn.IResolvable): any;
export declare function tfEventSourceMappingSourceAccessConfigurationPropertyToHclTerraform(struct?: TfEventSourceMapping.SourceAccessConfigurationProperty | cdktn.IResolvable): any;
export declare function tfEventSourceMappingTimeoutsPropertyToTerraform(struct?: TfEventSourceMapping.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfEventSourceMappingTimeoutsPropertyToHclTerraform(struct?: TfEventSourceMapping.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfEventSourceMapping {
    interface AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#type TfEventSourceMapping#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#uri TfEventSourceMapping#uri}
        */
        readonly uri?: string;
    }
    class AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        resetUri(): void;
        get uriInput(): string | undefined;
    }
    class AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyList extends cdktn.ComplexList {
        internalValue?: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyOutputReference;
    }
    interface AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#attribute TfEventSourceMapping#attribute}
        */
        readonly attribute?: string;
    }
    class AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
    }
    class AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyList extends cdktn.ComplexList {
        internalValue?: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyOutputReference;
    }
    interface AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#event_record_format TfEventSourceMapping#event_record_format}
        */
        readonly eventRecordFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#schema_registry_uri TfEventSourceMapping#schema_registry_uri}
        */
        readonly schemaRegistryUri?: string;
        /**
        * access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#access_config TfEventSourceMapping#access_config}
        */
        readonly accessConfig?: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * schema_validation_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#schema_validation_config TfEventSourceMapping#schema_validation_config}
        */
        readonly schemaValidationConfig?: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty[] | cdktn.IResolvable;
    }
    class AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigProperty | undefined;
        set internalValue(value: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigProperty | undefined);
        private _eventRecordFormat?;
        get eventRecordFormat(): string;
        set eventRecordFormat(value: string);
        resetEventRecordFormat(): void;
        get eventRecordFormatInput(): string | undefined;
        private _schemaRegistryUri?;
        get schemaRegistryUri(): string;
        set schemaRegistryUri(value: string);
        resetSchemaRegistryUri(): void;
        get schemaRegistryUriInput(): string | undefined;
        private _accessConfig;
        get accessConfig(): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyList;
        putAccessConfig(value: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty[] | cdktn.IResolvable): void;
        resetAccessConfig(): void;
        get accessConfigInput(): cdktn.IResolvable | AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty[] | undefined;
        private _schemaValidationConfig;
        get schemaValidationConfig(): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyList;
        putSchemaValidationConfig(value: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty[] | cdktn.IResolvable): void;
        resetSchemaValidationConfig(): void;
        get schemaValidationConfigInput(): cdktn.IResolvable | AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty[] | undefined;
    }
    interface AmazonManagedKafkaEventSourceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#consumer_group_id TfEventSourceMapping#consumer_group_id}
        */
        readonly consumerGroupId?: string;
        /**
        * schema_registry_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#schema_registry_config TfEventSourceMapping#schema_registry_config}
        */
        readonly schemaRegistryConfig?: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigProperty;
    }
    class AmazonManagedKafkaEventSourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AmazonManagedKafkaEventSourceConfigProperty | undefined;
        set internalValue(value: AmazonManagedKafkaEventSourceConfigProperty | undefined);
        private _consumerGroupId?;
        get consumerGroupId(): string;
        set consumerGroupId(value: string);
        resetConsumerGroupId(): void;
        get consumerGroupIdInput(): string | undefined;
        private _schemaRegistryConfig;
        get schemaRegistryConfig(): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyOutputReference;
        putSchemaRegistryConfig(value: AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigProperty): void;
        resetSchemaRegistryConfig(): void;
        get schemaRegistryConfigInput(): AmazonManagedKafkaEventSourceConfigSchemaRegistryConfigProperty | undefined;
    }
    interface OnFailureProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#destination_arn TfEventSourceMapping#destination_arn}
        */
        readonly destinationArn: string;
    }
    class OnFailurePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnFailureProperty | undefined;
        set internalValue(value: OnFailureProperty | undefined);
        private _destinationArn?;
        get destinationArn(): string;
        set destinationArn(value: string);
        get destinationArnInput(): string | undefined;
    }
    interface DestinationConfigProperty {
        /**
        * on_failure block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#on_failure TfEventSourceMapping#on_failure}
        */
        readonly onFailure?: OnFailureProperty;
    }
    class DestinationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationConfigProperty | undefined;
        set internalValue(value: DestinationConfigProperty | undefined);
        private _onFailure;
        get onFailure(): OnFailurePropertyOutputReference;
        putOnFailure(value: OnFailureProperty): void;
        resetOnFailure(): void;
        get onFailureInput(): OnFailureProperty | undefined;
    }
    interface DocumentDbEventSourceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#collection_name TfEventSourceMapping#collection_name}
        */
        readonly collectionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#database_name TfEventSourceMapping#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#full_document TfEventSourceMapping#full_document}
        */
        readonly fullDocument?: string;
    }
    class DocumentDbEventSourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DocumentDbEventSourceConfigProperty | undefined;
        set internalValue(value: DocumentDbEventSourceConfigProperty | undefined);
        private _collectionName?;
        get collectionName(): string;
        set collectionName(value: string);
        resetCollectionName(): void;
        get collectionNameInput(): string | undefined;
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _fullDocument?;
        get fullDocument(): string;
        set fullDocument(value: string);
        resetFullDocument(): void;
        get fullDocumentInput(): string | undefined;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#pattern TfEventSourceMapping#pattern}
        */
        readonly pattern?: string;
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _pattern?;
        get pattern(): string;
        set pattern(value: string);
        resetPattern(): void;
        get patternInput(): string | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface FilterCriteriaProperty {
        /**
        * filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#filter TfEventSourceMapping#filter}
        */
        readonly filter?: FilterProperty[] | cdktn.IResolvable;
    }
    class FilterCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterCriteriaProperty | undefined;
        set internalValue(value: FilterCriteriaProperty | undefined);
        private _filter;
        get filter(): FilterPropertyList;
        putFilter(value: FilterProperty[] | cdktn.IResolvable): void;
        resetFilter(): void;
        get filterInput(): cdktn.IResolvable | FilterProperty[] | undefined;
    }
    interface MetricsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#metrics TfEventSourceMapping#metrics}
        */
        readonly metrics: string[];
    }
    class MetricsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetricsConfigProperty | undefined;
        set internalValue(value: MetricsConfigProperty | undefined);
        private _metrics?;
        get metrics(): string[];
        set metrics(value: string[]);
        get metricsInput(): string[] | undefined;
    }
    interface ProvisionedPollerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#maximum_pollers TfEventSourceMapping#maximum_pollers}
        */
        readonly maximumPollers?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#minimum_pollers TfEventSourceMapping#minimum_pollers}
        */
        readonly minimumPollers?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#poller_group_name TfEventSourceMapping#poller_group_name}
        */
        readonly pollerGroupName?: string;
    }
    class ProvisionedPollerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProvisionedPollerConfigProperty | undefined;
        set internalValue(value: ProvisionedPollerConfigProperty | undefined);
        private _maximumPollers?;
        get maximumPollers(): number;
        set maximumPollers(value: number);
        resetMaximumPollers(): void;
        get maximumPollersInput(): number | undefined;
        private _minimumPollers?;
        get minimumPollers(): number;
        set minimumPollers(value: number);
        resetMinimumPollers(): void;
        get minimumPollersInput(): number | undefined;
        private _pollerGroupName?;
        get pollerGroupName(): string;
        set pollerGroupName(value: string);
        resetPollerGroupName(): void;
        get pollerGroupNameInput(): string | undefined;
    }
    interface ScalingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#maximum_concurrency TfEventSourceMapping#maximum_concurrency}
        */
        readonly maximumConcurrency?: number;
    }
    class ScalingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScalingConfigProperty | undefined;
        set internalValue(value: ScalingConfigProperty | undefined);
        private _maximumConcurrency?;
        get maximumConcurrency(): number;
        set maximumConcurrency(value: number);
        resetMaximumConcurrency(): void;
        get maximumConcurrencyInput(): number | undefined;
    }
    interface SelfManagedEventSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#endpoints TfEventSourceMapping#endpoints}
        */
        readonly endpoints: {
            [key: string]: string;
        };
    }
    class SelfManagedEventSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SelfManagedEventSourceProperty | undefined;
        set internalValue(value: SelfManagedEventSourceProperty | undefined);
        private _endpoints?;
        get endpoints(): {
            [key: string]: string;
        };
        set endpoints(value: {
            [key: string]: string;
        });
        get endpointsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#type TfEventSourceMapping#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#uri TfEventSourceMapping#uri}
        */
        readonly uri?: string;
    }
    class SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        resetUri(): void;
        get uriInput(): string | undefined;
    }
    class SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyList extends cdktn.ComplexList {
        internalValue?: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyOutputReference;
    }
    interface SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#attribute TfEventSourceMapping#attribute}
        */
        readonly attribute?: string;
    }
    class SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
    }
    class SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyList extends cdktn.ComplexList {
        internalValue?: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyOutputReference;
    }
    interface SelfManagedKafkaEventSourceConfigSchemaRegistryConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#event_record_format TfEventSourceMapping#event_record_format}
        */
        readonly eventRecordFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#schema_registry_uri TfEventSourceMapping#schema_registry_uri}
        */
        readonly schemaRegistryUri?: string;
        /**
        * access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#access_config TfEventSourceMapping#access_config}
        */
        readonly accessConfig?: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty[] | cdktn.IResolvable;
        /**
        * schema_validation_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#schema_validation_config TfEventSourceMapping#schema_validation_config}
        */
        readonly schemaValidationConfig?: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty[] | cdktn.IResolvable;
    }
    class SelfManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigProperty | undefined;
        set internalValue(value: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigProperty | undefined);
        private _eventRecordFormat?;
        get eventRecordFormat(): string;
        set eventRecordFormat(value: string);
        resetEventRecordFormat(): void;
        get eventRecordFormatInput(): string | undefined;
        private _schemaRegistryUri?;
        get schemaRegistryUri(): string;
        set schemaRegistryUri(value: string);
        resetSchemaRegistryUri(): void;
        get schemaRegistryUriInput(): string | undefined;
        private _accessConfig;
        get accessConfig(): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigPropertyList;
        putAccessConfig(value: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty[] | cdktn.IResolvable): void;
        resetAccessConfig(): void;
        get accessConfigInput(): cdktn.IResolvable | SelfManagedKafkaEventSourceConfigSchemaRegistryConfigAccessConfigProperty[] | undefined;
        private _schemaValidationConfig;
        get schemaValidationConfig(): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigPropertyList;
        putSchemaValidationConfig(value: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty[] | cdktn.IResolvable): void;
        resetSchemaValidationConfig(): void;
        get schemaValidationConfigInput(): cdktn.IResolvable | SelfManagedKafkaEventSourceConfigSchemaRegistryConfigSchemaValidationConfigProperty[] | undefined;
    }
    interface SelfManagedKafkaEventSourceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#consumer_group_id TfEventSourceMapping#consumer_group_id}
        */
        readonly consumerGroupId?: string;
        /**
        * schema_registry_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#schema_registry_config TfEventSourceMapping#schema_registry_config}
        */
        readonly schemaRegistryConfig?: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigProperty;
    }
    class SelfManagedKafkaEventSourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SelfManagedKafkaEventSourceConfigProperty | undefined;
        set internalValue(value: SelfManagedKafkaEventSourceConfigProperty | undefined);
        private _consumerGroupId?;
        get consumerGroupId(): string;
        set consumerGroupId(value: string);
        resetConsumerGroupId(): void;
        get consumerGroupIdInput(): string | undefined;
        private _schemaRegistryConfig;
        get schemaRegistryConfig(): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigPropertyOutputReference;
        putSchemaRegistryConfig(value: SelfManagedKafkaEventSourceConfigSchemaRegistryConfigProperty): void;
        resetSchemaRegistryConfig(): void;
        get schemaRegistryConfigInput(): SelfManagedKafkaEventSourceConfigSchemaRegistryConfigProperty | undefined;
    }
    interface SourceAccessConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#type TfEventSourceMapping#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#uri TfEventSourceMapping#uri}
        */
        readonly uri: string;
    }
    class SourceAccessConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceAccessConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceAccessConfigurationProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
    }
    class SourceAccessConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SourceAccessConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceAccessConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#create TfEventSourceMapping#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#delete TfEventSourceMapping#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_event_source_mapping#update TfEventSourceMapping#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
