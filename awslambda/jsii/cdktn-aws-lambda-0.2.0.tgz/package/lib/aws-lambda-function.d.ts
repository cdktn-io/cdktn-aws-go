import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFunctionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#architectures TfFunction#architectures}
    */
    readonly architectures?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#code_sha256 TfFunction#code_sha256}
    */
    readonly codeSha256?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#code_signing_config_arn TfFunction#code_signing_config_arn}
    */
    readonly codeSigningConfigArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#description TfFunction#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#filename TfFunction#filename}
    */
    readonly filename?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#function_name TfFunction#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#handler TfFunction#handler}
    */
    readonly handler?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#id TfFunction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#image_uri TfFunction#image_uri}
    */
    readonly imageUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#kms_key_arn TfFunction#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#layers TfFunction#layers}
    */
    readonly layers?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#memory_size TfFunction#memory_size}
    */
    readonly memorySize?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#package_type TfFunction#package_type}
    */
    readonly packageType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#publish TfFunction#publish}
    */
    readonly publish?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#publish_to TfFunction#publish_to}
    */
    readonly publishTo?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#region TfFunction#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#replace_security_groups_on_destroy TfFunction#replace_security_groups_on_destroy}
    */
    readonly replaceSecurityGroupsOnDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#replacement_security_group_ids TfFunction#replacement_security_group_ids}
    */
    readonly replacementSecurityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#reserved_concurrent_executions TfFunction#reserved_concurrent_executions}
    */
    readonly reservedConcurrentExecutions?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#role TfFunction#role}
    */
    readonly role: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#runtime TfFunction#runtime}
    */
    readonly runtime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#s3_bucket TfFunction#s3_bucket}
    */
    readonly s3Bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#s3_key TfFunction#s3_key}
    */
    readonly s3Key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#s3_object_version TfFunction#s3_object_version}
    */
    readonly s3ObjectVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#skip_destroy TfFunction#skip_destroy}
    */
    readonly skipDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#source_code_hash TfFunction#source_code_hash}
    */
    readonly sourceCodeHash?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#source_kms_key_arn TfFunction#source_kms_key_arn}
    */
    readonly sourceKmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#tags TfFunction#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#tags_all TfFunction#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#timeout TfFunction#timeout}
    */
    readonly timeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#use_resource_timeout_for_propagation TfFunction#use_resource_timeout_for_propagation}
    */
    readonly useResourceTimeoutForPropagation?: boolean | cdktn.IResolvable;
    /**
    * capacity_provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#capacity_provider_config TfFunction#capacity_provider_config}
    */
    readonly capacityProviderConfig?: TfFunction.CapacityProviderConfigProperty;
    /**
    * dead_letter_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#dead_letter_config TfFunction#dead_letter_config}
    */
    readonly deadLetterConfig?: TfFunction.DeadLetterConfigProperty;
    /**
    * durable_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#durable_config TfFunction#durable_config}
    */
    readonly durableConfig?: TfFunction.DurableConfigProperty;
    /**
    * environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#environment TfFunction#environment}
    */
    readonly environment?: TfFunction.EnvironmentProperty;
    /**
    * ephemeral_storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#ephemeral_storage TfFunction#ephemeral_storage}
    */
    readonly ephemeralStorage?: TfFunction.EphemeralStorageProperty;
    /**
    * file_system_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#file_system_config TfFunction#file_system_config}
    */
    readonly fileSystemConfig?: TfFunction.FileSystemConfigProperty;
    /**
    * image_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#image_config TfFunction#image_config}
    */
    readonly imageConfig?: TfFunction.ImageConfigProperty;
    /**
    * logging_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#logging_config TfFunction#logging_config}
    */
    readonly loggingConfig?: TfFunction.LoggingConfigProperty;
    /**
    * snap_start block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#snap_start TfFunction#snap_start}
    */
    readonly snapStart?: TfFunction.SnapStartProperty;
    /**
    * tenancy_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#tenancy_config TfFunction#tenancy_config}
    */
    readonly tenancyConfig?: TfFunction.TenancyConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#timeouts TfFunction#timeouts}
    */
    readonly timeouts?: TfFunction.TimeoutsProperty;
    /**
    * tracing_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#tracing_config TfFunction#tracing_config}
    */
    readonly tracingConfig?: TfFunction.TracingConfigProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#vpc_config TfFunction#vpc_config}
    */
    readonly vpcConfig?: TfFunction.VpcConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function aws_lambda_function}
*/
export declare class TfFunction extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambda_function";
    /**
    * Generates CDKTN code for importing a TfFunction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFunction to import
    * @param importFromId The id of the existing TfFunction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFunction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function aws_lambda_function} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFunctionConfig
    */
    constructor(scope: Construct, id: string, config: TfFunctionConfig);
    private _architectures?;
    get architectures(): string[];
    set architectures(value: string[]);
    resetArchitectures(): void;
    get architecturesInput(): string[] | undefined;
    get arn(): string;
    private _codeSha256?;
    get codeSha256(): string;
    set codeSha256(value: string);
    resetCodeSha256(): void;
    get codeSha256Input(): string | undefined;
    private _codeSigningConfigArn?;
    get codeSigningConfigArn(): string;
    set codeSigningConfigArn(value: string);
    resetCodeSigningConfigArn(): void;
    get codeSigningConfigArnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _filename?;
    get filename(): string;
    set filename(value: string);
    resetFilename(): void;
    get filenameInput(): string | undefined;
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _handler?;
    get handler(): string;
    set handler(value: string);
    resetHandler(): void;
    get handlerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageUri?;
    get imageUri(): string;
    set imageUri(value: string);
    resetImageUri(): void;
    get imageUriInput(): string | undefined;
    get invokeArn(): string;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    get lastModified(): string;
    private _layers?;
    get layers(): string[];
    set layers(value: string[]);
    resetLayers(): void;
    get layersInput(): string[] | undefined;
    private _memorySize?;
    get memorySize(): number;
    set memorySize(value: number);
    resetMemorySize(): void;
    get memorySizeInput(): number | undefined;
    private _packageType?;
    get packageType(): string;
    set packageType(value: string);
    resetPackageType(): void;
    get packageTypeInput(): string | undefined;
    private _publish?;
    get publish(): boolean | cdktn.IResolvable;
    set publish(value: boolean | cdktn.IResolvable);
    resetPublish(): void;
    get publishInput(): boolean | cdktn.IResolvable | undefined;
    private _publishTo?;
    get publishTo(): string;
    set publishTo(value: string);
    resetPublishTo(): void;
    get publishToInput(): string | undefined;
    get qualifiedArn(): string;
    get qualifiedInvokeArn(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replaceSecurityGroupsOnDestroy?;
    get replaceSecurityGroupsOnDestroy(): boolean | cdktn.IResolvable;
    set replaceSecurityGroupsOnDestroy(value: boolean | cdktn.IResolvable);
    resetReplaceSecurityGroupsOnDestroy(): void;
    get replaceSecurityGroupsOnDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _replacementSecurityGroupIds?;
    get replacementSecurityGroupIds(): string[];
    set replacementSecurityGroupIds(value: string[]);
    resetReplacementSecurityGroupIds(): void;
    get replacementSecurityGroupIdsInput(): string[] | undefined;
    private _reservedConcurrentExecutions?;
    get reservedConcurrentExecutions(): number;
    set reservedConcurrentExecutions(value: number);
    resetReservedConcurrentExecutions(): void;
    get reservedConcurrentExecutionsInput(): number | undefined;
    get responseStreamingInvokeArn(): string;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _runtime?;
    get runtime(): string;
    set runtime(value: string);
    resetRuntime(): void;
    get runtimeInput(): string | undefined;
    private _s3Bucket?;
    get s3Bucket(): string;
    set s3Bucket(value: string);
    resetS3Bucket(): void;
    get s3BucketInput(): string | undefined;
    private _s3Key?;
    get s3Key(): string;
    set s3Key(value: string);
    resetS3Key(): void;
    get s3KeyInput(): string | undefined;
    private _s3ObjectVersion?;
    get s3ObjectVersion(): string;
    set s3ObjectVersion(value: string);
    resetS3ObjectVersion(): void;
    get s3ObjectVersionInput(): string | undefined;
    get signingJobArn(): string;
    get signingProfileVersionArn(): string;
    private _skipDestroy?;
    get skipDestroy(): boolean | cdktn.IResolvable;
    set skipDestroy(value: boolean | cdktn.IResolvable);
    resetSkipDestroy(): void;
    get skipDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _sourceCodeHash?;
    get sourceCodeHash(): string;
    set sourceCodeHash(value: string);
    resetSourceCodeHash(): void;
    get sourceCodeHashInput(): string | undefined;
    get sourceCodeSize(): number;
    private _sourceKmsKeyArn?;
    get sourceKmsKeyArn(): string;
    set sourceKmsKeyArn(value: string);
    resetSourceKmsKeyArn(): void;
    get sourceKmsKeyArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _useResourceTimeoutForPropagation?;
    get useResourceTimeoutForPropagation(): boolean | cdktn.IResolvable;
    set useResourceTimeoutForPropagation(value: boolean | cdktn.IResolvable);
    resetUseResourceTimeoutForPropagation(): void;
    get useResourceTimeoutForPropagationInput(): boolean | cdktn.IResolvable | undefined;
    get version(): string;
    private _capacityProviderConfig;
    get capacityProviderConfig(): TfFunction.CapacityProviderConfigPropertyOutputReference;
    putCapacityProviderConfig(value: TfFunction.CapacityProviderConfigProperty): void;
    resetCapacityProviderConfig(): void;
    get capacityProviderConfigInput(): TfFunction.CapacityProviderConfigProperty | undefined;
    private _deadLetterConfig;
    get deadLetterConfig(): TfFunction.DeadLetterConfigPropertyOutputReference;
    putDeadLetterConfig(value: TfFunction.DeadLetterConfigProperty): void;
    resetDeadLetterConfig(): void;
    get deadLetterConfigInput(): TfFunction.DeadLetterConfigProperty | undefined;
    private _durableConfig;
    get durableConfig(): TfFunction.DurableConfigPropertyOutputReference;
    putDurableConfig(value: TfFunction.DurableConfigProperty): void;
    resetDurableConfig(): void;
    get durableConfigInput(): TfFunction.DurableConfigProperty | undefined;
    private _environment;
    get environment(): TfFunction.EnvironmentPropertyOutputReference;
    putEnvironment(value: TfFunction.EnvironmentProperty): void;
    resetEnvironment(): void;
    get environmentInput(): TfFunction.EnvironmentProperty | undefined;
    private _ephemeralStorage;
    get ephemeralStorage(): TfFunction.EphemeralStoragePropertyOutputReference;
    putEphemeralStorage(value: TfFunction.EphemeralStorageProperty): void;
    resetEphemeralStorage(): void;
    get ephemeralStorageInput(): TfFunction.EphemeralStorageProperty | undefined;
    private _fileSystemConfig;
    get fileSystemConfig(): TfFunction.FileSystemConfigPropertyOutputReference;
    putFileSystemConfig(value: TfFunction.FileSystemConfigProperty): void;
    resetFileSystemConfig(): void;
    get fileSystemConfigInput(): TfFunction.FileSystemConfigProperty | undefined;
    private _imageConfig;
    get imageConfig(): TfFunction.ImageConfigPropertyOutputReference;
    putImageConfig(value: TfFunction.ImageConfigProperty): void;
    resetImageConfig(): void;
    get imageConfigInput(): TfFunction.ImageConfigProperty | undefined;
    private _loggingConfig;
    get loggingConfig(): TfFunction.LoggingConfigPropertyOutputReference;
    putLoggingConfig(value: TfFunction.LoggingConfigProperty): void;
    resetLoggingConfig(): void;
    get loggingConfigInput(): TfFunction.LoggingConfigProperty | undefined;
    private _snapStart;
    get snapStart(): TfFunction.SnapStartPropertyOutputReference;
    putSnapStart(value: TfFunction.SnapStartProperty): void;
    resetSnapStart(): void;
    get snapStartInput(): TfFunction.SnapStartProperty | undefined;
    private _tenancyConfig;
    get tenancyConfig(): TfFunction.TenancyConfigPropertyOutputReference;
    putTenancyConfig(value: TfFunction.TenancyConfigProperty): void;
    resetTenancyConfig(): void;
    get tenancyConfigInput(): TfFunction.TenancyConfigProperty | undefined;
    private _timeouts;
    get timeouts(): TfFunction.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfFunction.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfFunction.TimeoutsProperty | undefined;
    private _tracingConfig;
    get tracingConfig(): TfFunction.TracingConfigPropertyOutputReference;
    putTracingConfig(value: TfFunction.TracingConfigProperty): void;
    resetTracingConfig(): void;
    get tracingConfigInput(): TfFunction.TracingConfigProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): TfFunction.VpcConfigPropertyOutputReference;
    putVpcConfig(value: TfFunction.VpcConfigProperty): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): TfFunction.VpcConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfFunctionLambdaManagedInstancesCapacityProviderConfigPropertyToTerraform(struct?: TfFunction.LambdaManagedInstancesCapacityProviderConfigPropertyOutputReference | TfFunction.LambdaManagedInstancesCapacityProviderConfigProperty): any;
export declare function tfFunctionLambdaManagedInstancesCapacityProviderConfigPropertyToHclTerraform(struct?: TfFunction.LambdaManagedInstancesCapacityProviderConfigPropertyOutputReference | TfFunction.LambdaManagedInstancesCapacityProviderConfigProperty): any;
export declare function tfFunctionCapacityProviderConfigPropertyToTerraform(struct?: TfFunction.CapacityProviderConfigPropertyOutputReference | TfFunction.CapacityProviderConfigProperty): any;
export declare function tfFunctionCapacityProviderConfigPropertyToHclTerraform(struct?: TfFunction.CapacityProviderConfigPropertyOutputReference | TfFunction.CapacityProviderConfigProperty): any;
export declare function tfFunctionDeadLetterConfigPropertyToTerraform(struct?: TfFunction.DeadLetterConfigPropertyOutputReference | TfFunction.DeadLetterConfigProperty): any;
export declare function tfFunctionDeadLetterConfigPropertyToHclTerraform(struct?: TfFunction.DeadLetterConfigPropertyOutputReference | TfFunction.DeadLetterConfigProperty): any;
export declare function tfFunctionDurableConfigPropertyToTerraform(struct?: TfFunction.DurableConfigPropertyOutputReference | TfFunction.DurableConfigProperty): any;
export declare function tfFunctionDurableConfigPropertyToHclTerraform(struct?: TfFunction.DurableConfigPropertyOutputReference | TfFunction.DurableConfigProperty): any;
export declare function tfFunctionEnvironmentPropertyToTerraform(struct?: TfFunction.EnvironmentPropertyOutputReference | TfFunction.EnvironmentProperty): any;
export declare function tfFunctionEnvironmentPropertyToHclTerraform(struct?: TfFunction.EnvironmentPropertyOutputReference | TfFunction.EnvironmentProperty): any;
export declare function tfFunctionEphemeralStoragePropertyToTerraform(struct?: TfFunction.EphemeralStoragePropertyOutputReference | TfFunction.EphemeralStorageProperty): any;
export declare function tfFunctionEphemeralStoragePropertyToHclTerraform(struct?: TfFunction.EphemeralStoragePropertyOutputReference | TfFunction.EphemeralStorageProperty): any;
export declare function tfFunctionFileSystemConfigPropertyToTerraform(struct?: TfFunction.FileSystemConfigPropertyOutputReference | TfFunction.FileSystemConfigProperty): any;
export declare function tfFunctionFileSystemConfigPropertyToHclTerraform(struct?: TfFunction.FileSystemConfigPropertyOutputReference | TfFunction.FileSystemConfigProperty): any;
export declare function tfFunctionImageConfigPropertyToTerraform(struct?: TfFunction.ImageConfigPropertyOutputReference | TfFunction.ImageConfigProperty): any;
export declare function tfFunctionImageConfigPropertyToHclTerraform(struct?: TfFunction.ImageConfigPropertyOutputReference | TfFunction.ImageConfigProperty): any;
export declare function tfFunctionLoggingConfigPropertyToTerraform(struct?: TfFunction.LoggingConfigPropertyOutputReference | TfFunction.LoggingConfigProperty): any;
export declare function tfFunctionLoggingConfigPropertyToHclTerraform(struct?: TfFunction.LoggingConfigPropertyOutputReference | TfFunction.LoggingConfigProperty): any;
export declare function tfFunctionSnapStartPropertyToTerraform(struct?: TfFunction.SnapStartPropertyOutputReference | TfFunction.SnapStartProperty): any;
export declare function tfFunctionSnapStartPropertyToHclTerraform(struct?: TfFunction.SnapStartPropertyOutputReference | TfFunction.SnapStartProperty): any;
export declare function tfFunctionTenancyConfigPropertyToTerraform(struct?: TfFunction.TenancyConfigPropertyOutputReference | TfFunction.TenancyConfigProperty): any;
export declare function tfFunctionTenancyConfigPropertyToHclTerraform(struct?: TfFunction.TenancyConfigPropertyOutputReference | TfFunction.TenancyConfigProperty): any;
export declare function tfFunctionTimeoutsPropertyToTerraform(struct?: TfFunction.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfFunctionTimeoutsPropertyToHclTerraform(struct?: TfFunction.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfFunctionTracingConfigPropertyToTerraform(struct?: TfFunction.TracingConfigPropertyOutputReference | TfFunction.TracingConfigProperty): any;
export declare function tfFunctionTracingConfigPropertyToHclTerraform(struct?: TfFunction.TracingConfigPropertyOutputReference | TfFunction.TracingConfigProperty): any;
export declare function tfFunctionVpcConfigPropertyToTerraform(struct?: TfFunction.VpcConfigPropertyOutputReference | TfFunction.VpcConfigProperty): any;
export declare function tfFunctionVpcConfigPropertyToHclTerraform(struct?: TfFunction.VpcConfigPropertyOutputReference | TfFunction.VpcConfigProperty): any;
export declare namespace TfFunction {
    interface LambdaManagedInstancesCapacityProviderConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#capacity_provider_arn TfFunction#capacity_provider_arn}
        */
        readonly capacityProviderArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#execution_environment_memory_gib_per_vcpu TfFunction#execution_environment_memory_gib_per_vcpu}
        */
        readonly executionEnvironmentMemoryGibPerVcpu?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#per_execution_environment_max_concurrency TfFunction#per_execution_environment_max_concurrency}
        */
        readonly perExecutionEnvironmentMaxConcurrency?: number;
    }
    class LambdaManagedInstancesCapacityProviderConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LambdaManagedInstancesCapacityProviderConfigProperty | undefined;
        set internalValue(value: LambdaManagedInstancesCapacityProviderConfigProperty | undefined);
        private _capacityProviderArn?;
        get capacityProviderArn(): string;
        set capacityProviderArn(value: string);
        get capacityProviderArnInput(): string | undefined;
        private _executionEnvironmentMemoryGibPerVcpu?;
        get executionEnvironmentMemoryGibPerVcpu(): number;
        set executionEnvironmentMemoryGibPerVcpu(value: number);
        resetExecutionEnvironmentMemoryGibPerVcpu(): void;
        get executionEnvironmentMemoryGibPerVcpuInput(): number | undefined;
        private _perExecutionEnvironmentMaxConcurrency?;
        get perExecutionEnvironmentMaxConcurrency(): number;
        set perExecutionEnvironmentMaxConcurrency(value: number);
        resetPerExecutionEnvironmentMaxConcurrency(): void;
        get perExecutionEnvironmentMaxConcurrencyInput(): number | undefined;
    }
    interface CapacityProviderConfigProperty {
        /**
        * lambda_managed_instances_capacity_provider_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#lambda_managed_instances_capacity_provider_config TfFunction#lambda_managed_instances_capacity_provider_config}
        */
        readonly lambdaManagedInstancesCapacityProviderConfig: LambdaManagedInstancesCapacityProviderConfigProperty;
    }
    class CapacityProviderConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityProviderConfigProperty | undefined;
        set internalValue(value: CapacityProviderConfigProperty | undefined);
        private _lambdaManagedInstancesCapacityProviderConfig;
        get lambdaManagedInstancesCapacityProviderConfig(): LambdaManagedInstancesCapacityProviderConfigPropertyOutputReference;
        putLambdaManagedInstancesCapacityProviderConfig(value: LambdaManagedInstancesCapacityProviderConfigProperty): void;
        get lambdaManagedInstancesCapacityProviderConfigInput(): LambdaManagedInstancesCapacityProviderConfigProperty | undefined;
    }
    interface DeadLetterConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#target_arn TfFunction#target_arn}
        */
        readonly targetArn: string;
    }
    class DeadLetterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeadLetterConfigProperty | undefined;
        set internalValue(value: DeadLetterConfigProperty | undefined);
        private _targetArn?;
        get targetArn(): string;
        set targetArn(value: string);
        get targetArnInput(): string | undefined;
    }
    interface DurableConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#execution_timeout TfFunction#execution_timeout}
        */
        readonly executionTimeout: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#retention_period TfFunction#retention_period}
        */
        readonly retentionPeriod?: number;
    }
    class DurableConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DurableConfigProperty | undefined;
        set internalValue(value: DurableConfigProperty | undefined);
        private _executionTimeout?;
        get executionTimeout(): number;
        set executionTimeout(value: number);
        get executionTimeoutInput(): number | undefined;
        private _retentionPeriod?;
        get retentionPeriod(): number;
        set retentionPeriod(value: number);
        resetRetentionPeriod(): void;
        get retentionPeriodInput(): number | undefined;
    }
    interface EnvironmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#variables TfFunction#variables}
        */
        readonly variables?: {
            [key: string]: string;
        };
    }
    class EnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnvironmentProperty | undefined;
        set internalValue(value: EnvironmentProperty | undefined);
        private _variables?;
        get variables(): {
            [key: string]: string;
        };
        set variables(value: {
            [key: string]: string;
        });
        resetVariables(): void;
        get variablesInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface EphemeralStorageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#size TfFunction#size}
        */
        readonly size?: number;
    }
    class EphemeralStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EphemeralStorageProperty | undefined;
        set internalValue(value: EphemeralStorageProperty | undefined);
        private _size?;
        get size(): number;
        set size(value: number);
        resetSize(): void;
        get sizeInput(): number | undefined;
    }
    interface FileSystemConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#arn TfFunction#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#local_mount_path TfFunction#local_mount_path}
        */
        readonly localMountPath: string;
    }
    class FileSystemConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FileSystemConfigProperty | undefined;
        set internalValue(value: FileSystemConfigProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _localMountPath?;
        get localMountPath(): string;
        set localMountPath(value: string);
        get localMountPathInput(): string | undefined;
    }
    interface ImageConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#command TfFunction#command}
        */
        readonly command?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#entry_point TfFunction#entry_point}
        */
        readonly entryPoint?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#working_directory TfFunction#working_directory}
        */
        readonly workingDirectory?: string;
    }
    class ImageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImageConfigProperty | undefined;
        set internalValue(value: ImageConfigProperty | undefined);
        private _command?;
        get command(): string[];
        set command(value: string[]);
        resetCommand(): void;
        get commandInput(): string[] | undefined;
        private _entryPoint?;
        get entryPoint(): string[];
        set entryPoint(value: string[]);
        resetEntryPoint(): void;
        get entryPointInput(): string[] | undefined;
        private _workingDirectory?;
        get workingDirectory(): string;
        set workingDirectory(value: string);
        resetWorkingDirectory(): void;
        get workingDirectoryInput(): string | undefined;
    }
    interface LoggingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#application_log_level TfFunction#application_log_level}
        */
        readonly applicationLogLevel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#log_format TfFunction#log_format}
        */
        readonly logFormat: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#log_group TfFunction#log_group}
        */
        readonly logGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#system_log_level TfFunction#system_log_level}
        */
        readonly systemLogLevel?: string;
    }
    class LoggingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingConfigProperty | undefined;
        set internalValue(value: LoggingConfigProperty | undefined);
        private _applicationLogLevel?;
        get applicationLogLevel(): string;
        set applicationLogLevel(value: string);
        resetApplicationLogLevel(): void;
        get applicationLogLevelInput(): string | undefined;
        private _logFormat?;
        get logFormat(): string;
        set logFormat(value: string);
        get logFormatInput(): string | undefined;
        private _logGroup?;
        get logGroup(): string;
        set logGroup(value: string);
        resetLogGroup(): void;
        get logGroupInput(): string | undefined;
        private _systemLogLevel?;
        get systemLogLevel(): string;
        set systemLogLevel(value: string);
        resetSystemLogLevel(): void;
        get systemLogLevelInput(): string | undefined;
    }
    interface SnapStartProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#apply_on TfFunction#apply_on}
        */
        readonly applyOn: string;
    }
    class SnapStartPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnapStartProperty | undefined;
        set internalValue(value: SnapStartProperty | undefined);
        private _applyOn?;
        get applyOn(): string;
        set applyOn(value: string);
        get applyOnInput(): string | undefined;
        get optimizationStatus(): string;
    }
    interface TenancyConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#tenant_isolation_mode TfFunction#tenant_isolation_mode}
        */
        readonly tenantIsolationMode: string;
    }
    class TenancyConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TenancyConfigProperty | undefined;
        set internalValue(value: TenancyConfigProperty | undefined);
        private _tenantIsolationMode?;
        get tenantIsolationMode(): string;
        set tenantIsolationMode(value: string);
        get tenantIsolationModeInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#create TfFunction#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#delete TfFunction#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#update TfFunction#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface TracingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#mode TfFunction#mode}
        */
        readonly mode: string;
    }
    class TracingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TracingConfigProperty | undefined;
        set internalValue(value: TracingConfigProperty | undefined);
        private _mode?;
        get mode(): string;
        set mode(value: string);
        get modeInput(): string | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#ipv6_allowed_for_dual_stack TfFunction#ipv6_allowed_for_dual_stack}
        */
        readonly ipv6AllowedForDualStack?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#security_group_ids TfFunction#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function#subnet_ids TfFunction#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        private _ipv6AllowedForDualStack?;
        get ipv6AllowedForDualStack(): boolean | cdktn.IResolvable;
        set ipv6AllowedForDualStack(value: boolean | cdktn.IResolvable);
        resetIpv6AllowedForDualStack(): void;
        get ipv6AllowedForDualStackInput(): boolean | cdktn.IResolvable | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        get vpcId(): string;
    }
}
