import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfRuntimeManagementConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_runtime_management_config#function_name TfRuntimeManagementConfig#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_runtime_management_config#qualifier TfRuntimeManagementConfig#qualifier}
    */
    readonly qualifier?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_runtime_management_config#region TfRuntimeManagementConfig#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_runtime_management_config#runtime_version_arn TfRuntimeManagementConfig#runtime_version_arn}
    */
    readonly runtimeVersionArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_runtime_management_config#update_runtime_on TfRuntimeManagementConfig#update_runtime_on}
    */
    readonly updateRuntimeOn?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_runtime_management_config aws_lambda_runtime_management_config}
*/
export declare class TfRuntimeManagementConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambda_runtime_management_config";
    /**
    * Generates CDKTN code for importing a TfRuntimeManagementConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfRuntimeManagementConfig to import
    * @param importFromId The id of the existing TfRuntimeManagementConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_runtime_management_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfRuntimeManagementConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_runtime_management_config aws_lambda_runtime_management_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfRuntimeManagementConfigConfig
    */
    constructor(scope: Construct, id: string, config: TfRuntimeManagementConfigConfig);
    get functionArn(): string;
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _qualifier?;
    get qualifier(): string;
    set qualifier(value: string);
    resetQualifier(): void;
    get qualifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _runtimeVersionArn?;
    get runtimeVersionArn(): string;
    set runtimeVersionArn(value: string);
    resetRuntimeVersionArn(): void;
    get runtimeVersionArnInput(): string | undefined;
    private _updateRuntimeOn?;
    get updateRuntimeOn(): string;
    set updateRuntimeOn(value: string);
    resetUpdateRuntimeOn(): void;
    get updateRuntimeOnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
