import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFunctionRecursionConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_recursion_config#function_name TfFunctionRecursionConfig#function_name}
    */
    readonly functionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_recursion_config#recursive_loop TfFunctionRecursionConfig#recursive_loop}
    */
    readonly recursiveLoop: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_recursion_config#region TfFunctionRecursionConfig#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_recursion_config aws_lambda_function_recursion_config}
*/
export declare class TfFunctionRecursionConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambda_function_recursion_config";
    /**
    * Generates CDKTN code for importing a TfFunctionRecursionConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFunctionRecursionConfig to import
    * @param importFromId The id of the existing TfFunctionRecursionConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_recursion_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFunctionRecursionConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambda_function_recursion_config aws_lambda_function_recursion_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFunctionRecursionConfigConfig
    */
    constructor(scope: Construct, id: string, config: TfFunctionRecursionConfigConfig);
    private _functionName?;
    get functionName(): string;
    set functionName(value: string);
    get functionNameInput(): string | undefined;
    private _recursiveLoop?;
    get recursiveLoop(): string;
    set recursiveLoop(value: string);
    get recursiveLoopInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
